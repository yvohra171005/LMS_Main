﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GDWDatabase;
using GDWInfrastructure;
using GDWRepositories;

namespace OSHALMS.Controllers
{
    public class InvoiceController : BaseController
    {
		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageMyAccount )]
        public ActionResult Index( int id )
        {
			using( var cRepository = new CustomerRepository() )
			{
				return View( cRepository.GetPurchaseDetails( GDWWebUser.CurrentUser.CustomerID.Value, id ) );
			}
        }

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageMyAccount )]
		public FileResult PDF( int id )
		{
			using( var cRepository = new CustomerRepository() )
			{
				var model = cRepository.GetPurchaseDetails( GDWWebUser.CurrentUser.CustomerID.Value, id );

				var html = RenderViewToString( ControllerContext, "Index", model );

				// convert HTML to PDF
				string homeUrl = string.Format( "http{0}://{1}{2}/", Request.IsSecureConnection ? "s" : "",
					Request.Url.DnsSafeHost, 
					Request.Url.IsDefaultPort ? "" : string.Format( ":{0}", Request.Url.Port ) );

				var queueComm = new AzureQueueCommunication();
				var fileStorage = new AzureFileStorage();
				var inputGuid = Guid.NewGuid().ToString();
				var outputGuid = Guid.NewGuid().ToString();
				var directoryName = "Invoices";

				using( var inputStream = new MemoryStream() )
				{
					using( var sw = new StreamWriter( inputStream ) )
					{
						sw.WriteLine( html );
						sw.Flush();

						inputStream.Seek( 0, SeekOrigin.Begin );

						fileStorage.UploadFile( directoryName, inputGuid, "text/html", inputStream );
					}
				}

				queueComm.GetInvoice( inputGuid, outputGuid, homeUrl, directoryName );

				while( true )
				{
					var outputStream = new MemoryStream();

					var contentType = fileStorage.DownloadFileToStream( directoryName, outputGuid, outputStream );
					if( contentType != null )
					{
						fileStorage.DeleteFile( directoryName, outputGuid );

						return File( outputStream, contentType, string.Format( "invoice {0}.pdf", id ) );
					}

					System.Threading.Thread.Sleep( 500 );
				}
			}
		}
	}
}