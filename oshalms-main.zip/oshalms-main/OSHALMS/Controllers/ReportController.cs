﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using AuthorizeNet;
using CsvHelper;
using CsvHelper.Configuration;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Report;
using GDWRepositories;
using GDWModels.Class;

namespace OSHALMS.Controllers
{
	public class ReportController : BaseController
	{
		[GDWReportAuthorize]
		public ActionResult Index()
		{
			return View();
		}

		[GDWReportAuthorize]
		public JsonResult FullReportList( ReportDataTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var rRepository = new ReportRepository() )
			{
				var results = rRepository.GetFullReportList(
					param, GDWWebUser.CurrentUser.PermissionList, GDWWebUser.CurrentUser.CustomerID, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWReportAuthorize]
		public JsonResult Get( int id )
		{
			using( var rRepository = new ReportRepository() )
			{
				return SuccessMessage( rRepository.GetReport( id ) );
			}
		}

		[GDWReportAuthorize]
		public JsonResult CustomerDropDownList( int? fixedId )
		{
			using( var cRepository = new CustomerRepository() )
			{
				return SuccessMessage( cRepository.GetReportDropDownList( fixedId ) );
			}
		}

		//[GDWReportAuthorize]
		//public JsonResult ClassDropDownList()
		//{
		//	using( var cRepo = new ClassRepository() )
		//	{
		//		return SuccessMessage( cRepo.GetDropDownList( GDWWebUser.CurrentUser.CustomerID ) );
		//	}
		//}

		[GDWReportAuthorize]
		public JsonResult AvailableClassList()
		{
			using( var cRepo = new ClassRepository() )
			{
				return SuccessMessage( cRepo.GetAvailableClassesList( GDWWebUser.CurrentUser.CustomerID ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.TakeClass )]
		public FileStreamResult MyTranscript()
		{
			using( var cRepo = new ClassRepository() )
			{
				var theData = cRepo.GetTranscript( TranscriptFilter.ForEmployee( GDWWebUser.CurrentUser.UserId, GDWWebUser.CurrentUser.CustomerID.Value ) );

				return new FileStreamResult( WriteCsvToMemory( theData, new TranscriptMap() ), "text/csv" ) { FileDownloadName = "mytranscript.csv" };
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public ActionResult Transcript()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public FileStreamResult DownloadTranscript( TranscriptFilter filter )
		{
			using( var cRepo = new ClassRepository() )
			{
				var theData = cRepo.GetTranscript( filter );

				return new FileStreamResult( WriteCsvToMemory( theData, new TranscriptMap() ), "text/csv" ) { FileDownloadName = "transcript.csv" };
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public FileStreamResult DownloadScoreSheet( TranscriptFilter filter )
		{
			using( var cRepo = new ClassRepository() )
			{
				var theData = cRepo.GetScoreSheet( filter );

				return new FileStreamResult( WriteCsvToMemory( theData, new ScoreImportDetailMap() ), "text/csv" ) { FileDownloadName = "scoresheet.csv" };
			}
		}
		
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public JsonResult SnapshotReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				filter.customerId = GDWWebUser.CurrentUser.CustomerID.Value;

				var theData = rRepo.GetSnapshotReport( filter );

				return SuccessMessage( new ReportResults<SnapshotInformation>( theData, filter.isBlank ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public FileStreamResult DownloadSnapshotReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				filter.customerId = GDWWebUser.CurrentUser.CustomerID.Value;

				var theData = rRepo.GetSnapshotReport( filter );

				return new FileStreamResult( WriteCsvToMemory( theData, new SnapshotInfoMap() ), "text/csv" ) { FileDownloadName = "snapshotreport.csv" };
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageCustomerAccount )]
		public JsonResult CustomerCreditReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				var theData = rRepo.GetCustomerCreditReport( filter );

				return SuccessMessage( new ReportResults<CustomerCreditInformation>( theData, filter.isBlank ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageCustomerAccount )]
		public FileStreamResult DownloadCustomerCreditReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				var theData = rRepo.GetCustomerCreditReport( filter );

				return new FileStreamResult( WriteCsvToMemory( theData, new CustomerCreditMap() ), "text/csv" ) { FileDownloadName = "customercreditreport.csv" };
			}
		}

		private void GetTransactionDetails( List<PurchaseReportInformation> theData )
		{
			var gate = new ReportingGateway( ConfigurationHelper.GetGatewayAPILogin(), ConfigurationHelper.GetGatewayTransactionKey(), ConfigurationHelper.GetGatewayMode() ? ServiceMode.Test : ServiceMode.Live );

			Parallel.ForEach( theData.Where( cp => !string.IsNullOrEmpty( cp.transactionNumber ) ), new ParallelOptions() { MaxDegreeOfParallelism = 10 }, ( cp =>
			{
				try
				{
					var details = gate.GetTransactionDetails( cp.transactionNumber );
					if( !string.IsNullOrEmpty( details.BatchSettlementID ) )
					{
						cp.paymentDate = details.BatchSettledOn.Date;
					}
				}
				catch
				{
				}
			} ) );
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageCustomerAccount )]
		public JsonResult PurchaseReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				var theData = rRepo.GetPurchaseReport( filter );

				GetTransactionDetails( theData );

				return SuccessMessage( new ReportResults<PurchaseReportInformation>( theData, filter.isBlank ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageCustomerAccount )]
		public FileStreamResult DownloadPurchaseReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				var theData = rRepo.GetPurchaseReport( filter );

				GetTransactionDetails( theData );

				return new FileStreamResult( WriteCsvToMemory( theData, new PurchaseReportMap() ), "text/csv" ) { FileDownloadName = "purchasereport.csv" };
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public JsonResult SystemWideClassReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				var theData = rRepo.GetSystemWideClassReport( filter );

				return SuccessMessage( new ReportResults<SystemWideClassInformation>( theData, filter.isBlank ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public FileStreamResult DownloadSystemWideClassReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				var theData = rRepo.GetSystemWideClassReport( filter );

				return new FileStreamResult( WriteCsvToMemory( theData, new SystemWideClassMap() ), "text/csv" ) { FileDownloadName = "systemwideclassreport.csv" };
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public JsonResult CustomerClassReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				var theData = rRepo.GetCustomerClassReport( filter );

				return SuccessMessage( new ReportResults<CustomerClassInformation>( theData, filter.isBlank ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public FileStreamResult DownloadCustomerClassReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				var theData = rRepo.GetCustomerClassReport( filter );

				return new FileStreamResult( WriteCsvToMemory( theData, new CustomerClassMap() ), "text/csv" ) { FileDownloadName = "customerclassreport.csv" };
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageCustomerAccount )]
		public JsonResult CustomerSummaryReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				var theData = rRepo.GetCustomerSummaryReport( filter );

				return SuccessMessage( new ReportResults<CustomerSummaryRptInformation>( theData, filter.isBlank ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageCustomerAccount )]
		public FileStreamResult DownloadCustomerSummaryReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				var theData = rRepo.GetCustomerSummaryReport( filter );

				return new FileStreamResult( WriteCsvToMemory( theData, new CustomerSummaryRptMap() ), "text/csv" ) { FileDownloadName = "customersummaryreport.csv" };
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public JsonResult COClassReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				filter.customerId = GDWWebUser.CurrentUser.CustomerID.Value;

				var theData = rRepo.GetCOClassReport( filter );

				return SuccessMessage( new ReportResults<COClassReportInformation>( theData, filter.isBlank ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public FileStreamResult DownloadCOClassReport( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				filter.customerId = GDWWebUser.CurrentUser.CustomerID.Value;

				var theData = rRepo.GetCOClassReport( filter );

				return new FileStreamResult( WriteCsvToMemory( theData, new COClassReportMap() ), "text/csv" ) { FileDownloadName = "classreport.csv" };
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public JsonResult COCreditSummary( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				filter.customerId = GDWWebUser.CurrentUser.CustomerID.Value;

				var theData = rRepo.GetCOCreditSummary( filter );

				return SuccessMessage( new ReportResults<COCreditSummaryInformation>( theData, filter.isBlank ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public FileStreamResult DownloadCOCreditSummary( ReportFilter filter )
		{
			using( var rRepo = new ReportRepository() )
			{
				filter.customerId = GDWWebUser.CurrentUser.CustomerID.Value;

				var theData = rRepo.GetCOCreditSummary( filter );

				return new FileStreamResult( WriteCsvToMemory( theData, new COCreditSummaryMap() ), "text/csv" ) { FileDownloadName = "classreport.csv" };
			}
		}
	}
}