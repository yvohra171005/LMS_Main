﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Discount;
using GDWRepositories;

namespace OSHALMS.Controllers
{
    public class DiscountController : BaseController
    {
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewDiscountCode )]
        public ActionResult Index()
        {
            return View();
        }

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewDiscountCode )]
		public JsonResult FullDiscountCodeList( DiscountTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var dRepo = new DiscountRepository() )
			{
				var results = dRepo.GetFullDiscountList( param, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddDiscountCode )]
		public JsonResult Add( DiscountInformation dcInfo )
		{
			using( var dRepo = new DiscountRepository() )
			{
				dRepo.AddDiscountCode( dcInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditDiscountCode )]
		public JsonResult Edit( DiscountInformation dcInfo )
		{
			using( var dRepo = new DiscountRepository() )
			{
				dRepo.EditDiscountCode( dcInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewDiscountCode )]
		public JsonResult Get( int id )
		{
			using( var dRepo = new DiscountRepository() )
			{
				return SuccessMessage( dRepo.GetDiscountCode( id ) );
			}
		}

		public JsonResult GetByCode( string code, GDWPurchaseTypes.PurchaseType pType )
		{
			using( var dRepo = new DiscountRepository() )
			{
				return SuccessMessage( dRepo.GetDiscountCode( code, pType, HttpContext.User.Identity.IsAuthenticated ? GDWWebUser.CurrentUser.CustomerID : null ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.DeactivateDiscountCode )]
		public JsonResult Delete( int id )
		{
			using( var dRepo = new DiscountRepository() )
			{
				dRepo.DeleteDiscountCode( id );

				return SuccessMessage();
			}
		}

		public JsonResult DiscountCodeTypeList()
		{
			var currentUser = GDWWebUser.CurrentUser;

			return SuccessMessage( new List<GDWListItem>()
			{
				new GDWListItem() { id = (int)GDWDiscountTypes.DiscountType.PercOffSomeCredits, name = currentUser.GetResourceString( "PercOffSomeCredits" ) },
				new GDWListItem() { id = (int)GDWDiscountTypes.DiscountType.PercOffCredits, name = currentUser.GetResourceString( "PercOffCredits" ) },
				new GDWListItem() { id = (int)GDWDiscountTypes.DiscountType.DollarOffCredits, name = currentUser.GetResourceString( "DollarOffCredits" ) },
				new GDWListItem() { id = (int)GDWDiscountTypes.DiscountType.PercOffSomeAccounts, name = currentUser.GetResourceString( "PercOffSomeAccounts" ) },
				new GDWListItem() { id = (int)GDWDiscountTypes.DiscountType.PercOffAccounts, name = currentUser.GetResourceString( "PercOffAccounts" ) },
				new GDWListItem() { id = (int)GDWDiscountTypes.DiscountType.DollarOffAccounts, name = currentUser.GetResourceString( "DollarOffAccounts" ) },
				new GDWListItem() { id = (int)GDWDiscountTypes.DiscountType.PercOffPurchase, name = currentUser.GetResourceString( "PercOffPurchase" ) },
				new GDWListItem() { id = (int)GDWDiscountTypes.DiscountType.DollarOffPurchase, name = currentUser.GetResourceString( "DollarOffPurchase" ) },
			} );
		}

		public JsonResult ValidCheck( int? discountCodeId, string codeText )
		{
			using( var dRepo = new DiscountRepository() )
			{
				return SuccessMessage( new { isValid = dRepo.IsValidCode( discountCodeId, codeText ) } );
			}
		}
	}
}