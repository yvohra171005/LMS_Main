﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CsvHelper;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Account;
using GDWModels.Customer;

using GDWRepositories;

namespace OSHALMS.Controllers
{
    public class EmployeeController : BaseController
	{
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public ActionResult Index()
		{
			return View();
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewEmployee )]
		public JsonResult FullEmployeeList( EmployeeTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var aRepository = new AccountRepository() )
			{
				var results = aRepository.GetFullEmployeeList(
					param, GDWWebUser.CurrentUser.UserId, GDWWebUser.CurrentUser.HasPermission( GDWPermissionTypes.Permissions.ViewInactiveEmployee ),
					out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageAssignments )]
		public JsonResult FullAssignmentList( EmployeeDetailTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var aRepository = new AccountRepository() )
			{
				var results = aRepository.GetFullEmployeeAssignmentList(
					param, out totalCount, out filteredCount, GDWWebUser.CurrentUser.PermissionList );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddEmployee )]
		public JsonResult Add( EmployeeInformation eInfo )
		{
			using( var aRepository = new AccountRepository() )
			{
				aRepository.AddUser( eInfo, false );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditEmployee )]
		public JsonResult Edit( EmployeeInformation eInfo )
		{
			using( var aRepository = new AccountRepository() )
			{
				aRepository.EditUser( eInfo, false );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageAssignments )]
		public JsonResult EditEmployeeClass( EmployeeAssignmentSummary eInfo )
		{
			using( var aRepository = new AccountRepository() )
			{
				aRepository.EditEmployeeClass( eInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewEmployee )]
		public JsonResult Get( int id )
		{
			using( var aRepository = new AccountRepository() )
			{
				return SuccessMessage( aRepository.GetEmployee( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageAssignments )]
		public JsonResult GetUserClass( int id )
		{
			using( var aRepository = new AccountRepository() )
			{
				return SuccessMessage( aRepository.GetEmployeeClass( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.DeactivateEmployee )]
		public JsonResult Delete( int id )
		{
			using( var aRepository = new AccountRepository() )
			{
				aRepository.DeleteUser( id );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult DropDownList( int customerId, string search, bool showDeleted )
		{
			using( var aRepository = new AccountRepository() )
			{
				return SuccessMessage( aRepository.GetEmployeeDropDownList( customerId, GDWWebUser.CurrentUser.UserId, search, showDeleted ) );
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult LocationDropDownList( int customerId )
		{
			using( var cRepository = new CustomerRepository() )
			{
				 return SuccessMessage( cRepository.GetLocationDropDownList( customerId, GDWWebUser.CurrentUser.UserId ) );
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult DepartmentDropDownList( int customerId )
		{
			using( var cRepository = new CustomerRepository() )
			{
				return SuccessMessage( cRepository.GetDepartmentDropDownList( customerId ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddEmployee )]
		public JsonResult UploadEmployees( string fileName )
		{
			var fileStorage = new AzureFileStorage();

			var stream = new MemoryStream();

			var contentType = fileStorage.DownloadFileToStream( "Files", fileName, stream );
			
			using( var aRepo = new AccountRepository() )
			{
				int userCount = 0;

				var errors = aRepo.ImportEmployees( stream, GDWWebUser.CurrentUser.CustomerID.Value, out userCount );

				return SuccessMessage( new { errorList = errors, userCount = userCount } );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddEmployee )]
		public FileStreamResult SampleUpload()
		{
			using( var aRepo = new AccountRepository() )
			{
				var theData = aRepo.GetBlankUploadHeaders( GDWWebUser.CurrentUser.CustomerID.Value );

				using( var memoryStream = new MemoryStream() )
				{
					using( var streamWriter = new StreamWriter( memoryStream ) )
					{
						using( var csvWriter = new CsvWriter( streamWriter ) )
						{
							foreach( var header in theData )
							{
								csvWriter.WriteField( header );
							}
							csvWriter.NextRecord();
							streamWriter.Flush();

							var result = memoryStream.ToArray();

							return new FileStreamResult( new MemoryStream( result ), "text/csv" ) { FileDownloadName = "employeelist.csv" };

						}
					}
				}
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult PendingSetupEmailsCount( )
		{
			using( var aRepository = new AccountRepository() )
			{
			    var count = aRepository.GetPendingSetupEmailsCount( GDWWebUser.CurrentUser.CustomerID.Value, GDWWebUser.CurrentUser.UserId );

			    return SuccessMessage( count );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddEmployee )]
		public JsonResult SendPendingSetupEmails( )
		{
			using( var aRepository = new AccountRepository() )
			{
			    var count = aRepository.SendPendingSetupEmails( GDWWebUser.CurrentUser.CustomerID.Value, GDWWebUser.CurrentUser.UserId, null );

			    return SuccessMessage( count );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddEmployee )]
		public JsonResult SendPendingSetupEmail( int id )
		{
			using( var aRepository = new AccountRepository() )
			{
			    var count = aRepository.SendPendingSetupEmails( GDWWebUser.CurrentUser.CustomerID.Value, GDWWebUser.CurrentUser.UserId, new [] { id } );

			    return SuccessMessage( count );
			}
		}

				
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployeeDocument, GDWPermissionTypes.Permissions.ViewOwnEmployeeDocument, GDWPermissionTypes.Permissions.ViewEmployeeNote )]
		public ActionResult EmployeeDocuments()
		{
			return View();
		}
		
        #region Documents
		
        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewEmployeeDocument, GDWPermissionTypes.Permissions.ViewOwnEmployeeDocument )]
        public JsonResult FullDocumentList( EmployeeDocumentTableParams param )
        {
	        int totalCount = 0, filteredCount = 0;

	        using( var aRepository = new AccountRepository() )
	        {
		        var results = aRepository.GetFullDocumentList(
			        param, GDWWebUser.CurrentUser, out totalCount, out filteredCount );

		        return SuccessMessage( new
		        {
			        sEcho = param.sEcho,
			        iTotalRecords = totalCount,
			        iTotalDisplayRecords = filteredCount,
			        aaData = results
		        } );
	        }
        }

        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewEmployeeDocument, GDWPermissionTypes.Permissions.ViewOwnEmployeeDocument )]
        public ActionResult GetDocumentContent( int id, int userId = 0 )
        {
	        DocumentInformation docInfo;
	        using( var aRepository = new AccountRepository() )
	        {
		        try
		        {
			        docInfo = aRepository.GetDocument( GDWWebUser.CurrentUser, id, userId );
		        }
		        catch (GDWException)
		        {
			        return HttpNotFound();
		        }
	        }

	        var fileStorage = new AzureFileStorage();
	        var stream = new MemoryStream();
	        var contentType = fileStorage.DownloadFileToStream( "Files", docInfo.fileName, stream );

	        return File( stream, contentType, docInfo.originalFileName );
        }

		
        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageEmployeeDocument )]
        public JsonResult AddDocument( DocumentInformation pInfo )
        {
	        using( var aRepository = new AccountRepository() )
	        {
		        aRepository.AddDocument( GDWWebUser.CurrentUser, pInfo );

		        return SuccessMessage();
	        }
        }

        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageEmployeeDocument )]
        public JsonResult EditDocument( DocumentInformation pInfo )
        {
	        using( var aRepository = new AccountRepository() )
	        {
		        aRepository.EditDocument( GDWWebUser.CurrentUser, pInfo );

		        return SuccessMessage();
	        }
        }
		
        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewEmployeeDocument )]
        public JsonResult GetDocument( int id, int userId = 0 )
        {
	        using( var aRepository = new AccountRepository() )
	        {
		        return SuccessMessage( aRepository.GetDocument( GDWWebUser.CurrentUser, id, userId ) );
	        }
        }

        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageEmployeeDocument )]
        public JsonResult DeleteDocument( int id, int userId = 0 )
        {
	        using( var aRepository = new AccountRepository() )
	        {
		        aRepository.DeleteDocument(GDWWebUser.CurrentUser, id, userId);

		        return SuccessMessage();
	        }
        }

        #endregion
		
        #region Notes
		
        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewEmployeeNote )]
        public JsonResult FullNoteList( EmployeeNoteTableParams param )
        {
	        int totalCount = 0, filteredCount = 0;

	        using( var aRepository = new AccountRepository() )
	        {
		        var results = aRepository.GetFullNoteList(
			        param, GDWWebUser.CurrentUser, out totalCount, out filteredCount );

		        return SuccessMessage( new
		        {
			        sEcho = param.sEcho,
			        iTotalRecords = totalCount,
			        iTotalDisplayRecords = filteredCount,
			        aaData = results
		        } );
	        }
        }

        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageEmployeeNote )]
        public JsonResult AddNote( NoteInformation pInfo )
        {
	        using( var aRepository = new AccountRepository() )
	        {
		        aRepository.AddNote( GDWWebUser.CurrentUser, pInfo );

		        return SuccessMessage();
	        }
        }

        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewEmployeeNote )]
        public JsonResult GetNote( int id, int userId )
        {
	        using( var aRepository = new AccountRepository() )
	        {
		        return SuccessMessage( aRepository.GetNote( GDWWebUser.CurrentUser, id, userId ) );
	        }
        }

        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageEmployeeNote )]
        public JsonResult DeleteNote( int id, int userId )
        {
	        using( var aRepository = new AccountRepository() )
	        {
		        aRepository.DeleteNote(GDWWebUser.CurrentUser, id, userId);

		        return SuccessMessage();
	        }
        }

        #endregion

	}
}