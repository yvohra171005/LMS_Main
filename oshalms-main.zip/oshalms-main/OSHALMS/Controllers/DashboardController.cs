﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Dashboard;
using GDWRepositories;

namespace OSHALMS.Controllers
{
    public class DashboardController : BaseController
    {
		[GDWAuthorize]
        public ActionResult Index()
        {
            return View();
        }

		[GDWAuthorize]
		public ActionResult TestWidget( int id )
		{
			ViewBag.WidgetID = id;

			return View();
		}

		[GDWAuthorize]
		public ActionResult SafetyContact()
		{
			return View();
		}

		[GDWAuthorizeJSON]
		public JsonResult MySafetyDirectors()
		{
			using( var cRepo = new CustomerRepository() )
			{
				return SuccessMessage( cRepo.GetMySafetyDirectors( GDWWebUser.CurrentUser.UserId ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.TakeClass )]
		public ActionResult CurrentClassStatus()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public ActionResult CurrentClassStatusFarm()
		{
			ViewBag.CallbackURL = "MyFarmCurrentClassStatus";
			ViewBag.ControllerName = "Farm";

			return View( viewName: "CurrentClassStatus" );
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public ActionResult CurrentClassStatusSystem()
		{
			ViewBag.CallbackURL = "SystemCurrentClassStatus";
			ViewBag.ControllerName = "System";

			return View( viewName: "CurrentClassStatus" );
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.TakeClass )]
		public JsonResult MyCurrentClassStatus()
		{
			using( var cRepo = new ClassRepository() )
			{
				return SuccessMessage( cRepo.GetCurrentClassStatus( userId: GDWWebUser.CurrentUser.UserId ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public JsonResult MyFarmCurrentClassStatus()
		{
			using( var cRepo = new ClassRepository() )
			{
				return SuccessMessage( cRepo.GetCurrentClassStatus( userId: GDWWebUser.CurrentUser.HasPermission( GDWPermissionTypes.Permissions.ManageAllLocations ) ? (int?)null : GDWWebUser.CurrentUser.UserId,
					customerId: GDWWebUser.CurrentUser.CustomerID ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public JsonResult SystemCurrentClassStatus()
		{
			using( var cRepo = new ClassRepository() )
			{
				return SuccessMessage( cRepo.GetCurrentClassStatus() );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageCreditsAndEmployees )]
		public ActionResult CreditReport()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public ActionResult CreditReportSystem()
		{
			ViewBag.CallbackURL = "SystemCreditReport";
			ViewBag.ControllerName = "System";

			return View( viewName: "CreditReport" );
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.TakeClass )]
		public ActionResult ClassPassingWidget()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public ActionResult ClassPassingWidgetFarm()
		{
			ViewBag.CallbackURL = "MyFarmClassPassingWidget";
			ViewBag.ControllerName = "Farm";

			return View( viewName: "ClassPassingWidget" );
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public ActionResult ClassPassingWidgetSystem()
		{
			ViewBag.CallbackURL = "SystemClassPassingWidget";
			ViewBag.ControllerName = "System";

			return View( viewName: "ClassPassingWidget" );
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.TakeClass )]
		public JsonResult MyClassPassingWidget()
		{
			using( var cRepo = new ClassRepository() )
			{
				return SuccessMessage( cRepo.GetClassPassingWidget( userId: GDWWebUser.CurrentUser.UserId ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewEmployee )]
		public JsonResult MyFarmClassPassingWidget()
		{
			using( var cRepo = new ClassRepository() )
			{
				return SuccessMessage( cRepo.GetClassPassingWidget( userId: GDWWebUser.CurrentUser.HasPermission( GDWPermissionTypes.Permissions.ManageAllLocations ) ? (int?)null : GDWWebUser.CurrentUser.UserId,
					customerId: GDWWebUser.CurrentUser.CustomerID ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public JsonResult SystemClassPassingWidget()
		{
			using( var cRepo = new ClassRepository() )
			{
				return SuccessMessage( cRepo.GetClassPassingWidget() );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageCreditsAndEmployees )]
		public JsonResult MyCreditReport()
		{
			using( var cRepo = new CustomerRepository() )
			{
				return SuccessMessage( cRepo.GetCreditReport( GDWWebUser.CurrentUser.CustomerID ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public JsonResult SystemCreditReport()
		{
			using( var cRepo = new CustomerRepository() )
			{
				return SuccessMessage( cRepo.GetCreditReport() );
			}
		}
		
		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public ActionResult SubscriberAnalytics()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public JsonResult SystemSubscriberAnalytics()
		{
			using( var cRepo = new CustomerRepository() )
			{
				return SuccessMessage( cRepo.GetSubscriberAnalytics() );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public ActionResult MostPopularCourse()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public JsonResult MostPopularCourseData()
		{
			using( var cRepo = new ClassRepository() )
			{
				return SuccessMessage( cRepo.GetMostPopularCourses() );
			}
		}

		[GDWAuthorize]
		public ActionResult Calendar()
		{
			return View();
		}

		[GDWAuthorize]
		public JsonResult MyCalendarData( bool onlyMe, DateTime startDate, DateTime endDate )
		{
			using( var aRepo = new AccountRepository() )
			{
				return SuccessMessage( aRepo.GetCalendarData( GDWWebUser.CurrentUser.UserId, onlyMe, GDWWebUser.CurrentUser.PermissionList, startDate, endDate ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageFAQs )]
		public ActionResult UnansweredFAQs()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageFAQs )]
		public JsonResult UnansweredFAQData()
		{
			using( var cRepo = new ClassRepository() )
			{
				return SuccessMessage( cRepo.GetUnansweredFAQData( GDWWebUser.CurrentUser.CustomerID.Value ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewWidgets )]
		public ActionResult Widgets()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewWidgets )]
		public JsonResult FullWidgetList( WidgetTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var dRepository = new DashboardRepository() )
			{
				var results = dRepository.GetWidgetList(
					param, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult MyWidgets()
		{
			if( GDWWebUser.CurrentUser.IsImpersonating )
			{
				return SuccessMessage( new List<WidgetDefinition>() );
			}

			using( var dRepo = new DashboardRepository() )
			{
				return SuccessMessage( dRepo.GetMyWidgets( GDWWebUser.CurrentUser.UserId ) );
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult AddWidget( int widgetId )
		{
			if( GDWWebUser.CurrentUser.IsImpersonating )
			{
				return SuccessMessage( new List<WidgetDefinition>() );
			}

			using( var dRepo = new DashboardRepository() )
			{
				dRepo.AddMyWidget( GDWWebUser.CurrentUser.UserId, widgetId );

				return SuccessMessage( dRepo.GetMyWidgets( GDWWebUser.CurrentUser.UserId ) );
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult UpdateWidgets( IEnumerable<WidgetDefinition> widgets )
		{
			if( GDWWebUser.CurrentUser.IsImpersonating )
			{
				return SuccessMessage();
			}

			using( var dRepo = new DashboardRepository() )
			{
				dRepo.UpdateMyWidgets( GDWWebUser.CurrentUser.UserId, widgets.ToList() );

				return SuccessMessage();
			}

		}

		[GDWAuthorizeJSON]
		public JsonResult DeleteWidget( int widgetId )
		{
			if( GDWWebUser.CurrentUser.IsImpersonating )
			{
				return SuccessMessage( new List<WidgetDefinition>() );
			}

			using( var dRepo = new DashboardRepository() )
			{
				dRepo.DeleteMyWidget( GDWWebUser.CurrentUser.UserId, widgetId );

				return SuccessMessage( dRepo.GetMyWidgets( GDWWebUser.CurrentUser.UserId ) );
			}
		}
	}
}