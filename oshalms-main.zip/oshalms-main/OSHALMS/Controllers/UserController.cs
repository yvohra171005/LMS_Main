﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Account;
using GDWRepositories;

namespace OSHALMS.Controllers
{
    public class UserController : BaseController
    {
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewUser )]
        public ActionResult Index()
        {
            return View();
        }

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewUser )]
		public JsonResult FullUserList( UserTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var aRepository = new AccountRepository() )
			{
				var results = aRepository.GetFullUserList(
					param, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddUser )]
		public JsonResult Add( UserInformation uInfo )
		{
			using( var aRepository = new AccountRepository() )
			{
				aRepository.AddUser( uInfo, true );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditUser )]
		public JsonResult Edit( UserInformation uInfo )
		{
			using( var aRepository = new AccountRepository() )
			{
				aRepository.EditUser( uInfo, true );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewUser )]
		public JsonResult Get( int id )
		{
			using( var aRepository = new AccountRepository() )
			{
				return SuccessMessage( aRepository.GetUser( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.DeactivateUser )]
		public JsonResult Delete( int id )
		{
			using( var aRepository = new AccountRepository() )
			{
				aRepository.DeleteUser( id );

				return SuccessMessage();
			}
		}

		public JsonResult VerifyUniqueEmailAddress( string email )
		{
			using( var aRepository = new AccountRepository() )
			{
				if( !aRepository.DoesEmailAddressExist( email ) )
				{
					return SuccessMessage();
				}
				throw new GDWException( "EmailAddressIsNotUnique" );
			}
		}
	}
}