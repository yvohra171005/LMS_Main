﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using GDWInfrastructure;
using GDWModels.Account;
using GDWRepositories;

namespace OSHALMS.Controllers
{
    public class AccountController : BaseController
    {
		[HttpGet]
        public ActionResult Login()
        {
            return View();
        }

		[HttpPost]
		public JsonResult Login( string username, string password, bool eulaAcknowledged )
		{
			using( var aRepo = new AccountRepository() )
			{
				bool eulaPassed = false;
				if( aRepo.ValidateUser( username, password, eulaAcknowledged ) )
				{
					eulaPassed = true;
					FormsAuthentication.SetAuthCookie( username, false );
				}

				// validateuser will exception out if the login failed
				return SuccessMessage( new { eulaPassed = eulaPassed } );
			}
		}

		public ActionResult DoLogout()
		{
			FormsAuthentication.SignOut();
			Session.Abandon();

			return View();
		}

		[GDWAuthorize]
		public JsonResult Logout()
		{
			GDWWebUser.CurrentUser.ClearImpersonate();
			FormsAuthentication.SignOut();
			Session.Abandon();

			return SuccessMessage();
		}

		[GDWAuthorizeJSON]
		public JsonResult Get()
		{
			using( var aRepo = new AccountRepository() )
			{
				return SuccessMessage( aRepo.GetUser( GDWWebUser.CurrentUser.UserId ) );
			}
		}

		[GDWAuthorize]
		public ActionResult MyProfile()
		{
			return View();
		}

		[GDWAuthorize]
		public ActionResult MyNotifications()
		{
			return View();
		}

		[GDWAuthorizeJSON]
		public JsonResult UpdateProfile( UserInformation uInfo )
		{
			if( uInfo.userId != GDWWebUser.CurrentUser.UserId )
			{
				throw new GDWException( "ErrorUserNotFound" );
			}

			using( var aRepo = new AccountRepository() )
			{
				aRepo.EditProfile( uInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult ResetPassword()
		{
			using( var aRepo = new AccountRepository() )
			{
				aRepo.ForgotPassword( GDWWebUser.CurrentUser.Identity.Name );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult Notifications()
		{
			using( var aRepo = new AccountRepository() )
			{
				return SuccessMessage( aRepo.GetMyNotifications( GDWWebUser.CurrentUser.UserId ) );
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult TestAlertMe()
		{
			using( var aRepo = new AccountRepository() )
			{
				aRepo.GenerateTestAlert( GDWWebUser.CurrentUser.UserId );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult ClearNotifications( int id )
		{
			using( var aRepo = new AccountRepository() )
			{
				aRepo.ClearMyNotifications( GDWWebUser.CurrentUser.UserId, id );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult MyNotificationList( long startDate, long endDate )
		{
			using( var aRepo = new AccountRepository() )
			{
				return SuccessMessage( aRepo.GetAllMyNotifications( GDWWebUser.CurrentUser.UserId, startDate, endDate ) );
			}
		}

		public ActionResult NewPassword( Guid id )
		{
			using( var aRepo = new AccountRepository() )
			{
				return View( aRepo.GetResetPasswordInfo( id ) );
			}
		}

		[HttpPost]
		public JsonResult NewPassword( ResetPasswordInfo info )
		{
			using( var aRepo = new AccountRepository() )
			{
				aRepo.ResetPassword( info );

				return SuccessMessage();
			}
		}

		[HttpPost]
		public JsonResult ForgotPassword( string userName )
		{
			using( var aRepo = new AccountRepository() )
			{
				aRepo.ForgotPassword( userName );

				return SuccessMessage();
			}
		}
	}
}