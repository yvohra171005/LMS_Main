﻿using System.IO;
using System.Web.Mvc;

using GDWDatabase;

using GDWInfrastructure;

using GDWModels.Configuration;

using GDWRepositories;

namespace OSHALMS.Controllers
{
    public class ConfigController : BaseController
    {
        [GDWAuthorize(GDWPermissionTypes.Permissions.ManageConfiguration)]
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult EULA()
        {
            using (var cRepository = new ConfigurationRepository())
            {
                var dbConfig = cRepository.GetConfiguration();
                if (dbConfig == null || string.IsNullOrEmpty(dbConfig.eulaFileName))
                {
                    // The old location (which probably doesn't work any longer).
                    return Redirect("https://gooddayswork.desk.com/customer/portal/articles/2050428-combined-terms-of-use-and-privacy-policy");
                }

                var fileStream = new MemoryStream();
                var contentType = new AzureFileStorage().DownloadFileToStream("Files", dbConfig.eulaFileName, fileStream);
                if (contentType != null)
                    return File(fileStream, contentType/*, dbConfig.originalEULAFileName*/);

                return HttpNotFound();
            }
        }

        public ActionResult Help()
        {
            using (var cRepository = new ConfigurationRepository())
            {
                var dbConfig = cRepository.GetConfiguration();
                if (dbConfig == null || string.IsNullOrEmpty(dbConfig.helpFileName))
                {
                    // The old location (which probably doesn't work any longer).
                    return Redirect("https://gooddayswork.desk.com/");
                }

                var fileStream = new MemoryStream();
                var contentType = new AzureFileStorage().DownloadFileToStream("Files", dbConfig.helpFileName, fileStream);
                if (contentType != null)
                    return File(fileStream, contentType/*, dbConfig.originalHelpFileName*/);

                return HttpNotFound();
            }
        }

        [GDWAuthorize(GDWPermissionTypes.Permissions.ManageConfiguration)]
        public JsonResult Get()
        {
            using (var cRepository = new ConfigurationRepository())
            {
                return SuccessMessage(cRepository.GetConfiguration());
            }
        }

        [GDWAuthorize(GDWPermissionTypes.Permissions.ManageConfiguration)]
        public JsonResult Edit(ConfigInformation cInfo)
        {
            using (var cRepository = new ConfigurationRepository())
            {
                cRepository.EditConfiguration(cInfo);

                return SuccessMessage();
            }
        }
    }
}