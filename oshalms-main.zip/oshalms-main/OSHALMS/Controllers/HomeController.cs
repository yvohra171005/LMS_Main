﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GDWInfrastructure;

namespace OSHALMS.Controllers
{
    public class HomeController : Controller
    {
		[GDWAuthorize]
        public ActionResult Index()
        {
            return View();
        }

		[GDWAuthorize]
		public ActionResult Temp()
		{
			return View();
		}

		[GDWAuthorize]
		public ActionResult RedirectToHomePage()
		{
			return RedirectToAction( "Index" );
		}
	}
}