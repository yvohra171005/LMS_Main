﻿using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Video;
using GDWRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OSHALMS.Controllers
{
    public class VideoController : BaseController
    {
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewVideo )]
		public ActionResult Index()
		{
			return View();
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewVideo )]
		public JsonResult FullVideoList( VideoTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var dRepo = new VideoRepository() )
			{
				var results = dRepo.GetFullVideoList( param, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddVideo )]
		public JsonResult Add( VideoInformation dcInfo )
		{
			using( var dRepo = new VideoRepository() )
			{
				dRepo.AddVideo( dcInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditVideo )]
		public JsonResult Edit( VideoInformation dcInfo )
		{
			using( var dRepo = new VideoRepository() )
			{
				dRepo.EditVideo( dcInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewVideo )]
		public JsonResult Get( int id )
		{
			using( var dRepo = new VideoRepository() )
			{
				return SuccessMessage( dRepo.GetVideo( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.DeactivateVideo )]
		public JsonResult Delete( int id )
		{
			using( var dRepo = new VideoRepository() )
			{
				dRepo.DeleteVideo( id );

				return SuccessMessage();
			}
		}
	}
}