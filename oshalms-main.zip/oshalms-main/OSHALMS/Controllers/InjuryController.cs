﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Injury;
using GDWRepositories;

namespace OSHALMS.Controllers
{
    public class InjuryController : BaseController
    {
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewInjury )]
        public ActionResult Index()
        {
            return View();
        }

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewInjury )]
		public JsonResult FullInjuryList( InjuryTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var iRepository = new InjuryRepository() )
			{
				var results = iRepository.GetFullInjuryList(
					param, GDWWebUser.CurrentUser.UserId, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddInjury )]
		public JsonResult Add( InjuryInformation iInfo )
		{
			using( var iRepo = new InjuryRepository() )
			{
				iRepo.AddInjuryCase( iInfo, GDWWebUser.CurrentUser.CustomerID.Value, GDWWebUser.CurrentUser.UserId );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewInjury )]
		public JsonResult Get( int id )
		{
			using( var iRepo = new InjuryRepository() )
			{
				return SuccessMessage( iRepo.GetInjuryCase( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditInjury )]
		public JsonResult AddVersion( InjuryInformation iInfo )
		{
			using( var iRepo = new InjuryRepository() )
			{
				iRepo.AddInjuryCaseVersion( iInfo, GDWWebUser.CurrentUser.UserId );

				return SuccessMessage();
			}
		}

		public JsonResult YearList()
		{
			using( var iRepo = new InjuryRepository() )
			{
				return SuccessMessage( iRepo.GetInjuryYearList( GDWWebUser.CurrentUser.CustomerID.Value ) );
			}
		}

		public static IEnumerable<GDWListItem> GetClassificationList()
		{
			return new List<GDWListItem>()
			{
				new GDWListItem() { id = (int)InjuryConstants.CaseClassificationType.Death, name = InjuryConstants.CaseClassificationType.Death.ToDisplayString() },
				new GDWListItem() { id = (int)InjuryConstants.CaseClassificationType.DaysAwayFromWork, name = InjuryConstants.CaseClassificationType.DaysAwayFromWork.ToDisplayString() },
				new GDWListItem() { id = (int)InjuryConstants.CaseClassificationType.JobTransfer, name = InjuryConstants.CaseClassificationType.JobTransfer.ToDisplayString() },
				new GDWListItem() { id = (int)InjuryConstants.CaseClassificationType.Other, name = InjuryConstants.CaseClassificationType.Other.ToDisplayString() },
			};
		}

		public static IEnumerable<GDWListItem> GetTypeOfIllnessList()
		{
			return new List<GDWListItem>()
			{
				new GDWListItem() { id = (int)InjuryConstants.InjuryIllnessType.Injury, name = InjuryConstants.InjuryIllnessType.Injury.ToDisplayString() },
				new GDWListItem() { id = (int)InjuryConstants.InjuryIllnessType.SkinDisorder, name = InjuryConstants.InjuryIllnessType.SkinDisorder.ToDisplayString() },
				new GDWListItem() { id = (int)InjuryConstants.InjuryIllnessType.Respiratory, name = InjuryConstants.InjuryIllnessType.Respiratory.ToDisplayString() },
				new GDWListItem() { id = (int)InjuryConstants.InjuryIllnessType.Poisoning, name = InjuryConstants.InjuryIllnessType.Poisoning.ToDisplayString() },
				new GDWListItem() { id = (int)InjuryConstants.InjuryIllnessType.HearingLoss, name = InjuryConstants.InjuryIllnessType.HearingLoss.ToDisplayString() },
				new GDWListItem() { id = (int)InjuryConstants.InjuryIllnessType.Other, name = InjuryConstants.InjuryIllnessType.Other.ToDisplayString() },
			};
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewInjury )]
		public ActionResult Form301( int id )
		{
			using( var iRepository = new InjuryRepository() )
			{
				var model = iRepository.GetInjuryCase( id );

				return View( new List<InjuryInformation> () { model } );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewInjury )]
		public FileResult PDF301( int id )
		{
			using( var iRepository = new InjuryRepository() )
			{
				var model = iRepository.GetInjuryCase( id );

				var html = RenderViewToString( ControllerContext, "Form301", new List<InjuryInformation>() { model } );

				// convert HTML to PDF
				string homeUrl = string.Format( "http{0}://{1}{2}/", Request.IsSecureConnection ? "s" : "",
					Request.Url.DnsSafeHost,
					Request.Url.IsDefaultPort ? "" : string.Format( ":{0}", Request.Url.Port ) );

				var queueComm = new AzureQueueCommunication();
				var fileStorage = new AzureFileStorage();
				var inputGuid = Guid.NewGuid().ToString();
				var outputGuid = Guid.NewGuid().ToString();
				var directoryName = "OSHAForms";

				using( var inputStream = new MemoryStream() )
				{
					using( var sw = new StreamWriter( inputStream ) )
					{
						sw.WriteLine( html );
						sw.Flush();

						inputStream.Seek( 0, SeekOrigin.Begin );

						fileStorage.UploadFile( directoryName, inputGuid, "text/html", inputStream );
					}
				}

				queueComm.GetInvoice( inputGuid, outputGuid, homeUrl, directoryName, "Landscape" );

				while( true )
				{
					var outputStream = new MemoryStream();

					var contentType = fileStorage.DownloadFileToStream( directoryName, outputGuid, outputStream );
					if( contentType != null )
					{
						fileStorage.DeleteFile( directoryName, outputGuid );

						return File( outputStream, contentType, "form301.pdf" );
					}

					System.Threading.Thread.Sleep( 500 );
				}
			}
		}

		[Route( "~/Injury/Form300/{year:int=0}/{locationId:int=0}/{showPrivacyForms:bool=false}/{activeState='active'}" )]
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewInjury )]
		public ActionResult Form300( int year, int locationId, bool showPrivacyForms, string activeState )
		{
			using( var iRepository = new InjuryRepository() )
			{
				var model = iRepository.GetInjuryCases( GDWWebUser.CurrentUser.CustomerID.Value, year, locationId, showPrivacyForms, activeState );

				return View( model );
			}
		}

		[Route( "~/Injury/PDF300/{year:int=0}/{locationId:int=0}/{showPrivacyForms:bool=false}/{activeState='active'}" )]
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewInjury )]
		public FileResult PDF300( int year, int locationId, bool showPrivacyForms, string activeState )
		{
			using( var iRepository = new InjuryRepository() )
			{
				var model = iRepository.GetInjuryCases( GDWWebUser.CurrentUser.CustomerID.Value, year, locationId, showPrivacyForms, activeState );

				var html = RenderViewToString( ControllerContext, "Form300", model );

				// convert HTML to PDF
				string homeUrl = string.Format( "http{0}://{1}{2}/", Request.IsSecureConnection ? "s" : "",
					Request.Url.DnsSafeHost,
					Request.Url.IsDefaultPort ? "" : string.Format( ":{0}", Request.Url.Port ) );

				var queueComm = new AzureQueueCommunication();
				var fileStorage = new AzureFileStorage();
				var inputGuid = Guid.NewGuid().ToString();
				var outputGuid = Guid.NewGuid().ToString();
				var directoryName = "OSHAForms";

				using( var inputStream = new MemoryStream() )
				{
					using( var sw = new StreamWriter( inputStream ) )
					{
						sw.WriteLine( html );
						sw.Flush();

						inputStream.Seek( 0, SeekOrigin.Begin );

						fileStorage.UploadFile( directoryName, inputGuid, "text/html", inputStream );
					}
				}

				queueComm.GetInvoice( inputGuid, outputGuid, homeUrl, directoryName, "Landscape", true );

				while( true )
				{
					var outputStream = new MemoryStream();

					var contentType = fileStorage.DownloadFileToStream( directoryName, outputGuid, outputStream );
					if( contentType != null )
					{
						fileStorage.DeleteFile( directoryName, outputGuid );

						return File( outputStream, contentType, "form300.pdf" );
					}

					System.Threading.Thread.Sleep( 500 );
				}
			}
		}

		[Route( "~/Injury/Form300A/{year:int=0}/{locationId:int=0}/{activeState='active'}" )]
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewInjury )]
		public ActionResult Form300A( int year, int locationId, string activeState )
		{
			using( var iRepository = new InjuryRepository() )
			{
				var model = iRepository.GetInjuryCases( GDWWebUser.CurrentUser.CustomerID.Value, year, locationId, false, activeState );

				return View( model );
			}
		}

		[Route( "~/Injury/PDF300A/{year:int=0}/{locationId:int=0}/{activeState='active'}" )]
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewInjury )]
		public FileResult PDF300A( int year, int locationId, string activeState )
		{
			using( var iRepository = new InjuryRepository() )
			{
				var model = iRepository.GetInjuryCases( GDWWebUser.CurrentUser.CustomerID.Value, year, locationId, false, activeState );

				var html = RenderViewToString( ControllerContext, "Form300A", model );

				// convert HTML to PDF
				string homeUrl = string.Format( "http{0}://{1}{2}/", Request.IsSecureConnection ? "s" : "",
					Request.Url.DnsSafeHost,
					Request.Url.IsDefaultPort ? "" : string.Format( ":{0}", Request.Url.Port ) );

				var queueComm = new AzureQueueCommunication();
				var fileStorage = new AzureFileStorage();
				var inputGuid = Guid.NewGuid().ToString();
				var outputGuid = Guid.NewGuid().ToString();
				var directoryName = "OSHAForms";

				using( var inputStream = new MemoryStream() )
				{
					using( var sw = new StreamWriter( inputStream ) )
					{
						sw.WriteLine( html );
						sw.Flush();

						inputStream.Seek( 0, SeekOrigin.Begin );

						fileStorage.UploadFile( directoryName, inputGuid, "text/html", inputStream );
					}
				}

				queueComm.GetInvoice( inputGuid, outputGuid, homeUrl, directoryName, "Landscape", true );

				while( true )
				{
					var outputStream = new MemoryStream();

					var contentType = fileStorage.DownloadFileToStream( directoryName, outputGuid, outputStream );
					if( contentType != null )
					{
						fileStorage.DeleteFile( directoryName, outputGuid );

						return File( outputStream, contentType, "form300a.pdf" );
					}

					System.Threading.Thread.Sleep( 500 );
				}
			}
		}

		[Route( "~/Injury/Form301Multi/{startDate}/{endDate}/{locationId:int=0}/{activeState='active'}" )]
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewInjury )]
		public ActionResult Form301Multi( string startDate, string endDate, int locationId, string activeState )
		{
			using( var iRepository = new InjuryRepository() )
			{
				var model = iRepository.GetInjuryCase( startDate, endDate, locationId, GDWWebUser.CurrentUser.CustomerID.Value, activeState );

				return View( "Form301", model );
			}
		}

		[Route( "~/Injury/PDF301Multi/{startDate}/{endDate}/{locationId:int=0}/{activeState='active'}" )]
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewInjury )]
		public FileResult PDF301Multi( string startDate, string endDate, int locationId, string activeState )
		{
			using( var iRepository = new InjuryRepository() )
			{
				var model = iRepository.GetInjuryCase( startDate, endDate, locationId, GDWWebUser.CurrentUser.CustomerID.Value, activeState );

				var html = RenderViewToString( ControllerContext, "Form301", model );

				// convert HTML to PDF
				string homeUrl = string.Format( "http{0}://{1}{2}/", Request.IsSecureConnection ? "s" : "",
					Request.Url.DnsSafeHost,
					Request.Url.IsDefaultPort ? "" : string.Format( ":{0}", Request.Url.Port ) );

				var queueComm = new AzureQueueCommunication();
				var fileStorage = new AzureFileStorage();
				var inputGuid = Guid.NewGuid().ToString();
				var outputGuid = Guid.NewGuid().ToString();
				var directoryName = "OSHAForms";

				using( var inputStream = new MemoryStream() )
				{
					using( var sw = new StreamWriter( inputStream ) )
					{
						sw.WriteLine( html );
						sw.Flush();

						inputStream.Seek( 0, SeekOrigin.Begin );

						fileStorage.UploadFile( directoryName, inputGuid, "text/html", inputStream );
					}
				}

				queueComm.GetInvoice( inputGuid, outputGuid, homeUrl, directoryName, "Landscape" );

				while( true )
				{
					var outputStream = new MemoryStream();

					var contentType = fileStorage.DownloadFileToStream( directoryName, outputGuid, outputStream );
					if( contentType != null )
					{
						fileStorage.DeleteFile( directoryName, outputGuid );

						return File( outputStream, contentType, "form301s.pdf" );
					}

					System.Threading.Thread.Sleep( 500 );
				}
			}
		}
	}
}