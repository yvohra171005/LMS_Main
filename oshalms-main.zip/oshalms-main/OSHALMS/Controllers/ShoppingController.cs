﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AuthorizeNet;
using AuthorizeNet.APICore;
using GDWInfrastructure;
using GDWModels.Customer;
using GDWRepositories;
using System.Net;

namespace OSHALMS.Controllers
{
    public class ShoppingController : BaseController
    {
		[Route( "~/Cart/{userAccounts:int=0}/{credits:int=0}" )]
		[Route( "~/Shopping/{userAccounts:int=0}/{credits:int=0}" )]
		public ActionResult Index( int userAccounts, int credits )
        {
			ViewBag.UserAccounts = userAccounts;
			ViewBag.Credits = credits;

            return View();
        }

		public ActionResult Calculator()
		{
			return View();
		}

		public JsonResult GetShoppingList()
		{
			using( var cRepo = new ClassRepository() )
			{
				return SuccessMessage( cRepo.GetShoppingList() );
			}
		}

		public JsonResult GetConfig()
		{
			using( var cRepo = new ConfigurationRepository() )
			{
				return SuccessMessage( cRepo.GetShoppingConfig() );
			}
		}

		public JsonResult GetCreditTiers()
		{
			using( var cRepo = new CustomerRepository() )
			{
				return SuccessMessage( cRepo.GetTierList() );
			}
		}

		public JsonResult CompleteOrder( NewAccountInformation aInfo )
		{
			//ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

			var gate = new Gateway( ConfigurationHelper.GetGatewayAPILogin(), ConfigurationHelper.GetGatewayTransactionKey(), ConfigurationHelper.GetGatewayMode() );
			string transactionId = null;

			if( aInfo.payment.method == GDWDatabase.GDWPaymentMethods.PaymentMethod.CreditCard.ToString() )
			{
				var request = new PriorAuthCaptureRequest( aInfo.totalAmount + aInfo.salesTax, aInfo.payment.transactionNumber );

				var response = gate.Send( request );

				if( !response.Approved )
				{
					throw new GDWEnglishException( "Your Credit Card was declined.  Please try again." );
				}

				transactionId = response.TransactionID;
			}
			else if( aInfo.payment.method == GDWDatabase.GDWPaymentMethods.PaymentMethod.eCheck.ToString() )
			{
				var request = new EcheckPriorAuthCaptureRequest( aInfo.payment.transactionNumber, aInfo.totalAmount + aInfo.salesTax );

				var response = gate.Send( request );

				if( !response.Approved )
				{
					throw new GDWEnglishException( "Your eCheck was declined.  Please try again." );
				}

				transactionId = response.TransactionID;
			}

			try
			{
				using( var cRepository = new CustomerRepository() )
				{
					string invoiceNumber = "";

					var customerId = cRepository.CreateNewAccount( aInfo, transactionId, out invoiceNumber );

					var cGate = new CustomerGateway( ConfigurationHelper.GetGatewayAPILogin(), ConfigurationHelper.GetGatewayTransactionKey(), ConfigurationHelper.GetGatewayMode() ? ServiceMode.Test : ServiceMode.Live );

					var customerProfile = cGate.CreateCustomer( "", "", customerId.ToString() );

					if( aInfo.payment.method == GDWDatabase.GDWPaymentMethods.PaymentMethod.CreditCard.ToString() && aInfo.payment.saveCreditCard )
					{
						var ccProfileID = cGate.AddCreditCard( customerProfile.ProfileID, aInfo.payment.ccNumber, aInfo.payment.ccMonth, aInfo.payment.ccYear, aInfo.payment.ccCVV, new Address()
						{
							First = aInfo.accountInfo.firstName,
							Last = aInfo.accountInfo.lastName,
							Street = aInfo.accountInfo.companyAddress1,
							City = aInfo.accountInfo.companyCity,
							State = aInfo.accountInfo.companyState,
							Zip = aInfo.accountInfo.companyZipCode
						} );

						cRepository.SetCustomerCCProfile( customerId, customerProfile.ProfileID, ccProfileID, aInfo.payment.maskedCCNumber, GDWDatabase.GDWPaymentMethods.PaymentMethod.CreditCard );
					}
					else if( aInfo.payment.method == GDWDatabase.GDWPaymentMethods.PaymentMethod.eCheck.ToString() && aInfo.payment.saveECheck )
					{
						var bankAccountType = (BankAccountType)Enum.Parse( typeof( BankAccountType ), aInfo.payment.eAccountType );

						var ccProfileID = cGate.AddECheckBankAccount( customerProfile.ProfileID, bankAccountType, aInfo.payment.eRoutingNumber, aInfo.payment.eAccountNumber, aInfo.payment.eNameOnAccount );

						cRepository.SetCustomerCCProfile( customerId, customerProfile.ProfileID, ccProfileID, aInfo.payment.maskedECheckNumber, GDWDatabase.GDWPaymentMethods.PaymentMethod.eCheck );
					}

					PaymentController.FinalizeSalesTax( customerId, invoiceNumber, new Avalara.Address()
					{
						Line1 = aInfo.accountInfo.companyAddress1,
						Line2 = aInfo.accountInfo.companyAddress2,
						City = aInfo.accountInfo.companyCity,
						Region = aInfo.accountInfo.companyState,
						PostalCode = aInfo.accountInfo.companyZipCode
					}, aInfo.totalAmount );

					try
					{
						var invoiceDetail = cRepository.GetPurchaseDetails( customerId, int.Parse( invoiceNumber ) );

						var html = RenderViewToString( ControllerContext, "Index", invoiceDetail, "Invoice" );

						// convert HTML to PDF
						string homeUrl = string.Format( "http{0}://{1}{2}/", Request.IsSecureConnection ? "s" : "",
							Request.Url.DnsSafeHost,
							Request.Url.IsDefaultPort ? "" : string.Format( ":{0}", Request.Url.Port ) );

						var queueComm = new AzureQueueCommunication();
						var fileStorage = new AzureFileStorage();
						var inputGuid = Guid.NewGuid().ToString();
						var outputGuid = Guid.NewGuid().ToString();
						var directoryName = "Invoices";

						using( var inputStream = new MemoryStream() )
						{
							using( var sw = new StreamWriter( inputStream ) )
							{
								sw.WriteLine( html );
								sw.Flush();

								inputStream.Seek( 0, SeekOrigin.Begin );

								fileStorage.UploadFile( directoryName, inputGuid, "text/html", inputStream );
							}
						}

						queueComm.GetInvoice( inputGuid, outputGuid, homeUrl, directoryName, emailAddresses: aInfo.accountInfo.emailAddress );
					}
					catch
					{
						// don't let doing this fail the purchase
					}

					return SuccessMessage();
				}
			}
			catch
			{
				if( aInfo.payment.method == GDWDatabase.GDWPaymentMethods.PaymentMethod.CreditCard.ToString() )
				{
					var request = new VoidRequest( aInfo.payment.transactionNumber );

					gate.Send( request );
				}
				else if( aInfo.payment.method == GDWDatabase.GDWPaymentMethods.PaymentMethod.eCheck.ToString() )
				{
					var request = new EcheckVoidRequest( aInfo.payment.transactionNumber );

					gate.Send( request );
				}

				throw;
			}
		}
	}
}