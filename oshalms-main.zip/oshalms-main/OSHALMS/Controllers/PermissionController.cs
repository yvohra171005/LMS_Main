﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Account;
using GDWRepositories;

namespace OSHALMS.Controllers
{
    public class PermissionController : BaseController
    {
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewPermissionGroup )]
        public ActionResult Index()
        {
            return View();
        }

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewCustomerPermissionGroup )]
		public ActionResult Customer()
		{
			return View();
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewPermissionGroup, GDWPermissionTypes.Permissions.ViewCustomerPermissionGroup )]
		public JsonResult FullPermissionGroupList( PermissionTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var aRepository = new AccountRepository() )
			{
				var results = aRepository.GetFullPermissionList(
					param, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddPermissionGroup, GDWPermissionTypes.Permissions.AddCustomerPermissionGroup )]
		public JsonResult Add( PermissionGroupInformation pInfo )
		{
			using( var aRepository = new AccountRepository() )
			{
				aRepository.AddPermissionGroup( pInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditPermissionGroup, GDWPermissionTypes.Permissions.EditCustomerPermissionGroup )]
		public JsonResult Edit( PermissionGroupInformation pInfo )
		{
			using( var aRepository = new AccountRepository() )
			{
				aRepository.EditPermissionGroup( pInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewPermissionGroup, GDWPermissionTypes.Permissions.ViewCustomerPermissionGroup )]
		public JsonResult Get( int id )
		{
			using( var aRepository = new AccountRepository() )
			{
				return SuccessMessage( aRepository.GetPermissionGroup( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.DeactivatePermissionGroup, GDWPermissionTypes.Permissions.DeactivateCustomerPermissionGroup )]
		public JsonResult Delete( int id )
		{
			using( var aRepository = new AccountRepository() )
			{
				aRepository.DeletePermissionGroup( id );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult PermissionList()
		{
			using( var aRepository = new AccountRepository() )
			{
				return SuccessMessage( aRepository.GetPermissionList() );
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult DropDownList( bool bAccount, int? customerId )
		{
			using( var aRepository = new AccountRepository() )
			{
				return SuccessMessage( aRepository.GetGroupDropDownList( bAccount, customerId ) );
			}
		}
	}
}