﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AuthorizeNet;
using GDWDatabase;
using GDWInfrastructure;
using GDWModels.Customer;
using GDWRepositories;
using OSHALMS.Avalara;
using System.Net;

namespace OSHALMS.Controllers
{
    public class PaymentController : BaseController
    {
		public JsonResult AuthorizeCard( PaymentInformation pInfo, decimal totalCost )
		{
			string expDate = new DateTime( pInfo.ccYear, pInfo.ccMonth, 1 ).ToString( "MMyy" );
			
			var request = new AuthorizationRequest( pInfo.ccNumber, expDate, totalCost, "Good Day's Work", false );

			request.AddCardCode( pInfo.ccCVV );

			//ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

			var gate = new Gateway( ConfigurationHelper.GetGatewayAPILogin(), ConfigurationHelper.GetGatewayTransactionKey(), ConfigurationHelper.GetGatewayMode() );

			var response = gate.Send( request );

			if( response.Approved )
			{
				return SuccessMessage( new { transNumber = response.TransactionID, authCode = response.AuthorizationCode, maskedCCNumber = response.CardNumber } );
			}

			throw new GDWEnglishException( "Credit Card information is invalid." );
		}

		public JsonResult VoidCardTransaction( string transactionNumber )
		{
			var request = new VoidRequest( transactionNumber );

			//ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

			var gate = new Gateway( ConfigurationHelper.GetGatewayAPILogin(), ConfigurationHelper.GetGatewayTransactionKey(), ConfigurationHelper.GetGatewayMode() );

			gate.Send( request );

			return SuccessMessage();
		}

		public JsonResult VoidECheckTransaction( string transactionNumber )
		{
			var request = new EcheckVoidRequest( transactionNumber );

			//ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

			var gate = new Gateway( ConfigurationHelper.GetGatewayAPILogin(), ConfigurationHelper.GetGatewayTransactionKey(), ConfigurationHelper.GetGatewayMode() );

			gate.Send( request );

			return SuccessMessage();
		}

		public JsonResult AuthorizeECheck( PaymentInformation pInfo, decimal totalCost )
		{
			var bankAccountType = (BankAccountType)Enum.Parse( typeof(BankAccountType), pInfo.eAccountType );
			var transType = EcheckType.WEB;
			if( bankAccountType == BankAccountType.BusinessChecking )
				transType = EcheckType.CCD;

			var request = new EcheckAuthorizationRequest( transType, totalCost, pInfo.eRoutingNumber, pInfo.eAccountNumber, bankAccountType, 
				"", pInfo.eNameOnAccount, "" );

			//ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

			var gate = new Gateway( ConfigurationHelper.GetGatewayAPILogin(), ConfigurationHelper.GetGatewayTransactionKey(), ConfigurationHelper.GetGatewayMode() );

			var response = gate.Send( request );

			if( response.Approved )
			{
				return SuccessMessage( new { transNumber = response.TransactionID, authCode = response.AuthorizationCode, maskedECheckNumber = response.CardNumber } );
			}

			throw new GDWEnglishException( "eCheck information is invalid." );
		}

		public static void FinalizeSalesTax( int customerId, string invoiceNumber, OSHALMS.Avalara.Address shipTo, decimal totalCost )
		{
			return;

			// Header Level Elements
			// Required Header Level Elements
			string accountNumber = ConfigurationManager.AppSettings["AvaTax:AccountNumber"];
			string licenseKey = ConfigurationManager.AppSettings["AvaTax:LicenseKey"];
			string serviceURL = ConfigurationManager.AppSettings["AvaTax:ServiceUrl"];

			TaxSvc taxSvc = new TaxSvc( accountNumber, licenseKey, serviceURL );

			GetTaxRequest getTaxRequest = new GetTaxRequest();

			// Document Level Elements
			// Required Request Parameters
			getTaxRequest.CustomerCode = customerId.ToString();
			getTaxRequest.DocDate = DateTime.Now.ToString( "yyyy-MM-dd" );

			// Best Practice Request Parameters
			getTaxRequest.Client = "lms.gooddayswork.ag";
			getTaxRequest.DocCode = invoiceNumber;
			getTaxRequest.DetailLevel = DetailLevel.Tax;
			getTaxRequest.Commit = true;
			getTaxRequest.DocType = DocType.SalesInvoice;

			// Situational Request Parameters
			getTaxRequest.CurrencyCode = "USD";

			// Address Data
			var shipFrom = new OSHALMS.Avalara.Address();
			shipFrom.AddressCode = "shipFrom";
			shipFrom.Line1 = "9229 Delegates Row";
			shipFrom.City = "Indianapolis";
			shipFrom.Region = "IN";

			shipTo.AddressCode = "shipTo";

			OSHALMS.Avalara.Address[] addresses = { shipFrom, shipTo };
			getTaxRequest.Addresses = addresses;

			// Line Data
			Line line1 = new Line();
			line1.LineNo = "01";
			line1.Qty = 1;
			line1.Amount = totalCost;
			line1.OriginCode = "shipFrom";
			line1.DestinationCode = "shipTo";

			Line[] lines = { line1 };
			getTaxRequest.Lines = lines;

			GetTaxResult getTaxResult = taxSvc.GetTax( getTaxRequest );

			// Print results
			if( getTaxResult.ResultCode.Equals( SeverityLevel.Success ) )
			{
				return;
			}

			throw new GDWEnglishException( "Unable to calculate Sales Tax" );
		}

		public JsonResult CalculateSalesTax( NewAccountSummary aInfo, int? customerId, decimal totalCost )
		{
			return SuccessMessage( new { totalTax = 0.0 } );

			// Header Level Elements
			// Required Header Level Elements
			string accountNumber = ConfigurationManager.AppSettings["AvaTax:AccountNumber"];
			string licenseKey = ConfigurationManager.AppSettings["AvaTax:LicenseKey"];
			string serviceURL = ConfigurationManager.AppSettings["AvaTax:ServiceUrl"];

			TaxSvc taxSvc = new TaxSvc( accountNumber, licenseKey, serviceURL );

			GetTaxRequest getTaxRequest = new GetTaxRequest();

			// Document Level Elements
			// Required Request Parameters
			getTaxRequest.CustomerCode = "123456";
			getTaxRequest.DocDate = DateTime.Now.ToString( "yyyy-MM-dd" );
			
			// Best Practice Request Parameters
			getTaxRequest.Client = "lms.gooddayswork.ag";
			getTaxRequest.DocCode = "PreCalc001";
			getTaxRequest.DetailLevel = DetailLevel.Tax;
			getTaxRequest.Commit = false;
			getTaxRequest.DocType = DocType.SalesOrder;

			// Situational Request Parameters
			getTaxRequest.CurrencyCode = "USD";

			// Address Data
			var shipFrom = new OSHALMS.Avalara.Address();
			shipFrom.AddressCode = "shipFrom";
			shipFrom.Line1 = "9229 Delegates Row";
			shipFrom.City = "Indianapolis";
			shipFrom.Region = "IN";

			var shipTo = new OSHALMS.Avalara.Address();
			shipTo.AddressCode = "shipTo";
			if( customerId.HasValue )
			{
				using( var cRepo = new CustomerRepository() )
				{
					var cInfo = cRepo.GetCustomer( customerId.Value );

					shipTo.Line1 = cInfo.address1;
					shipTo.Line2 = cInfo.address2;
					shipTo.City = cInfo.city;
					shipTo.Region = cInfo.state;
					shipTo.PostalCode = cInfo.zipCode;
				}
			}
			else
			{
				shipTo.Line1 = aInfo.companyAddress1;
				shipTo.Line2 = aInfo.companyAddress2;
				shipTo.City = aInfo.companyCity;
				shipTo.Region = aInfo.companyState;
				shipTo.PostalCode = aInfo.companyZipCode;
			}

			OSHALMS.Avalara.Address[] addresses = { shipFrom, shipTo };
			getTaxRequest.Addresses = addresses;

			// Line Data
			Line line1 = new Line();
			line1.LineNo = "01";
			line1.Qty = 1;
			line1.Amount = totalCost;
			line1.OriginCode = "shipFrom";
			line1.DestinationCode = "shipTo";

			Line[] lines = { line1 };
			getTaxRequest.Lines = lines;

			GetTaxResult getTaxResult = taxSvc.GetTax( getTaxRequest );

			// Print results
			if( getTaxResult.ResultCode.Equals( SeverityLevel.Success ) )
			{
				return SuccessMessage( new { totalTax = getTaxResult.TotalTax } );
			}

			throw new GDWEnglishException( "Unable to calculate Sales Tax" );
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageMyAccount )]
		public JsonResult AddCreditCard( PaymentInformation pInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				var profileId = cRepository.GetCustomerProfileID( GDWWebUser.CurrentUser.CustomerID.Value );

				var cInfo = cRepository.GetCustomer( GDWWebUser.CurrentUser.CustomerID.Value );

				//ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

				var cGate = new CustomerGateway( ConfigurationHelper.GetGatewayAPILogin(), ConfigurationHelper.GetGatewayTransactionKey(), ConfigurationHelper.GetGatewayMode() ? ServiceMode.Test : ServiceMode.Live );

				if( string.IsNullOrEmpty( profileId ) )
				{
					var customerProfile = cGate.CreateCustomer( "", "", GDWWebUser.CurrentUser.CustomerID.Value.ToString() );

					profileId = customerProfile.ProfileID;
				}

				var ccProfileID = cGate.AddCreditCard( profileId, pInfo.ccNumber, pInfo.ccMonth, pInfo.ccYear, pInfo.ccCVV, new AuthorizeNet.Address()
				{
					First = cInfo.firstName,
					Last = cInfo.lastName,
					Street = cInfo.address1,
					City = cInfo.city,
					State = cInfo.state,
					Zip = cInfo.zipCode
				} );

				cRepository.SetCustomerCCProfile( GDWWebUser.CurrentUser.CustomerID.Value, profileId, ccProfileID, "XXXX" + pInfo.ccNumber.Substring( pInfo.ccNumber.Length - 4, 4 ), GDWPaymentMethods.PaymentMethod.CreditCard );

			}

			return SuccessMessage();
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageMyAccount )]
		public JsonResult AddECheck( PaymentInformation pInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				var profileId = cRepository.GetCustomerProfileID( GDWWebUser.CurrentUser.CustomerID.Value );

				var cGate = new CustomerGateway( ConfigurationHelper.GetGatewayAPILogin(), ConfigurationHelper.GetGatewayTransactionKey(), ConfigurationHelper.GetGatewayMode() ? ServiceMode.Test : ServiceMode.Live );

				if( string.IsNullOrEmpty( profileId ) )
				{
					var customerProfile = cGate.CreateCustomer( "", "", GDWWebUser.CurrentUser.CustomerID.Value.ToString() );

					profileId = customerProfile.ProfileID;
				}

				var bankAccountType = (BankAccountType)Enum.Parse( typeof( BankAccountType ), pInfo.eAccountType );

				var ccProfileID = cGate.AddECheckBankAccount( profileId, bankAccountType, pInfo.eRoutingNumber, pInfo.eAccountNumber, pInfo.eNameOnAccount );

				cRepository.SetCustomerCCProfile( GDWWebUser.CurrentUser.CustomerID.Value, profileId, ccProfileID, "XXXX" + pInfo.eAccountNumber.Substring( pInfo.eAccountNumber.Length - 4, 4 ), GDWPaymentMethods.PaymentMethod.eCheck );

			}

			return SuccessMessage();
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageMyAccount )]
		public JsonResult DeleteMethod( string id )
		{
			using( var cRepository = new CustomerRepository() )
			{
				var profileId = cRepository.GetCustomerProfileID( GDWWebUser.CurrentUser.CustomerID.Value );

				var cGate = new CustomerGateway( ConfigurationHelper.GetGatewayAPILogin(), ConfigurationHelper.GetGatewayTransactionKey(), ConfigurationHelper.GetGatewayMode() ? ServiceMode.Test : ServiceMode.Live );

				cGate.DeletePaymentProfile( profileId, id );

				cRepository.DeleteCustomerPaymentProfile( GDWWebUser.CurrentUser.CustomerID.Value, id );

			}

			return SuccessMessage();
		}
	}
}