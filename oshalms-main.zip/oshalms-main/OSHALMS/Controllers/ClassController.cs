﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Class;
using GDWRepositories;

using OSHALMS.Models;

namespace OSHALMS.Controllers
{
    public class ClassController : BaseController
    {
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewClass )]
		public ActionResult Index()
        {
            return View();
        }

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewClass )]
		public ActionResult Versions( int id )
		{
			using( var cRepository = new ClassRepository() )
			{
				return View( cRepository.GetClass( id ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.TakeClass )]
		public ActionResult MyClasses()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.TakeClass )]
		public ActionResult ViewClass()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewScreeningRoom )]
		public ActionResult ScreeningRoom()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewScreeningRoom )]
		public ActionResult ScreenClass()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewLibrary )]
		public ActionResult Library()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewScreeningRoom )]
		[Route( "Class/QuestionsPDF/{id}/{includeAnswers}/{languageId}" )]
		public FileResult QuestionsPDF( int id, bool includeAnswers, int languageId, int? altLanguageId = null )
		{
			using( var cRepository = new ClassRepository() )
			{
			    var model = new PrintQuestionsModel
			        {
			            CurrentVersion = cRepository.GetScreenClassInfo( id, languageId, GDWWebUser.CurrentUser.CustomerID.Value )
			        };
			    if ( includeAnswers )
			        model.CurrentVersion.name += " - Answer Key";
                var fileName = model.CurrentVersion.name.SanitizeForFileName();
                if ( altLanguageId.HasValue && model.CurrentVersion.languageName != null )
			        model.CurrentVersion.name += " (" + model.CurrentVersion.languageName + ")";
				if( !string.IsNullOrEmpty( model.CurrentVersion.customerLogoFileName ) )
				{
					model.CurrentVersion.customerLogoFileName = FileController.GetSASFileName( "Files", model.CurrentVersion.customerLogoFileName );
				}
                if( !string.IsNullOrEmpty( model.CurrentVersion.thirdPartyLogoFileName ) )
				{
					model.CurrentVersion.thirdPartyLogoFileName = FileController.GetSASFileName( "Files", model.CurrentVersion.thirdPartyLogoFileName );
				}

				foreach( var q in model.CurrentVersion.questions )
				{
					if( !string.IsNullOrEmpty( q.imageFileName ) )
					{
						q.imageFileName = FileController.GetSASFileName( "Files", q.imageFileName );
					}
					if( !includeAnswers )
					{
						foreach( var a in q.answers )
						{
							a.isChosen = false;
						}
					}
				}

			    if ( altLanguageId.HasValue )
			    {
			        model.AlternateVersion = cRepository.GetScreenClassInfo( id, altLanguageId.Value, GDWWebUser.CurrentUser.CustomerID.Value );
			        if ( includeAnswers )
			            model.AlternateVersion.name += " - Answer Key";
                    if ( model.AlternateVersion.languageName != null )
			            model.AlternateVersion.name += " (" + model.AlternateVersion.languageName + ")";

			        foreach ( var q in model.AlternateVersion.questions )
			        {
			            if ( !string.IsNullOrEmpty( q.imageFileName ) )
			            {
			                q.imageFileName = FileController.GetSASFileName( "Files", q.imageFileName );
			            }
			            if ( !includeAnswers )
			            {
			                foreach ( var a in q.answers )
			                {
			                    a.isChosen = false;
			                }
			            }
			        }
			    }

			    var html = RenderViewToString( ControllerContext, "Questions", model );

				// convert HTML to PDF
				string homeUrl = string.Format( "http{0}://{1}{2}/", Request.IsSecureConnection ? "s" : "",
					Request.Url.DnsSafeHost,
					Request.Url.IsDefaultPort ? "" : string.Format( ":{0}", Request.Url.Port ) );

				var queueComm = new AzureQueueCommunication();
				var fileStorage = new AzureFileStorage();
				var inputGuid = Guid.NewGuid().ToString();
				var outputGuid = Guid.NewGuid().ToString();
				var directoryName = "Invoices";

				using( var inputStream = new MemoryStream() )
				{
					using( var sw = new StreamWriter( inputStream ) )
					{
						sw.WriteLine( html );
						sw.Flush();

						inputStream.Seek( 0, SeekOrigin.Begin );

						fileStorage.UploadFile( directoryName, inputGuid, "text/html", inputStream );
					}
				}

				queueComm.GetInvoice( inputGuid, outputGuid, homeUrl, directoryName, includeFooter: true, topPadding: 36f );

				while( true )
				{
					var outputStream = new MemoryStream();

					var contentType = fileStorage.DownloadFileToStream( directoryName, outputGuid, outputStream );
					if( contentType != null )
					{
						fileStorage.DeleteFile( directoryName, outputGuid );

					    if ( !includeAnswers )
					        fileName = fileName + " - Questions";
						return File( outputStream, contentType, fileName + ".pdf" );
					}

					System.Threading.Thread.Sleep( 500 );
				}
			}
		}

		#region Screening Room

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewLibrary )]
		public JsonResult FullLibraryList( LibraryTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var cRepository = new ClassRepository() )
			{
				var results = cRepository.GetFullClassList(
					param, GDWWebUser.CurrentUser.UserId, GDWWebUser.CurrentUser.CustomerID.Value, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewScreeningRoom )]
		public JsonResult FullScreeningRoomList( ScreeningRoomTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var cRepository = new ClassRepository() )
			{
				var results = cRepository.GetFullClassList(
					param, GDWWebUser.CurrentUser.CustomerID.Value, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}
                
		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewScreeningRoom )]
		public JsonResult GetScreeningRoomVersions( int id )
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.GetAvailableClassVersions( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewScreeningRoom )]
		public JsonResult ScreenAClass( int id, int languageId )
		{
			using( var cRepository = new ClassRepository() )
			{
				var cInfo = cRepository.GetScreenClassInfo( id, languageId, GDWWebUser.CurrentUser.CustomerID.Value );
				
				cRepository.AuditScreenClass( id, GDWWebUser.CurrentUser.UserId );

				return SuccessMessage( cInfo );
			}
		}

		#endregion

		#region Classes

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewClass )]
		public JsonResult FullClassList( ClassTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var cRepository = new ClassRepository() )
			{
				var results = cRepository.GetFullClassList(
					param, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddClass )]
		public JsonResult Add( ClassInformation uInfo )
		{
			using( var cRepository = new ClassRepository() )
			{
				cRepository.AddClass( uInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditClass )]
		public JsonResult Edit( ClassInformation uInfo )
		{
			using( var cRepository = new ClassRepository() )
			{
				cRepository.EditClass( uInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewClass )]
		public JsonResult Get( int id )
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.GetClass( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.DeactivateClass )]
		public JsonResult Delete( int id )
		{
			using( var cRepository = new ClassRepository() )
			{
				cRepository.DeleteClass( id );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult VideoDropDownList()
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.GetVideoDropDownList() );
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult CategoryDropDownList()
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.GetCategoryDropDownList() );
			}
		}
        
		[GDWAuthorizeJSON]
		public JsonResult CustomerCategoryDropDownList()
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.GetCustomerCategoryDropDownList( GDWWebUser.CurrentUser.CustomerID ) );
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult DropDownList( string category = null )
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.GetDropDownList( GDWWebUser.CurrentUser.CustomerID, category ) );
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult AvailableClassList( string category = null )
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.GetAvailableClassesList( GDWWebUser.CurrentUser.CustomerID, category ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageFAQs )]
		public ActionResult FAQs()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageFAQs )]
		public JsonResult GetFAQItem( int id )
		{
			using( var cRepo = new ClassRepository() )
			{
				return SuccessMessage( cRepo.GetFAQItem( id ) );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageFAQs )]
		public JsonResult AddFAQItem( FAQInformation fInfo )
		{
			using( var cRepo = new ClassRepository() )
			{
				cRepo.AddFAQItem( fInfo, GDWWebUser.CurrentUser.UserId );

				return SuccessMessage();
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageFAQs )]
		public JsonResult EditFAQItem( FAQInformation fInfo )
		{
			using( var cRepo = new ClassRepository() )
			{
				cRepo.EditFAQItem( fInfo, GDWWebUser.CurrentUser.UserId );

				return SuccessMessage(  );
			}
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageFAQs )]
		public JsonResult FullFAQItemList( FAQTableParams param )
		{
			using( var cRepo = new ClassRepository() )
			{
				int totalCount = 0, filteredCount = 0;

				using( var cRepository = new ClassRepository() )
				{
					var results = cRepository.GetFullFAQItemList(
						param, GDWWebUser.CurrentUser.CustomerID.Value, out totalCount, out filteredCount );

					return SuccessMessage( new
					{
						sEcho = param.sEcho,
						iTotalRecords = totalCount,
						iTotalDisplayRecords = filteredCount,
						aaData = results
					} );
				}

			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageAssignments )]
		public JsonResult Reclaim( int employeeId, int? userClassId )
		{
			using( var cRepository = new ClassRepository() )
			{
				cRepository.ReclaimClassCredits( employeeId, userClassId, GDWWebUser.CurrentUser.UserId, GDWWebUser.CurrentUser.PermissionList );

				return SuccessMessage();
			}
		}

		#endregion

		#region Class Versions

		[GDWAuthorizeJSON(GDWPermissionTypes.Permissions.ViewClassVersion)]
		public JsonResult ScormProviders()
		{
			return SuccessMessage(GDWScormProviders.ScormProviders.GetScormProviders()
				.Select(p => new { id = p.ID, name = p.Name, classHandleLabel = p.ClassHandleLabel }).ToList());
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewClassVersion )]
		public JsonResult FullClassVersionList( ClassVersionTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			if( !param.classId.HasValue )
			{
				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = new List<ClassVersionSummary>()
				} );
			}

			using( var cRepository = new ClassRepository() )
			{
				var results = cRepository.GetFullClassVersionList(
					param, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddClassVersion )]
		public JsonResult AddVersion( ClassVersionInformation uInfo )
		{
			using( var cRepository = new ClassRepository() )
			{
				cRepository.AddClassVersion( uInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditClassVersion )]
		public JsonResult EditVersion( ClassVersionInformation uInfo )
		{
			using( var cRepository = new ClassRepository() )
			{
				cRepository.EditClassVersion( uInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewClassVersion )]
		public JsonResult GetVersion( int id )
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.GetClassVersion( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.DeactivateClassVersion )]
		public JsonResult DeleteVersion( int id )
		{
			using( var cRepository = new ClassRepository() )
			{
				cRepository.DeleteClassVersion( id );

				return SuccessMessage();
			}
		}
		
		#endregion

		#region My Classes

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.TakeClass )]
		public JsonResult MyClassList()
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.GetClassListForUser( GDWWebUser.CurrentUser.UserId ) );
			}
		}
        
		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.TakeClass )]
		public FileResult MyCertificatePDF( int id )
		{
			using( var cRepository = new ClassRepository() )
			{
			    var model = cRepository.GetClassCertificateInformationForUser( id, GDWWebUser.CurrentUser.UserId );
				if( !string.IsNullOrEmpty( model.CustomerLogoFileName ) )
				{
					model.CustomerLogoFileName = FileController.GetSASFileName( "Files", model.CustomerLogoFileName );
				}
				if( !string.IsNullOrEmpty( model.AuthorizedSignatureFileName ) )
				{
					model.AuthorizedSignatureFileName = FileController.GetSASFileName( "Files", model.AuthorizedSignatureFileName );
				}
                if (!string.IsNullOrEmpty(model.GDWLogoFileName))
                {
                    model.GDWLogoFileName = FileController.GetSASFileName("Files", model.GDWLogoFileName);
                }
                if (!string.IsNullOrEmpty(model.GDWAuthorizedSignatureFileName))
                {
                    model.GDWAuthorizedSignatureFileName = FileController.GetSASFileName("Files", model.GDWAuthorizedSignatureFileName);
                }

                var fileName = "Class Certificate";

			    var html = RenderViewToString( ControllerContext, "ClassCertificate", model );

				// convert HTML to PDF
				string homeUrl = string.Format( "http{0}://{1}{2}/", Request.IsSecureConnection ? "s" : "",
					Request.Url.DnsSafeHost,
					Request.Url.IsDefaultPort ? "" : string.Format( ":{0}", Request.Url.Port ) );

				var queueComm = new AzureQueueCommunication();
				var fileStorage = new AzureFileStorage();
				var inputGuid = Guid.NewGuid().ToString();
				var outputGuid = Guid.NewGuid().ToString();
				var directoryName = "Invoices";

				using( var inputStream = new MemoryStream() )
				{
					using( var sw = new StreamWriter( inputStream ) )
					{
						sw.WriteLine( html );
						sw.Flush();

						inputStream.Seek( 0, SeekOrigin.Begin );

						fileStorage.UploadFile( directoryName, inputGuid, "text/html", inputStream );
					}
				}

				queueComm.GetInvoice( inputGuid, outputGuid, homeUrl, directoryName, "Landscape" );

				while( true )
				{
					var outputStream = new MemoryStream();

					var contentType = fileStorage.DownloadFileToStream( directoryName, outputGuid, outputStream );
					if( contentType != null )
					{
						fileStorage.DeleteFile( directoryName, outputGuid );
						return File( outputStream, contentType, fileName + ".pdf" );
					}

					System.Threading.Thread.Sleep( 500 );
				}
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.TakeClass )]
		public JsonResult ViewMyClass( int id )
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.GetUserClassInfo( id ) );
			}
		}

		[GDWAuthorizeJSON(GDWPermissionTypes.Permissions.TakeClass)]
		public JsonResult IsScormClassComplete( int id )
        {
			using (var cRepository = new ClassRepository())
			{
				return SuccessMessage( new { complete = cRepository.IsScormClassComplete( id ) } );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.TakeClass )]
		public JsonResult VideoComplete( int id )
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.MarkClassVideoComplete( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.TakeClass )]
		public JsonResult VideoStateChange( int userClassId, string newState, double timeIndex )
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.MarkVideoStateChange( userClassId, newState, timeIndex ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.TakeClass )]
		public JsonResult StartTest( int id )
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.MarkClassTestStarted( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.TakeClass )]
		public JsonResult SubmitQuestion( MyClassQuestion question )
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.SubmitTestQuestion( question ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.TakeClass )]
		public JsonResult SubmitTest( int id )
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.SubmitTestResults( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.TakeClass )]
		public JsonResult ReTakeTest( int id )
		{
			using( var cRepository = new ClassRepository() )
			{
				return SuccessMessage( cRepository.ReTakeTest( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.TakeClass )]
		public JsonResult SubmitFAQ( int userClassId, string questionText )
		{
			using( var cRepository = new ClassRepository() )
			{
				cRepository.SubmitFAQ( userClassId, questionText );

				return SuccessMessage();
			}
		}

		#endregion
	}
}