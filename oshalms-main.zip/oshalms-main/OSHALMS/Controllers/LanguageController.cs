﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Account;
using GDWRepositories;

namespace OSHALMS.Controllers
{
    public class LanguageController : BaseController
    {
		[GDWAuthorizeJSON]
		public JsonResult DropDownList()
		{
			using( var aRepository = new AccountRepository() )
			{
				return SuccessMessage( aRepository.GetLanguageDropDownList() );
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult DropDownListForClass( int? classId, int? versionId )
		{
			if( !classId.HasValue )
			{
				return DropDownList();
			}

			using( var aRepository = new AccountRepository() )
			{
				return SuccessMessage( aRepository.GetLanguageDropDownList( classId.Value, versionId ) );
			}
		}
		
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewLanguage )]
		public ActionResult Index()
		{
			return View();
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewLanguage )]
		public JsonResult FullLanguageList( LanguageTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var aRepository = new AccountRepository() )
			{
				var results = aRepository.GetFullLanguageList(
					param, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddLanguage )]
		public JsonResult Add( LanguageInformation lInfo )
		{
			using( var aRepository = new AccountRepository() )
			{
				aRepository.AddLanguage( lInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditLanguage )]
		public JsonResult Edit( LanguageInformation lInfo )
		{
			using( var aRepository = new AccountRepository() )
			{
				aRepository.EditLanguage( lInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewLanguage )]
		public JsonResult Get( int id )
		{
			using( var aRepository = new AccountRepository() )
			{
				return SuccessMessage( aRepository.GetLanguage( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.DeactivateLanguage )]
		public JsonResult Delete( int id )
		{
			using( var aRepository = new AccountRepository() )
			{
				aRepository.DeleteLanguage( id );

				return SuccessMessage();
			}
		}
	}
}