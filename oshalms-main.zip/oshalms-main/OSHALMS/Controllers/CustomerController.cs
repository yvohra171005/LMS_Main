﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AuthorizeNet;

using CsvHelper;

using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Customer;
using GDWRepositories;
using System.Net;

namespace OSHALMS.Controllers
{
    public class CustomerController : BaseController
    {
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewCustomer )]
		public ActionResult Index()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewCreditTier )]
		public ActionResult Tiers()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewLocation )]
		public ActionResult Locations()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewDepartment )]
		public ActionResult Departments()
		{
			return View();
		}
		
		[GDWAuthorize( GDWPermissionTypes.Permissions.ViewCompanyDocument, GDWPermissionTypes.Permissions.ViewCompanyNote )]
		public ActionResult CompanyDocuments()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageAssignments )]
		public ActionResult Assignments()
		{
			return View();
		}

		[GDWAuthorize( GDWPermissionTypes.Permissions.ManageAssignments )]
		public ActionResult ScheduledAssignments()
		{
			return View();
		}

		public ActionResult MyAccount()
		{
			return View();
		}

		#region Tiers

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewCreditTier )]
		public JsonResult FullCreditTierList( TierTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var cRepository = new CustomerRepository() )
			{
				var results = cRepository.GetFullTierList(
					param, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddCreditTier )]
		public JsonResult AddTier( TierInformation pInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.AddTier( pInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditCreditTier )]
		public JsonResult EditTier( TierInformation pInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.EditTier( pInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewCreditTier )]
		public JsonResult GetTier( int id )
		{
			using( var cRepository = new CustomerRepository() )
			{
				return SuccessMessage( cRepository.GetCreditTier( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.DeactivateCreditTier )]
		public JsonResult DeleteTier( int id )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.DeleteTier( id );

				return SuccessMessage();
			}
		}

		#endregion

		#region Customers

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewCustomer )]
		public JsonResult FullCustomerList( CustomerTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var cRepository = new CustomerRepository() )
			{
				var results = cRepository.GetFullCustomerList(
					param, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageMyAccount )]
		public JsonResult FullPurchaseList( PurchaseTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var cRepository = new CustomerRepository() )
			{
				var results = cRepository.GetFullPurchaseList(
					GDWWebUser.CurrentUser.CustomerID, param, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddCustomer )]
		public JsonResult Add( CustomerInformation cInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.AddCustomer( cInfo );

				return SuccessMessage();
			}
		}
		
		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditCustomer )]
		public JsonResult Edit( CustomerInformation cInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.EditCustomer( cInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewCustomer )]
		public JsonResult Get( int id )
		{
			using( var cRepository = new CustomerRepository() )
			{
				return SuccessMessage( cRepository.GetCustomer( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageMyAccount )]
		public JsonResult GetMyAccount()
		{
			using( var cRepository = new CustomerRepository() )
			{
				return SuccessMessage( cRepository.GetCustomer( GDWWebUser.CurrentUser.CustomerID.Value ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageMyAccount )]
		public JsonResult UpdateMyAccount( CustomerInformation cInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.EditCustomer( cInfo );

				return SuccessMessage();
			}
		}
		
		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.DeactivateCustomer )]
		public JsonResult Delete( int id )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.DeleteCustomer( id );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageCustomerAccount )]
		public JsonResult MarkPaid( int id )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.MarkCustomerPaid( id );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageCustomerAccount )]
		public JsonResult AddCredits( int customerId, int credits )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.AddCustomerCredits( customerId, credits, GDWWebUser.CurrentUser.UserId );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageCustomerAccount )]
		public JsonResult AddEmployees( int customerId, int employees )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.AddCustomerEmployees( customerId, employees, GDWWebUser.CurrentUser.UserId );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ImpersonateCustomer )]
		public JsonResult Impersonate( int id )
		{
			using( var cRepository = new CustomerRepository() )
			{
				var cInfo = cRepository.GetCustomer( id );

				GDWWebUser.CurrentUser.ImpersonateCustomer( id, cInfo.name, cInfo.enterpriseLevel );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON]
		public JsonResult ClearImpersonate()
		{
			GDWWebUser.CurrentUser.ClearImpersonate();

			return SuccessMessage();
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageMyAccount )]
		public JsonResult MyPaymentTypeList()
		{
			using( var cRepository = new CustomerRepository() )
			{
				return SuccessMessage( cRepository.GetPaymentTypeList( GDWWebUser.CurrentUser.CustomerID.Value ) );
			}
		}

		#endregion

		#region Locations

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewLocation )]
		public JsonResult FullLocationList( LocationTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var cRepository = new CustomerRepository() )
			{
				var results = cRepository.GetFullLocationList(
					param, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddLocation )]
		public JsonResult AddLocation( LocationInformation pInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.AddLocation( pInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditLocation )]
		public JsonResult EditLocation( LocationInformation pInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.EditLocation( pInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewLocation )]
		public JsonResult GetLocation( int id )
		{
			using( var cRepository = new CustomerRepository() )
			{
				return SuccessMessage( cRepository.GetLocation( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.DeactivateLocation )]
		public JsonResult DeleteLocation( int id )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.DeleteLocation( id );

				return SuccessMessage();
			}
		}

		#endregion

		#region Departments

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewDepartment )]
		public JsonResult FullDepartmentList( DepartmentTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var cRepository = new CustomerRepository() )
			{
				var results = cRepository.GetFullDepartmentList(
					param, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddDepartment )]
		public JsonResult AddDepartment( DepartmentInformation pInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.AddDepartment( pInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditDepartment )]
		public JsonResult EditDepartment( DepartmentInformation pInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.EditDepartment( pInfo );

				return SuccessMessage();
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewDepartment )]
		public JsonResult GetDepartment( int id )
		{
			using( var cRepository = new CustomerRepository() )
			{
				return SuccessMessage( cRepository.GetDepartment( id ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.DeactivateDepartment )]
		public JsonResult DeleteDepartment( int id )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.DeleteDepartment( id );

				return SuccessMessage();
			}
		}

		#endregion

        #region Signatures

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageMyAccount )]
		public JsonResult GetSignature()
		{
			using( var cRepository = new CustomerRepository() )
			{
				return SuccessMessage( cRepository.GetCustomerSignature( GDWWebUser.CurrentUser.CustomerID.Value ) );
			}
		}
        
		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.EditSignature )]
		public JsonResult EditSignature( CustomerSignatureInformation csInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.EditCustomerSignature( GDWWebUser.CurrentUser.CustomerID.Value, csInfo );

				return SuccessMessage();
			}
		}

        #endregion

        #region Documents
		
        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewCompanyDocument )]
        public JsonResult FullDocumentList( CompanyDocumentTableParams param )
        {
	        int totalCount = 0, filteredCount = 0;

	        using( var cRepository = new CustomerRepository() )
	        {
		        var results = cRepository.GetFullDocumentList(
			        param, GDWWebUser.CurrentUser, out totalCount, out filteredCount );

		        return SuccessMessage( new
		        {
			        sEcho = param.sEcho,
			        iTotalRecords = totalCount,
			        iTotalDisplayRecords = filteredCount,
			        aaData = results
		        } );
	        }
        }

        [GDWAuthorize( GDWPermissionTypes.Permissions.ViewCompanyDocument )]
        public ActionResult GetDocumentContent( int id )
        {
	        DocumentInformation docInfo;
	        using( var cRepository = new CustomerRepository() )
	        {
		        try
		        {
			        docInfo = cRepository.GetDocument( GDWWebUser.CurrentUser, id );
		        }
		        catch (GDWException)
		        {
			        return HttpNotFound();
		        }
	        }

	        var fileStorage = new AzureFileStorage();
	        var stream = new MemoryStream();
	        var contentType = fileStorage.DownloadFileToStream( "Files", docInfo.fileName, stream );

	        return File( stream, contentType, docInfo.originalFileName );
        }

		
        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageCompanyDocument )]
        public JsonResult AddDocument( DocumentInformation pInfo )
        {
	        using( var cRepository = new CustomerRepository() )
	        {
		        cRepository.AddDocument( GDWWebUser.CurrentUser, pInfo );

		        return SuccessMessage();
	        }
        }

        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageCompanyDocument )]
        public JsonResult EditDocument( DocumentInformation pInfo )
        {
	        using( var cRepository = new CustomerRepository() )
	        {
		        cRepository.EditDocument( GDWWebUser.CurrentUser, pInfo );

		        return SuccessMessage();
	        }
        }
		
        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewCompanyDocument )]
        public JsonResult GetDocument( int id )
        {
	        using( var cRepository = new CustomerRepository() )
	        {
		        return SuccessMessage( cRepository.GetDocument( GDWWebUser.CurrentUser, id ) );
	        }
        }

        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageCompanyDocument )]
        public JsonResult DeleteDocument( int id )
        {
	        using( var cRepository = new CustomerRepository() )
	        {
		        cRepository.DeleteDocument(GDWWebUser.CurrentUser, id);

		        return SuccessMessage();
	        }
        }

        #endregion

        #region Notes
				
        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewCompanyNote )]
        public JsonResult FullNoteList( CompanyNoteTableParams param )
        {
	        int totalCount = 0, filteredCount = 0;

	        using( var cRepository = new CustomerRepository() )
	        {
		        var results = cRepository.GetFullNoteList(
			        param, GDWWebUser.CurrentUser, out totalCount, out filteredCount );

		        return SuccessMessage( new
		        {
			        sEcho = param.sEcho,
			        iTotalRecords = totalCount,
			        iTotalDisplayRecords = filteredCount,
			        aaData = results
		        } );
	        }
        }

        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageCompanyNote )]
        public JsonResult AddNote( NoteInformation pInfo )
        {
	        using( var cRepository = new CustomerRepository() )
	        {
		        cRepository.AddNote( GDWWebUser.CurrentUser, pInfo );

		        return SuccessMessage();
	        }
        }

        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ViewCompanyNote )]
        public JsonResult GetNote( int id )
        {
	        using( var cRepository = new CustomerRepository() )
	        {
		        return SuccessMessage( cRepository.GetNote( GDWWebUser.CurrentUser, id ) );
	        }
        }

        [GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageCompanyNote )]
        public JsonResult DeleteNote( int id )
        {
	        using( var cRepository = new CustomerRepository() )
	        {
		        cRepository.DeleteNote(GDWWebUser.CurrentUser, id);

		        return SuccessMessage();
	        }
        }

        #endregion

        [GDWAuthorizeJSON]
		public JsonResult AccountStatus()
		{
			using( var cRepository = new CustomerRepository() )
			{
				return SuccessMessage( cRepository.GetAccountStatus( GDWWebUser.CurrentUser.CustomerID ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.AddInvoice )]
		public JsonResult AddInvoice( NewInvoiceInformation iInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				return SuccessMessage( cRepository.AddInvoice( iInfo, GDWWebUser.CurrentUser.CustomerID.Value ) );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageCreditsAndEmployees )]
		public JsonResult UpdateStatus( NewPurchaseInformation pInfo )
		{
			using( var cRepository = new CustomerRepository() )
			{
				var cProfileId = cRepository.GetCustomerProfileID( pInfo.customerId );

				var cInfo = cRepository.GetCustomer( GDWWebUser.CurrentUser.CustomerID.Value );

				var cGate = new CustomerGateway( ConfigurationHelper.GetGatewayAPILogin(), ConfigurationHelper.GetGatewayTransactionKey(), ConfigurationHelper.GetGatewayMode() ? ServiceMode.Test : ServiceMode.Live );

				if( string.IsNullOrEmpty( pInfo.profileId ) )
				{
					if( pInfo.saveCreditCard && pInfo.method == GDWPaymentMethods.PaymentMethod.CreditCard.ToString() )
					{
						// a new card
						if( string.IsNullOrEmpty( cProfileId ) )
						{
							var customerProfile = cGate.CreateCustomer( "", "", GDWWebUser.CurrentUser.CustomerID.Value.ToString() );

							cProfileId = customerProfile.ProfileID;
						}

						pInfo.profileId = cGate.AddCreditCard( cProfileId, pInfo.ccNumber, pInfo.ccMonth, pInfo.ccYear, pInfo.ccCVV, new Address()
						{
							First = cInfo.firstName,
							Last = cInfo.lastName,
							Street = cInfo.address1,
							City = cInfo.city,
							State = cInfo.state,
							Zip = cInfo.zipCode
						} );

						cRepository.SetCustomerCCProfile( GDWWebUser.CurrentUser.CustomerID.Value, cProfileId, pInfo.profileId, "XXXX" + pInfo.ccNumber.Substring( pInfo.ccNumber.Length - 4, 4 ), GDWPaymentMethods.PaymentMethod.CreditCard );
					}
					else if( pInfo.saveECheck && pInfo.method == GDWPaymentMethods.PaymentMethod.eCheck.ToString() )
					{
						if( string.IsNullOrEmpty( cProfileId ) )
						{
							var customerProfile = cGate.CreateCustomer( "", "", GDWWebUser.CurrentUser.CustomerID.Value.ToString() );

							cProfileId = customerProfile.ProfileID;
						}

						var bankAccountType = (BankAccountType)Enum.Parse( typeof( BankAccountType ), pInfo.eAccountType );

						pInfo.profileId = cGate.AddECheckBankAccount( cProfileId, bankAccountType, pInfo.eRoutingNumber, pInfo.eAccountNumber, pInfo.eNameOnAccount );

						cRepository.SetCustomerCCProfile( GDWWebUser.CurrentUser.CustomerID.Value, cProfileId, pInfo.profileId, "XXXX" + pInfo.eAccountNumber.Substring( pInfo.eAccountNumber.Length - 4, 4 ), GDWDatabase.GDWPaymentMethods.PaymentMethod.eCheck );
					}
				}

				bool approved = false;
				string transactionId = null;
				if( !string.IsNullOrEmpty( pInfo.profileId ) )
				{
					// use existing card, which may be new from above
					var response = cGate.AuthorizeAndCapture( cProfileId, pInfo.profileId, pInfo.totalAmount + pInfo.salesTax );

					approved = response.Approved;
					transactionId = response.TransactionID;
				}
				else if( pInfo.method == GDWPaymentMethods.PaymentMethod.CreditCard.ToString() )
				{
					// just run the card through
					string expDate = new DateTime( pInfo.ccYear, pInfo.ccMonth, 1 ).ToString( "MMyy" );

					var request = new AuthorizationRequest( pInfo.ccNumber, expDate, pInfo.totalAmount + pInfo.salesTax, "Good Day's Work", true );

					request.AddCardCode( pInfo.ccCVV );

					//ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

					var gate = new Gateway( ConfigurationHelper.GetGatewayAPILogin(), ConfigurationHelper.GetGatewayTransactionKey(), ConfigurationHelper.GetGatewayMode() );

					var response = gate.Send( request );

					approved = response.Approved;
					transactionId = response.TransactionID;
				}
				else if( pInfo.method == GDWPaymentMethods.PaymentMethod.eCheck.ToString() )
				{
					// just run the check through
					var bankAccountType = (BankAccountType)Enum.Parse( typeof( BankAccountType ), pInfo.eAccountType );
					var transType = EcheckType.WEB;
					if( bankAccountType == BankAccountType.BusinessChecking )
						transType = EcheckType.CCD;

					var request = new EcheckAuthorizationRequest( transType, pInfo.totalAmount + pInfo.salesTax, pInfo.eRoutingNumber, pInfo.eAccountNumber, bankAccountType,
						"", pInfo.eNameOnAccount, "" );

					//ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

					var gate = new Gateway( ConfigurationHelper.GetGatewayAPILogin(), ConfigurationHelper.GetGatewayTransactionKey(), ConfigurationHelper.GetGatewayMode() );

					var response = gate.Send( request );

					if( response.Approved )
					{
						var cRequest = new EcheckPriorAuthCaptureRequest( response.TransactionID, pInfo.totalAmount + pInfo.salesTax );

						var cResponse = gate.Send( cRequest );

						approved = cResponse.Approved;
						transactionId = cResponse.TransactionID;
					}
				}

				if( approved )
				{
					string invoiceNumber = "";

					cRepository.UpdateCustomerStatus( pInfo, transactionId, out invoiceNumber );

					PaymentController.FinalizeSalesTax( cInfo.customerId, invoiceNumber, new Avalara.Address() {
						Line1 = cInfo.address1,
						Line2 = cInfo.address2,
						City = cInfo.city,
						Region = cInfo.state,
						PostalCode = cInfo.zipCode
					}, pInfo.totalAmount );

					try
					{
						var invoiceDetail = cRepository.GetPurchaseDetails( cInfo.customerId, int.Parse( invoiceNumber ) );

						var html = RenderViewToString( ControllerContext, "Index", invoiceDetail, "Invoice" );

						// convert HTML to PDF
						string homeUrl = string.Format( "http{0}://{1}{2}/", Request.IsSecureConnection ? "s" : "",
							Request.Url.DnsSafeHost,
							Request.Url.IsDefaultPort ? "" : string.Format( ":{0}", Request.Url.Port ) );

						var queueComm = new AzureQueueCommunication();
						var fileStorage = new AzureFileStorage();
						var inputGuid = Guid.NewGuid().ToString();
						var outputGuid = Guid.NewGuid().ToString();
						var directoryName = "Invoices";

						using( var inputStream = new MemoryStream() )
						{
							using( var sw = new StreamWriter( inputStream ) )
							{
								sw.WriteLine( html );
								sw.Flush();

								inputStream.Seek( 0, SeekOrigin.Begin );

								fileStorage.UploadFile( directoryName, inputGuid, "text/html", inputStream );
							}
						}

					    var emailAddresses = new List<string> { cInfo.emailAddress };
                        using ( var aRepo = new AccountRepository() )
                        {
                            var user = aRepo.FindUserByUserName( GDWWebUser.CurrentUser.Identity.Name );
                            if ( user != null )
                                emailAddresses.AddRange( aRepo.GetEmailRecipientsForUser( user ).Select( u => u.EmailAddress ) );
                        }
						queueComm.GetInvoice( inputGuid, outputGuid, homeUrl, directoryName, emailAddresses: string.Join( ",", emailAddresses ) );
					}
					catch
					{
						// don't let doing this fail the purchase
					}

					return SuccessMessage();
				}
			}

			if( string.IsNullOrEmpty( pInfo.profileId ) )
			{
				if( pInfo.method == GDWPaymentMethods.PaymentMethod.CreditCard.ToString() )
				{
					throw new GDWException( "CreditCardDeclined" );
				}
				else if( pInfo.method == GDWPaymentMethods.PaymentMethod.eCheck.ToString() )
				{
					throw new GDWException( "ECheckDeclined" );
				}
			}
			throw new GDWException( "TransactionDeclined" );
		}

		#region Assignments
		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageAssignments )]
		public JsonResult AssignedClassList( ClassAssignmentTableParams param )
		{
			int totalCount = 0, filteredCount = 0;
			int totalCredits = 0;

			using( var cRepository = new CustomerRepository() )
			{
				var results = cRepository.GetClassAssignmentList(
					param, out totalCount, out filteredCount, out totalCredits, GDWWebUser.CurrentUser.CustomerID );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					iTotalCredits = totalCredits,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageAssignments )]
		public JsonResult AssignedEmployeeList( EmployeeAssignmentTableParams param )
		{
			int totalCount = 0, filteredCount = 0;
			int totalEmployees = 0, creditsUsed = 0;

			using( var cRepository = new CustomerRepository() )
			{
				var results = cRepository.GetEmployeeAssignmentList(
					param, out totalCount, out filteredCount, out totalEmployees, out creditsUsed, GDWWebUser.CurrentUser.CustomerID );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					iTotalEmployees = totalEmployees,
					iTotalCreditsUsed = creditsUsed,
					aaData = results
				} );
			}
		}

        [GDWAuthorizeJSON(GDWPermissionTypes.Permissions.ManageAssignments)]
        public JsonResult AssignClasses(NewAssignmentInformation aInfo)
        {
            using ( var cRepository = new CustomerRepository() )
            {
                var results = cRepository.AssignClassesToUsers( aInfo );
                if ( !results.AssignedUserClasses.Any() )
                    throw new GDWException( "NoClassesToAssign" );

                var creditCount = results.RemainingCreditCount;
                return SuccessMessage( new
                    {
                        completeMessage =
                            string.Format(
                                GDWWebUser.CurrentUser.GetResourceString( creditCount < int.MaxValue
                                    ? "AssignmentsComplete"
                                    : "AssignmentsCompleteNoCredits"), creditCount )
                    });
            }
        }

        #endregion

        #region Assignment Scheduling
		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageAssignments )]
		public JsonResult ScheduledAssignmentList( ScheduledAssignmentTableParams param )
		{
			int totalCount = 0, filteredCount = 0;

			using( var cRepo = new CustomerRepository() )
			{
				var results = cRepo.GetScheduledAssignmentList( param, out totalCount, out filteredCount, GDWWebUser.CurrentUser.CustomerID.Value );

				return SuccessMessage( new
				{
					sEcho = param.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}


		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageAssignments )]
		public JsonResult UploadScheduledAssignments( string fileName )
		{
			var fileStorage = new AzureFileStorage();

			var stream = new MemoryStream();

			var contentType = fileStorage.DownloadFileToStream( "Files", fileName, stream );
			
			using( var cRepo = new CustomerRepository() )
			{
				int recordCount = 0;

				var errors = cRepo.ImportScheduledAssignments( GDWWebUser.CurrentUser.UserId, stream, GDWWebUser.CurrentUser.CustomerID.Value, out recordCount );

				return SuccessMessage( new { errorList = errors, recordCount = recordCount } );
			}
		}

		public FileStreamResult SampleScheduledAssignmentUpload()
		{
			using( var cRepo = new CustomerRepository() )
			{
				var theData = cRepo.GetBlankScheduledAssignmentUploadHeaders();

				using( var memoryStream = new MemoryStream() )
				{
					using( var streamWriter = new StreamWriter( memoryStream ) )
					{
						using( var csvWriter = new CsvWriter( streamWriter ) )
						{
							foreach( var header in theData )
							{
								csvWriter.WriteField( header );
							}
							csvWriter.NextRecord();
							streamWriter.Flush();

							var result = memoryStream.ToArray();

							return new FileStreamResult( new MemoryStream( result ), "text/csv" ) { FileDownloadName = "scheduled_assignments.csv" };

						}
					}
				}
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ManageAssignments )]
		public JsonResult CancelScheduledAssignment( int scheduledAssignmentId )
		{
			using( var cRepository = new CustomerRepository() )
			{
				cRepository.CancelScheduledAssignment( scheduledAssignmentId, GDWWebUser.CurrentUser.CustomerID.Value );

				return SuccessMessage();
			}
		}
        #endregion
    }
}