﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using GDWInfrastructure;
using GDWRepositories;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

namespace OSHALMS.Controllers
{
    public class FileController : BaseController
    {
		private class UploadResult
		{
			public string originalName { get; set; }
			public string newFileName { get; set; }
		}

		[GDWAuthorizeJSON]
		public JsonResult Upload()
		{
			string fileType = null;

			var fileStorage = new AzureFileStorage();
			List<UploadResult> results = new List<UploadResult>();

			if( Request.Files.Count > 0 )
			{ //they're uploading the old way
				for( int i = 0; i < Request.Files.Count; i++ )
				{
					var file = Request.Files[i];
					fileType = file.ContentType;

					string newFileName = Guid.NewGuid().ToString();
					fileStorage.UploadFile( "Files", newFileName, fileType, file.InputStream );

					results.Add( new UploadResult() { originalName = file.FileName, newFileName = newFileName } );
				}
			}
			else if( Request.ContentLength > 0 )
			{
				fileType = Request.Headers["X-File-Type"];

				string newFileName = Guid.NewGuid().ToString();
				fileStorage.UploadFile( "Files", newFileName, fileType, Request.InputStream );

				results.Add( new UploadResult() { originalName = Request.Headers["X-File-Name"], newFileName = newFileName } );
			}

			return SuccessMessage( results );
		}

		[GDWAuthorize]
		public FileResult Get( string id )
		{
			var fileStorage = new AzureFileStorage();

			var stream = new MemoryStream();

			var contentType = fileStorage.DownloadFileToStream( "Files", id, stream );

			return File( stream, contentType );
		}

		[GDWAuthorize]
		public FileResult GetTarget( string id, string targetName )
		{
			var fileStorage = new AzureFileStorage();

			var stream = new MemoryStream();

			var contentType = fileStorage.DownloadFileToStream( "Files", id, stream );

			return File( stream, contentType, targetName );
		}

		[GDWAuthorize]
		public FileResult GetVTT( string id )
		{
			var fileStorage = new AzureFileStorage();

			var stream = new MemoryStream();

			var contentType = fileStorage.DownloadFileToStream( "Files", id, stream );

			return File( stream, "text/vtt" );
		}

		// option for streaming:
		// http://code.msdn.microsoft.com/windowsazure/ASPNET-WebAPI-2-Stream-7d96cb70

		private static CloudStorageAccount GetStorageAccount()
		{
			var connectionString = ConfigurationHelper.GetStorageConnectionString();
			var storageAccount = CloudStorageAccount.Parse( connectionString );
			return storageAccount;
		}

		private static CloudBlobClient GetBlobClient()
		{
			var storageAccount = GetStorageAccount();
			var blobClient = storageAccount.CreateCloudBlobClient();
			return blobClient;
		}

		[GDWAuthorize]
		public async Task<FileStreamResult> GetStream( string id )
		{
			var blobClient = GetBlobClient();

			// Get and create the container 
			var blobContainer = blobClient.GetContainerReference( "Files".ToLowerInvariant() );

			var blob = blobContainer.GetBlockBlobReference( id );

			var blobExists = await blob.ExistsAsync();
			if( blobExists )
			{
				Stream blobStream = await blob.OpenReadAsync();
				
				return File( blobStream, blob.Properties.ContentType );
			}

			return null;
		}

		public static string GetSASFileName( string containerName, string fileName )
		{
			var blobClient = GetBlobClient();
			var container = blobClient.GetContainerReference( containerName.ToLowerInvariant() );

			var blockBlob = container.GetBlockBlobReference( fileName );

			SharedAccessBlobPolicy sasConstraints = new SharedAccessBlobPolicy();
			sasConstraints.SharedAccessStartTime = DateTime.UtcNow.AddMinutes( -5 );
			sasConstraints.SharedAccessExpiryTime = DateTime.UtcNow.AddHours( 1 );
			sasConstraints.Permissions = SharedAccessBlobPermissions.Read;

			//Generate the shared access signature on the blob, setting the constraints directly on the signature.
			string sasBlobToken = blockBlob.GetSharedAccessSignature( sasConstraints );

			//Return the URI string for the container, including the SAS token.
			return blockBlob.Uri + sasBlobToken;
		}

		public FileResult Subtitles()
		{
			var subtitles = @"WEBVTT

00:00:01.000 --> 00:00:10.000
This is the first line of text, displaying from 1-10 seconds

00:00:15.000 --> 00:00:20.000
And the second line of text
separated over two lines";

			return File( Encoding.UTF8.GetBytes( subtitles ), "text/vtt" );
		}

		[GDWAuthorize]
		public FileResult ClassDocumentSet( int id )
		{
			using( var cRepo = new ClassRepository() )
			{
				return GetZipFile( cRepo.GetUserClassInfo( id ).documents, string.Format( "ClassDocuments{0}.zip", id ) );
			}
		}

		[GDWAuthorize]
		public FileResult FullClassDocumentSet( int id )
		{
			using( var cRepo = new ClassRepository() )
			{
				return GetZipFile( cRepo.GetScreenClassInfo( id, GDWWebUser.CurrentUser.ResourceClass, GDWWebUser.CurrentUser.CustomerID.Value ).documents, string.Format( "ClassDocuments{0}.zip", id ) );
			}
		}

		[GDWAuthorize]
		public FileResult FullClassSafetyDocumentSet( int id )
		{
			using( var cRepo = new ClassRepository() )
			{
				return GetZipFile( cRepo.GetScreenClassInfo( id, GDWWebUser.CurrentUser.ResourceClass, GDWWebUser.CurrentUser.CustomerID.Value ).safetyDocuments, string.Format( "ClassSafetyDocuments{0}.zip", id ) );
			}
		}

		private FileResult GetZipFile( IEnumerable<GDWModels.Class.MyClassDocument> documents, string fileName )
		{
			var memoryStream = new MemoryStream();
			using( var zip = new ZipArchive( memoryStream, ZipArchiveMode.Create, true ) )
			{
				foreach( var doc in documents )
				{
					try
					{
						var fileStream = new MemoryStream();

						new AzureFileStorage().DownloadFileToStream( "Files", doc.fileName, fileStream );

						var entry = zip.CreateEntry( doc.displayName );
						using( var entryStream = entry.Open() )
						{
							fileStream.CopyTo( entryStream );
						}
					}
					catch
					{
					}
				}
			}


			memoryStream.Seek( 0, SeekOrigin.Begin );

			return File( memoryStream, "application/zip", fileName );
		}
	}
}