﻿using CsvHelper;
using CsvHelper.Configuration;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Class;
using GDWRepositories;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OSHALMS.Controllers
{
    public class ScoreController : BaseController
    {
        [GDWAuthorize( GDWPermissionTypes.Permissions.ImportScores )]
        public ActionResult Index()
        {
            return View();
        }

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ImportScores )]
		public JsonResult FullImportList( ScoreImportTableParams dtParams )
		{
			int totalCount = 0, filteredCount = 0;

			using( var dRepo = new ClassRepository() )
			{
				var results = dRepo.GetFullImportList( dtParams, GDWWebUser.CurrentUser.CustomerID, out totalCount, out filteredCount );

				return SuccessMessage( new
				{
					sEcho = dtParams.sEcho,
					iTotalRecords = totalCount,
					iTotalDisplayRecords = filteredCount,
					aaData = results
				} );
			}
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ImportScores )]
		public JsonResult Import( ScoreImportInformation import )
		{
			var storage = new AzureFileStorage();

			using( var outputStream = new MemoryStream() )
			{
				storage.DownloadFileToStream( "Files", import.newImportName, outputStream );

				using( var textReader = new StreamReader( outputStream ) )
				{
					var csvReader = new CsvReader( textReader, new CsvConfiguration() { HasHeaderRecord = true, IsHeaderCaseSensitive = false } );
					csvReader.Configuration.RegisterClassMap( new ScoreImportDetailMap() );

					Guid? errorFile = null;

					int success = 0;
					var errors = new List<ScoreImportError>();
					while( csvReader.Read() )
					{
						try
						{
							var record = csvReader.GetRecord<ScoreImportDetail>();
							using( var cRepo = new CustomerRepository() )
							{
								try
								{
									cRepo.ImportScore( record, GDWWebUser.CurrentUser.CustomerID, import.classId, import.completedDate, import.replaceInProgressClasses );

									success++;
								}
								catch( GDWEnglishException e )
								{
									errors.Add( new ScoreImportError() { firstName = record.firstName, lastName = record.lastName, score = record.score, error = e.Message } );
								}
								catch
								{
									errors.Add( new ScoreImportError() { firstName = record.firstName, lastName = record.lastName, score = record.score, error = "An error has occurred" } );
								}
							}
						}
						catch( MissingFieldException e )
						{
							errors.Add( new ScoreImportError() { firstName = string.Format( "Line {0}", csvReader.Row ), error = e.Message } );
						}
						catch
						{
							errors.Add( new ScoreImportError() { firstName = string.Format( "Line {0}", csvReader.Row ), error = "An error has occurred" } );
						}
					}

					if( errors.Any() )
					{
						var errorStream = WriteCsvToMemory<ScoreImportError>( errors, new ScoreImportErrorMap() );

						errorFile = Guid.NewGuid();

						storage.UploadFile( "Files", errorFile.ToString(), "text/csv", errorStream );
					}

					using( var cRepo = new CustomerRepository() )
					{
						cRepo.RecordImport(
                            GDWWebUser.CurrentUser.CustomerID.Value, import.classId, import.originalImportName, import.newImportName, errorFile.ToString(),
                            success, errors.Count, GDWWebUser.CurrentUser.UserId, import.originalSignatureFileName, import.newSignatureFileName );
					}
				}
			}

			return SuccessMessage( true );
		}

		[GDWAuthorizeJSON( GDWPermissionTypes.Permissions.ImportScores )]
		public FileStreamResult SampleUpload()
		{
			return new FileStreamResult( WriteCsvToMemory( new List<ScoreImportDetail>(), new ScoreImportDetailMap() ), "text/csv" ) { FileDownloadName = "scores.csv" };
		}
	}
}