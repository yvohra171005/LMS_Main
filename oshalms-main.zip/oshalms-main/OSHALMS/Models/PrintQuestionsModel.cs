﻿using GDWModels.Class;

namespace OSHALMS.Models
{
    public class PrintQuestionsModel
    {
        public ScreenClassInformation CurrentVersion { get; set; }
        public ScreenClassInformation AlternateVersion { get; set; }
    }
}