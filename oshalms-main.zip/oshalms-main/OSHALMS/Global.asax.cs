﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using GDWInfrastructure;
using GDWRepositories;
using OSHALMSStrings;

namespace OSHALMS
{
	public class MvcApplication : System.Web.HttpApplication
	{
		protected void Application_Start()
		{
			AreaRegistration.RegisterAllAreas();
			RouteConfig.RegisterRoutes( RouteTable.Routes );
		}

		private void Application_PostAuthenticateRequest( object sender, EventArgs e )
		{
			IPrincipal user = HttpContext.Current.User;
			if( user.Identity.IsAuthenticated )
			{
				using( var aRepo = new AccountRepository() )
				{
					GDWWebUser principal = aRepo.CreateGDWWebUser( user.Identity.Name, user.Identity.AuthenticationType );
					if( principal != null )
					{
						HttpContext.Current.User = principal;
						System.Threading.Thread.CurrentPrincipal = principal;
					}
				}
			}
		}

		protected void Application_Error( object sender, EventArgs e )
		{
			var exception = Server.GetLastError();

			var errorData = new { success = false, message = "An error has occured.", extraMessage = exception.Message + " " + (exception.InnerException != null ? exception.InnerException.Message : "") };
			if( exception is GDWException )
			{
				var gdwException = (GDWException)exception;
				var resClass = "EnglishStrings";
				if( HttpContext.Current.User.Identity.IsAuthenticated )
					resClass = GDWWebUser.CurrentUser.ResourceClass;

				errorData = new { success = false, message = StringManager.GetStringFromResourceFile( resClass, gdwException.StringID ), extraMessage = "" };
			}
			else if( exception is GDWEnglishException )
			{
				errorData = new { success = false, message = exception.Message, extraMessage = "" };
			}

			Response.Clear();

			HttpContext ctx = HttpContext.Current;
			RequestContext rc = ((MvcHandler)ctx.CurrentHandler).RequestContext;
			string controllerName = rc.RouteData.GetRequiredString( "controller" );
			IControllerFactory factory = ControllerBuilder.Current.GetControllerFactory();
			IController controller = factory.CreateController( rc, controllerName );
			ControllerContext cc = new ControllerContext( rc, (ControllerBase)controller );

			var jResult = new JsonResult()
			{
				Data = errorData,
				JsonRequestBehavior = JsonRequestBehavior.AllowGet
			};

			jResult.ExecuteResult( cc );

			Server.ClearError();
		}
	}
}
