﻿using GDWDatabase;
using GDWInfrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWScormProviders
{
    //TODO-TROY implement this class
    public class EasyGeneratorScormProvider : IScormProvider
    {
        public string ID => "EasyGenerator";

        public string Name => GDWWebUser.CurrentUser.GetResourceString("EasyGenerator");

        public string ClassHandleLabel => GDWWebUser.CurrentUser.GetResourceString("CourseLink");

        public Uri LaunchCourse(UserClassVersion course, string classHandle)
        {
            throw new NotImplementedException();
        }

        public void OnCourseImported(string classHandle)
        {
            throw new NotImplementedException();
        }

        public bool IsCourseComplete(UserClassVersion course, string classHandle)
        {
            throw new NotImplementedException();
        }
    }
}
