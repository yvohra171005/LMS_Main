﻿using GDWDatabase;
using GDWInfrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Com.RusticiSoftware.Cloud.V2.Api;
using Com.RusticiSoftware.Cloud.V2.Model;

namespace GDWScormProviders
{
    public class ScormCloudProvider : IScormProvider
    {
        public string ID => "ScormCloud";

        public string Name => GDWWebUser.CurrentUser.GetResourceString("ScormCloud");

        public string ClassHandleLabel => GDWWebUser.CurrentUser.GetResourceString("CourseId");

        public Uri LaunchCourse(UserClassVersion course, string classHandle)
        {
            Com.RusticiSoftware.Cloud.V2.Client.Configuration.Default.Username = GDWInfrastructure.ConfigurationHelper.GetScormCloudUsername();
            Com.RusticiSoftware.Cloud.V2.Client.Configuration.Default.Password = GDWInfrastructure.ConfigurationHelper.GetScormCloudPassword();

            try
            {
                new RegistrationApi().GetRegistration(course.VersionID.ToString());
            }
            catch (Com.RusticiSoftware.Cloud.V2.Client.ApiException e)
            {
                if (e.ErrorCode == 404)
                {
                    // user is not yet registered - must create registration before they can access the course.
                    // doing this "lazily" - i.e. on course access rather than course assignment - may minimize the number of registrations actually created
                    var registrationSchema = new CreateRegistrationSchema(
                        courseId: classHandle,
                        learner: new LearnerSchema(id: course.UserClass.UserID.ToString(), email: course.UserClass.User.EmailAddress, firstName: course.UserClass.User.FirstName, lastName: course.UserClass.User.LastName),
                        registrationId: course.VersionID.ToString());
                    new RegistrationApi().CreateRegistration(registrationSchema);
                }
                else
                {
                    throw;
                }
            }
            //TODO-TROY redirectOnExitUrl should be something different. I should really make a simple view for this that says something like,
            // "thanks for completing this course. If the 'Take Test' button does not appear soon, please reload the page to take the test."
            return new Uri(new RegistrationApi().BuildRegistrationLaunchLink(course.VersionID.ToString(), new LaunchLinkRequestSchema(redirectOnExitUrl: "http://www.google.com")).LaunchLink);
        }

        public void OnCourseImported(string classHandle)
        {
            Com.RusticiSoftware.Cloud.V2.Client.Configuration.Default.Username = GDWInfrastructure.ConfigurationHelper.GetScormCloudUsername();
            Com.RusticiSoftware.Cloud.V2.Client.Configuration.Default.Password = GDWInfrastructure.ConfigurationHelper.GetScormCloudPassword();

            try
            {
                // Configure the course to launch inside an iframe, not a new window.
                // This also verifies that the course exists - if it does not, a 404 will be returned and handled in the catch block below
                new CourseApi().SetCourseConfiguration(classHandle, new SettingsPostSchema(new List<SettingsIndividualSchema>()
                {
                    new SettingsIndividualSchema("PlayerLaunchType", "FRAMESET", true),
                    new SettingsIndividualSchema("PlayerScoLaunchType", "FRAMESET", true),
                }));
            }
            catch (Com.RusticiSoftware.Cloud.V2.Client.ApiException e)
            {
                if (e.ErrorCode == 404)
                    throw new GDWException("CourseIDNotFound");

                // error codes other than 404 are unexpected and not handled here
                throw;
            }
        }

        public bool IsCourseComplete(UserClassVersion course, string classHandle)
        {
            Com.RusticiSoftware.Cloud.V2.Client.Configuration.Default.Username = GDWInfrastructure.ConfigurationHelper.GetScormCloudUsername();
            Com.RusticiSoftware.Cloud.V2.Client.Configuration.Default.Password = GDWInfrastructure.ConfigurationHelper.GetScormCloudPassword();

            try
            {
                var progress = new RegistrationApi().GetRegistrationProgress(course.VersionID.ToString());

                // NOTE: we are considering the user to have "completed" the course only if they passed - a failed attempt does not count as a
                // completion. This is because GDW SCORM courses do not allow you to "fail" in the traditional sense - you simply try repeatedly
                // until you succeed. If in the future we want these courses to behave like GDW course tests (where an email is sent to the
                // employee's supervisor after three successive failures), this API will have to become more complex.
                return progress.RegistrationCompletion == RegistrationCompletion.COMPLETED
                    && progress.RegistrationSuccess == RegistrationSuccess.PASSED;
            }
            catch (Com.RusticiSoftware.Cloud.V2.Client.ApiException e)
            {
                if (e.ErrorCode == 404)
                {
                    // user is not yet registered - return false as clearly they aren't done with the course
                    return false;
                }
                else
                {
                    throw;
                }
            }
        }
    }
}