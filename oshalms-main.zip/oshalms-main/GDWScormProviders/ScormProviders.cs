﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace GDWScormProviders
{
    public static class ScormProviders
    {
        public static IEnumerable<IScormProvider> GetScormProviders()
        {
            return from type in typeof(IScormProvider).Assembly.GetTypes()
                   where typeof(IScormProvider).IsAssignableFrom(type) && type.GetConstructor(Type.EmptyTypes) != null
                   select (IScormProvider) type.GetConstructor(Type.EmptyTypes).Invoke(new object[0]);
        }
        public static IScormProvider GetScormProvider(string id)
        {
            return GetScormProviders().Where(provider => provider.ID == id).SingleOrDefault();
        }
    }
}
