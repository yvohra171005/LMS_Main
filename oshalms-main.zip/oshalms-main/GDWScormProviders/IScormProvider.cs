﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWScormProviders
{
    /// <summary>
    /// Interface definition for a SCORM provider class. A SCORM provider is a third-party service that
    /// hosts SCORM content for Good Day's Work. This polymorphic architecture allows for multiple SCORM
    /// providers to be used together.
    /// <br></br>
    /// To add support for a new SCORM provider, just create a class in the GDWScormProviders project. This class must implement
    /// IScormProvider, and have a public parameterless constructor.
    /// At runtime, the application will reflect on GDWScormProviders.dll to select the correct provider.
    /// </summary>
    public interface IScormProvider
    {
        /// <summary>
        /// The name of this SCORM provider. This name is displayed to the user, when the user selects a SCORM provider to use.
        /// Therefore, it should be in the current user's language (i.e. using <c>GDWWebUser.CurrentUser.GetResourceString(...)</c>)
        /// </summary>
        string Name { get; }

        /// <summary>
        /// An ID used to refer to this provider. This ID is stored in the database and used to match a SCORM course to its provider.
        /// <br></br>
        /// Make sure that it is unique across all the other SCORM providers, and make sure it is a constant that never changes!
        /// </summary>
        string ID { get; }

        /// <summary>
        /// A short description of the semantic meaning of the <c>classHandle</c> parameter. For example, some SCORM providers use a string ID
        /// to refer to their courses. Since the classHandle refers to the SCORM class's ID, <c>ClassHandleLabel</c> could return "Class ID".
        /// Other SCORM providers simply provide a URL to access the course. In this case, <c>ClassHandleLabel</c> could return "Class Link".
        /// <br></br>
        /// This label is displayed to the user to describe what to enter for a class's handle.
        /// Therefore, it should be in the current user's language (i.e. using <c>GDWWebUser.CurrentUser.GetResourceString(...)</c>)
        /// </summary>
        string ClassHandleLabel { get; }

        /// <summary>
        /// Called whenever a new SCORM class is imported into Good Day's Work using the "Add Class Version" form.
        /// Implementations may use this method to check that the SCORM course actually exists, or to perform one-time initialization work before the course is imported.
        /// </summary>
        /// <param name="classHandle">
        /// An 'ID' that is used to refer to the course. Each SCORM provider may have different semantics surrounding
        /// what the class handle should represent (for example, some providers may use the course's primary key in the SCORM provider's database, and some
        /// may use a URL to refer to the course). The only requirement is that the provider must use the class handle to identify the course in the SCORM provider's system.
        /// </param>
        /// <exception cref="GDWInfrastructure.GDWException">
        /// Thrown if the class cannot be imported (for example, if it does not exist in the SCORM provider's database). If this occurs, the import will fail.
        /// </exception>
        void OnCourseImported(string classHandle);

        /// <summary>
        /// Called when a user wishes to view a course.
        /// </summary>
        /// <param name="course">The <c>UserClassVersion</c> containing information from the database, about both the course and the user taking it.
        /// </param>
        /// <param name="classHandle">
        /// An 'ID' that is used to refer to the course. Each SCORM provider may have different semantics surrounding
        /// what the class handle should represent (for example, some providers may use the course's primary key in the SCORM provider's database, and some
        /// may use a URL to refer to the course). The only requirement is that the provider must use the class handle to identify the course in the SCORM provider's system.
        /// </param>
        /// <returns>A URL link to the SCORM course.</returns>
        Uri LaunchCourse(GDWDatabase.UserClassVersion course, string classHandle);

        /// <summary>
        /// Called to check whether a user has completed a course.
        /// </summary>
        /// <param name="course">The <c>UserClassVersion</c> containing information from the database, about both the course and the user taking it.
        /// </param>
        /// <param name="classHandle">An 'ID' that is used to refer to the course. For more information, see <see cref="LaunchCourse(GDWDatabase.UserClassVersion, string)"/></param>
        /// <returns><c>true</c> if the course is complete; <c>false</c> otherwise.</returns>
        bool IsCourseComplete(GDWDatabase.UserClassVersion course, string classHandle);
    }
}
