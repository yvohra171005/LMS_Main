﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWDatabase;

namespace GDWModels.Dashboard
{
	public class WidgetDefinition
	{
		public int widgetId { get; set; }
		public string widgetName { get; set; }
		public string widgetNameKey { get; set; }
		public int widgetWidth { get; set; }
		public int displayOrder { get; set; }
		public GDWPermissionTypes.Permissions requiredPermission { get; set; }
		public string url { get; set; }
		public bool allCustomerUsers { get; set; }
		public bool allUsers { get; set; }

		public WidgetDefinition()
		{
			displayOrder = -1;
			allCustomerUsers = false;
			allUsers = false;
		}

		public static IEnumerable<WidgetDefinition> GetFullList()
		{
			return new List<WidgetDefinition>()
				{
					new WidgetDefinition() { widgetId = 10, widgetNameKey = "SafetyDirectors", widgetWidth = 6, requiredPermission = GDWPermissionTypes.Permissions.TakeClass, url = "/Dashboard/SafetyContact", allCustomerUsers = true },
		
					new WidgetDefinition() { widgetId = 11, widgetNameKey = "CurrentClassStatus", widgetWidth = 6, requiredPermission = GDWPermissionTypes.Permissions.TakeClass, url = "/Dashboard/CurrentClassStatus" },
					new WidgetDefinition() { widgetId = 12, widgetNameKey = "CurrentClassStatusFarm", widgetWidth = 6, requiredPermission = GDWPermissionTypes.Permissions.ViewEmployee, url = "/Dashboard/CurrentClassStatusFarm" },
					new WidgetDefinition() { widgetId = 13, widgetNameKey = "CurrentClassStatusSystem", widgetWidth = 6, requiredPermission = GDWPermissionTypes.Permissions.ImpersonateCustomer, url = "/Dashboard/CurrentClassStatusSystem" },

					new WidgetDefinition() { widgetId = 14, widgetNameKey = "CreditReport", widgetWidth = 6, requiredPermission = GDWPermissionTypes.Permissions.ManageCreditsAndEmployees, url = "/Dashboard/CreditReport" },
					new WidgetDefinition() { widgetId = 15, widgetNameKey = "CreditReportSystem", widgetWidth = 6, requiredPermission = GDWPermissionTypes.Permissions.ImpersonateCustomer, url = "/Dashboard/CreditReportSystem" },
		
					new WidgetDefinition() { widgetId = 16, widgetNameKey = "ClassPassing", widgetWidth = 6, requiredPermission = GDWPermissionTypes.Permissions.TakeClass, url = "/Dashboard/ClassPassingWidget" },
					new WidgetDefinition() { widgetId = 17, widgetNameKey = "ClassPassingFarm", widgetWidth = 6, requiredPermission = GDWPermissionTypes.Permissions.ViewEmployee, url = "/Dashboard/ClassPassingWidgetFarm" },
					new WidgetDefinition() { widgetId = 18, widgetNameKey = "ClassPassingSystem", widgetWidth = 6, requiredPermission = GDWPermissionTypes.Permissions.ImpersonateCustomer, url = "/Dashboard/ClassPassingWidgetSystem" },

					new WidgetDefinition() { widgetId = 19, widgetNameKey = "SubscriberAnalytics", widgetWidth = 6, requiredPermission = GDWPermissionTypes.Permissions.ImpersonateCustomer, url = "/Dashboard/SubscriberAnalytics" },

					new WidgetDefinition() { widgetId = 20, widgetNameKey = "MostPopularCourses", widgetWidth = 12, requiredPermission = GDWPermissionTypes.Permissions.ImpersonateCustomer, url = "/Dashboard/MostPopularCourse" },

					new WidgetDefinition() { widgetId = 21, widgetNameKey = "Calendar", widgetWidth = 12, requiredPermission = GDWPermissionTypes.Permissions.TakeClass, url = "/Dashboard/Calendar", allUsers = true },

					new WidgetDefinition() { widgetId = 22, widgetNameKey = "FAQs", widgetWidth = 6, requiredPermission = GDWPermissionTypes.Permissions.ManageFAQs, url = "/Dashboard/UnansweredFAQs" },

					// any new widget added - make sure that the string version of the permission is in the translated string set
				};
		}
	}
}
