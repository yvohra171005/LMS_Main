﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Dashboard
{
	public class WidgetSummary
	{
		public string name { get; set; }
		public string permission { get; set; }
		public string widthDisplay { get; set; }
	}
}
