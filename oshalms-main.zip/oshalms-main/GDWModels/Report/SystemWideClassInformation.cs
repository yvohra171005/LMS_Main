﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper.Configuration;

namespace GDWModels.Report
{
	public class SystemWideClassInformation : IReportResults
	{
		public string className { get; set; }
		public int numAssignments { get; set; }
		public double avgScoreFirstAttempt { get; set; }
		public double avgAttemptsToPass { get; set; }
		public int numAttemptsMoreThree { get; set; }

		#region IReportResults Members

		public List<ReportDetail> headers
		{
			get
			{
				return new List<ReportDetail>() { 
					new ReportDetail( "Class Name" ), 
					new ReportDetail( "# Times Assigned", "text-right" ), 
					new ReportDetail( "Average Score on First Attempt", "text-right" ), 
					new ReportDetail( "Average # of Attempts to Pass", "text-right" ), 
					new ReportDetail( "# of Attempts > 3", "text-right" ), 
				};
			}
		}

		public List<ReportDetail> items
		{
			get
			{
				return new List<ReportDetail>()
				{
					new ReportDetail( className ),
					new ReportDetail( numAssignments.ToString(), "text-right" ),
					new ReportDetail( avgScoreFirstAttempt.ToString( "F0" ), "text-right" ),
					new ReportDetail( avgAttemptsToPass.ToString( "F2" ), "text-right" ),
					new ReportDetail( numAttemptsMoreThree.ToString(), "text-right" ),
				};
			}
		}

		#endregion
	}

	public class SystemWideClassMap : CsvClassMap<SystemWideClassInformation>
	{
		public SystemWideClassMap()
		{
			Map( m => m.className ).Name( "Class Name" );
			Map( m => m.numAssignments ).Name( "# Times Assigned" );
			Map( m => m.avgScoreFirstAttempt ).Name( "Average Score on First Attempt" ).TypeConverterOption( "F0" );
			Map( m => m.avgAttemptsToPass ).Name( "Average # of Attempts to Pass" ).TypeConverterOption( "F2" );
			Map( m => m.numAttemptsMoreThree ).Name( "# of Attempts > 3" );
		}
	}
}
