﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Report
{
	public class ReportFilter
	{
		public DateTime? startDate { get; set; }
		public DateTime? endDate { get; set; }
		public int? customerId { get; set; }
		public string oshaOnly { get; set; }
		public string sortBy { get; set; }
		public int? classId { get; set; }
		public int? languageId { get; set; }
		public bool isBlank { get; set; }
		public string employeeStatus { get; set; }
	}
}
