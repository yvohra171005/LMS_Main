﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWInfrastructure;

namespace GDWModels.Report
{
	public class ReportInformation
	{
		public int reportId { get; set; }
		public string name { get; set; }
		public ReportDefinition.ReportFilterSet filterSet { get; set; }
		public string viewURL { get; set; }
		public string downloadURL { get; set; }
	}
}
