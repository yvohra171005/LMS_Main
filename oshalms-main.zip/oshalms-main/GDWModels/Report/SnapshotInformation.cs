﻿using CsvHelper.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;

namespace GDWModels.Report
{
	public class SnapshotInformation : IReportResults
	{
		public string EmployeeName { get; set; }
		public string EmailOrUserID { get; set; }
		public string ClassName { get; set; }
		public string AssignedDate { get; set; }
		public string DueDate { get; set; }
		public string Status { get; set; }
		public string CompletedDate { get; set; }
		public string DaysOverDue { get; set; }
		public string FinalScore { get; set; }
		public string Location { get; set; }
		public string Department { get; set; }
		public string ActiveState { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string PhoneNumber { get; set; }
		public string HireDate { get; set; }
		public string Gender { get; set; }
		public string Role { get; set; }
		public string Language { get; set; }
		public string Category { get; set; }
		public string AverageScore { get; set; }

		public List<double?> Scores { get; set; }
		public string Score1
		{
			get
			{
				if( Scores.Any() )
				{
					if( Scores[0].HasValue )
					{
						return Math.Round( Scores[0].Value ).ToString();
					}
				}
				return "";
			}
		}
		public string Score2
		{
			get
			{
				if( Scores.Count > 1 )
				{
					if( Scores[1].HasValue )
					{
						return Math.Round( Scores[1].Value ).ToString();
					}
				}
				return "";
			}
		}
		public string Score3
		{
			get
			{
				if( Scores.Count > 2 )
				{
					if( Scores[2].HasValue )
					{
						return Math.Round( Scores[2].Value ).ToString();
					}
				}
				return "";
			}
		}

		public List<bool> Imports { get; set; }
		public string Import1
		{
			get
			{
				if( Imports.Any() )
				{
					return Imports[0] ? "Import" : "Taken";
				}
				return "";
			}
		}
		public string Import2
		{
			get
			{
				if( Imports.Count > 1 )
				{
					return Imports[1] ? "Import" : "Taken";
				}
				return "";
			}
		}
		public string Import3
		{
			get
			{
				if( Imports.Count > 2 )
				{
					return Imports[2] ? "Import" : "Taken";
				}
				return "";
			}
		}

		#region IReportResults Members

		public List<ReportDetail> headers
		{
			get
			{
				return new List<ReportDetail>() { 
					new ReportDetail( "Employee Name" ), 
					new ReportDetail( "Email/User ID" ), 
					new ReportDetail( "Class Name" ), 
					new ReportDetail( "Assigned Date", "text-right" ), 
					new ReportDetail( "Due Date", "text-right" ), 
					new ReportDetail( "Status" ), 
					new ReportDetail( "Completed Date", "text-right" ), 
					new ReportDetail( "Days Over Due", "text-right" ), 
					new ReportDetail( "Final Score", "text-right" ), 
					new ReportDetail( "Location" ), 
					new ReportDetail( "Department" ), 
					new ReportDetail( "Active/Inactive" ), 
					new ReportDetail( "First Name" ), 
					new ReportDetail( "Last Name" ), 
					new ReportDetail( "Phone Number" ), 
					new ReportDetail( "Hire Date", "text-right" ), 
					new ReportDetail( "Gender" ), 
					new ReportDetail( "Role" ), 
					new ReportDetail( "Language" ), 
					new ReportDetail( "First Attempt Score", "text-right" ), 
					new ReportDetail( "First Attempt Type" ), 
					new ReportDetail( "Second Attempt Score", "text-right" ), 
					new ReportDetail( "Second Attempt Type" ), 
					new ReportDetail( "Third Attempt Score", "text-right" ), 
					new ReportDetail( "Third Attempt Type" ), 
					new ReportDetail( "Average Score", "text-right" ), 
					new ReportDetail( "Category" ), 
				};
			}
		}

		public List<ReportDetail> items
		{
			get
			{
				return new List<ReportDetail>()
				{
					new ReportDetail( EmployeeName ),
					new ReportDetail( EmailOrUserID ),
					new ReportDetail( ClassName ),
					new ReportDetail( AssignedDate, "text-right" ),
					new ReportDetail( DueDate, "text-right" ),
					new ReportDetail( Status ),
					new ReportDetail( CompletedDate, "text-right" ),
					new ReportDetail( DaysOverDue, "text-right" ),
					new ReportDetail( FinalScore, "text-right" ),
					new ReportDetail( Location ),
					new ReportDetail( Department ),
					new ReportDetail( ActiveState ),
					new ReportDetail( FirstName ),
					new ReportDetail( LastName ),
					new ReportDetail( PhoneNumber ),
					new ReportDetail( HireDate, "text-right" ),
					new ReportDetail( Gender ),
					new ReportDetail( Role ),
					new ReportDetail( Language ),
					new ReportDetail( Score1, "text-right" ),
					new ReportDetail( Import1 ),
					new ReportDetail( Score2, "text-right" ),
					new ReportDetail( Import2 ),
					new ReportDetail( Score3, "text-right" ),
					new ReportDetail( Import3 ),
					new ReportDetail( AverageScore, "text-right" ),
					new ReportDetail( Category ),
				};
			}
		}

		#endregion
	}

	public class SnapshotInfoMap : CsvClassMap<SnapshotInformation>
	{
		public SnapshotInfoMap()
		{
			Map( m => m.EmployeeName ).Name( "Employee Name" );
			Map( m => m.EmailOrUserID ).Name( "Email/User ID" );
			Map( m => m.ClassName ).Name( "Class Name" );
			Map( m => m.AssignedDate ).Name( "Assigned Date" );
			Map( m => m.DueDate ).Name( "Due Date" );
			Map( m => m.Status ).Name( "Status" );
			Map( m => m.CompletedDate ).Name( "Completed Date" );
			Map( m => m.DaysOverDue ).Name( "Days Over Due" );
			Map( m => m.FinalScore ).Name( "Final Score" );
			Map( m => m.Location ).Name( "Location" );
			Map( m => m.Department ).Name( "Department" );
			Map( m => m.ActiveState ).Name( "Active/Inactive" );
			Map( m => m.FirstName ).Name( "First Name" );
			Map( m => m.LastName ).Name( "Last Name" );
			Map( m => m.PhoneNumber ).Name( "Phone Number" );
			Map( m => m.HireDate ).Name( "Hire Date" );
			Map( m => m.Gender ).Name( "Gender" );
			Map( m => m.Role ).Name( "Role" );
			Map( m => m.Language ).Name( "Language" );
			Map( m => m.Score1 ).Name( "First Attempt Score" );
			Map( m => m.Import1 ).Name( "First Attempt Type" );
			Map( m => m.Score2 ).Name( "Second Attempt Score" );
			Map( m => m.Import2 ).Name( "Second Attempt Type" );
			Map( m => m.Score3 ).Name( "Third Attempt Score" );
			Map( m => m.Import3 ).Name( "Third Attempt Type" );
			Map( m => m.AverageScore ).Name( "Average Score" );
			Map( m => m.Category ).Name( "Category" );
		}
	}
}
