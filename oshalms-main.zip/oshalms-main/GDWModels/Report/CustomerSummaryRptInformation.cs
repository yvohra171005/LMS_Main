﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper.Configuration;

namespace GDWModels.Report
{
	public class CustomerSummaryRptInformation : IReportResults
	{
		public string customerName { get; set; }
		public int? numCredits { get; set; }
		public int numVideoViews { get; set; }
		public int numQuizzesPassed { get; set; }
		public double avgScoreLastAttempt { get; set; }

		#region IReportResults Members

		public List<ReportDetail> headers
		{
			get
			{
				return new List<ReportDetail>() { 
					new ReportDetail( "Customer Name" ), 
					new ReportDetail( "# Credits", "text-right" ), 
					new ReportDetail( "# Video Views", "text-right" ), 
					new ReportDetail( "# Quizzes Passed", "text-right" ), 
					new ReportDetail( "Average Score on Quizzes", "text-right" ), 
				};
			}
		}

		public List<ReportDetail> items
		{
			get
			{
				return new List<ReportDetail>()
				{
					new ReportDetail( customerName ),
					new ReportDetail( numCredits.ToString(), "text-right" ),
					new ReportDetail( numVideoViews.ToString(), "text-right" ),
					new ReportDetail( numQuizzesPassed.ToString(), "text-right" ),
					new ReportDetail( avgScoreLastAttempt.ToString( "F0" ), "text-right" ),
				};
			}
		}

		#endregion
	}

	public class CustomerSummaryRptMap : CsvClassMap<CustomerSummaryRptInformation>
	{
		public CustomerSummaryRptMap()
		{
			Map( m => m.customerName ).Name( "Customer Name" );
			Map( m => m.numCredits ).Name( "# Credits" );
			Map( m => m.numVideoViews ).Name( "# Video Views" );
			Map( m => m.numQuizzesPassed ).Name( "# Quizzes Passed" );
			Map( m => m.avgScoreLastAttempt ).Name( "Average Score on Quizzes" ).TypeConverterOption( "F0" );
		}
	}
}
