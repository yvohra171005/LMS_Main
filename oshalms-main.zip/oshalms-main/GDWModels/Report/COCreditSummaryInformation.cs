﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper.Configuration;

namespace GDWModels.Report
{
	public class COCreditSummaryInformation : IReportResults
	{
		public string monthYear { get; set; }
		public int creditsPurchased { get; set; }
		public int creditsAssigned { get; set; }
		public int creditsUsed { get; set; }
		public decimal creditsAssignedPerUserAccount { get { return (decimal)creditsAssigned / userAccounts; } }
		public int userAccounts { get; set; }

		#region IReportResults Members

		public List<ReportDetail> headers
		{
			get
			{
				return new List<ReportDetail>() { 
					new ReportDetail( "Month and Year" ), 
					new ReportDetail( "Credits Purchased", "text-right" ), 
					new ReportDetail( "Credits Assigned", "text-right" ), 
					new ReportDetail( "Credits Used", "text-right" ), 
					new ReportDetail( "Credits Assigned per User Account", "text-right" ), 
				};
			}
		}

		public List<ReportDetail> items
		{
			get
			{
				return new List<ReportDetail>()
				{
					new ReportDetail( monthYear ),
					new ReportDetail( creditsPurchased.ToString(), "text-right" ),
					new ReportDetail( creditsAssigned.ToString(), "text-right" ),
					new ReportDetail( creditsUsed.ToString(), "text-right" ),
					new ReportDetail( creditsAssignedPerUserAccount.ToString( "F2" ), "text-right" ),
				};
			}
		}

		#endregion
	}

	public class COCreditSummaryMap : CsvClassMap<COCreditSummaryInformation>
	{
		public COCreditSummaryMap()
		{
			Map( m => m.monthYear ).Name( "Month and Year" );
			Map( m => m.creditsPurchased ).Name( "Credits Purchased" );
			Map( m => m.creditsAssigned ).Name( "Credits Assigned" );
			Map( m => m.creditsUsed ).Name( "Credits Used" );
			Map( m => m.creditsAssignedPerUserAccount ).Name( "Credits Assigned per User Account" ).TypeConverterOption( "F2" );
		}
	}
}
