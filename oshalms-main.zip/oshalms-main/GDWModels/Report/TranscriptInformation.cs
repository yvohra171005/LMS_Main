﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper.Configuration;

namespace GDWModels.Report
{
	public class TranscriptInformation
	{
		public string EmployeeName { get; set; }
		public string ClassName { get; set; }
		public string AssignedDate { get; set; }
		public string DueDate { get; set; }
		public string CompletedDate { get; set; }
		public string Score { get; set; }
		public string Score1 { get; set; }
		public string Score2 { get; set; }
		public string Score3 { get; set; }
		public string TestType1 { get; set; }
		public string TestType2 { get; set; }
		public string TestType3 { get; set; }
	}

	public class TranscriptMap : CsvClassMap<TranscriptInformation>
	{
		public TranscriptMap()
		{
			Map( m => m.EmployeeName ).Name( "Employee Name" );
			Map( m => m.ClassName ).Name( "Class Name" );
			Map( m => m.AssignedDate ).Name( "Assigned Date" );
			Map( m => m.DueDate ).Name( "Due Date" );
			Map( m => m.CompletedDate ).Name( "Completed Date" );
			Map( m => m.Score ).Name( "Final Score" );
			Map( m => m.Score1 ).Name( "First Attempt Score" );
			Map( m => m.TestType1 ).Name( "First Attempt Type" );
			Map( m => m.Score2 ).Name( "Second Attempt Score" );
			Map( m => m.TestType2 ).Name( "Second Attempt Type" );
			Map( m => m.Score3 ).Name( "Third Attempt Score" );
			Map( m => m.TestType3 ).Name( "Third Attempt Type" );
		}
	}
}
