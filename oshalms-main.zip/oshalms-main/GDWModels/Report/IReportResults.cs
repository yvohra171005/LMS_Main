﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Report
{
	public interface IReportResults
	{
		List<ReportDetail> headers { get; }
		List<ReportDetail> items { get; }
	}
}
