﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Report
{
	public class TranscriptFilter
	{
		public int customerId { get; set; }
		public DateTime startDate { get; set; }
		public DateTime endDate { get; set; }
		public IEnumerable<int> locations { get; set; }
		public IEnumerable<int> departments { get; set; }
		public IEnumerable<int> employees { get; set; }
		public IEnumerable<string> categories { get; set; }
		public IEnumerable<int> classes { get; set; }
		public string status { get; set; }

		public static TranscriptFilter ForEmployee( int userId, int customer )
		{
			return new TranscriptFilter()
			{
				customerId = customer,
				employees = new List<int>() { userId },
				startDate = new DateTime( 2014, 1, 1 ),
				endDate = DateTime.Now,
				status = "all"
			};
		}
	}
}
