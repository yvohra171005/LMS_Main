﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper.Configuration;

namespace GDWModels.Report
{
	public class COClassReportInformation : IReportResults
	{
		public int classId { get; set; }
		public string className { get; set; }
		public int numAssignments { get; set; }
		public int numViews { get; set; }
		public decimal numViewsPerUserAccount { get { return numUserAccounts > 0 ? (decimal)numViews / numUserAccounts : 0; } }
		public double avgScoreAttempt1 { get; set; }
		public decimal percPassedAttempt1 { get { return numCompleteQuiz > 0 ? (decimal)numPassedAttempt1 / numCompleteQuiz : 0; } }
		public double avgScoreAttempt2 { get; set; }
		public decimal percPassedAttempt2 { get { return numCompleteQuiz > 0 ? (decimal)numPassedAttempt2 / numCompleteQuiz : 0; } }
		public double avgScoreAttempt3 { get; set; }
		public decimal percPassedAttempt3 { get { return numCompleteQuiz > 0 ? (decimal)numPassedAttempt3 / numCompleteQuiz : 0; } }
		public decimal percMoreThanAttempt3 { get { return numCompleteQuiz > 0 ? (decimal)numMoreThanAttempt3 / numCompleteQuiz : 0; } }
		public decimal percClassesCompletedByDueDate { get { return numAssignments > 0 ? (decimal)numClassesCompletedByDueDate / numAssignments : 0; } }
		public decimal percClassesOverdue { get { return numAssignments > 0 ? (decimal)numClassesOverdue / numAssignments : 0; } }
		public int numScreenings { get; set; }

		public int numPassedAttempt1 { get; set; }
		public int numPassedAttempt2 { get; set; }
		public int numPassedAttempt3 { get; set; }
		public int numMoreThanAttempt3 { get; set; }
		public int numClassesCompletedByDueDate { get; set; }
		public int numClassesOverdue { get; set; }
		public int numUserAccounts { get; set; }
		public int numCompleteQuiz { get; set; }

		#region IReportResults Members

		public List<ReportDetail> headers
		{
			get
			{
				return new List<ReportDetail>() { 
					new ReportDetail( "Class Name" ), 
					new ReportDetail( "# Times Assigned", "text-right" ), 
					new ReportDetail( "# Times Viewed", "text-right" ), 
					new ReportDetail( "# Times Viewed per User Account", "text-right" ), 
					new ReportDetail( "Avg Score / % Passed on First Attempt", "text-right" ), 
					new ReportDetail( "Avg Score / % Passed on Second Attempt", "text-right" ), 
					new ReportDetail( "Avg Score / % Passed on Third Attempt", "text-right" ), 
					new ReportDetail( "% More Than Three Attempts", "text-right" ), 
					new ReportDetail( "% Completed by Due Date", "text-right" ), 
					new ReportDetail( "% Overdue", "text-right" ), 
					new ReportDetail( "# Screenings", "text-right" ),
				};
			}
		}

		public List<ReportDetail> items
		{
			get
			{
				return new List<ReportDetail>()
				{
					new ReportDetail( className ),
					new ReportDetail( numAssignments.ToString(), "text-right" ),
					new ReportDetail( numViews.ToString(), "text-right" ),
					new ReportDetail( numViewsPerUserAccount.ToString( "F2" ), "text-right" ),
					new ReportDetail( avgScoreAttempt1.ToString( "F0" ) + " / " + percPassedAttempt1.ToString( "P2" ), "text-right" ),
					new ReportDetail( avgScoreAttempt2.ToString( "F0" ) + " / " + percPassedAttempt2.ToString( "P2" ), "text-right" ),
					new ReportDetail( avgScoreAttempt3.ToString( "F0" ) + " / " + percPassedAttempt3.ToString( "P2" ), "text-right" ),
					new ReportDetail( percMoreThanAttempt3.ToString( "P2" ), "text-right" ),
					new ReportDetail( percClassesCompletedByDueDate.ToString( "P2" ), "text-right" ),
					new ReportDetail( percClassesOverdue.ToString( "P2" ), "text-right" ),
					new ReportDetail( numScreenings.ToString(), "text-right" ),
				};
			}
		}

		#endregion
	}

	public class COClassReportMap : CsvClassMap<COClassReportInformation>
	{
		public COClassReportMap()
		{
			Map( m => m.className ).Name( "Class Name" );
			Map( m => m.numAssignments ).Name( "# Times Assigned" );
			Map( m => m.numViews ).Name( "# Times Viewed" );
			Map( m => m.numViewsPerUserAccount ).Name( "# Times Viewed per User Account" ).TypeConverterOption( "F2" );
			Map( m => m.avgScoreAttempt1 ).Name( "Avg Score on First Attempt" ).TypeConverterOption( "F0" );
			Map( m => m.percPassedAttempt1 ).Name( "% Passed on First Attempt" ).TypeConverterOption( "P2" );
			Map( m => m.avgScoreAttempt2 ).Name( "Avg Score on Second Attempt" ).TypeConverterOption( "F0" );
			Map( m => m.percPassedAttempt2 ).Name( "% Passed on Second Attempt" ).TypeConverterOption( "P2" );
			Map( m => m.avgScoreAttempt3 ).Name( "Avg Score on Third Attempt" ).TypeConverterOption( "F0" );
			Map( m => m.percPassedAttempt3 ).Name( "% Passed on Third Attempt" ).TypeConverterOption( "P2" );
			Map( m => m.percMoreThanAttempt3 ).Name( "% More Than Three Attempts" ).TypeConverterOption( "P2" );
			Map( m => m.percClassesCompletedByDueDate ).Name( "% Completed by Due Date" ).TypeConverterOption( "P2" );
			Map( m => m.percClassesOverdue ).Name( "% Overdue" ).TypeConverterOption( "P2" );
			Map( m => m.numScreenings ).Name( "# Screenings" );
		}
	}
}
