﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper.Configuration;

namespace GDWModels.Report
{
	public class CustomerCreditInformation : IReportResults
	{
		public string customerName { get; set; }
		public string purchaseDate { get; set; }
		public string expirationDate { get; set; }
		public int creditsPurchased { get; set; }
		public int creditsUsed { get; set; }
		public int creditsUnassigned { get; set; }
		public int creditsAssignedNew { get; set; }
		public decimal creditsPerUserAccount { get { return userAccounts > 0 ? ((decimal)creditsUsed / userAccounts) : 0; } }
		public decimal costPerCredit { get { return creditsPurchased > 0 ? (totalCreditValue / creditsPurchased) : 0; } }
		public decimal totalCreditValue { get; set; }
		public int userAccounts { get; set; }

		#region IReportResults Members

		public List<ReportDetail> headers
		{
			get
			{
				return new List<ReportDetail>() { 
					new ReportDetail( "Customer Name" ), 
					new ReportDetail( "Original Purchase Date", "text-right" ), 
					new ReportDetail( "Expiration Date", "text-right" ), 
					new ReportDetail( "# Credits Purchased", "text-right" ), 
					new ReportDetail( "# Used", "text-right" ), 
					new ReportDetail( "# Unassigned", "text-right" ), 
					new ReportDetail( "# Assigned but Not Used", "text-right" ), 
					new ReportDetail( "# Credits Used per User Account", "text-right" ), 
					new ReportDetail( "Cost per Credit Purchased", "text-right" ), 
					new ReportDetail( "Total Value of Credits Purchased", "text-right" ) 
				};
			}
		}

		public List<ReportDetail> items
		{
			get
			{
				return new List<ReportDetail>()
				{
					new ReportDetail( customerName ),
					new ReportDetail( purchaseDate, "text-right" ),
					new ReportDetail( expirationDate, "text-right" ),
					new ReportDetail( creditsPurchased.ToString(), "text-right" ),
					new ReportDetail( creditsUsed.ToString(), "text-right" ),
					new ReportDetail( creditsUnassigned.ToString(), "text-right" ),
					new ReportDetail( creditsAssignedNew.ToString(), "text-right" ),
					new ReportDetail( creditsPerUserAccount.ToString( "F2" ), "text-right" ),
					new ReportDetail( costPerCredit.ToString( "C" ), "text-right" ),
					new ReportDetail( totalCreditValue.ToString( "C" ), "text-right" )
				};
			}
		}

		#endregion
	}

	public class CustomerCreditMap : CsvClassMap<CustomerCreditInformation>
	{
		public CustomerCreditMap()
		{
			Map( m => m.customerName ).Name( "Customer Name" );
			Map( m => m.purchaseDate ).Name( "Original Purchase Date" );
			Map( m => m.expirationDate ).Name( "Expiration Date" );
			Map( m => m.creditsPurchased ).Name( "# Credits Purchased" );
			Map( m => m.creditsUsed ).Name( "# Used" );
			Map( m => m.creditsUnassigned ).Name( "# Unassigned" );
			Map( m => m.creditsAssignedNew ).Name( "# Assigned but Not Used" );
			Map( m => m.creditsPerUserAccount ).Name( "# Credits Used per User Account" ).TypeConverterOption( "F2" );
			Map( m => m.costPerCredit ).Name( "Cost per Credit Purchased" ).TypeConverterOption( "C" );
			Map( m => m.totalCreditValue ).Name( "Total Value of Credits Purchased" ).TypeConverterOption( "C" );
		}
	}
}
