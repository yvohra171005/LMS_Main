﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper.Configuration;

namespace GDWModels.Report
{
	public class CustomerClassInformation : IReportResults
	{
		public string customerName { get; set; }
		public string purchaseDate { get; set; }
		public string expirationDate { get; set; }
		public int classesAssigned { get; set; }
		public int classesViewed { get; set; }
		public int classesNoQuizAttempts { get; set; }
		public decimal classesViewPerUserAccount { get { return userAccounts > 0 ? ((decimal)classesViewed / userAccounts) : 0; } }
		public double avgScoreFirstAttempt { get; set; }
		public int userAccounts { get; set; }

		#region IReportResults Members

		public List<ReportDetail> headers
		{
			get
			{
				return new List<ReportDetail>() { 
					new ReportDetail( "Customer Name" ), 
					new ReportDetail( "Original Purchase Date", "text-right" ), 
					new ReportDetail( "Expiration Date", "text-right" ), 
					new ReportDetail( "# Classes Assigned", "text-right" ), 
					new ReportDetail( "# Classes Viewed", "text-right" ), 
					new ReportDetail( "# Classes Viewed per User Account", "text-right" ), 
					new ReportDetail( "Average Score on First Quiz Attempt", "text-right" ), 
					new ReportDetail( "Classes Viewed with No Quiz Attempts", "text-right" ), 
				};
			}
		}

		public List<ReportDetail> items
		{
			get
			{
				return new List<ReportDetail>()
				{
					new ReportDetail( customerName ),
					new ReportDetail( purchaseDate, "text-right" ),
					new ReportDetail( expirationDate, "text-right" ),
					new ReportDetail( classesAssigned.ToString(), "text-right" ),
					new ReportDetail( classesViewed.ToString(), "text-right" ),
					new ReportDetail( classesViewPerUserAccount.ToString( "F2" ), "text-right" ),
					new ReportDetail( avgScoreFirstAttempt.ToString( "F0" ), "text-right" ),
					new ReportDetail( classesNoQuizAttempts.ToString(), "text-right" ),
				};
			}
		}

		#endregion
	}

	public class CustomerClassMap : CsvClassMap<CustomerClassInformation>
	{
		public CustomerClassMap()
		{
			Map( m => m.customerName ).Name( "Customer Name" );
			Map( m => m.purchaseDate ).Name( "Original Purchase Date" );
			Map( m => m.expirationDate ).Name( "Expiration Date" );
			Map( m => m.classesAssigned ).Name( "# Classes Assigned" );
			Map( m => m.classesViewed ).Name( "# Classes Viewed" );
			Map( m => m.classesViewPerUserAccount ).Name( "# Classes Viewed per User Account" ).TypeConverterOption( "F2" );
			Map( m => m.avgScoreFirstAttempt ).Name( "Average Score on First Quiz Attempt" ).TypeConverterOption( "F0" );
			Map( m => m.classesNoQuizAttempts ).Name( "Classes Viewed with No Quiz Attempts" );
		}
	}
}
