﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Report
{
	public class ReportDetail
	{
		public ReportDetail( string v )
		{
			value = v;
			displayClass = null;
		}

		public ReportDetail( string v, string c )
		{
			value = v;
			displayClass = c;
		}

		public string value { get; set; }
		public string displayClass { get; set; }
	}

	public class ReportResults<T> where T : IReportResults
	{
		public ReportResults( List<T> theData, bool empty )
		{
			headers = Activator.CreateInstance<T>().headers;

			items = theData.Select( d => d.items );

			isBlank = empty;
		}

		public IEnumerable<ReportDetail> headers { get; set; }
		public IEnumerable<IEnumerable<ReportDetail>> items { get; set; }
		public bool isBlank { get; set; }
	}
}
