﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper.Configuration;

namespace GDWModels.Report
{
	public class PurchaseReportInformation : IReportResults
	{
		public string customerName { get; set; }
		public string customerAddress { get; set; }
		public string customerContact { get; set; }
		public string phoneNumber { get; set; }
		public decimal totalAmount { get; set; }
		public int invoiceNumber { get; set; }
		public string transactionNumber { get; set; }
		public DateTime orderDate { get; set; }
		public DateTime? paymentDate { get; set; }
		public string paymentType { get; set; }
		public int credits { get; set; }
		public int userAccounts { get; set; }
		public string couponCode { get; set; }

		#region IReportResults Members

		public List<ReportDetail> headers
		{
			get
			{
				return new List<ReportDetail>() { 
					new ReportDetail( "Invoice Number" ),
					new ReportDetail( "Order Date" ),
					new ReportDetail( "Customer Name" ),
					new ReportDetail( "Customer Address" ),
					new ReportDetail( "Customer Contact" ),
					new ReportDetail( "Customer Phone Number" ),
					new ReportDetail( "Credits", "text-right" ),
					new ReportDetail( "User Accounts", "text-right" ),
					new ReportDetail( "Coupon Code", "text-right" ),
					new ReportDetail( "Total Amount", "text-right" ),
					new ReportDetail( "Payment Date" ),
					new ReportDetail( "Payment Type" ),
					new ReportDetail( "Transaction Number" ),
				};
			}
		}

		public List<ReportDetail> items
		{
			get
			{
				return new List<ReportDetail>()
				{
					new ReportDetail( invoiceNumber.ToString() ),
					new ReportDetail( orderDate.ToShortDateString() ),
					new ReportDetail( customerName ),
					new ReportDetail( customerAddress ),
					new ReportDetail( customerContact ),
					new ReportDetail( phoneNumber ),
					new ReportDetail( credits.ToString(), "text-right" ),
					new ReportDetail( userAccounts.ToString(), "text-right" ),
					new ReportDetail( couponCode, "text-right" ),
					new ReportDetail( totalAmount.ToString( "C" ), "text-right" ),
					new ReportDetail( paymentDate.HasValue ? paymentDate.Value.ToShortDateString() : "N/A" ),
					new ReportDetail( paymentType ),
					new ReportDetail( transactionNumber ),
				};
			}
		}

		#endregion
	}

	public class PurchaseReportMap : CsvClassMap<PurchaseReportInformation>
	{
		public PurchaseReportMap()
		{
			Map( m => m.invoiceNumber ).Name( "Invoice Number" );
			Map( m => m.orderDate ).Name( "Order Date" );
			Map( m => m.customerName ).Name( "Customer Name" );
			Map( m => m.customerAddress ).Name( "Customer Address" );
			Map( m => m.customerContact ).Name( "Customer Contact" );
			Map( m => m.phoneNumber ).Name( "Customer Phone Number" );
			Map( m => m.credits ).Name( "Credits" );
			Map( m => m.userAccounts ).Name( "User Accounts" );
			Map( m => m.couponCode ).Name( "Coupon Code" );
			Map( m => m.totalAmount ).Name( "Total Amount" ).TypeConverterOption( "C" );
			Map( m => m.paymentDate ).Name( "Payment Date" );
			Map( m => m.paymentType ).Name( "Payment Type" );
			Map( m => m.transactionNumber ).Name( "Transaction Number" );
		}
	}
}
