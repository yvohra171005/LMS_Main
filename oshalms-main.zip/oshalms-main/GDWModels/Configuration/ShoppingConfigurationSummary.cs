﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Configuration
{
	public class ShoppingConfigurationSummary
	{
		public int oshaMinimum { get; set; }
		public decimal costPerEmployee { get; set; }
	}
}
