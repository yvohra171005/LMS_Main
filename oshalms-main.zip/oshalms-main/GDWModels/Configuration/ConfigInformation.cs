﻿namespace GDWModels.Configuration
{
    public class ConfigInformation
    {
        // General information
        //
        public int defaultRole { get; set; }
        public int defaultCredits { get; set; }
        public int defaultEmployees { get; set; }
        public decimal costPerEmployee { get; set; }

        public string eulaVersion { get; set; }
        public string eulaFileName { get; set; }
        public string originalEULAFileName { get; set; }

        public string helpFileName { get; set; }
        public string originalHelpFileName { get; set; }

        // Certificate signature information
        //
        public string logoImageFileName { get; set; }
        public string originalLogoImageFileName { get; set; }

        public string signatureName { get; set; }
        public string signatureTitle { get; set; }

        public string signatureImageFileName { get; set; }
        public string originalSignatureImageFileName { get; set; }
    }
}