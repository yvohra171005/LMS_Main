﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Injury
{
	public class InjurySummary
	{
		public int caseNumber { get; set; }
		public string employeeName { get; set; }
		public string injuryDate { get; set; }
		public string classification { get; set; }
		public int revisions { get; set; }
		public string editButtons { get; set; }
	}
}
