﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Injury
{
	public class InjuryDetailList : List<InjuryDetail>
	{
		public int year { get; set; }
		public string customerName { get; set; }
		public string customerAddress { get; set; }
		public string customerCity { get; set; }
		public string customerState { get; set; }
		public string customerZipCode { get; set; }
		public string locationName { get; set; }
		public string locationAddress { get; set; }
		public string locationCity { get; set; }
		public string locationState { get; set; }
		public string locationZipCode { get; set; }
	}
}
