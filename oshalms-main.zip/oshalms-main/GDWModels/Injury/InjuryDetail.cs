﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWDatabase;

namespace GDWModels.Injury
{
	public class InjuryDetail
	{
		public int caseNumber { get; set; }
		public string employeeName { get; set; }
		public string jobTitle { get; set; }
		public string dateOfInjury { get; set; }
		public string whereOccurred { get; set; }
		public string describeInjury { get; set; }
		public InjuryConstants.CaseClassificationType caseClassification { get; set; }
		public int daysAwayFromWork { get; set; }
		public int daysTransferred { get; set; }
		public InjuryConstants.InjuryIllnessType injuryType { get; set; }

	}
}
