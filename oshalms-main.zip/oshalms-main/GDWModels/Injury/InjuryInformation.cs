﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWInfrastructure;

namespace GDWModels.Injury
{
	public class InjuryInformation
	{
		public int caseNumber { get; set; }
		public GDWInfrastructure.GDWListItem employee { get; set; }
		public string jobTitle { get; set; }
		public DateTime dateOfInjury { get; set; }
		public string whereEventOccurred { get; set; }
		public int caseClassification { get; set; }
		public int? daysAwayFromWork { get; set; }
		public int? daysTransferred { get; set; }
		public int typeOfIllness { get; set; }
		public string address1 { get; set; }
		public string address2 { get; set; }
		public string city { get; set; }
		public string state { get; set; }
		public string zipCode { get; set; }
		public GDWDateObject birth { get; set; }
		public string hcPhysician { get; set; }
		public string mdAddress1 { get; set; }
		public string mdAddress2 { get; set; }
		public string mdCity { get; set; }
		public string mdState { get; set; }
		public string mdZipCode { get; set; }
		public string hcName { get; set; }
		public string hcAddress1 { get; set; }
		public string hcAddress2 { get; set; }
		public string hcCity { get; set; }
		public string hcState { get; set; }
		public string hcZipCode { get; set; }
		public bool hcEmergencyRoom { get; set; }
		public bool hcHospitalized { get; set; }
		public DateTime? startWorkTime { get; set; }
		public DateTime? eventTime { get; set; }
		public DateTime? dateOfDeath { get; set; }
		public int locationID { get; set; }
		public bool isPrivacy { get; set; }

		public string summaryDescription { get; set; }
		public string doingActivity { get; set; }
		public string whatHappened { get; set; }
		public string injuryOrIllness { get; set; }
		public string objectHarmedEmployee { get; set; }

		// form 301 fields
		public string dateHired { get; set; }
		public string gender { get; set; }
		public string completedByName { get; set; }
		public string completedByPhone { get; set; }
		public string completedOnDate { get; set; }
	}
}
