﻿using System;

namespace GDWModels.Customer
{
    public class NoteInformation
    {
        public int noteId { get; set; }
        public int customerId { get; set; }
        public int userId { get; set; }
        public string text { get; set; }

        public DateTime lastUpdated { get; set; }
        public double? lastUpdateMilliseconds
        {
            get
            {
                if( lastUpdated > DateTime.UtcNow )
                    return null;

                return (lastUpdated - (new DateTime( 1970, 1, 1 ))).TotalMilliseconds;
            }
        }

        public string lastUpdatedByUser { get; set; }
    }
}