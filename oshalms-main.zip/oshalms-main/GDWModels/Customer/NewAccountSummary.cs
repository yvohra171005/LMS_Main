﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class NewAccountSummary
	{
		public string companyName { get; set; }
		public string companyAddress1 { get; set; }
		public string companyAddress2 { get; set; }
		public string companyCity { get; set; }
		public string companyState { get; set; }
		public string companyZipCode { get; set; }
		public string companyPhone { get; set; }
		public string locationName { get; set; }
		public string firstName { get; set; }
		public string lastName { get; set; }
		public string emailAddress { get; set; }
		public DateTime? dateOfBirth { get; set; }
		public string gender { get; set; }
		public string enterpriseLevel { get; set; }
	}
}
