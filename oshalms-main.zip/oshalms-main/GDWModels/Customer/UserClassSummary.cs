﻿using System;

namespace GDWModels.Customer
{
    public class UserClassSummary
    {
        public int userID { get; set; }
        public int classID { get; set; }
        public DateTime dueDate { get; set; }
        public int userClassID { get; set; }
    }
}
