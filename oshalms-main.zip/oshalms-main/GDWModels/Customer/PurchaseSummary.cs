﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class PurchaseSummary
	{
		public int purchaseId { get; set; }
		public string transactionDetails { get; set; }
		public string amount { get; set; }
		public DateTime purchaseDate { get; set; }
		public double purchaseDateMilliseconds { get { return (purchaseDate - (new DateTime( 1970, 1, 1 ))).TotalMilliseconds; } }
		public string editButtons { get; set; }
	}
}
