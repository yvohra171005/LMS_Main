﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class CustomerStatus
	{
		public int creditCount { get; set; }
		public int activeEmployees { get; set; }
		public int maxEmployees { get; set; }
		public int expirationDays { get; set; }
		public bool trackCredits { get; set; }
	}
}
