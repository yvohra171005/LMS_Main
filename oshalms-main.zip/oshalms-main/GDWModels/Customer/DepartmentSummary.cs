﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class DepartmentSummary
	{
		public int departmentId { get; set; }
		public string name { get; set; }
		public int employeeCount { get; set; }
		public string editButtons { get; set; }
		public bool isActive { get; set; }
	}
}
