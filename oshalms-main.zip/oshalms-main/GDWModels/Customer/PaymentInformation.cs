﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class PaymentInformation
	{
		public string method { get; set; }

		public bool billMeConfirm { get; set; }

		public string ccNumber { get; set; }
		public string ccCVV { get; set; }
		public string ccNameOnCard { get; set; }
		public int ccMonth { get; set; }
		public int ccYear { get; set; }
		public bool saveCreditCard { get; set; }
		public string maskedCCNumber { get; set; }

		public string eRoutingNumber { get; set; }
		public string eAccountNumber { get; set; }
		public string eAccountType { get; set; }
		public string eNameOnAccount { get; set; }
		public string maskedECheckNumber { get; set; }
		public bool saveECheck { get; set; }

		public string transactionNumber { get; set; }
		public string authorizationCode { get; set; }
	}
}
