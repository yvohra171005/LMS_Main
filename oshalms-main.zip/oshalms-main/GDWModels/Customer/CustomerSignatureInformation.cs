﻿namespace GDWModels.Customer
{
    public class CustomerSignatureInformation
    {
        public int signatureId { get; set; }
        public int customerId { get; set; }

        public string signatureName { get; set; }
        public string signatureTitle { get; set; }

        public string signatureImageFileName { get; set; }
        public string originalSignatureImageFileName { get; set; }
    }
}