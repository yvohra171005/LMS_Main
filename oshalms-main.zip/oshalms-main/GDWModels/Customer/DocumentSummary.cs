﻿using System;

namespace GDWModels.Customer
{
    public class DocumentSummary
    {
        public int documentId { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string editButtons { get; set; }
        public bool isRestricted { get; set; }
        public bool isActive { get; set; }
        public DateTime lastUpdateDate { get; set; }
        public double? lastUpdateDateMilliseconds
        {
            get
            {
                if( lastUpdateDate > DateTime.UtcNow )
                    return null;

                return (lastUpdateDate - (new DateTime( 1970, 1, 1 ))).TotalMilliseconds;
            }
        }
    }
}