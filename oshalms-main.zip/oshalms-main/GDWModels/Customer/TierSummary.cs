﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWInfrastructure;

namespace GDWModels.Customer
{
	public class TierSummary
	{
		public int tierId { get; set; }
		public int minimumCredits { get; set; }
		public decimal costPerCredit { get; set; }
		public string costPerCreditDisplay { get { return costPerCredit.ToCurrency(); } }
		public string editButtons { get; set; }
	}
}
