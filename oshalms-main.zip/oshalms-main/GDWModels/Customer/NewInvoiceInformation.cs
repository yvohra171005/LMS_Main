﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWDatabase;

namespace GDWModels.Customer
{
	public class NewInvoiceInformation
	{
		public int credits { get; set; }
		public decimal creditCost { get; set; }
		public int employees { get; set; }
		public decimal employeeCost { get; set; }
		public string discountCode { get; set; }
		public decimal discountAmt { get; set; }
		public decimal salesTax { get; set; }
		public GDWPaymentMethods.PaymentMethod paymentMethod { get; set; }
		public string paymentDetail { get; set; }
		public string transactionNumber { get; set; }
	}
}
