﻿using System.Collections.Generic;

namespace GDWModels.Customer
{
    public class AssignmentResultInformation
    {
        public List<UserClassSummary> AssignedUserClasses { get; set; }
        public int RemainingCreditCount { get; set; }
    }
}