﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class PaymentTypeInformation
	{
		public string profileId { get; set; }
		public string paymentMethod { get; set; }
		public string maskedAccount { get; set; }
	}
}
