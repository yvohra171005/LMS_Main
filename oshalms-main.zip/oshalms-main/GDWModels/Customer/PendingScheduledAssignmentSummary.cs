﻿using System;
using System.Collections.Generic;

namespace GDWModels.Customer
{
    public class IncompleteScheduledAssignmentSummary
    {
        public int ScheduledAssignmentID { get; set; }
        public int CreatedByUserID { get; set; }
        public int CustomerID { get; set; }

        public string ClassName { get; set; }
        public DateTime AssignmentDate { get; set; }
        public DateTime DueDate { get; set; }
        public IList<string> LocationNames { get; set; }
        public IList<string> DepartmentNames { get; set; }
        public bool CreatedScheduledUserClasses { get; set; }
        public int FailureCount { get; set; }
    }
}