﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class PurchaseInformation
	{
		public int purchaseID { get; set; }
		public DateTime purchaseDate { get; set; }
		public double purchaseDateMilliseconds { get { return (purchaseDate - (new DateTime( 1970, 1, 1 ))).TotalMilliseconds; } }

		public int creditCount { get; set; }
		public int employeeCount { get; set; }
		public decimal perCreditCost { get; set; }
		public decimal perEmployeeCost { get; set; }

		public string customerName { get; set; }
		public string customerContact { get; set; }
		public string customerEmail { get; set; }
		public string customerPhone { get; set; }

		public string paymentMethod { get; set; }
		public string paymentDetail { get; set; }

		public string discountCode { get; set; }
		public decimal discountAmount { get; set; }

		public decimal salesTax { get; set; }

		public decimal totalCost
		{
			get
			{
				return (perCreditCost * creditCount) + (perEmployeeCost * employeeCount) + discountAmount + salesTax;
			}
		}
	}
}
