﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class TierInformation
	{
		public int tierId { get; set; }
		public int minimumCredits { get; set; }
		public decimal costPerCredit { get; set; }
	}
}
