﻿using System;

namespace GDWModels.Customer
{
    public class NoteSummary
    {
        public int noteId { get; set; }
        public string text { get; set; }
        public string editButtons { get; set; }
        public DateTime lastUpdateDate { get; set; }
        public double? lastUpdateDateMilliseconds
        {
            get
            {
                if( lastUpdateDate > DateTime.UtcNow )
                    return null;

                return (lastUpdateDate - (new DateTime( 1970, 1, 1 ))).TotalMilliseconds;
            }
        }
        public string lastUpdatedByUser { get; set; }
    }
}