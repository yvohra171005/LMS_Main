﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class CustomerSummary
	{
		public int customerId { get; set; }
		public string customerName { get; set; }
		public int employeeCount { get; set; }
		public int? employeesRemainingCount { get; set; }
		public int? creditCount { get; set; }
		public string editButtons { get; set; }
		public bool isActive { get; set; }
		public bool isPaid { get; set; }
		public string enterpriseLevel { get; set; }
		public int? availableClassCount { get; set; }
	}
}
