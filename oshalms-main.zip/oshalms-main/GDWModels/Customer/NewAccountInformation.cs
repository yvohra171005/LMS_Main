﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWModels.Discount;

namespace GDWModels.Customer
{
	public class NewAccountInformation
	{
		public int credits { get; set; }
		public int employees { get; set; }
		public int? discountCodeId { get; set; }
		public decimal? discountCodeAmount { get; set; }
		public string discountCode { get; set; }
		public NewAccountSummary accountInfo { get; set; }
		public PaymentInformation payment { get; set; }
		public decimal costPerCredit { get; set; }
		public decimal costPerEmployee { get; set; }
		public decimal salesTax { get; set; }

		public decimal totalAmount
		{
			get
			{
				return (credits * costPerCredit) + (employees * costPerEmployee) + (discountCodeAmount ?? 0);
			}
		}
	}
}
