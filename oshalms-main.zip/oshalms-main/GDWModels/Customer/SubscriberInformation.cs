﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class SubscriberInformation
	{
		public int customers { get; set; }
		public int renewalSoon { get; set; }
		public int userAccounts { get; set; }
		public int activeEmployees { get; set; }
		public int purchasedCredits { get; set; }
		public int outstandingCredits { get; set; }
	}
}
