﻿using System;

namespace GDWModels.Customer
{
    public class ScheduledClassAssignmentSummary
    {
        public int scheduleId { get; set; }
        public string whenCreated { get; set; }
        public string className { get; set; }
        public string assignmentDate { get; set; }
        public string dueDate { get; set; }
        public string locations { get; set; }
        public string departments { get; set; }
        public bool isCompleted { get; set; }
        public bool isStarted { get; set; }
        public bool hasErrors { get; set; }

        // only meaningful if isStarted == true:
        public int totalAssignmentsScheduled { get; set; }
        public int numberOfAssignmentsCompleted { get; set; }

		public string editButtons { get; set; }
    }
}