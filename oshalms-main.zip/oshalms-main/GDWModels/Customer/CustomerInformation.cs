﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using GDWInfrastructure;

namespace GDWModels.Customer
{
	public class CustomerInformation
	{
		public int customerId { get; set; }
		public string name { get; set; }
		public string address1 { get; set; }
		public string address2 { get; set; }
		public string city { get; set; }
		public string state { get; set; }
		public string zipCode { get; set; }
		public string phoneNumber { get; set; }

        public string logoFileName { get; set; }
        public string originalLogoFileName { get; set; }
		
		public string firstName { get; set; }
		public string lastName { get; set; }
		public string emailAddress { get; set; }
		public DateTime? dateOfBirth { get; set; }
		public string gender { get; set; }

		public string enterpriseLevel { get; set; }

		// add fields only
		public string primaryLocation { get; set; }

		// edit fields only
		public DateTime expirationDate { get; set; }
		public int creditsWarning { get; set; }
		public int employeesWarning { get; set; }
		public string classEmailFrequency { get; set; }

		// display fields only
		public int creditCount { get; set; }
		public int maxEmployeeCount { get; set; }
		public bool trackCredits { get; set; }

		public bool isActive { get; set; }

		public IList<GDWListItem> availableClasses { get; set; }
	}
}
