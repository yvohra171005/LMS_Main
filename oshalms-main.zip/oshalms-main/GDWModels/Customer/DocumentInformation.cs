﻿namespace GDWModels.Customer
{
    public class DocumentInformation
    {
        public int documentId { get; set; }
        public int customerId { get; set; }
        public int userId { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public bool isActive { get; set; }
        public bool isRestricted { get; set; }

        public string fileName { get; set; }
        public string originalFileName { get; set; }
    }
}