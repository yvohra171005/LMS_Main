﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class DepartmentInformation
	{
		public int departmentId { get; set; }
		public int customerId { get; set; }
		public string name { get; set; }
		public bool isActive { get; set; }
	}
}
