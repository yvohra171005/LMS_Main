﻿using System;

namespace GDWModels.Customer
{
    public class ScheduledUserClassSummary
    {
        public int ScheduledUserClassID { get; set; }
        public int ScheduledClassAssignmentID { get; set; }
        public int ClassID { get; set; }
        public int UserID { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime WhenCreated { get; set; }
        public DateTime? WhenCompleted { get; set; }
        public int? UserClassID { get; set; }
    }
}