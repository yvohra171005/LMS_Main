﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class LocationInformation
	{
		public int locationId { get; set; }
		public int customerId { get; set; }
		public string name { get; set; }
		public string address1 { get; set; }
		public string address2 { get; set; }
		public string city { get; set; }
		public string state { get; set; }
		public string zipCode { get; set; }
		public bool isActive { get; set; }
		public string sdName { get; set; }
		public string sdPhone { get; set; }
		public string sdCell { get; set; }
		public string sdEmail { get; set; }
	}
}
