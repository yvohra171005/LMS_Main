﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class CreditReportStatus
	{
		public int unassigned { get; set; }
		public int assigned { get; set; }
		public int used { get; set; }
	}
}
