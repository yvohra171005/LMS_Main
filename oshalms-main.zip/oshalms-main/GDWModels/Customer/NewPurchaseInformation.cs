﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class NewPurchaseInformation : PaymentInformation
	{
		public int customerId { get; set; }
		public int newCredits { get; set; }
		public int newEmployees { get; set; }
		public decimal costPerCredit { get; set; }
		public decimal costPerEmployee { get; set; }
		public string profileId { get; set; }
		public decimal totalAmount { get; set; }
		public bool isRenew { get; set; }
		public int? discountCodeId { get; set; }
		public decimal? discountCodeAmount { get; set; }
		public string discountCode { get; set; }
		public decimal salesTax { get; set; }
	}
}
