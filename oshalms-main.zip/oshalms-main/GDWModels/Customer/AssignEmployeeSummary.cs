﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class AssignEmployeeSummary
	{
		public int id { get; set; }
		public string name { get; set; }
		public bool isLocation { get; set; }
		public bool isDepartment { get; set; }
		public int employeeCount { get; set; }
		public string nameField { get; set; }
		public string editButtons { get; set; }
	}
}
