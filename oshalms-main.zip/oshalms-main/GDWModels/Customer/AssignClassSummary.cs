﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Customer
{
	public class AssignClassSummary
	{
		public string id { get; set; }
		public string name { get; set; }
		public bool isCategory { get; set; }
		public int creditsPerEmployee { get; set; }
		public int classCount { get; set; }
		public string nameField { get; set; }
		public string editButtons { get; set; }
	}
}
