﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class MyClassResults
	{
		public int passPercent { get; set; }
		public IEnumerable<MyClassResultQuestion> questions { get; set; }
		public int attempts { get; set; }

		public int correctQuestions { get { return questions.Count( q => q.isCorrect ); } }
		public int totalQuestions { get { return questions.Count(); } }
		public int percentCorrect { get; set; }
		public bool isPassingGrade { get { return percentCorrect >= passPercent; } }
		public bool isImport { get; set; }
	}
}
