﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class ClassVersionInformation
	{
		public int versionId { get; set; }
		public int classId { get; set; }
		public int languageId { get; set; }
		public string languageName { get; set; }
		public string originalCaptionName { get; set; }
		public string newCaptionName { get; set; }
		public bool isActive { get; set; }
		public string classType { get; set; }
		public int? videoId { get; set; }
		public string scormProvider { get; set; }
		public string scormClassHandle { get; set; }
		public string originalPDFName { get; set; }
		public string newPDFName { get; set; }
		public int versionCountForLangauge { get; set; }
		public string originalGuideName { get; set; }
		public string newGuideName { get; set; }
		public IEnumerable<VersionDocumentInfo> documents { get; set; }
		public IEnumerable<VersionDocumentInfo> safetyDocuments { get; set; }
		public IEnumerable<VersionQuestionInfo> questions { get; set; }
	}
}
