﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class LibrarySummary
	{
		public int classId { get; set; }
		public string name { get; set; }
		public bool hasRelatedDocs { get; set; }
		public string relatedDocuments { get; set; }
		public bool hasSafetyDocs { get; set; }
		public string safetyDocuments { get; set; }
	}
}
