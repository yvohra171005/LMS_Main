﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class PopularClassInformation
	{
		public IEnumerable<PopularClassSummary> baseClasses { get; set; }
		public IEnumerable<PopularClassSummary> nonBaseClasses { get; set; }
	}
}
