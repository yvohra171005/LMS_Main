﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class ScoreImportInformation
	{
		public int classId { get; set; }
		public string originalImportName { get; set; }
		public string newImportName { get; set; }
		public DateTime completedDate { get; set; }
		public string originalSignatureFileName { get; set; }
		public string newSignatureFileName { get; set; }
		public bool replaceInProgressClasses { get; set; }
	}
}
