﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class VersionQuestionInfo
	{
		public int questionId { get; set; }
		public string text { get; set; }
		public string narrative { get; set; }
		public int displayOrder { get; set; }
		public bool isActive { get; set; }
		public string imageFileName { get; set; }
		public string originalImageFileName { get; set; }
		public string audioFileName { get; set; }
		public string originalAudioFileName { get; set; }
		public string fullAudioFileName { get; set; }
		public string originalFullAudioFileName { get; set; }
		public IEnumerable<VersionAnswerInfo> answers { get; set; }
	}
}
