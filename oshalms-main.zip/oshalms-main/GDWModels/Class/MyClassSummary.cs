﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class MyClassSummary
	{
		public int userClassId { get; set; }
		public string name { get; set; }
		public DateTime dueDate { get; set; }
		public int progress { get; set; }
		public int score { get; set; }
		public bool isPassingGrade { get; set; }
		public DateTime? completeDate { get; set; }
		public bool hasDocuments { get; set; }

		public string dueDateString { get { return dueDate.ToShortDateString(); } }
		public bool isOverdue { get { return dueDate < DateTime.Now; } }
		public bool isDueSoon { get { return dueDate < DateTime.Now.AddDays( 30 ) && !isOverdue; } }
	}
}
