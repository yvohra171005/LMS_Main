﻿using CsvHelper.Configuration;

namespace GDWModels.Class
{
	public class ScoreImportDetail
	{
		public string firstName { get; set; }
		public string lastName { get; set; }
		public double? score { get; set; }

        // remaining fields are not used by the application but are provided for signatures etc. on hard-copy
        public string signature { get; set; }
	}

	public class ScoreImportDetailMap : CsvClassMap<ScoreImportDetail>
	{
		public ScoreImportDetailMap()
		{
			Map( m => m.firstName ).Name( "First Name" );
			Map( m => m.lastName ).Name( "Last Name" );
			Map( m => m.score ).Name( "Score" );
			Map( m => m.signature ).Name( "Signature" );
		}
	}

	public class ScoreImportError : ScoreImportDetail
	{
		public string error { get; set; }
	}

	public class ScoreImportErrorMap : CsvClassMap<ScoreImportError>
	{
		public ScoreImportErrorMap()
		{
			Map( m => m.firstName ).Name( "First Name" );
			Map( m => m.lastName ).Name( "Last Name" );
			Map( m => m.score ).Name( "Score" );
			Map( m => m.signature ).Name( "Signature" );
			Map( m => m.error ).Name( "Error" );
		}
	}
}
