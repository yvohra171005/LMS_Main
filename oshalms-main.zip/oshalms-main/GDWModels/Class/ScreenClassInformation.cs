﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class ScreenClassInformation
	{
		public int classId { get; set; }
		public string name { get; set; }
		public string description { get; set; }
        public string thirdPartyLogoFileName { get; set; }
        public string customerLogoFileName { get; set; }
		public int languageId { get; set; }
		public string languageName { get; set; }
		public bool isVideo { get; set; }
		public string videoFile { get; set; }
		public string pdfFile { get; set; }
		public IEnumerable<CaptionFileInformation> captions { get; set; }
		public IEnumerable<MyClassDocument> documents { get; set; }
		public IEnumerable<MyClassDocument> safetyDocuments { get; set; }
		public IEnumerable<MyClassFAQ> faqs { get; set; }
		public IEnumerable<MyClassQuestion> questions { get; set; }
	}
}
