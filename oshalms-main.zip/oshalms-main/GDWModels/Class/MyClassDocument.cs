﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class MyClassDocument
	{
		public string displayName { get; set; }
		public string fileName { get; set; }
	}
}
