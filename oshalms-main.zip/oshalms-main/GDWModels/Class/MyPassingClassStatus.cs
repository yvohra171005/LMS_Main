﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class MyPassingClassStatus
	{
		public int inProgress { get; set; }
		public int passedFirstAttempt { get; set; }
		public int passedSecondAttempt { get; set; }
		public int passedThirdAttempt { get; set; }
		public int failedThreeOrMoreAttempt { get; set; }
	}
}
