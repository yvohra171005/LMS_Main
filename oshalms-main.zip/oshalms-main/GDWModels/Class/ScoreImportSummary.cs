﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class ScoreImportSummary
	{
		public string originalFileName { get; set; }
		public string sourceFileName { get; set; }
		public int successRecords { get; set; }
		public int errorRecords { get; set; }
		public string errorFileName { get; set; }
		public string className { get; set; }
		public DateTime importDate { get; set; }
		public double importDateMilliseconds { get { return (importDate - (new DateTime( 1970, 1, 1 ))).TotalMilliseconds; } }
		public string userName { get; set; }
		public string originalSignatureFileName { get; set; }
		public string signatureFileName { get; set; }
	}
}
