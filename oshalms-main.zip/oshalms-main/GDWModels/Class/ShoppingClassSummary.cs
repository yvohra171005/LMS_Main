﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class ShoppingClassSummary
	{
		public string name { get; set; }
		public int credits { get; set; }
		public bool isBaseClass { get; set; }
		public int employees { get; set; }
	}
}
