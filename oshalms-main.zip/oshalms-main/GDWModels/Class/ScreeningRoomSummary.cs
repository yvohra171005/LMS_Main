﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class ScreeningRoomSummary
	{
		public int classId { get; set; }
		public string name { get; set; }
		public int assignments { get; set; }
		public string guideFileName { get; set; }
		public string guideOriginalName { get; set; }
		public string editButtons { get; set; }
	}
}
