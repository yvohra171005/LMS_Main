﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class ClassInformation
	{
		public int classId { get; set; }
		public string name { get; set; }
		public string description { get; set; }
        public string logoFileName { get; set; }
        public string originalLogoFileName { get; set; }
		public int? customerId { get; set; }
		public int passPercent { get; set; }
		public bool randomizeQuestions { get; set; }
		public int? totalQuestionMinimum { get; set; }
		public int? totalQuestionMaximum { get; set; }
		public bool isActive { get; set; }
		public bool isBaseClass { get; set; }
		public IEnumerable<string> categories { get; set; }
		public int creditCount { get; set; }
		public string referenceNumber { get; set; }
	}
}
