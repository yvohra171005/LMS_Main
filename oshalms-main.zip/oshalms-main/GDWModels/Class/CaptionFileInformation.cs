﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class CaptionFileInformation
	{
		public string fileName { get; set; }
		public string language { get; set; }
	}
}
