﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class FAQInformation
	{
		public int faqId { get; set; }
		public int classId { get; set; }
		public string className { get; set; }
		public string userName { get; set; }
		public string originalQuestion { get; set; }
		public string editedQuestion { get; set; }
		public string answerText { get; set; }
		public bool isPublic { get; set; }
	}
}
