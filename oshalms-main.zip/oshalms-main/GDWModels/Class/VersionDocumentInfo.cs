﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class VersionDocumentInfo
	{
		public int documentId { get; set; }
		public string originalFileName { get; set; }
		public string newFileName { get; set; }
		public bool isActive { get; set; }
	}
}
