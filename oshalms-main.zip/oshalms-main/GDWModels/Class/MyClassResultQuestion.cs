﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class MyClassResultQuestion
	{
		public string questionText { get; set; }
		public string questionNarrative { get; set; }
		public string correctAnswerText { get; set; }
		public string givenAnswerText { get; set; }
		public bool isCorrect { get; set; }
	}
}
