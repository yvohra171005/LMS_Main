﻿using System;

namespace GDWModels.Class
{
    public class MyClassCertificateInformation
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string ClassName { get; set; }

        public DateTime CompletedDate { get; set; }

        public string CustomerLogoFileName { get; set; }

        public string AuthorizedName { get; set; }

        public string AuthorizedTitle { get; set; }

        public string AuthorizedSignatureFileName { get; set; }

        public string GDWLogoFileName { get; set; }

        public string GDWAuthorizedName { get; set; }

        public string GDWAuthorizedTitle { get; set; }

        public string GDWAuthorizedSignatureFileName { get; set; }
    }
}