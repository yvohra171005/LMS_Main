﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class MyClassStatus
	{
		public int assigned { get; set; }
		public int started { get; set; }
		public int notStarted { get; set; }
		public int dueThisWeek { get; set; }
		public int overdue { get; set; }
	}
}
