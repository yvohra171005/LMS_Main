﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class FAQSummary
	{
		public int faqId { get; set; }
		public string className { get; set; }
		public string askedByUser { get; set; }
		public DateTime askedDate { get; set; }
		public double askedDateMilliseconds { get { return (askedDate - (new DateTime( 1970, 1, 1 ))).TotalMilliseconds; } }
		public bool isAnswered { get; set; }
		public bool isPublic { get; set; }
		public string editButtons { get; set; }
	}
}
