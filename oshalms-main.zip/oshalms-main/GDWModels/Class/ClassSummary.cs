﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class ClassSummary
	{
		public int classId { get; set; }
		public string name { get; set; }
		public int versionsCount { get; set; }
		public DateTime createDate { get; set; }
		public double createDateMilliseconds { get { return (createDate - (new DateTime( 1970, 1, 1 ))).TotalMilliseconds; } }
		public DateTime lastModifiedDate { get; set; }
		public double lastModifiedDateMilliseconds { get { return (lastModifiedDate - (new DateTime( 1970, 1, 1 ))).TotalMilliseconds; } }
		public string editButtons { get; set; }
		public bool isActive { get; set; }
	}
}
