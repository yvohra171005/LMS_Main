﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class VersionAnswerInfo
	{
		public int answerId { get; set; }
		public string text { get; set; }
		public bool isCorrect { get; set; }
		public bool isActive { get; set; }
		public string audioFileName { get; set; }
		public string originalAudioFileName { get; set; }
	}
}
