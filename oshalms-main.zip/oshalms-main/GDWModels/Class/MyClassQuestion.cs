﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Class
{
	public class MyClassQuestion
	{
		public int tQuestionId { get; set; }
		public string text { get; set; }
		public string narrative { get; set; }
		public string imageFileName { get; set; }
		public string fullAudioFileName { get; set; }
		public IEnumerable<MyClassAnswer> answers { get; set; }
		public List<object> audioSources
		{
			get
			{
				if( string.IsNullOrEmpty( fullAudioFileName ) )
				{
					return new List<object>();
				}
				return new List<object>() { new { src = "/File/Get/" + fullAudioFileName, type = "audio/mp3" } };
			}
		}
	}
}
