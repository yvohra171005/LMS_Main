﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Account
{
	public class CalendarEventInformation
	{
		public string title { get; set; }
		public DateTime startDate { get; set; }
		public string start { get { return startDate.ToShortDateString(); } }		
		public bool allDay { get; set; }
		public string backgroundColor { get; set; }

		public CalendarEventInformation()
		{
			allDay = true;
			backgroundColor = null;
		}
	}
}
