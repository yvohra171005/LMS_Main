﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Account
{
	public class EmployeeInformation : UserInformation
	{
		public IEnumerable<int> locations { get; set; }
		public IEnumerable<int> departments { get; set; }
	}
}
