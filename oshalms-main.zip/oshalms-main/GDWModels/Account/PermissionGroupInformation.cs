﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Account
{
	public class PermissionGroupInformation
	{
		public int groupId { get; set; }
		public string name { get; set; }
		public string description { get; set; }
		public bool isActive { get; set; }
		public bool isCustomer { get; set; }
		public int? customerId { get; set; }
		public List<string> permissions { get; set; }
	}
}
