﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Account
{
	public class UserInformation
	{
		public int userId { get; set; }
		public string firstName { get; set; }
		public string lastName { get; set; }
		public string emailAddress { get; set; }
        public bool canRemoveEmailAddress { get; set; }
		public string phoneNumber { get; set; }
		public IEnumerable<int> roles { get; set; }
		public string gender { get; set; }
		public bool isActive { get; set; }
        public bool setupEmailSent { get; set; }
		public string imageFileName { get; set; }
		public bool resetPassword { get; set; }
		public int languageId { get; set; }
		public DateTime? hireDate { get; set; }
	}
}
