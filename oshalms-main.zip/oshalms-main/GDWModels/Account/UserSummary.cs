﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Account
{
	public class UserSummary
	{
		public int userId { get; set; }
        public string userName { get; set; }
		public string fullName { get; set; }
		public string emailAddress { get; set; }
        public string locations { get; set; }
        public string departments { get; set; }
		public string role { get; set; }
		public string editButtons { get; set; }
		public int assignmentCount { get; set; }
		public int newAssignmentCount { get; set; }
		public bool isActive { get; set; }
		public DateTime lastLoginDate { get; set; }
		public double? lastLoginDateMilliseconds
		{
			get
			{
				if( lastLoginDate > DateTime.UtcNow )
					return null;

				return (lastLoginDate - (new DateTime( 1970, 1, 1 ))).TotalMilliseconds;
			}
		}
        public bool setupEmailSent { get; set; }
	}
}
