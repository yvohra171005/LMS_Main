﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Account
{
	public class LanguageInformation
	{
		public int languageId { get; set; }
		public string name { get; set; }
		public bool isActive { get; set; }
	}
}
