﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Account
{
	public class EmployeeAssignmentSummary
	{
		public int userClassId { get; set; }
		public string name { get; set; }
		public string status { get; set; }
		public string dueDate { get; set; }
		public string score { get; set; }
		public string editButtons { get; set; }
		public string employeeName { get; set; }
		public DateTime? realDueDate { get; set; }
		public bool canReclaim { get; set; }
	}
}
