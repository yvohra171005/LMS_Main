﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Account
{
	public class LanguageSummary
	{
		public int languageId { get; set; }
		public string name { get; set; }
		public int userCount { get; set; }
		public string editButtons { get; set; }
		public bool isActive { get; set; }
	}
}
