﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWInfrastructure;

namespace GDWModels.Account
{
	public class NotificationSummary
	{
		public int alertId { get; set; }
		public string header { get; set; }
		public string text { get; set; }
		public DateTime noteDateTime { get; set; }
		public double noteDateMilliseconds { get { return (noteDateTime - (new DateTime( 1970, 1, 1 ))).TotalMilliseconds; } }
		public string time
		{
			get
			{
				var span = DateTime.UtcNow - noteDateTime;
				var num = 0;
				var fmt = "";
				if( span.Days > 1 )
				{
					fmt = GDWWebUser.CurrentUser.GetResourceString( "MultipleDays" );
					num = span.Days;
				}
				else if( span.Days > 0 )
				{
					fmt = GDWWebUser.CurrentUser.GetResourceString( "SingleDay" );
					num = span.Days;
				}
				else if( span.Hours > 1 )
				{
					fmt = GDWWebUser.CurrentUser.GetResourceString( "MultipleHours" );
					num = span.Hours;
				}
				else if( span.Hours > 0 )
				{
					fmt = GDWWebUser.CurrentUser.GetResourceString( "SingleHour" );
					num = span.Hours;
				}
				else if( span.Minutes > 1 )
				{
					fmt = GDWWebUser.CurrentUser.GetResourceString( "MultipleMinutes" );
					num = span.Minutes;
				}
				else 
				{
					return GDWWebUser.CurrentUser.GetResourceString( "JustNow" );
				}

				return string.Format( fmt, num );
			}
		}
		public bool isNew { get; set; }
		public bool isRead { get; set; }
	}
}
