﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Account
{
	public class PermissionInformation
	{
		public class IndividualPermission
		{
			public string buttonName { get; set; }
			public string permissionName { get; set; }
		}

		public string objectName { get; set; }
		public bool isCustomer { get; set; }
		public IEnumerable<IndividualPermission> buttons { get; set; }
	}
}
