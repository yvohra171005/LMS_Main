﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Video
{
	public class VideoInformation
	{
		public int videoId { get; set; }
		public string name { get; set; }
		public string originalVideoName { get; set; }
		public string newVideoName { get; set; }
		public bool isActive { get; set; }
	}
}
