﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Video
{
	public class PendingVideoSummary
	{
		public int videoId { get; set; }
		public string blobName { get; set; }
		public string jobId { get; set; }
		public string streamName { get; set; }
	}
}
