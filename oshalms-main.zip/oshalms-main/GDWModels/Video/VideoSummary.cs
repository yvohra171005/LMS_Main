﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Video
{
	public class VideoSummary
	{
		public int videoId { get; set; }
		public string name { get; set; }
		public string status { get; set; }
		public int classes { get; set; }
		public bool isActive { get; set; }
		public DateTime createDate { get; set; }
		public double createDateMilliseconds { get { return (createDate - (new DateTime( 1970, 1, 1 ))).TotalMilliseconds; } }
		public string editButtons { get; set; }
	}
}
