﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWModels.Discount
{
	public class DiscountInformation
	{
		public int discountCodeId { get; set; }
		public string name { get; set; }
		public string description { get; set; }
		public int codeType { get; set; }
		public double dollarOffAmount { get; set; }
		public double percOffAmount { get; set; }
		public double firstAmount { get; set; }
		public double minimumPurchase { get; set; }
		public string codeText { get; set; }
		public DateTime startDate { get; set; }
		public DateTime endDate { get; set; }
		public bool isMultiUse { get; set; }
		public bool isNewPurchase { get; set; }
		public bool isExistingCustomer { get; set; }
		public bool isRenewal { get; set; }
		public bool isActive { get; set; }
	}
}
