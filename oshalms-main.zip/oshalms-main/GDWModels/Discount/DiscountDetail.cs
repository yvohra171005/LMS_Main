﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWDatabase;

namespace GDWModels.Discount
{
	public class DiscountDetail
	{
		public int discountCodeId { get; set; }
		public int codeType { get; set; }
		public string codeText { get; set; }
		public double dollarOffAmount { get; set; }
		public double percOffAmount { get; set; }
		public double firstAmount { get; set; }
		public double minimumPurchase { get; set; }
		public double discountAmount { get { return 0.0; } }	// serves as initializer for UI
	}
}
