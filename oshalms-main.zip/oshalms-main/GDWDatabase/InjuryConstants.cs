﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWDatabase
{
	public static class InjuryConstants
	{
		public enum CaseClassificationType
		{
			Death = 1,
			DaysAwayFromWork = 2,
			JobTransfer = 3,
			Other = 4
		}

		public static string ToDisplayString( this CaseClassificationType type )
		{
			switch( type )
			{
				case CaseClassificationType.Death:
					return "Death";
				case CaseClassificationType.DaysAwayFromWork:
					return "Days away from work";
				case CaseClassificationType.JobTransfer:
					return "Job transfer or restriction";
				case CaseClassificationType.Other:
					return "Other recordable cases";
			}

			return "";
		}

		public enum InjuryIllnessType
		{
			Injury = 1,
			SkinDisorder = 2,
			Respiratory = 3,
			Poisoning = 4,
			HearingLoss = 5,
			Other = 6
		}

		public static string ToDisplayString( this InjuryIllnessType type )
		{
			switch( type )
			{
				case InjuryIllnessType.Injury:
					return "Injury";
				case InjuryIllnessType.SkinDisorder:
					return "Skin disorder";
				case InjuryIllnessType.Respiratory:
					return "Respiratory condition";
				case InjuryIllnessType.Poisoning:
					return "Poisoning";
				case InjuryIllnessType.HearingLoss:
					return "Hearing loss";
				case InjuryIllnessType.Other:
					return "All other illnesses";
			}

			return "";
		}
	}
}
