﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWDatabase
{
	public static class GDWPaymentMethods
	{
		public enum PaymentMethod
		{
			BillMeLater,
			CreditCard,
			eCheck
		}

		public static string ToDisplayString( this PaymentMethod p )
		{
			switch( p )
			{
				case PaymentMethod.BillMeLater:
					return "Bill Me Later";
				case PaymentMethod.CreditCard:
					return "Credit Card";
				case PaymentMethod.eCheck:
					return "eCheck";
			}

			return "";
		}
	}
}
