﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWDatabase
{
	public partial class GoodDaysWorkEntities
	{
		public GoodDaysWorkEntities( string connectionString )
			: base( connectionString )
		{
		}
	}
}
