﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWDatabase
{
	public partial class UserClass
	{
		public int Progress
		{
			get
			{
				switch( Status )
				{
					case GDWClassStatus.Status.New:
						return 0;
					case GDWClassStatus.Status.Started:
						return 25;
					case GDWClassStatus.Status.VideoComplete:
						return 50;
					case GDWClassStatus.Status.InTest:
						return 75;
					case GDWClassStatus.Status.TestComplete:
						return 95;
					case GDWClassStatus.Status.TestPassed:
						return 100;
				}

				return 0;
			}
		}

		public double? Score
		{
			get
			{
				if( Status == GDWClassStatus.Status.TestPassed )
				{
					var uTest = UserTests.OrderByDescending( t => t.TestID ).FirstOrDefault();
					if( uTest != null )
					{
						return uTest.Score;
					}
				}

				return 0;
			}
		}
	}
}
