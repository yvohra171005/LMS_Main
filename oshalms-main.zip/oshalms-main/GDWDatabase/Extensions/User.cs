﻿namespace GDWDatabase
{
	public partial class User
	{
		public string FullName
		{
			get
			{
				return FirstName + " " + LastName;
			}
		}

	    public bool HasNonEmailUserName
	    {
	        get { return string.IsNullOrEmpty( EmailAddress ); }
	    }

	    public string UserName
	    {
	        get
	        {
	            return HasNonEmailUserName ? GetNonEmailUserName() : EmailAddress;
	        }
	    }

	    protected string GetNonEmailUserName()
	    {
	        string initFirst = !string.IsNullOrEmpty( FirstName ) ? FirstName.Substring( 0, 1 ) : "x";
	        string initLast = !string.IsNullOrEmpty( LastName ) ? LastName.Substring( 0, 1 ) : "x";
	        return (initFirst + initLast + UserID.ToString( "D" )).ToLower();
	    }

	    public static int? ParseIdFromNonEmailUserName( string userName )
	    {
	        int? userId = null;
	        if ( userName != null && userName.Length >= 3 && char.IsLetter( userName[0] ) && char.IsLetter( userName[1] ) )
	        {
	            int i;
                for ( i = 2; i < userName.Length; ++i )
                    if ( userName[i] < '0' || userName[i] > '9' )
                        break;
	            if ( i == userName.Length )
	                userId = int.Parse( userName.Substring( 2 ) );
	        }
	        return userId;
	    }
	}
}
