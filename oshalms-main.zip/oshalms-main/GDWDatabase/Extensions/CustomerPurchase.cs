﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWDatabase
{
	public partial class CustomerPurchase
	{
		public List<string> TransactionDetails
		{
			get
			{
				var retList = new List<string>();

				if( PurchaseType == GDWPurchaseTypes.PurchaseType.Original )
				{
					retList.Add( "Original Purchase" );
				}
				else if( PurchaseType == GDWPurchaseTypes.PurchaseType.Renewal )
				{
					retList.Add( "Renewal" );
				}
				if( CreditCount > 0 )
				{
					retList.Add( string.Format( "Credits ({0})", CreditCount ) );
				}
				if( EmployeeCount > 0 )
				{
					retList.Add( string.Format( "User Accounts ({0})", EmployeeCount ) );
				}

				return retList;
			}
		}
	}
}
