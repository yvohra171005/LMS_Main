﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWDatabase
{
	public partial class Notification
	{
		public static Notification NewNotification()
		{
			return new Notification()
			{
				IsNew = true,
				IsRead = false
			};
		}
	}
}
