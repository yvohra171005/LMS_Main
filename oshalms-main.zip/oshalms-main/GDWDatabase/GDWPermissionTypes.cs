﻿using System.Collections.Generic;

namespace GDWDatabase
{
	public class GDWPermissionTypes
	{
		public enum Permissions
		{
			ViewUser = 1,
			AddUser = 2,
			EditUser = 3,
			DeactivateUser = 4,

			ViewPermissionGroup = 5,
			AddPermissionGroup = 6,
			EditPermissionGroup = 7,
			DeactivatePermissionGroup = 8,

			ViewLanguage = 9,
			AddLanguage = 10,
			EditLanguage = 11,
			DeactivateLanguage = 12,

			ViewClass = 13,
			AddClass = 14,
			EditClass = 15,
			DeactivateClass = 16,

			ViewClassVersion = 17,
			AddClassVersion = 18,
			EditClassVersion = 19,
			DeactivateClassVersion = 20,

			TakeClass = 21,

			ViewCreditTier = 22,
			AddCreditTier = 23,
			EditCreditTier = 24,
			DeactivateCreditTier = 25,

			ManageConfiguration = 26,

			ViewCustomer = 27,
			AddCustomer = 28,
			EditCustomer = 29,
			DeactivateCustomer = 30,
			ManageCustomerAccount = 31,

			ViewEmployee = 32,
			AddEmployee = 33,
			EditEmployee = 34,
			DeactivateEmployee = 35,

			ViewLocation = 36,
			AddLocation = 37,
			EditLocation = 38,
			DeactivateLocation = 39,
			ManageAllLocations = 40,

			ViewDepartment = 41,
			AddDepartment = 42,
			EditDepartment = 43,
			DeactivateDepartment = 44,

			ManageAssignments = 45,

			ManageCreditsAndEmployees = 46,
			ManageMyAccount = 47,

			ImpersonateCustomer = 48,

			ViewCustomerPermissionGroup = 49,
			AddCustomerPermissionGroup = 50,
			EditCustomerPermissionGroup = 51,
			DeactivateCustomerPermissionGroup = 52,

			AlertThreeFailed = 53,
			AlertAccountExpiration = 54,

			ViewWidgets = 55,

			ManageFAQs = 56,

			ViewScreeningRoom = 57,
			ViewLibrary = 58,

			ViewInjury = 59,
			AddInjury = 60,
			EditInjury = 61,

//			ReactivateEmployee = 62,

			ViewDiscountCode = 63,
			AddDiscountCode = 64,
			EditDiscountCode = 65,
			DeactivateDiscountCode = 66,

			ViewInactiveEmployee = 67,
			EditInactiveEmployee = 68,

			AddInvoice = 69,

			ReclaimStartedClass = 70,

			ViewVideo = 71,
			AddVideo = 72,
			EditVideo = 73,
			DeactivateVideo = 74,

			ImportScores = 75,

            ReceiveEmailOnBehalfOfEmployees = 76,

            EditSignature = 77,

			ViewCompanyDocument = 78,
			ManageCompanyDocument = 79,
			ViewRestrictedCompanyDocument = 81,
			ManageRestrictedCompanyDocument = 82,

			ViewEmployeeDocument = 83,
			ManageEmployeeDocument = 84,
			ViewRestrictedEmployeeDocument = 85,
			ManageRestrictedEmployeeDocument = 87,
			ViewOwnEmployeeDocument = 88,

			ViewCompanyNote = 90,
			ManageCompanyNote = 91,
			ViewEmployeeNote = 92,
			ManageEmployeeNote = 93
		}

		public static IEnumerable<Permissions> ImpersonateList
		{
			get
			{
				return new List<Permissions>
				{
					Permissions.ViewEmployee,
					Permissions.AddEmployee,
					Permissions.EditEmployee,
					Permissions.DeactivateEmployee,
					Permissions.ViewInactiveEmployee,
					Permissions.EditInactiveEmployee,

					Permissions.ViewLocation,
					Permissions.AddLocation,
					Permissions.EditLocation,
					Permissions.DeactivateLocation,
					Permissions.ManageAllLocations,

					Permissions.ViewDepartment,
					Permissions.AddDepartment,
					Permissions.EditDepartment,
					Permissions.DeactivateDepartment,

					Permissions.ManageAssignments,

					Permissions.ManageCreditsAndEmployees,
					Permissions.ManageMyAccount,

					Permissions.ViewCustomerPermissionGroup,
					Permissions.AddCustomerPermissionGroup,
					Permissions.EditCustomerPermissionGroup,
					Permissions.DeactivateCustomerPermissionGroup,

					Permissions.ManageFAQs,

					Permissions.ViewScreeningRoom,
					Permissions.ViewLibrary,

					Permissions.ViewCompanyDocument,
					Permissions.ManageCompanyDocument,
					Permissions.ViewRestrictedCompanyDocument,
					Permissions.ManageRestrictedCompanyDocument,

					Permissions.ViewEmployeeDocument,
					Permissions.ManageEmployeeDocument,
					Permissions.ViewRestrictedEmployeeDocument,
					Permissions.ManageRestrictedEmployeeDocument,

					Permissions.ViewCompanyNote,
					Permissions.ManageCompanyNote,
					Permissions.ViewEmployeeNote,
					Permissions.ManageEmployeeNote,

					Permissions.ViewInjury,
					Permissions.AddInjury,
					Permissions.EditInjury,

					Permissions.AddInvoice,

					Permissions.ReclaimStartedClass,

					Permissions.ImportScores,

                    Permissions.EditSignature
				};
			}
		}
	}
}
