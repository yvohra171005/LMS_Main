﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWDatabase
{
    public class GDWClassTypes
    {
        public enum ClassType
        {
            Video = 0,
            Scorm = 1,
            Pdf = 2
        }
    }
}
