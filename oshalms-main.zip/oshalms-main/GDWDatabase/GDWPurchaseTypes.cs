﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWDatabase
{
	public class GDWPurchaseTypes
	{
		public enum PurchaseType
		{
			Original = 0,
			AddOns = 1,
			Renewal = 2
		}
	}
}
