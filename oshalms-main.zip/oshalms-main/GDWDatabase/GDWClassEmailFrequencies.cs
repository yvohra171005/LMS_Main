﻿namespace GDWDatabase
{
    public static class GDWClassEmailFrequencies
    {
		public enum ClassEmailFrequency
		{
            All = 0,
            Limited,
            AssignmentOnly,
			None
		}

		public static string ToDisplayString( this ClassEmailFrequency f )
		{
            // NOTE: These strings will need to be changed if the class email schedules are changed in
            // ClassRepository's CheckClassStatus method.
			switch( f )
			{
				case ClassEmailFrequency.All:
					return "Assignment and All Overdue Warnings (30 days, 14, 7, 2, 1, overdue)";
				case ClassEmailFrequency.Limited:
					return "Assignment and Limited Overdue Warnings (7 days, 2, overdue)";
				case ClassEmailFrequency.AssignmentOnly:
					return "Assignment Only";
				case ClassEmailFrequency.None:
					return "None";
			}

			return "";
		}
    }
}
