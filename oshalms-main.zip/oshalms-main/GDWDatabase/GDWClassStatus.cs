﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWDatabase
{
	public class GDWClassStatus
	{
		public enum Status
		{
			New = 1,
			Started = 2,
			VideoComplete = 3,
			InTest = 4,
			TestComplete = 5,
			TestPassed = 6
		}

		public static string DisplayString( Status s )
		{
			switch( s )
			{
				case Status.New:
					return "New";
				case Status.Started:
				case Status.VideoComplete:
				case Status.InTest:
					return "In Progress";
				case Status.TestComplete:
					return "Failed";
				case Status.TestPassed:
					return "Passed";
			}

			return "";
		}
	}
}
