﻿namespace GDWDatabase
{
    public static class GDWEnterpriseLevels
    {
        public enum EnterpriseLevel
        {
            Basic = 0,
            Premium = 1,
            PremiumPlus = 2
        }

        public static string ToDisplayString(this EnterpriseLevel l)
        {
            switch (l)
            {
            case EnterpriseLevel.Basic:
                return "Basic";
            case EnterpriseLevel.Premium:
                return "Premium";
            case EnterpriseLevel.PremiumPlus:
                return "Premium Plus";
            default:
                return l.ToString();
            }

        }
    }
}