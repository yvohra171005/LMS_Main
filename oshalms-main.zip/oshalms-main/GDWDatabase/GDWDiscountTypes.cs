﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWDatabase
{
	public class GDWDiscountTypes
	{
		public enum DiscountType
		{
			PercOffSomeCredits,
			PercOffCredits,
			DollarOffCredits,
			PercOffSomeAccounts,
			PercOffAccounts,
			DollarOffAccounts,
			PercOffPurchase,
			DollarOffPurchase
		}
	}
}
