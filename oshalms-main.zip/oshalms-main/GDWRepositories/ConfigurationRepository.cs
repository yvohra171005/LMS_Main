﻿using System;
using System.Linq;
using GDWDatabase;

using GDWInfrastructure;

using GDWModels.Configuration;

namespace GDWRepositories
{
	public class ConfigurationRepository : BaseRepository
	{
		public ConfigInformation GetConfiguration()
		{
			var dbConfig = database.ConfigurationOptions
				.FirstOrDefault();

			var cInfo = new ConfigInformation();

			if( dbConfig != null )
			{
				cInfo.defaultRole = dbConfig.DefaultPermissionGroupID;
				cInfo.defaultCredits = dbConfig.DefaultCreditWarning;
				cInfo.defaultEmployees = dbConfig.DefaultEmployeeWarning;
				cInfo.costPerEmployee = dbConfig.CostPerEmployee;
				cInfo.eulaVersion = dbConfig.EULAVersion;
				cInfo.eulaFileName = dbConfig.EULAFileName;
				cInfo.originalEULAFileName = dbConfig.OriginalEULAFileName;
				cInfo.helpFileName = dbConfig.HelpFileName;
				cInfo.originalHelpFileName = dbConfig.OriginalHelpFileName;
				cInfo.logoImageFileName = dbConfig.CertificateLogoFileName;
				cInfo.originalLogoImageFileName = dbConfig.OriginalCertificateLogoFileName;
				cInfo.signatureName = dbConfig.CertificateSignatureName;
				cInfo.signatureTitle = dbConfig.CertificateSignatureTitle;
				cInfo.signatureImageFileName = dbConfig.CertificateSignatureImageFileName;
				cInfo.originalSignatureImageFileName = dbConfig.OriginalCertificateSignatureImageFileName;

				return cInfo;
			}

			return cInfo;
		}

		public void EditConfiguration( ConfigInformation cInfo )
		{
			var dbConfig = database.ConfigurationOptions
				.FirstOrDefault();

			if( dbConfig == null )
			{
				dbConfig = new ConfigurationOption();

				database.ConfigurationOptions.Add( dbConfig );
			}

			dbConfig.DefaultPermissionGroupID = cInfo.defaultRole;
			dbConfig.DefaultCreditWarning = cInfo.defaultCredits;
			dbConfig.DefaultEmployeeWarning = cInfo.defaultEmployees;
			dbConfig.CostPerEmployee = cInfo.costPerEmployee;

			dbConfig.EULAVersion = cInfo.eulaVersion;

			if (!string.IsNullOrEmpty(cInfo.eulaFileName))
			{
				if (!string.Equals(cInfo.eulaFileName, dbConfig.EULAFileName, StringComparison.InvariantCultureIgnoreCase))
				{
					if (!string.IsNullOrEmpty(dbConfig.EULAFileName))
					{
						var fileStorage = new AzureFileStorage();
						fileStorage.DeleteFile("Files", dbConfig.EULAFileName);
					}
				}

				dbConfig.EULAFileName = cInfo.eulaFileName;
				dbConfig.OriginalEULAFileName = cInfo.originalEULAFileName;
			}

			if (!string.IsNullOrEmpty(cInfo.helpFileName))
			{
				if (!string.Equals(cInfo.helpFileName, dbConfig.HelpFileName, StringComparison.InvariantCultureIgnoreCase))
				{
					if (!string.IsNullOrEmpty(dbConfig.HelpFileName))
					{
						var fileStorage = new AzureFileStorage();
						fileStorage.DeleteFile("Files", dbConfig.HelpFileName);
					}
				}

				dbConfig.HelpFileName = cInfo.helpFileName;
				dbConfig.OriginalHelpFileName = cInfo.originalHelpFileName;
			}

			dbConfig.CertificateSignatureName = cInfo.signatureName;
			dbConfig.CertificateSignatureTitle = cInfo.signatureTitle;

            if (!string.IsNullOrEmpty(cInfo.logoImageFileName))
            {
                if (!string.Equals(cInfo.logoImageFileName, dbConfig.CertificateLogoFileName, StringComparison.InvariantCultureIgnoreCase))
                {
                    if (!string.IsNullOrEmpty(dbConfig.CertificateLogoFileName))
                    {
                        var fileStorage = new AzureFileStorage();
                        fileStorage.DeleteFile("Files", dbConfig.CertificateLogoFileName);
                    }
                }

                dbConfig.CertificateLogoFileName = cInfo.logoImageFileName;
                dbConfig.OriginalCertificateLogoFileName = cInfo.originalLogoImageFileName;
            }
            else
            {
                dbConfig.CertificateLogoFileName = null;
                dbConfig.OriginalCertificateLogoFileName = null;
            }

            if (!string.IsNullOrEmpty(cInfo.signatureImageFileName))
            {
                if (!string.Equals(cInfo.signatureImageFileName, dbConfig.CertificateSignatureImageFileName, StringComparison.InvariantCultureIgnoreCase))
                {
                    if (!string.IsNullOrEmpty(dbConfig.CertificateSignatureImageFileName))
                    {
                        var fileStorage = new AzureFileStorage();
                        fileStorage.DeleteFile("Files", dbConfig.CertificateSignatureImageFileName);
                    }
                }

                dbConfig.CertificateSignatureImageFileName = cInfo.signatureImageFileName;
                dbConfig.OriginalCertificateSignatureImageFileName = cInfo.originalSignatureImageFileName;
            }
            else
            {
                dbConfig.CertificateSignatureImageFileName = null;
                dbConfig.OriginalCertificateSignatureImageFileName = null;
            }

            database.SaveChanges();
		}

		public ShoppingConfigurationSummary GetShoppingConfig()
		{
			var retInfo = new ShoppingConfigurationSummary();

			var dbConfig = database.ConfigurationOptions
				.FirstOrDefault();

			if( dbConfig != null )
			{
				retInfo.costPerEmployee = dbConfig.CostPerEmployee;
			}

			retInfo.oshaMinimum = database.Classes
				.Where( c => !c.IsDeleted && !c.CustomerID.HasValue )
				.Where( c => c.IsBaseClass )
				.Count();

			return retInfo;
		}
	}
}
