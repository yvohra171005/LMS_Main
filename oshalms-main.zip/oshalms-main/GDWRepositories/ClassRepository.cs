﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWInfrastructure.EmailSenders;
using GDWModels.Class;
using GDWModels.Report;
using GDWScormProviders;

namespace GDWRepositories
{
	public class ClassRepository : BaseRepository
	{
		#region Classes
		public IEnumerable<ClassSummary> GetFullClassList( ClassTableParams param, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var classList = database.Classes
				.Include( u => u.ClassVersions )
				.AsQueryable();

			totalRecords = classList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				classList = classList.Where( i =>
					i.Name.Contains( param.sSearch ) );
			}
			switch( (param.activeState ?? "active").ToLower() )
			{
				case "active":
					classList = classList.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					classList = classList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}
			if( (param.category ?? "").Any() )
			{
				classList = classList.Where( c => c.ClassCategories.Any( cat => cat.Name == param.category ) );
			}

			displayedRecords = classList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<Class> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "name":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = classList.OrderBy( v => v.Name );
					}
					else
					{
						filteredAndSorted = classList.OrderByDescending( v => v.Name );
					}
					break;
				case "versionscount":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = classList.OrderBy( v => v.ClassVersions.Where( cv => !cv.IsDeleted ).Count() );
					}
					else
					{
						filteredAndSorted = classList.OrderByDescending( v => v.ClassVersions.Where( cv => !cv.IsDeleted ).Count() );
					}
					break;
				case "createdate":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = classList.OrderBy( v => v.DateCreated );
					}
					else
					{
						filteredAndSorted = classList.OrderByDescending( v => v.DateCreated );
					}
					break;
				case "lastmodifieddate":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = classList.OrderBy( v => v.LastModified );
					}
					else
					{
						filteredAndSorted = classList.OrderByDescending( v => v.LastModified );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new ClassSummary()
			{
				classId = v.ClassID,
				name = v.Name,
				versionsCount = v.ClassVersions.Where( cv => !cv.IsDeleted ).Count(),
				createDate = v.DateCreated,
				lastModifiedDate = v.LastModified,
				isActive = !v.IsDeleted,
			} );
		}

		public ClassInformation GetClass( int classId )
		{
			var dbClass = database.Classes
				.FirstOrDefault( u => u.ClassID == classId );

			if( dbClass != null )
			{
				var uInfo = new ClassInformation();

				uInfo.classId = dbClass.ClassID;
				uInfo.name = dbClass.Name;
				uInfo.description = dbClass.Description;
			    uInfo.logoFileName = dbClass.LogoFileName;
			    uInfo.originalLogoFileName = dbClass.OriginalLogoFileName;
				uInfo.passPercent = dbClass.PassPercent;
				uInfo.randomizeQuestions = dbClass.RandomizeQuestions;
				uInfo.totalQuestionMinimum = dbClass.TotalQuestionMinimum;
				uInfo.totalQuestionMaximum = dbClass.TotalQuestionMaximum;
				uInfo.isActive = !dbClass.IsDeleted;
				uInfo.customerId = dbClass.CustomerID;
				uInfo.categories = dbClass.ClassCategories.Select( c => c.Name );
				uInfo.creditCount = dbClass.Credits;
				uInfo.isBaseClass = dbClass.IsBaseClass;
				uInfo.referenceNumber = dbClass.ReferenceNumber;

				return uInfo;
			}

			throw new GDWException( "ErrorClassNotFound" );

		}
        
		public IEnumerable<ClassSummary> FindClassByName( string className, int customerId )
		{
			var customer = database.Customers.Include(c => c.AvailableClasses).SingleOrDefault(c => c.CustomerID == customerId);
			if (customer == null)
				return new ClassSummary[0];

			var query = database.Classes
			                    .Include(cl => cl.ClassVersions)
			                    .Where(cl => !cl.IsDeleted)
			                    .Where(cl => cl.CustomerID == customerId || !cl.CustomerID.HasValue)
			                    .Where(cl => cl.Name == className)
			                    .Where(cl => database.Customers.Any(c => c.CustomerID == customerId &&
			                                                             (c.EnterpriseLevel != GDWEnterpriseLevels.EnterpriseLevel.Basic ||
			                                                              c.AvailableClasses.Any(ac => ac.ClassID == cl.ClassID))));

		    return query
		        .OrderBy(cl => cl.Name)
		        .Select(cl => new ClassSummary()
		            {
		                classId = cl.ClassID,
		                name = cl.Name,
		                versionsCount = cl.ClassVersions.Count(cv => !cv.IsDeleted),
		                createDate = cl.DateCreated,
		                lastModifiedDate = cl.LastModified,
		                isActive = !cl.IsDeleted,
		            })
		        .ToList();
		}

		public void AddClass( ClassInformation uInfo )
		{
			var newClass = new Class();

			newClass.Name = uInfo.name;
			newClass.Description = uInfo.description;
		    newClass.LogoFileName = uInfo.logoFileName;
		    newClass.OriginalLogoFileName = uInfo.originalLogoFileName;
			newClass.PassPercent = uInfo.passPercent;
			newClass.RandomizeQuestions = uInfo.randomizeQuestions;
			newClass.TotalQuestionMinimum = uInfo.totalQuestionMinimum;
			newClass.TotalQuestionMaximum = uInfo.totalQuestionMaximum;
			newClass.CustomerID = uInfo.customerId;
			newClass.Credits = uInfo.creditCount;
			newClass.IsBaseClass = uInfo.isBaseClass;
			newClass.ReferenceNumber = uInfo.referenceNumber;

			newClass.IsDeleted = !uInfo.isActive;
			newClass.DateCreated = DateTime.UtcNow;
			newClass.LastModified = DateTime.UtcNow;

			if( uInfo.categories != null )
			{
				uInfo.categories = uInfo.categories.Select( c => c.Trim() );

				foreach( var cat in uInfo.categories )
				{
					var dbCat = database.ClassCategories.FirstOrDefault( c => c.Name == cat );
					if( dbCat == null )
					{
						dbCat = new ClassCategory() { Name = cat };
					}
					newClass.ClassCategories.Add( dbCat );
				}
			}

			database.Classes.Add( newClass );

			database.SaveChanges();
		}

		public void EditClass( ClassInformation uInfo )
		{
			var dbClass = database.Classes.FirstOrDefault( u => u.ClassID == uInfo.classId );

			if( dbClass != null )
			{
		        if ( !string.Equals( uInfo.logoFileName, dbClass.LogoFileName, StringComparison.InvariantCultureIgnoreCase ) )
		        {
		            if ( !string.IsNullOrEmpty( dbClass.LogoFileName ) )
		            {
	                    var fileStorage = new AzureFileStorage();
	                    fileStorage.DeleteFile( "Files", dbClass.LogoFileName );
		            }
		        }
				dbClass.Name = uInfo.name;
				dbClass.Description = uInfo.description;
		        dbClass.LogoFileName = uInfo.logoFileName;
		        dbClass.OriginalLogoFileName = uInfo.originalLogoFileName;
				dbClass.PassPercent = uInfo.passPercent;
				dbClass.RandomizeQuestions = uInfo.randomizeQuestions;
				dbClass.TotalQuestionMinimum = uInfo.totalQuestionMinimum;
				dbClass.TotalQuestionMaximum = uInfo.totalQuestionMaximum;
				dbClass.LastModified = DateTime.UtcNow;
				dbClass.CustomerID = uInfo.customerId;
				dbClass.IsDeleted = !uInfo.isActive;
				dbClass.Credits = uInfo.creditCount;
				dbClass.IsBaseClass = uInfo.isBaseClass;
				dbClass.ReferenceNumber = uInfo.referenceNumber;

				if( uInfo.categories != null )
				{
					uInfo.categories = uInfo.categories.Select( c => c.Trim() );

					foreach( var newCategory in uInfo.categories.Where( p => !dbClass.ClassCategories.Select( cat => cat.Name ).Contains( p ) ) )
					{
						var dbCat = database.ClassCategories.FirstOrDefault( p => p.Name == newCategory );
						if( dbCat == null )
						{
							dbCat = new ClassCategory() { Name = newCategory };
						}

						dbClass.ClassCategories.Add( dbCat );
					}

					foreach( var oldCategory in dbClass.ClassCategories.Where( cat => !uInfo.categories.Contains( cat.Name, StringComparer.InvariantCultureIgnoreCase ) ).ToList() )
					{
						dbClass.ClassCategories.Remove( oldCategory );
					}
				}
				else
				{
					dbClass.ClassCategories.Clear();
				}

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorClassNotFound" );
		}

		public void DeleteClass( int classId )
		{
			var dbClass = database.Classes.FirstOrDefault( u => u.ClassID == classId );

			if( dbClass != null )
			{
				dbClass.IsDeleted = true;
				dbClass.LastModified = DateTime.UtcNow;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorClassNotFound" );
		}

		public IEnumerable<GDWListItem> GetVideoDropDownList()
		{
			return database.Videos
				.Where( v => !v.IsDeleted && !string.IsNullOrEmpty( v.StreamName ) )
				.Select( v => new GDWListItem() { id = v.VideoID, name = v.Name } )
				.ToList();
		}

		public IEnumerable<string> GetCategoryDropDownList()
		{
			return database.ClassCategories
				.Where( c => c.Classes.Any() )
				.Select( c => c.Name )
				.ToList();
		}

		public IEnumerable<GDWListItem> GetDropDownList(int? customerId, string categoryName = null)
		{
			var query = database.Classes
			                    .Where(c => !c.IsDeleted)
			                    .Where(c => (c.CustomerID == customerId) || !c.CustomerID.HasValue || !customerId.HasValue);
			if (!string.IsNullOrEmpty(categoryName))
				query = query.Where(c => c.ClassCategories.Any(cat => cat.Name == categoryName));

			return query
			       .OrderBy(c => c.Name)
			       .Select(c => new GDWListItem() { id = c.ClassID, name = c.Name })
			       .ToList();
		}

		public IEnumerable<GDWListItem> GetAvailableClassesList(int? customerId, string categoryName = null)
		{
			if (!customerId.HasValue)
			{
				return database.Classes
				               .Where(c => !c.IsDeleted)
				               .OrderBy(c => c.Name)
				               .Select(c => new GDWListItem() { id = c.ClassID, name = c.Name })
				               .ToList();
			}

			var customer = database.Customers
			                       .Include(c => c.AvailableClasses.Select(ac => ac.ClassCategories))
			                       .FirstOrDefault(c => c.CustomerID == customerId.Value);
			if (customer == null)
				throw new GDWException("ErrorCustomerNotFound");

			if (customer.EnterpriseLevel == GDWEnterpriseLevels.EnterpriseLevel.Basic)
			{
				var query = customer.AvailableClasses
				                    .Where(c => !c.IsDeleted);
				if (!string.IsNullOrEmpty(categoryName))
					query = query.Where(c => c.ClassCategories.Any(cat => cat.Name == categoryName));
				return query
				       .OrderBy(c => c.Name)
				       .Select(c => new GDWListItem() { id = c.ClassID, name = c.Name })
				       .ToList();
			}
			else
			{
				var query = database.Classes
				                    .Where(c => !c.IsDeleted)
				                    .Where(c => (c.CustomerID == customer.CustomerID) || !c.CustomerID.HasValue);
				if (!string.IsNullOrEmpty(categoryName))
					query = query.Where(c => c.ClassCategories.Any(cat => cat.Name == categoryName));

				return query
				       .OrderBy(c => c.Name)
				       .Select(c => new GDWListItem() { id = c.ClassID, name = c.Name })
				       .ToList();
			}
		}

		public IEnumerable<ShoppingClassSummary> GetShoppingList()
		{
			return database.Classes
				.Where( c => !c.IsDeleted && !c.CustomerID.HasValue )
				.OrderBy( c => c.Name )
				.Select( c => new ShoppingClassSummary()
				{
					name = c.Name,
					credits = c.Credits,
					isBaseClass = c.IsBaseClass
				} )
				.ToList();
		}

		#endregion

		#region Class Versions
		public IEnumerable<ClassVersionSummary> GetFullClassVersionList( ClassVersionTableParams param, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var versionList = database.ClassVersions
				.Include( v => v.Language )
				.Include( v => v.ClassQuestions )
				.Where( v => v.ClassID == param.classId )
				.AsQueryable();

			totalRecords = versionList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				versionList = versionList.Where( i =>
					i.Language.Name.Contains( param.sSearch ) );
			}

			switch( (param.activeState ?? "active").ToLower() )
			{
				case "active":
					versionList = versionList.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					versionList = versionList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}

			displayedRecords = versionList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<ClassVersion> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "language":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = versionList.OrderBy( v => v.Language.Name );
					}
					else
					{
						filteredAndSorted = versionList.OrderByDescending( v => v.Language.Name );
					}
					break;
				case "questioncount":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = versionList.OrderBy( v => v.ClassQuestions.Count( cq => !cq.IsDeleted ) );
					}
					else
					{
						filteredAndSorted = versionList.OrderByDescending( v => v.ClassQuestions.Count( cq => !cq.IsDeleted ) );
					}
					break;
				case "createDate":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = versionList.OrderBy( v => v.DateCreated );
					}
					else
					{
						filteredAndSorted = versionList.OrderByDescending( v => v.DateCreated );
					}
					break;
				case "lastModifiedDate":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = versionList.OrderBy( v => v.LastModified );
					}
					else
					{
						filteredAndSorted = versionList.OrderByDescending( v => v.LastModified );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new ClassVersionSummary()
			{
				versionId = v.VersionID,
				language = v.Language.Name,
                languageId = v.Language.LanguageID,
				questionCount = v.ClassQuestions.Count( cq => !cq.IsDeleted ),
				createDate = v.DateCreated,
				lastModifiedDate = v.LastModified,
				isActive = !v.IsDeleted,
			} );
		}

	    public IEnumerable<ClassVersionSummary> GetAvailableClassVersions( int classId )
	    {
			var versionList = database.ClassVersions
				.Where( v => v.ClassID == classId && !v.IsDeleted )
				.AsQueryable();

			return versionList.Select( v => new ClassVersionSummary()
			{
				versionId = v.VersionID,
				language = v.Language.Name,
                languageId = v.Language.LanguageID,
				questionCount = v.ClassQuestions.Count( cq => !cq.IsDeleted ),
				createDate = v.DateCreated,
				lastModifiedDate = v.LastModified,
				isActive = !v.IsDeleted,
			} ).ToList();
	    }

		public ClassVersionInformation GetClassVersion( int versionId )
		{
			var dbClassVersion = database.ClassVersions
				.Include( c => c.ClassVersionDocuments )
				.Include( c => c.ClassVersionSafetyDocuments )
				.Include( c => c.ClassQuestions )
				.Include( c => c.ClassQuestions.Select( q => q.ClassAnswers ) )
				.Include( c => c.ScormClass )
				.FirstOrDefault( u => u.VersionID == versionId );

			if( dbClassVersion != null )
			{
				var uInfo = new ClassVersionInformation();

				uInfo.versionId = dbClassVersion.VersionID;
				uInfo.classId = dbClassVersion.ClassID;
				uInfo.languageId = dbClassVersion.LanguageID;
				uInfo.languageName = dbClassVersion.Language.Name;
				uInfo.newCaptionName = dbClassVersion.CaptionFileName;
				uInfo.originalCaptionName = dbClassVersion.OriginalCaptionName;
				uInfo.isActive = !dbClassVersion.IsDeleted;
				uInfo.versionCountForLangauge = dbClassVersion.Class.ClassVersions.Count( v => !v.IsDeleted && v.LanguageID == dbClassVersion.LanguageID );

				uInfo.classType = dbClassVersion.ClassType.ToString();
				uInfo.videoId = null;
				uInfo.scormProvider = null;
				uInfo.scormClassHandle = null;
				uInfo.newPDFName = null;
				uInfo.originalPDFName = null;
				switch (dbClassVersion.ClassType)
                {
					case GDWClassTypes.ClassType.Video:
						uInfo.videoId = dbClassVersion.VideoID;
						break;
					case GDWClassTypes.ClassType.Scorm:
						uInfo.scormClassHandle = dbClassVersion.ScormClass.ClassHandle;
						uInfo.scormProvider = dbClassVersion.ScormClass.ScormProvider;
						break;
					case GDWClassTypes.ClassType.Pdf:
						uInfo.newPDFName = dbClassVersion.PDFFileName;
						uInfo.originalPDFName = dbClassVersion.OriginalPDFName;
						break;
                }

				uInfo.documents = dbClassVersion.ClassVersionDocuments
					.Where( d => !d.IsDeleted )
					.Select( d => new VersionDocumentInfo()
					{
						documentId = d.DocumentID,
						isActive = true,
						newFileName = d.FileName,
						originalFileName = d.OriginalName
					} )
					.ToList();

				uInfo.safetyDocuments = dbClassVersion.ClassVersionSafetyDocuments
					.Where( d => !d.IsDeleted )
					.Select( d => new VersionDocumentInfo()
					{
						documentId = d.SafetyDocumentID,
						isActive = true,
						newFileName = d.FileName,
						originalFileName = d.OriginalName
					} )
					.ToList();

				uInfo.questions = dbClassVersion.ClassQuestions
					.Where( q => !q.IsDeleted )
					.OrderBy( q => q.DisplayOrder )
					.Select( q => new VersionQuestionInfo()
					{
						questionId = q.QuestionID,
						text = q.Text,
						narrative = q.Narrative,
						displayOrder = q.DisplayOrder,
						imageFileName = q.ImageFileName,
						originalImageFileName = q.OriginalImageFileName,
						audioFileName = q.AudioFileName,
						originalAudioFileName = q.OriginalAudioFileName,
						fullAudioFileName = q.FullAudioFileName,
						originalFullAudioFileName = q.OriginalFullAudioFileName,
						isActive = true,
						answers = q.ClassAnswers
							.Where( a => !a.IsDeleted )
							.Select( a => new VersionAnswerInfo()
							{
								answerId = a.AnswerID,
								isCorrect = a.IsCorrect,
								text = a.Text,
								isActive = true,
								audioFileName = a.AudioFileName,
								originalAudioFileName = a.OriginalAudioFileName,
							} )
							.ToList()
					} )
					.ToList();
				return uInfo;
			}
			
			throw new GDWException( "ErrorClassVersionNotFound" );

		}

		public void AddClassVersion( ClassVersionInformation cvInfo )
		{
			var dbClass = database.Classes.FirstOrDefault( c => c.ClassID == cvInfo.classId );
			if( dbClass != null )
			{
				var newClassVersion = new ClassVersion();

				newClassVersion.Language = database.Languages.FirstOrDefault( l => l.LanguageID == cvInfo.languageId );
				newClassVersion.OriginalCaptionName = cvInfo.originalCaptionName;
				newClassVersion.CaptionFileName = cvInfo.newCaptionName;

				newClassVersion.ClassType = (GDWClassTypes.ClassType)Enum.Parse(typeof(GDWClassTypes.ClassType), cvInfo.classType);
				newClassVersion.VideoID = null;
				newClassVersion.ScormClassID = null;
				newClassVersion.PDFFileName = null;
				newClassVersion.OriginalPDFName = null;
				switch (newClassVersion.ClassType)
                {
					case GDWClassTypes.ClassType.Video:
						newClassVersion.VideoID = cvInfo.videoId;
						break;
					case GDWClassTypes.ClassType.Scorm:
						newClassVersion.ScormClass = new ScormClass()
						{
							ScormProvider = cvInfo.scormProvider,
							ClassHandle = cvInfo.scormClassHandle
						};
						ScormProviders.GetScormProvider(cvInfo.scormProvider).OnCourseImported(newClassVersion.ScormClass.ClassHandle);
						break;
					case GDWClassTypes.ClassType.Pdf:
						newClassVersion.PDFFileName = cvInfo.newPDFName;
						newClassVersion.OriginalPDFName = cvInfo.originalPDFName;
						break;
                }

                newClassVersion.GuideFileName = cvInfo.newGuideName;
                newClassVersion.OriginalGuideName = cvInfo.originalGuideName;

				newClassVersion.IsDeleted = !cvInfo.isActive;
				newClassVersion.DateCreated = DateTime.UtcNow;
				newClassVersion.LastModified = DateTime.UtcNow;

				if( cvInfo.documents != null )
				{
					foreach( var doc in cvInfo.documents.Where( d => d.isActive ) )
					{
						var newDocument = new ClassVersionDocument();

						newDocument.FileName = doc.newFileName;
						newDocument.OriginalName = doc.originalFileName;
						newDocument.IsDeleted = false;

						newClassVersion.ClassVersionDocuments.Add( newDocument );
					}
				}

				if( cvInfo.safetyDocuments != null )
				{
					foreach( var doc in cvInfo.safetyDocuments.Where( d => d.isActive ) )
					{
						var newDocument = new ClassVersionSafetyDocument();

						newDocument.FileName = doc.newFileName;
						newDocument.OriginalName = doc.originalFileName;
						newDocument.IsDeleted = false;

						newClassVersion.ClassVersionSafetyDocuments.Add( newDocument );
					}
				}

				var order = 0;
				foreach( var question in cvInfo.questions.Where( q => q.isActive ) )
				{
					var newQuestion = new ClassQuestion();

					newQuestion.Text = question.text;
					newQuestion.Narrative = question.narrative;
					newQuestion.DisplayOrder = order++;
					newQuestion.ImageFileName = question.imageFileName;
					newQuestion.OriginalImageFileName = question.originalImageFileName;
					newQuestion.AudioFileName = question.audioFileName;
					newQuestion.OriginalAudioFileName = question.originalAudioFileName;
					newQuestion.FullAudioFileName = question.fullAudioFileName;
					newQuestion.OriginalFullAudioFileName = question.originalFullAudioFileName;
					newQuestion.IsDeleted = false;

					foreach( var answer in question.answers.Where( a => a.isActive ) )
					{
						var newAnswer = new ClassAnswer();

						newAnswer.Text = answer.text;
						newAnswer.IsCorrect = answer.isCorrect;
						newAnswer.IsDeleted = false;
						newAnswer.AudioFileName = answer.audioFileName;
						newAnswer.OriginalAudioFileName = answer.originalAudioFileName;

						newQuestion.ClassAnswers.Add( newAnswer );
					}

					newClassVersion.ClassQuestions.Add( newQuestion );
				}

				dbClass.ClassVersions.Add( newClassVersion );

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorClassNotFound" );
		}

		public void EditClassVersion( ClassVersionInformation cvInfo )
		{
			var dbClassVersion = database.ClassVersions
				.FirstOrDefault( u => u.VersionID == cvInfo.versionId );

			if( dbClassVersion != null )
			{
				dbClassVersion.OriginalCaptionName = cvInfo.originalCaptionName;
				dbClassVersion.CaptionFileName = cvInfo.newCaptionName;
				dbClassVersion.IsDeleted = !cvInfo.isActive;

				dbClassVersion.ClassType = (GDWClassTypes.ClassType)Enum.Parse(typeof(GDWClassTypes.ClassType), cvInfo.classType);

				switch (dbClassVersion.ClassType)
				{
					case GDWClassTypes.ClassType.Video:
						dbClassVersion.VideoID = cvInfo.videoId;
						dbClassVersion.ScormClassID = null;
						dbClassVersion.PDFFileName = null;
						dbClassVersion.OriginalPDFName = null;
						break;
					case GDWClassTypes.ClassType.Scorm:
						dbClassVersion.VideoID = null;
						dbClassVersion.PDFFileName = null;
						dbClassVersion.OriginalPDFName = null;

						if (dbClassVersion.ScormClass == null ||
							dbClassVersion.ScormClass.ScormProvider != cvInfo.scormProvider ||
							dbClassVersion.ScormClass.ClassHandle != cvInfo.scormClassHandle)
                        {
							dbClassVersion.ScormClass = new ScormClass()
							{
								ScormProvider = cvInfo.scormProvider,
								ClassHandle = cvInfo.scormClassHandle
							};
							ScormProviders.GetScormProvider(cvInfo.scormProvider).OnCourseImported(dbClassVersion.ScormClass.ClassHandle);
						}
						break;
					case GDWClassTypes.ClassType.Pdf:
						dbClassVersion.VideoID = null;
						dbClassVersion.ScormClassID = null;
						dbClassVersion.PDFFileName = cvInfo.newPDFName;
						dbClassVersion.OriginalPDFName = cvInfo.originalPDFName;
						break;
				}

                dbClassVersion.GuideFileName = cvInfo.newGuideName;
				dbClassVersion.OriginalGuideName = cvInfo.originalGuideName;

				dbClassVersion.LastModified = DateTime.UtcNow;

				if( cvInfo.documents != null )
				{
					foreach( var doc in cvInfo.documents )
					{
						if( doc.documentId == 0 )
						{
							if( doc.isActive )
							{
								var newDocument = new ClassVersionDocument();

								newDocument.FileName = doc.newFileName;
								newDocument.OriginalName = doc.originalFileName;
								newDocument.IsDeleted = false;

								dbClassVersion.ClassVersionDocuments.Add( newDocument );
							}
						}
						else if( !doc.isActive )
						{
							var dbDocument = dbClassVersion.ClassVersionDocuments
								.FirstOrDefault( d => d.DocumentID == doc.documentId );
							if( dbDocument != null )
							{
								dbDocument.IsDeleted = true;
							}
						}
					}
				}

				if( cvInfo.safetyDocuments != null )
				{
					foreach( var doc in cvInfo.safetyDocuments )
					{
						if( doc.documentId == 0 )
						{
							if( doc.isActive )
							{
								var newDocument = new ClassVersionSafetyDocument();

								newDocument.FileName = doc.newFileName;
								newDocument.OriginalName = doc.originalFileName;
								newDocument.IsDeleted = false;

								dbClassVersion.ClassVersionSafetyDocuments.Add( newDocument );
							}
						}
						else if( !doc.isActive )
						{
							var dbDocument = dbClassVersion.ClassVersionSafetyDocuments
								.FirstOrDefault( d => d.SafetyDocumentID == doc.documentId );
							if( dbDocument != null )
							{
								dbDocument.IsDeleted = true;
							}
						}
					}
				}

				var order = 0;
				foreach( var question in cvInfo.questions )
				{
					if( question.questionId == 0 )
					{
						if( question.isActive )
						{
							var newQuestion = new ClassQuestion();

							newQuestion.Text = question.text;
							newQuestion.Narrative = question.narrative;
							newQuestion.DisplayOrder = order++;
							newQuestion.ImageFileName = question.imageFileName;
							newQuestion.OriginalImageFileName = question.originalImageFileName;
							newQuestion.IsDeleted = false;
							newQuestion.AudioFileName = question.audioFileName;
							newQuestion.OriginalAudioFileName = question.originalAudioFileName;
							newQuestion.FullAudioFileName = question.fullAudioFileName;
							newQuestion.OriginalFullAudioFileName = question.originalFullAudioFileName;

							foreach( var answer in question.answers.Where( a => a.isActive ) )
							{
								var newAnswer = new ClassAnswer();

								newAnswer.Text = answer.text;
								newAnswer.IsCorrect = answer.isCorrect;
								newAnswer.IsDeleted = false;
								newAnswer.AudioFileName = answer.audioFileName;
								newAnswer.OriginalAudioFileName = answer.originalAudioFileName;

								newQuestion.ClassAnswers.Add( newAnswer );
							}

							dbClassVersion.ClassQuestions.Add( newQuestion );
						}
					}
					else
					{
						var dbQuestion = dbClassVersion.ClassQuestions
							.FirstOrDefault( q => q.QuestionID == question.questionId );
						if( dbQuestion != null )
						{
							dbQuestion.Text = question.text;
							dbQuestion.Narrative = question.narrative;
							dbQuestion.DisplayOrder = order++;
							dbQuestion.ImageFileName = question.imageFileName;
							dbQuestion.OriginalImageFileName = question.originalImageFileName;
							dbQuestion.IsDeleted = !question.isActive;
							dbQuestion.AudioFileName = question.audioFileName;
							dbQuestion.OriginalAudioFileName = question.originalAudioFileName;
							dbQuestion.FullAudioFileName = question.fullAudioFileName;
							dbQuestion.OriginalFullAudioFileName = question.originalFullAudioFileName;

							foreach( var answer in question.answers )
							{
								if( answer.answerId == 0 )
								{
									if( answer.isActive )
									{
										var newAnswer = new ClassAnswer();

										newAnswer.Text = answer.text;
										newAnswer.IsCorrect = answer.isCorrect;
										newAnswer.IsDeleted = false;
										newAnswer.AudioFileName = answer.audioFileName;
										newAnswer.OriginalAudioFileName = answer.originalAudioFileName;

										dbQuestion.ClassAnswers.Add( newAnswer );
									}
								}
								else
								{
									var dbAnswer = dbQuestion.ClassAnswers
										.FirstOrDefault( a => a.AnswerID == answer.answerId );
									if( dbAnswer != null )
									{
										dbAnswer.Text = answer.text;
										dbAnswer.IsCorrect = answer.isCorrect;
										dbAnswer.IsDeleted = !answer.isActive;
										dbAnswer.AudioFileName = answer.audioFileName;
										dbAnswer.OriginalAudioFileName = answer.originalAudioFileName;
									}
								}
							}
						}
					}
				}

				database.SaveChanges();

				return;
			}
			
			throw new GDWException( "ErrorClassVersionNotFound" );
		}

		public void DeleteClassVersion( int versionId )
		{
			var dbClassVersion = database.ClassVersions.FirstOrDefault( u => u.VersionID == versionId );

			if( dbClassVersion != null )
			{
				dbClassVersion.IsDeleted = true;
				dbClassVersion.LastModified = DateTime.UtcNow;

				database.SaveChanges();

				return;
			}
			
			throw new GDWException( "ErrorClassVersionNotFound" );
		}
		#endregion

		public IEnumerable<string> GetCustomerCategoryDropDownList( int? customerId )
		{
            if (!customerId.HasValue)
                return GetCategoryDropDownList();

            var customer = database.Customers
                                   .Include(c => c.AvailableClasses.Select(ac => ac.ClassCategories))
                                   .FirstOrDefault(c => c.CustomerID == customerId.Value);
            if (customer == null)
	            throw new GDWException("ErrorCustomerNotFound");

            if (customer.EnterpriseLevel == GDWEnterpriseLevels.EnterpriseLevel.Basic)
            {
	            return customer.AvailableClasses.SelectMany(cl => cl.ClassCategories).Select(c => c.Name).Distinct().OrderBy(n => n).ToList();
            }

			return database.ClassCategories
				.Where( c => c.Classes.Any( cl => !cl.CustomerID.HasValue || cl.CustomerID.Value == customerId.Value ) )
				.Select( c => c.Name )
				.ToList();
		}

        public IEnumerable<MyClassSummary> GetClassListForUser( int userId )
		{
		    var theList = database.UserClasses
		        .Where( c => c.UserID == userId )
		        .Where(uc => uc.User.CustomerLocations.Any(
			               cl => cl.Customer.EnterpriseLevel != GDWEnterpriseLevels.EnterpriseLevel.Basic ||
			                     cl.Customer.AvailableClasses.Any(ac => ac.ClassID == uc.ClassID)))
		        .ToList()
		        .Select( c => new MyClassSummary()
		            {
		                userClassId = c.UserClassID,
		                name = c.Name,
		                dueDate = c.DueDate,
		                progress = c.Progress,
		                score = (int)(Math.Round( c.Score ?? 0, 0 )),
                        isPassingGrade = c.Score.HasValue && c.Score.Value >= c.PassPercent,
		                completeDate = c.UserTests.Max( t => t.CompleteDate ),
		                hasDocuments = c.UserClassVersions.Any( ucv => ucv.LanguageID == (c.PrefLanguageID ?? c.User.LanguageID) )
		                    ? c.UserClassVersions.First( ucv => ucv.LanguageID == (c.PrefLanguageID ?? c.User.LanguageID) ).UserClassVersionDocuments.Any()
		                    : c.UserClassVersions.Any() && c.UserClassVersions.First().UserClassVersionDocuments.Any()
		            } )
		        .ToList();

			return theList
				.OrderByDescending( c => c.progress )
				.ThenBy( c => c.dueDate );
		}

	    public MyClassCertificateInformation GetClassCertificateInformationForUser( int id, int userId )
	    {
			var ucInfo = database.UserClasses
                .Include( uc => uc.User )
                .Include( uc => uc.UserTests )
                .FirstOrDefault( uc => uc.UserClassID == id && uc.UserID == userId );
			if( ucInfo == null )
			{
				throw new GDWException( "ErrorClassNotFoundForUser" );
			}

	        if ( ucInfo.Status != GDWClassStatus.Status.TestPassed )
	        {
	            throw new GDWException( "ErrorClassNotFoundForUser" );
	        }
            
	        var completedDate = ucInfo.UserTests.OrderByDescending( t => t.TestID ).First().CompleteDate;
	        Debug.Assert( completedDate.HasValue );

	        var customer = database.Customers
	            .Include( c => c.CustomerSignatures )
	            .FirstOrDefault(c => c.CustomerLocations.Any( l => l.Users.Any( u => u.UserID == userId ) ));
            var customerSig = customer != null
                ? customer.CustomerSignatures.FirstOrDefault( cs => !string.IsNullOrEmpty( cs.Name ) && !string.IsNullOrEmpty( cs.Title ) && !string.IsNullOrEmpty( cs.ImageFileName ) )
                : null;
            var dbConfig = database.ConfigurationOptions.FirstOrDefault();

            return new MyClassCertificateInformation
	            {
                    FirstName = ucInfo.User.FirstName,
                    LastName = ucInfo.User.LastName,
                    ClassName = ucInfo.Name,
					CompletedDate = completedDate.Value,
                    CustomerLogoFileName = customer != null ? customer.LogoFileName : null,
                    AuthorizedName = customerSig != null ? customerSig.Name : null,
                    AuthorizedTitle = customerSig != null ? customerSig.Title : null,
                    AuthorizedSignatureFileName = customerSig != null ? customerSig.ImageFileName : null,
					GDWLogoFileName = dbConfig?.CertificateLogoFileName,
					GDWAuthorizedName = dbConfig?.CertificateSignatureName,
					GDWAuthorizedTitle = dbConfig?.CertificateSignatureTitle,
					GDWAuthorizedSignatureFileName = dbConfig?.CertificateSignatureImageFileName
	            };
	    }

		public MyClassInformation GetUserClassInfo( int id )
		{
			var ucInfo = database.UserClasses
			                     .Where(uc => uc.User.CustomerLocations.Any(
				                            cl => cl.Customer.EnterpriseLevel != GDWEnterpriseLevels.EnterpriseLevel.Basic ||
				                                  cl.Customer.AvailableClasses.Any(ac => ac.ClassID == uc.ClassID)))
			                     .FirstOrDefault(uc => uc.UserClassID == id);
			if( ucInfo == null )
			{
				throw new GDWException( "ErrorClassNotFoundForUser" );
			}

			if( ucInfo.Status == GDWClassStatus.Status.New )
			{
				// first time to view the class
				ucInfo.Status = GDWClassStatus.Status.Started;
				ucInfo.StartDate = DateTime.UtcNow;

//				database.SaveChanges(); // don't need to save changed - having no user tests will save them later
				var newUserVersion = ucInfo.UserClassVersions.FirstOrDefault( cv => cv.LanguageID == ucInfo.User.LanguageID );
				if( newUserVersion == null )
				{
					newUserVersion = ucInfo.UserClassVersions.FirstOrDefault();
				}

				if( newUserVersion == null )
				{
					throw new GDWException( "ErrorClassNotFoundForUser" );
				}

				ucInfo.PrefLanguageID = newUserVersion.LanguageID;
			}

			var userVersion = ucInfo.UserClassVersions.FirstOrDefault( cv => cv.LanguageID == ucInfo.PrefLanguageID );
			if( userVersion == null )
			{
				throw new GDWException( "ErrorClassNotFoundForUser" );
			}

			if( !ucInfo.UserTests.Any() )
			{
				ucInfo.UserTests.Add( NewUserTest( ucInfo, userVersion ) );

				database.SaveChanges();
			}

			var userTest = ucInfo.UserTests
				.OrderByDescending( t => t.TestID )
				.FirstOrDefault();

			return ToMyClassInformation( ucInfo, userVersion, userTest );
		}

		public MyClassInformation ToMyClassInformation( UserClass ucInfo, UserClassVersion userVersion, UserTest userTest )
		{
			return new MyClassInformation()
			{
				userClassId = ucInfo.UserClassID,
				name = ucInfo.Name,
				description = ucInfo.Description,
				status = ucInfo.Status.ToString(),
				classType = userVersion.ClassType.ToString(),
				videoFile = userVersion.ClassType == GDWClassTypes.ClassType.Video ? userVersion.Video.StreamName : null,
				scormLink = userVersion.ClassType == GDWClassTypes.ClassType.Scorm ?
								ScormProviders.GetScormProvider(userVersion.ScormClass.ScormProvider)
												.LaunchCourse(userVersion, userVersion.ScormClass.ClassHandle).ToString()
								: null,
				pdfFile = userVersion.ClassType == GDWClassTypes.ClassType.Pdf ? userVersion.PDFFileName : null,
				captions = ucInfo.UserClassVersions.Where( v => v.CaptionFileName != null ).Select( v => new CaptionFileInformation() { fileName = v.CaptionFileName, language = v.Language.Name } ).ToList(),
				documents = userVersion.UserClassVersionDocuments
					.Select( d => new MyClassDocument()
					{
						displayName = d.OriginalName,
						fileName = d.FileName
					} )
					.ToList(),
				questions = userTest.UserTestQuestions
						.OrderBy( q => q.DisplayOrder )
						.Select( q => new MyClassQuestion()
						{
							tQuestionId = q.TQuestionID,
							text = q.UserClassQuestion.Text,
							narrative = q.UserClassQuestion.Narrative,
							imageFileName = q.UserClassQuestion.ImageFileName,
							fullAudioFileName = q.UserClassQuestion.AudioFileName,
							answers = q.UserTestAnswers
							.Select( a => new MyClassAnswer()
							{
								tAnswerId = a.TAnswerID,
								text = a.UserClassAnswer.Text,
								isChosen = a.IsChosen ?? false,
								fullAudioFileName = a.UserClassAnswer.AudioFileName,
							} )
							.ToList()
						} )
						.ToList(),
				testResults = GetResults( ucInfo ),
				faqs = ucInfo.Class
					.ClassFAQs
					.Where( f => f.IsPublic || f.AskUserID == ucInfo.UserID )
					.Where( f => f.AnswerText != null )
					.Where( f => ucInfo.User.CustomerLocations.First().Customer == f.AskUser.CustomerLocations.First().Customer )
					.Select( f => new MyClassFAQ() { questionText = f.UpdatedAskText ?? f.AskText, answerText = f.AnswerText } )
					.ToList()
			};
		}

		private UserTest NewUserTest( UserClass ucInfo, UserClassVersion userVersion )
		{
			var newTest = new UserTest();
			
			newTest.IsImport = false;

			int minCount = userVersion.UserClassQuestions.Count, maxCount = userVersion.UserClassQuestions.Count;
			if( ucInfo.TotalQuestionMinimum.HasValue && (ucInfo.TotalQuestionMinimum.Value > 0) )
			{
				minCount = Math.Min( ucInfo.TotalQuestionMinimum.Value, userVersion.UserClassQuestions.Count );
			}
			if( ucInfo.TotalQuestionMaximum.HasValue && (ucInfo.TotalQuestionMaximum.Value > 0) )
			{
				maxCount = Math.Min( ucInfo.TotalQuestionMaximum.Value, userVersion.UserClassQuestions.Count );
			}

			int qCount = minCount;
			if( minCount != maxCount )
			{
				qCount = (new Random().Next( minCount, maxCount ));
			}

			var r = new Random();
			var newOrder = 0;
			foreach( var ucQuestion in userVersion.UserClassQuestions
				.OrderBy( t => r.Next() )	// pick random questions
				.Take( qCount )
				.OrderBy( t => ucInfo.RandomizeQuestions ? r.Next() : t.DisplayOrder ) )	// order them at random if needed
			{
				var newQuestion = new UserTestQuestion()
				{
					UserClassQuestion = ucQuestion,
					DisplayOrder = newOrder
				};

				foreach( var ucAnswer in ucQuestion.UserClassAnswers )
				{
					newQuestion.UserTestAnswers.Add( new UserTestAnswer()
					{
						UserClassAnswer = ucAnswer,
						IsChosen = null
					} );
				}

				newTest.UserTestQuestions.Add( newQuestion );

				newOrder++;
			}

			return newTest;
		}

		private MyClassResults GetResults( UserClass ucInfo )
		{
			var results = new MyClassResults() { questions = new List<MyClassResultQuestion>() };
			if( ucInfo.Status == GDWClassStatus.Status.TestPassed ||
				ucInfo.Status == GDWClassStatus.Status.TestComplete )
			{
				var dbTest = ucInfo.UserTests
					.OrderByDescending( t => t.TestID )
					.FirstOrDefault();

				results.questions = dbTest.UserTestQuestions
						.OrderBy( q => q.DisplayOrder )
						.Select( q => new MyClassResultQuestion()
						{
							questionText = q.UserClassQuestion.Text,
							questionNarrative = q.UserClassQuestion.Narrative,
							correctAnswerText = q.UserClassQuestion.UserClassAnswers.FirstOrDefault( a => a.IsCorrect ).Text,
							givenAnswerText = q.UserTestAnswers.FirstOrDefault( a => a.IsChosen ?? false ).UserClassAnswer.Text,
							isCorrect = q.UserTestAnswers.FirstOrDefault( a => a.IsChosen ?? false ).UserClassAnswer.IsCorrect
						} ).ToList();

				results.passPercent = ucInfo.PassPercent;
				results.attempts = ucInfo.UserTests.Count();
				results.percentCorrect = dbTest.Score.HasValue ? (int)dbTest.Score.Value : 0;
				results.isImport = dbTest.IsImport;
			}

			return results;
		}

		public MyClassResults SubmitTestResults( int id )
		{
			var ucInfo = database.UserClasses.FirstOrDefault( uc => uc.UserClassID == id );
			if( ucInfo == null )
			{
				throw new GDWException( "ErrorClassNotFoundForUser" );
			}

			var uTest = ucInfo.UserTests
					.OrderByDescending( t => t.TestID )
					.FirstOrDefault();
			uTest.CompleteDate = DateTime.UtcNow;
			uTest.Score = database.GetTestScore( uTest.TestID ).First().Score;

			ucInfo.Status = GDWClassStatus.Status.TestPassed;
			if( ucInfo.Score < ucInfo.Class.PassPercent )
			{
				ucInfo.Status = GDWClassStatus.Status.TestComplete;
			}

			database.SaveChanges();

			var results = GetResults( ucInfo );

			if( results.attempts >= 3 &&
				!results.isPassingGrade )
			{
				// three failed attempts - send emails around
				var alertUsers = ucInfo.User.CustomerLocations
					.SelectMany( cl => cl.Users )
					.Union( ucInfo.User.CustomerDepartments
						.SelectMany( cd => cd.Users ) )
					.Where( u => u.PermissionGroups
						.SelectMany( pg => pg.PermissionGroupItems.Select( pgi => pgi.PermissionID ) )
						.Contains( GDWPermissionTypes.Permissions.AlertThreeFailed ) )
					.Where( u => !u.IsDeleted )
					.Distinct();

			    using ( var aRepo = new AccountRepository() )
			    {
			        foreach ( var user in alertUsers )
			        {
			            var emailRecipients = aRepo.GetEmailRecipientsForUser( user );
			            foreach ( var recip in emailRecipients )
			            {
			                (new ThreeFailedClassesEmailSender( recip.Language.StringClass )).SubmitThreeFailedClassesEmail( recip.EmailAddress, ucInfo.Name, ucInfo.User.FullName, results.attempts );
			            }
			        }
			    }
			}

			return results;
		}

		public bool IsScormClassComplete( int id )
        {
			var ucInfo = database.UserClasses.FirstOrDefault(uc => uc.UserClassID == id);
			if (ucInfo == null)
			{
				throw new GDWException("ErrorClassNotFoundForUser");
			}

			var userVersion = ucInfo.UserClassVersions.FirstOrDefault(cv => cv.LanguageID == ucInfo.PrefLanguageID);
			if (userVersion == null)
			{
				userVersion = ucInfo.UserClassVersions.FirstOrDefault();
			}

			if (userVersion == null)
			{
				throw new GDWException("ErrorClassNotFoundForUser");
			}

			if (userVersion.ClassType != GDWClassTypes.ClassType.Scorm)
            {
				throw new GDWException("ErrorNotAScormCourse");
            }

			return ScormProviders.GetScormProvider(userVersion.ScormClass.ScormProvider).IsCourseComplete(userVersion, userVersion.ScormClass.ClassHandle);
        }

		public bool MarkClassVideoComplete( int id )
		{
			var ucInfo = database.UserClasses.FirstOrDefault( uc => uc.UserClassID == id );
			if( ucInfo == null )
			{
				throw new GDWException( "ErrorClassNotFoundForUser" );
			}

			ucInfo.Status = GDWClassStatus.Status.VideoComplete;

			database.SaveChanges();

			return true;
		}

		public bool MarkVideoStateChange( int userClassId, string newState, double timeIndex )
		{
			var ucInfo = database.UserClasses.FirstOrDefault( uc => uc.UserClassID == userClassId );
			if( ucInfo == null )
			{
				throw new GDWException( "ErrorClassNotFoundForUser" );
			}

			switch( newState )
			{
				case "play":
					// add a new item
					ucInfo.UserClassActivities.Add( new UserClassActivity() { PlayDateTime = DateTime.UtcNow, TimeIndex = timeIndex } );
					break;
				case "pause":
					// update last item
					{
						var prev = ucInfo.UserClassActivities
							.Where( a => !a.PauseDateTime.HasValue )
							.OrderByDescending( a => a.PlayDateTime )
							.FirstOrDefault();
						if( prev != null )
						{
							prev.PauseDateTime = DateTime.UtcNow;
							prev.TimeIndex = timeIndex;
						}
					}
					break;
			}

			database.SaveChanges();

			return true;
		}

		public bool MarkClassTestStarted( int id )
		{
			var ucInfo = database.UserClasses.FirstOrDefault( uc => uc.UserClassID == id );
			if( ucInfo == null )
			{
				throw new GDWException( "ErrorClassNotFoundForUser" );
			}

			ucInfo.Status = GDWClassStatus.Status.InTest;

			database.SaveChanges();

			return true;
		}

		public bool SubmitTestQuestion( MyClassQuestion question )
		{
			var tQuestion = database.UserTestQuestions.FirstOrDefault( q => q.TQuestionID == question.tQuestionId );
			if( tQuestion == null )
			{
				throw new GDWException( "ErrorClassNotFoundForUser" );
			}

			foreach( var tAnswer in tQuestion.UserTestAnswers )
			{
				var userAnswer = question.answers.FirstOrDefault( a => a.tAnswerId == tAnswer.TAnswerID );
				if( userAnswer != null )
				{
					tAnswer.IsChosen = userAnswer.isChosen;
				}
			}
		
			database.SaveChanges();

			return true;
		}

		public MyClassInformation ReTakeTest( int id )
		{
			var ucInfo = database.UserClasses.FirstOrDefault( uc => uc.UserClassID == id );
			if( ucInfo == null )
			{
				throw new GDWException( "ErrorClassNotFoundForUser" );
			}

			var userVersion = ucInfo.UserClassVersions.FirstOrDefault( cv => cv.LanguageID == ucInfo.PrefLanguageID );
			if( userVersion == null )
			{
				userVersion = ucInfo.UserClassVersions.FirstOrDefault();
			}

			if( userVersion == null )
			{
				throw new GDWException( "ErrorClassNotFoundForUser" );
			}

			var newTest = NewUserTest( ucInfo, userVersion );
			ucInfo.UserTests.Add( newTest );
			ucInfo.Status = userVersion.ClassType == GDWClassTypes.ClassType.Video ? GDWClassStatus.Status.VideoComplete : GDWClassStatus.Status.Started;

			database.SaveChanges();

			return ToMyClassInformation( ucInfo, userVersion, newTest );
		}

		#region Reports

		public IEnumerable<ScoreImportDetail> GetScoreSheet( TranscriptFilter filter )
		{
			if( filter.locations == null )
			{
				filter.locations = new List<int>();
			}

			if( filter.departments == null )
			{
				filter.departments = new List<int>();
			}

			if( filter.employees == null )
			{
				filter.employees = new List<int>();
			}

			var employeeList = database.Users
				.Where( e => e.CustomerLocations.Any( l => l.CustomerID == filter.customerId ) )
				.AsQueryable();

			if( filter.locations.Any() || filter.departments.Any() || filter.employees.Any() )
			{
				employeeList = employeeList
					.Where( c => filter.locations.Intersect( c.CustomerLocations.Select( l => l.LocationID ) ).Any() ||
						filter.departments.Intersect( c.CustomerDepartments.Select( d => d.DepartmentID ) ).Any() ||
						filter.employees.Contains( c.UserID ) );
			}

			switch( (filter.status ?? "active").ToLower() )
			{
				case "active":
					employeeList = employeeList.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					employeeList = employeeList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}

			var employeeIdList = employeeList
				.Select( e => e.UserID )
				.Distinct()
				.ToList();

			return database.Users
				.Where( u => employeeIdList.Contains( u.UserID ) )
				.Select( u => new ScoreImportDetail()
				{
					firstName = u.FirstName,
					lastName = u.LastName
				} )
				.ToList();
		}

		public IEnumerable<TranscriptInformation> GetTranscript( TranscriptFilter filter )
		{
			if( filter.categories == null )
			{
				filter.categories = new List<string>();
			}

			if( filter.classes == null )
			{
				filter.classes = new List<int>();
			}

			if( filter.locations == null )
			{
				filter.locations = new List<int>();
			}

			if( filter.departments == null )
			{
				filter.departments = new List<int>();
			}

			if( filter.employees == null )
			{
				filter.employees = new List<int>();
			}

			var classList = database.Classes
				.Where( c => !c.IsDeleted )
				.AsQueryable();

			if( filter.categories.Any() || filter.classes.Any() )
			{
				classList = classList
					.Where( c => filter.classes.Contains( c.ClassID ) || filter.categories.Intersect( c.ClassCategories.Select( ca => ca.Name ) ).Any() );
			}

			var classIdList = classList
				.Select( c => c.ClassID )
				.Distinct()
				.ToList();

			var employeeList = database.Users
				.Where( e => e.CustomerLocations.Any( l => l.CustomerID == filter.customerId ) )
				.AsQueryable();

			if( filter.locations.Any() || filter.departments.Any() || filter.employees.Any() )
			{
				employeeList = employeeList
					.Where( c => filter.locations.Intersect( c.CustomerLocations.Select( l => l.LocationID ) ).Any() ||
						filter.departments.Intersect( c.CustomerDepartments.Select( d => d.DepartmentID ) ).Any() ||
						filter.employees.Contains( c.UserID ) );
			}

			switch( (filter.status ?? "active").ToLower() )
			{
				case "active":
					employeeList = employeeList.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					employeeList = employeeList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}

			var employeeIdList = employeeList
				.Select( e => e.UserID )
				.Distinct()
				.ToList();

			var startDate = filter.startDate.ToUniversalTime();
			var endDate = filter.endDate.ToUniversalTime().AddDays( 1 ).AddMilliseconds( -1 );

			var userClasses = database.UserClasses
				.Include( uc => uc.User )
				.Where( uc => uc.AssignDate >= startDate && uc.AssignDate <= endDate )
				.Where( uc => employeeIdList.Contains( uc.UserID ) && classIdList.Contains( uc.ClassID ) )
				.Where( uc => uc.Status == GDWClassStatus.Status.TestPassed )
				.OrderBy( uc => uc.User.LastName )
				.ThenBy( uc => uc.User.FirstName )
				.ThenByDescending( uc => uc.AssignDate )
				.ToList();

			var results = new List<TranscriptInformation>();
			foreach (var uc in userClasses)
			{
				var tests = uc.UserTests.OrderBy(t => t.TestID).ToArray();
				var test1 = tests.Length >= 1 ? tests[0] : null;
				var test2 = tests.Length >= 2 ? tests[1] : null;
				var test3 = tests.Length >= 3 ? tests[2] : null;
				var lastTest = uc.UserTests.OrderByDescending(t => t.TestID).FirstOrDefault();

				var info = new TranscriptInformation()
				{
					EmployeeName = uc.User.FullName,
					ClassName = uc.Name,
					AssignedDate = uc.AssignDate?.ToShortDateString() ?? "",
					DueDate = uc.DueDate.ToShortDateString(),
					CompletedDate = lastTest?.CompleteDate?.ToShortDateString() ?? "",
					Score = uc.Score.HasValue ? Math.Round(uc.Score.Value).ToString() : "",
					Score1 = test1?.Score != null ? Math.Round(test1.Score.Value).ToString() : "",
					Score2 = test2?.Score != null ? Math.Round(test2.Score.Value).ToString() : "",
					Score3 = test3?.Score != null ? Math.Round(test3.Score.Value).ToString() : "",
					TestType1 = test1 != null ? (test1.IsImport ? "Import" : "Taken") : "",
					TestType2 = test2 != null ? (test2.IsImport ? "Import" : "Taken") : "",
					TestType3 = test3 != null ? (test3.IsImport ? "Import" : "Taken") : "",
				};
				results.Add(info);
			}

			return results;
		}

		#endregion

		public void CheckClassStatus()
		{
            // NOTE: The strings in GDWClassEmailFrequencies's ToDisplayString method will need to be changed
            // if these email schedules are changed.
			var allOverdueWarnings = new int[] { 30, 14, 7, 2, 1, 0 };
			var limitedOverdueWarnings = new int[] { 7, 2, 0 };
			var singleOverdueWarning = new int[] { 0 };

		    var cachedCustomersById = new Dictionary<int, Customer>();

			foreach( var incompleteClass in database.UserClasses
				.Include( uc => uc.User.CustomerLocations )
				.Where( uc => uc.Status != GDWClassStatus.Status.TestPassed ) )
			{
				var daysToDue = (incompleteClass.DueDate - DateTime.Now.Date).Days;
                
                var customerID = incompleteClass.User.CustomerLocations.Select( cl => cl.CustomerID ).FirstOrDefault();
			    Customer dbCustomer = null;
                if ( customerID != 0 )
                {
                    if ( !cachedCustomersById.TryGetValue( customerID, out dbCustomer ) )
                    { 
                        dbCustomer = database.Customers.SingleOrDefault( c => c.CustomerID == customerID );
                        cachedCustomersById[ customerID ] = dbCustomer;
                    }
                }

			    var emailFrequency = dbCustomer != null ? dbCustomer.ClassEmailFrequency : GDWClassEmailFrequencies.ClassEmailFrequency.All;

			    int neededWarning;
			    switch ( emailFrequency )
			    {
			        case GDWClassEmailFrequencies.ClassEmailFrequency.All:
                        neededWarning = allOverdueWarnings.Where( w => w >= daysToDue ).DefaultIfEmpty( 60 ).Min();	// the smallest warning greater than the number of days left
			            break;

                    case GDWClassEmailFrequencies.ClassEmailFrequency.Limited:
                        neededWarning = limitedOverdueWarnings.Where( w => w >= daysToDue ).DefaultIfEmpty( 60 ).Min();	// the smallest warning greater than the number of days left
			            break;

                    default:
                        neededWarning = singleOverdueWarning.Where( w => w >= daysToDue ).DefaultIfEmpty( 60 ).Min();	// the smallest warning greater than the number of days left
			            break;
			    }

				if( neededWarning < 60 )
				{
					if( neededWarning < incompleteClass.OverdueWarning || !incompleteClass.OverdueWarning.HasValue )
					{
                        if ( emailFrequency != GDWClassEmailFrequencies.ClassEmailFrequency.None && emailFrequency != GDWClassEmailFrequencies.ClassEmailFrequency.AssignmentOnly )
                        { 
						    // send alert
					        using ( var aRepo = new AccountRepository() )
					        {
					            var emailRecipients = aRepo.GetEmailRecipientsForUser( incompleteClass.User );
					            foreach ( var recip in emailRecipients )
					            {
					                (new OverdueWarningEmailSender( recip.Language.StringClass )).SubmitOverdueWarningEmail( recip.EmailAddress, incompleteClass.User.FirstName,
                                        incompleteClass.User.LastName, neededWarning, incompleteClass.UserClassID, incompleteClass.Name );
					            }
					        }
					    }

					    // update warning setting
						incompleteClass.OverdueWarning = neededWarning;
					}
				}
			}

			database.SaveChanges();
		}

		public MyClassStatus GetCurrentClassStatus( int? userId = null, int? customerId = null )
		{
			var locations = new List<int>();

			if( customerId.HasValue )
			{
				// get this user's locations or all locations
				locations = database.CustomerLocations
					.Where( c => !c.IsDeleted )
					.Where( c => c.CustomerID == customerId.Value )
					.Where( c => c.Users.Any( u => u.UserID == userId ) || (userId == null) )
					.Select( c => c.LocationID )
					.ToList();
			}
			else if( userId.HasValue )
			{
				locations.Add( 0 );
			}
			else
			{
				locations = database.CustomerLocations
					.Where( c => !c.IsDeleted )
					.Select( c => c.LocationID )
					.ToList();
			}

			var dbUsers = database.Users
				.Where( u => (!u.IsDeleted) &&
					((u.UserID == userId) ||
					 (u.CustomerLocations.Any( c => locations.Contains( c.LocationID ) ))) );

			var assignedStatus = new GDWClassStatus.Status[5] { GDWClassStatus.Status.New, GDWClassStatus.Status.InTest, 
				GDWClassStatus.Status.Started, GDWClassStatus.Status.VideoComplete, GDWClassStatus.Status.TestComplete };
			var startedStatus = new GDWClassStatus.Status[4] { GDWClassStatus.Status.InTest, 
				GDWClassStatus.Status.Started, GDWClassStatus.Status.VideoComplete, GDWClassStatus.Status.TestComplete };
			
			var overDueDate = DateTime.Now;
			var thisWeekDueDate = DateTime.Now.AddDays( 7 );

			return new MyClassStatus()
			{
				assigned = dbUsers.SelectMany( u => u.UserClasses.Where( uc => assignedStatus.Contains( uc.Status ) ) ).Count(),
				notStarted = dbUsers.SelectMany( u => u.UserClasses.Where( uc => (uc.Status == GDWClassStatus.Status.New) && (uc.DueDate > thisWeekDueDate) ) ).Count(),
				started = dbUsers.SelectMany( u => u.UserClasses.Where( uc => startedStatus.Contains( uc.Status ) && uc.DueDate > thisWeekDueDate ) ).Count(),
				dueThisWeek = dbUsers.SelectMany( u => u.UserClasses.Where( uc => assignedStatus.Contains( uc.Status ) && uc.DueDate > overDueDate && uc.DueDate <= thisWeekDueDate ) ).Count(),
				overdue = dbUsers.SelectMany( u => u.UserClasses.Where( uc => assignedStatus.Contains( uc.Status ) && uc.DueDate <= overDueDate ) ).Count()				
			};
		}

		public object GetClassPassingWidget( int? userId = null, int? customerId = null )
		{
			var locations = new List<int>();

			if( customerId.HasValue )
			{
				// get this user's locations or all locations
				locations = database.CustomerLocations
					.Where( c => !c.IsDeleted )
					.Where( c => c.CustomerID == customerId.Value )
					.Where( c => c.Users.Any( u => u.UserID == userId ) || (userId == null) )
					.Select( c => c.LocationID )
					.ToList();
			}
			else if( userId.HasValue )
			{
				locations.Add( 0 );
			}
			else
			{
				locations = database.CustomerLocations
					.Where( c => !c.IsDeleted )
					.Select( c => c.LocationID )
					.ToList();
			}

			var dbUserClasses = database.Users
				.Where( u => (!u.IsDeleted) &&
					((u.UserID == userId) ||
					 (u.CustomerLocations.Any( c => locations.Contains( c.LocationID ) ))) )
				.SelectMany( u => u.UserClasses );

			var inTheLastYear = DateTime.Now.AddYears( -1 );

			return new MyPassingClassStatus()
			{
				inProgress = dbUserClasses.Where( uc => uc.AssignDate >= inTheLastYear &&
					uc.Status != GDWClassStatus.Status.TestPassed && uc.UserTests.Count( ut => ut.CompleteDate.HasValue ) >= 1 && uc.UserTests.Count( ut => ut.CompleteDate.HasValue ) < 3 ).Count(),
				passedFirstAttempt = dbUserClasses.Where( uc => uc.AssignDate >= inTheLastYear && 
					uc.Status == GDWClassStatus.Status.TestPassed && uc.UserTests.Count() == 1 ).Count(),
				passedSecondAttempt = dbUserClasses.Where( uc => uc.AssignDate >= inTheLastYear && 
					uc.Status == GDWClassStatus.Status.TestPassed && uc.UserTests.Count() == 2 ).Count(),
				passedThirdAttempt = dbUserClasses.Where( uc => uc.AssignDate >= inTheLastYear && 
					uc.Status == GDWClassStatus.Status.TestPassed && uc.UserTests.Count() == 3 ).Count(),
				failedThreeOrMoreAttempt = dbUserClasses.Where( uc => uc.AssignDate >= inTheLastYear && 
					((uc.Status == GDWClassStatus.Status.TestComplete && uc.UserTests.Count() == 3) || (uc.UserTests.Count() > 3)) ).Count()
			};
		}

		private IEnumerable<PopularClassSummary> GetMostPopularCourses( bool baseClassOnly )
		{
			var inTheLastYear = DateTime.Now.AddYears( -1 );

			return database.Classes
				.Where( c => !c.IsDeleted && (c.IsBaseClass == baseClassOnly) && (!c.CustomerID.HasValue) )
				.Select( c => new PopularClassSummary()
				{
					name = c.Name,
					count = c.UserClasses
						.Where( uc => uc.AssignDate >= inTheLastYear )
						.Count()
				} )
				.ToList()
				.OrderByDescending( pci => pci.count )
				.Where( pci => pci.count > 0 )
				.Take( 10 );
		}

		public PopularClassInformation GetMostPopularCourses()
		{
			return new PopularClassInformation()
			{
				baseClasses = GetMostPopularCourses( true ),
				nonBaseClasses = GetMostPopularCourses( false )
			};
		}

		public void SubmitFAQ( int userClassId, string questionText )
		{
			var dbUserClass = database.UserClasses.FirstOrDefault( uc => uc.UserClassID == userClassId );

			if( dbUserClass != null )
			{
				var newQuestion = new ClassFAQ()
				{
					AskUser = dbUserClass.User,
					AskText = questionText,
					Class = dbUserClass.Class,
					IsPublic = false,
					DateAsked = DateTime.UtcNow
				};

				database.ClassFAQs.Add( newQuestion );

				if( database.SaveChanges() > 0 )
				{
					var alertUsers = dbUserClass.User.CustomerLocations
						.SelectMany( cl => cl.Users )
						.Where( u => u.PermissionGroups
							.SelectMany( pg => pg.PermissionGroupItems.Select( pgi => pgi.PermissionID ) )
							.Contains( GDWPermissionTypes.Permissions.ManageFAQs ) )
						.Where( u => !u.IsDeleted )
						.Distinct();

					using ( var aRepo = new AccountRepository() )
					{
					    foreach( var user in alertUsers )
					    {
						    var emailRecipients = aRepo.GetEmailRecipientsForUser( user );
						    foreach ( var recip in emailRecipients )
						    {
						        (new NewFAQEmailSender( recip.Language.StringClass )).SubmitNewFAQEmail( recip.EmailAddress, dbUserClass.Class.Name, dbUserClass.User.FullName, questionText );
						    }
						}
					}

				}

				return;
			}

			throw new GDWException( "ErrorClassNotFound" );
		}

		public FAQInformation GetFAQItem( int id )
		{
			var dbFAQ = database.ClassFAQs.FirstOrDefault( f => f.FAQID == id );
			if( dbFAQ != null )
			{
				return new FAQInformation()
				{
					faqId = dbFAQ.FAQID,
					classId = dbFAQ.ClassID,
					className = dbFAQ.Class.Name,
					userName = dbFAQ.AskUser.FullName,
					originalQuestion = dbFAQ.AskText,
					editedQuestion = dbFAQ.UpdatedAskText,
					answerText = dbFAQ.AnswerText,
					isPublic = dbFAQ.IsPublic
				};
			}

			throw new GDWException( "ErrorClassNotFound" );
		}

		public IEnumerable<FAQSummary> GetFullFAQItemList( FAQTableParams param, int customerId, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var faqList = database.ClassFAQs
				.Include( f => f.AskUser.CustomerLocations )
				.Include( f => f.Class )
				.Where( f => f.AskUser.CustomerLocations.Any( c => c.CustomerID == customerId ) )
				.AsQueryable();

			totalRecords = faqList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				faqList = faqList.Where( i =>
					i.AskUser.FirstName.Contains( param.sSearch ) ||
					i.AskUser.LastName.Contains( param.sSearch ) ||
					i.Class.Name.Contains( param.sSearch ) );
			}
			switch( (param.answeredState ?? "answered").ToLower() )
			{
				case "answered":
					faqList = faqList.Where( u => u.AnswerText != null );
					break;
				case "unanswered":
					faqList = faqList.Where( u => u.AnswerText == null );
					break;
				case "all":
					break;
			}

			displayedRecords = faqList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<ClassFAQ> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "classname":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = faqList.OrderBy( v => v.Class.Name );
					}
					else
					{
						filteredAndSorted = faqList.OrderByDescending( v => v.Class.Name );
					}
					break;
				case "askedbyuser":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = faqList.OrderBy( v => v.AskUser.FirstName ).ThenBy( v => v.AskUser.LastName );
					}
					else
					{
						filteredAndSorted = faqList.OrderByDescending( v => v.AskUser.FirstName ).ThenByDescending( v => v.AskUser.LastName );
					}
					break;
				case "askeddate":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = faqList.OrderBy( v => v.DateAsked );
					}
					else
					{
						filteredAndSorted = faqList.OrderByDescending( v => v.DateAsked );
					}
					break;
				case "isanswered":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = faqList.OrderBy( v => v.AnswerText != null );
					}
					else
					{
						filteredAndSorted = faqList.OrderByDescending( v => v.AnswerText != null );
					}
					break;
				case "ispublic":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = faqList.OrderBy( v => v.IsPublic );
					}
					else
					{
						filteredAndSorted = faqList.OrderByDescending( v => v.IsPublic );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new FAQSummary()
			{
				faqId = v.FAQID,
				className = v.Class.Name,
				askedByUser = v.AskUser.FullName,
				askedDate = v.DateAsked,
				isAnswered = !string.IsNullOrEmpty( v.AnswerText ),
				isPublic = v.IsPublic,
			} );
		}

		public void AddFAQItem( FAQInformation faqInfo, int userId )
		{
			var newQuestion = new ClassFAQ()
			{
				AskUserID = userId,
				AskText = faqInfo.editedQuestion,
				ClassID = faqInfo.classId,
				DateAsked = DateTime.UtcNow,

				UpdatedAskText = faqInfo.editedQuestion,
				AnswerText = faqInfo.answerText,
				AnswerUserID = userId,
				DateAnswered = DateTime.UtcNow,
				IsPublic = faqInfo.isPublic,
			};

			database.ClassFAQs.Add( newQuestion );

			database.SaveChanges();

			return;
		}

		public void EditFAQItem( FAQInformation fInfo, int userId )
		{
			var dbFAQ = database.ClassFAQs.FirstOrDefault( f => f.FAQID == fInfo.faqId );
			if( dbFAQ != null )
			{
				dbFAQ.UpdatedAskText = fInfo.editedQuestion;
				dbFAQ.AnswerText = fInfo.answerText;
				dbFAQ.AnswerUserID = userId;
				dbFAQ.DateAnswered = DateTime.UtcNow;
				dbFAQ.IsPublic = fInfo.isPublic;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorClassNotFound" );
		}

		public object GetUnansweredFAQData( int customerId )
		{
			var faqs = database.ClassFAQs
				.Where( f => f.AskUser.CustomerLocations.Any( c => c.CustomerID == customerId ) )
				.AsQueryable();

			return
				new
				{
					count = faqs
						.Where( f => f.AnswerText == null )
						.Count(),
					lastDate = faqs
						.OrderByDescending( f => f.DateAsked )
						.ToList()
						.Select( f => (double?)(f.DateAsked - (new DateTime( 1970, 1, 1 ))).TotalMilliseconds )
						.DefaultIfEmpty( null )
						.FirstOrDefault()
				};
		}

		public IEnumerable<ScreeningRoomSummary> GetFullClassList( ScreeningRoomTableParams param, int customerId, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

            // Short-circuit database query if language ID will never match.
            // (Workaround for not being able to defer DataTables loading before the filters are initialized.)
		    int languageId = param.languageId;
            if ( languageId <= 0 )
                return new ScreeningRoomSummary[0];

            var customer = database.Customers.Include(cl => cl.AvailableClasses).FirstOrDefault(c => c.CustomerID == customerId);
            if (customer == null)
            {
                throw new GDWException("ErrorCustomerNotFound");
            }

            var q = database.Classes.Where(c => !c.IsDeleted);
            if (customer.EnterpriseLevel == GDWEnterpriseLevels.EnterpriseLevel.Basic)
            {
                var classIds = customer.AvailableClasses.Select(cl => cl.ClassID).ToArray();
                q = q.Where(c => classIds.Contains(c.ClassID));
            }

            var classList = from c in q
		        from cv in database.ClassVersions
		        where !cv.IsDeleted && cv.ClassID == c.ClassID && cv.LanguageID == languageId
		        join uc in database.UserClasses on c.ClassID equals uc.ClassID into ucg
		        select new
		            {
		                ClassID = c.ClassID,
		                Name = c.Name,
                        GuideFileName = cv.GuideFileName,
                        OriginalGuideName = cv.OriginalGuideName,
		                AssignmentCount = ucg.Count( x => x.User.CustomerLocations.Any( cl => cl.CustomerID == customerId ) )
		            };

            classList = classList.Where( i => i.AssignmentCount > 0 );

			displayedRecords = totalRecords = classList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				classList = classList.Where( i => i.Name.Contains( param.sSearch ) );
			    displayedRecords = classList.Count();
			}

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			switch( sortCol.ToLower() )
			{
				case "name":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						classList = classList.OrderBy( v => v.Name );
					}
					else
					{
						classList = classList.OrderByDescending( v => v.Name );
					}
					break;
				case "assignments":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						classList = classList.OrderBy( v => v.AssignmentCount );
					}
					else
					{
						classList = classList.OrderByDescending( v => v.AssignmentCount );
					}
					break;
			}

		    if( param.iDisplayLength <= 0 )
                param.iDisplayLength = displayedRecords;
			if( displayedRecords > param.iDisplayLength || param.iDisplayStart > 0 )
			{
				classList = classList.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return classList.ToList().Select( v => new ScreeningRoomSummary()
			{
				classId = v.ClassID,
				name = v.Name,
				assignments = v.AssignmentCount,
				guideFileName = v.GuideFileName,
				guideOriginalName = v.OriginalGuideName
			} );
		}

		public IEnumerable<LibrarySummary> GetFullClassList( LibraryTableParams param, int userId, int customerId, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var dbUser = database.Users.First( u => u.UserID == userId );

			var classList = database.Classes
			                        .Include(c => c.ClassVersions.Select(cv => cv.ClassVersionDocuments))
			                        .Include(c => c.ClassVersions.Select(cv => cv.ClassVersionSafetyDocuments))
			                        .Where(c => !c.IsDeleted)
			                        .Where(c => c.ClassVersions.Any())
			                        .Where(c => c.UserClasses.Any(uc => uc.User.CustomerLocations.Any(
				                                                      cl => cl.CustomerID == customerId &&
				                                                            (cl.Customer.EnterpriseLevel != GDWEnterpriseLevels.EnterpriseLevel.Basic ||
				                                                             cl.Customer.AvailableClasses.Any(ac => ac.ClassID == c.ClassID)))))
			                        .AsQueryable();

			totalRecords = classList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				classList = classList.Where( i =>
					i.Name.Contains( param.sSearch ) );
			}

			displayedRecords = classList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<Class> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "name":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = classList.OrderBy( v => v.Name );
					}
					else
					{
						filteredAndSorted = classList.OrderByDescending( v => v.Name );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new LibrarySummary()
			{
				classId = v.ClassID,
				name = v.Name,
				hasRelatedDocs = v.ClassVersions.Any( ucv => ucv.LanguageID == dbUser.LanguageID ) ?
						v.ClassVersions.Where( ucv => ucv.LanguageID == dbUser.LanguageID ).FirstOrDefault().ClassVersionDocuments.Any() :
						v.ClassVersions.FirstOrDefault().ClassVersionDocuments.Any(),
				hasSafetyDocs = v.ClassVersions.Any( ucv => ucv.LanguageID == dbUser.LanguageID ) ?
						v.ClassVersions.Where( ucv => ucv.LanguageID == dbUser.LanguageID ).FirstOrDefault().ClassVersionSafetyDocuments.Any() :
						v.ClassVersions.FirstOrDefault().ClassVersionSafetyDocuments.Any(),
			} );
		}

		public ScreenClassInformation GetScreenClassInfo( int classId, string resourceClass, int customerId )
		{
			var language = database.Languages.FirstOrDefault( cv => cv.StringClass == resourceClass );
			if( language == null )
			{
				language = database.Languages.First();
			}

			return GetScreenClassInfo( classId, language.LanguageID, customerId );
		}

		public ScreenClassInformation GetScreenClassInfo( int classId, int languageId, int customerId )
		{
            var customer = database.Customers.Include( cl => cl.AvailableClasses ).FirstOrDefault( c => c.CustomerID == customerId );
            if (customer == null)
            {
                throw new GDWException("ErrorCustomerNotFound");
            }

			var cInfo = database.Classes.Include( cl => cl.ClassVersions ).FirstOrDefault( c => c.ClassID == classId );
			if( cInfo == null )
			{
				throw new GDWException( "ErrorClassNotFound" );
			}

			if (customer.EnterpriseLevel == GDWEnterpriseLevels.EnterpriseLevel.Basic)
			{
				if (customer.AvailableClasses.All( c => c.ClassID != classId ))
					throw new GDWException( "ErrorClassNotFound" );
			}

			var classVersion = cInfo.ClassVersions.FirstOrDefault( cv => cv.LanguageID == languageId && !cv.IsDeleted );
			if( classVersion == null )
			{
				classVersion = cInfo.ClassVersions.FirstOrDefault( cv => !cv.IsDeleted );
			}
			if( classVersion == null )
			{
				throw new GDWException( "ErrorClassNotFound" );
			}

			return ToScreenClassInformation( cInfo, classVersion, customer );
		}

		public void AuditScreenClass( int classId, int userId )
		{
			database.ClassScreenings.Add( new ClassScreening()
			{
				ClassID = classId,
				UserID = userId,
				ScreenDateTime = DateTime.UtcNow
			} );

			database.SaveChanges();
		}

		public ScreenClassInformation ToScreenClassInformation( Class cInfo, ClassVersion classVersion, Customer customer )
		{
			return new ScreenClassInformation()
			{
				classId = cInfo.ClassID,
				name = cInfo.Name,
                languageId = classVersion.LanguageID,
                languageName = classVersion.Language != null ? classVersion.Language.Name : null,
				description = cInfo.Description,
                thirdPartyLogoFileName = cInfo.LogoFileName,
                customerLogoFileName = customer.LogoFileName,
				isVideo = classVersion.ClassType == GDWClassTypes.ClassType.Video,
				videoFile = classVersion.ClassType == GDWClassTypes.ClassType.Video ? classVersion.Video.StreamName : null,
				pdfFile = classVersion.ClassType == GDWClassTypes.ClassType.Pdf ? classVersion.PDFFileName : null,
				captions = cInfo.ClassVersions.Where( v => v.CaptionFileName != null && !v.IsDeleted ).Select( v => new CaptionFileInformation() { fileName = v.CaptionFileName, language = v.Language.Name } ).ToList(),
				documents = classVersion.ClassVersionDocuments
					.Where( d => !d.IsDeleted )
					.Select( d => new MyClassDocument()
					{
						displayName = d.OriginalName,
						fileName = d.FileName
					} )
					.ToList(),
				safetyDocuments = classVersion.ClassVersionSafetyDocuments
					.Where( d => !d.IsDeleted )
					.Select( d => new MyClassDocument()
					{
						displayName = d.OriginalName,
						fileName = d.FileName
					} )
					.ToList(),
				faqs = cInfo
					.ClassFAQs
					.Where( f => f.IsPublic )
					.Where( f => f.AnswerText != null )
					.Where( f => customer.CustomerID == f.AskUser.CustomerLocations.First().CustomerID )
					.Select( f => new MyClassFAQ() { questionText = f.UpdatedAskText ?? f.AskText, answerText = f.AnswerText } )
					.ToList(),
				questions = classVersion.ClassQuestions
						.Where( q => !q.IsDeleted )
						.OrderBy( q => q.DisplayOrder )
						.Select( q => new MyClassQuestion()
						{
							tQuestionId = q.QuestionID,
							text = q.Text,
							narrative = q.Narrative,
							imageFileName = q.ImageFileName,
							fullAudioFileName = q.FullAudioFileName,
							answers = q.ClassAnswers
							.Where( a => !a.IsDeleted )
							.Select( a => new MyClassAnswer()
							{
								tAnswerId = a.AnswerID,
								text = a.Text,
								isChosen = a.IsCorrect,
							} )
							.ToList()
						} )
						.ToList(),

			};
		}

		public void ReclaimClassCredits( int employeeId, int? userClassId, int userId, List<GDWPermissionTypes.Permissions> permissions )
		{
			var listAssignments = database.UserClasses
				.Include( uc => uc.Class )
                .Include( uc => uc.ScheduledUserClasses )
				.Include( uc => uc.User.CustomerLocations.Select( cl => cl.Customer ) )
				.Where( uc => uc.UserID == employeeId )
				.AsQueryable();

			if( userClassId.HasValue )
			{
				listAssignments = listAssignments.Where( uc => uc.UserClassID == userClassId.Value );

				if( !permissions.Contains( GDWPermissionTypes.Permissions.ReclaimStartedClass ) )
				{
					listAssignments = listAssignments.Where( uc => uc.Status == GDWClassStatus.Status.New );
				}
				else
				{
					listAssignments = listAssignments.Where( uc => uc.Status != GDWClassStatus.Status.TestPassed );
				}
			}
			else
			{
				listAssignments = listAssignments.Where( uc => uc.Status == GDWClassStatus.Status.New );
			}

			foreach( var assignment in listAssignments.ToList() )
			{
				var customer = assignment.User.CustomerLocations.First().Customer;
				if( customer.TracksCredits )
				{
					customer.CreditCount += assignment.Class.Credits;
				}

				assignment.Class.CustomerReclaimClasses.Add( new CustomerReclaimClass()
				{
					UserID = userId,
					EmployeeID = employeeId,
					Credits = assignment.Class.Credits,
					ReclaimDateTime = DateTime.UtcNow
				} );

				database.UserClasses.Remove( assignment );
                if( assignment.ScheduledUserClasses.Any() )
                    database.ScheduledUserClasses.RemoveRange( assignment.ScheduledUserClasses );
			}

			database.SaveChanges();
		}

		public List<ScoreImportSummary> GetFullImportList( ScoreImportTableParams dtParams, int? customerId, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var importList = database.ScoreImports
				.Where( i => i.CustomerID == customerId )
				.OrderByDescending( i => i.DateImported )
				.AsQueryable();

			totalRecords = importList.Count();

			displayedRecords = importList.Count();

			if( (displayedRecords > dtParams.iDisplayLength) && (dtParams.iDisplayLength > 0) )
			{
				importList = importList.Skip( dtParams.iDisplayStart ).Take( dtParams.iDisplayLength );
			}

			return importList.ToList().Select( i => new ScoreImportSummary()
			{
				originalFileName = i.OriginalSourceFileName,
				sourceFileName = i.SourceFileName,
				successRecords = i.ImportCount,
				errorRecords = i.ErrorCount,
				errorFileName = i.ErrorFileName,
				className = i.Class.Name,
				importDate = i.DateImported,
				userName = i.User.FullName,
                originalSignatureFileName = i.OriginalSignatureFileName,
                signatureFileName = i.SignatureFileName
			} ).ToList();
		}
	}
}
