﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using GDWDatabase;
using GDWInfrastructure;
using OSHALMSStrings;

namespace GDWRepositories
{
    public class BaseRepository : IDisposable
    {
		protected GDWEntities database { get; private set; }

		public BaseRepository()
		{
			database = new GDWEntities();
		}

		#region IDisposable Members

		public void Dispose()
		{
			database.Dispose();
		}

		#endregion

		public string ConnectionString()
		{
			return database.Database.Connection.ConnectionString;
		}

		protected string EncodePassword( string originalPassword )
		{
			//Declarations
			Byte[] originalBytes;
			Byte[] encodedBytes;
			MD5 md5;

			//Instantiate MD5CryptoServiceProvider, get bytes for original password and compute hash (encoded password)
			md5 = new MD5CryptoServiceProvider();
			originalBytes = ASCIIEncoding.Default.GetBytes( originalPassword );
			encodedBytes = md5.ComputeHash( originalBytes );

			//Convert encoded bytes back to a 'readable' string
			return BitConverter.ToString( encodedBytes );
		}

		protected string GetUserString( string stringId )
		{
			var resClass = "EnglishStrings";
			if( GDWWebUser.CurrentUser != null )
				resClass = GDWWebUser.CurrentUser.ResourceClass;

			return StringManager.GetStringFromResourceFile( resClass, stringId );
		}

		#region Alert Generation
		
		public void GenerateTestAlert( int userId )
		{
			var dbUser = database.Users.FirstOrDefault( u => u.UserID == userId );

			if( dbUser != null )
			{
				var newAlert = Notification.NewNotification();

				newAlert.NotificationHeader = "AlertTestToMeHeader";
				newAlert.NotificationString = "AlertTestToMeBody";
				newAlert.NotificationDateTime = DateTime.UtcNow;

				newAlert.NotificationParameters.Add( new NotificationParameter() { DisplayOrder = 0, TextData = dbUser.FirstName + " " + dbUser.LastName } );

				dbUser.Notifications.Add( newAlert );

				database.SaveChanges();
			}	
		}

		#endregion
	}
}
