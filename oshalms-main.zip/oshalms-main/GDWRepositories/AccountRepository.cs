﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWInfrastructure.EmailSenders;
using GDWModels.Account;
using GDWModels.Customer;

namespace GDWRepositories
{
	public class AccountRepository : BaseRepository
	{
		public GDWWebUser CreateGDWWebUser( string userName, string authType )
		{
		    var user = FindUserByUserName( userName );

		    if( user != null )
			{
				int? customerId = null;
				GDWEnterpriseLevels.EnterpriseLevel? enterpriseLevel = null;
				if( user.CustomerLocations.Any() )
				{
					customerId = user.CustomerLocations.First().CustomerID;
					enterpriseLevel = database.Customers.First(c => c.CustomerID == customerId).EnterpriseLevel;
				}

				return new GDWWebUser( user.UserName, authType, user.UserID,
					user.FirstName, user.LastName, user.Language.StringClass,
					user.PermissionGroups.SelectMany( p => p.PermissionGroupItems ).Select( pgi => pgi.PermissionID ),
					customerId, enterpriseLevel.ToString() );
			}

			return null;
		}

		public bool ValidateUser( string userName, string password, bool eulaAcknowledged )
		{
			if( !database.Users.Any() )
			{
				var newUser = new User();
				newUser.FirstName = "Matt";
				newUser.LastName = "James";
				newUser.EmailAddress = "matt.james@wddsoftware.com";
				newUser.Password = EncodePassword( "Password!" );
				newUser.IsDeleted = false;
			    newUser.SetupEmailSent = true;

				newUser.Language = database.Languages.OrderBy( l => l.LanguageID ).First();

				newUser.PermissionGroups.Add( database.PermissionGroups.First() );

				database.Users.Add( newUser );

				if( database.SaveChanges() == 0 )
				{
					throw new Exception();
				}
			}

		    var user = FindUserByUserName( userName );

			if( user != null )
			{
				if( user.CustomerLocations.Any() )
				{
					var customer = user.CustomerLocations.First().Customer;
					if( customer.IsDeleted || customer.ExpirationDate < DateTime.Now )
					{
						throw new GDWException( "ErrorLoginFailed" );
					}
				}

				if( EncodePassword( password ) == user.Password )
				{
					user.UserLoginActivities.Add( new UserLoginActivity() { LoginDateTime = DateTime.UtcNow } );
					
					database.SaveChanges();

					var configOptions = database.ConfigurationOptions.First();
					if( eulaAcknowledged )
					{
						user.EULAVersion = configOptions.EULAVersion;

						database.SaveChanges();
					}
					else
					{
						return (user.EULAVersion == configOptions.EULAVersion);
					}

					return true;
				}
			}

			throw new GDWException( "ErrorLoginFailed" );
		}

		#region Users
		public UserInformation GetUser( int userId )
		{
			var dbUser = database.Users
				.Include( u => u.PermissionGroups )
				.FirstOrDefault( u => u.UserID == userId );

			if( dbUser != null )
			{
				var uInfo = new UserInformation();

				uInfo.userId = dbUser.UserID;
				uInfo.firstName = dbUser.FirstName;
				uInfo.lastName = dbUser.LastName;
				uInfo.emailAddress = dbUser.EmailAddress;
			    uInfo.canRemoveEmailAddress = string.IsNullOrEmpty( uInfo.emailAddress );
				uInfo.isActive = !dbUser.IsDeleted;
			    uInfo.setupEmailSent = dbUser.SetupEmailSent;
				uInfo.phoneNumber = dbUser.PhoneNumber;
				uInfo.gender = dbUser.Gender.ToString();
				uInfo.roles = dbUser.PermissionGroups.Where( p => !p.IsDeleted ).Select( p => p.GroupID );
				uInfo.imageFileName = dbUser.ImageFileName;
				uInfo.languageId = dbUser.LanguageID;
				uInfo.hireDate = dbUser.HireDate;

				return uInfo;
			}

			throw new GDWException( "ErrorUserNotFound" );

		}

		public EmployeeInformation GetEmployee( int userId )
		{
			var dbUser = database.Users
				.Include( u => u.PermissionGroups )
				.Include( u => u.CustomerDepartments )
				.Include( u => u.CustomerLocations )
				.FirstOrDefault( u => u.UserID == userId );

			if( dbUser != null )
			{
				var uInfo = new EmployeeInformation();

				uInfo.userId = dbUser.UserID;
				uInfo.firstName = dbUser.FirstName;
				uInfo.lastName = dbUser.LastName;
				uInfo.emailAddress = dbUser.EmailAddress;
			    uInfo.canRemoveEmailAddress = string.IsNullOrEmpty( uInfo.emailAddress );
				uInfo.isActive = !dbUser.IsDeleted;
			    uInfo.setupEmailSent = dbUser.SetupEmailSent;
				uInfo.phoneNumber = dbUser.PhoneNumber;
				uInfo.gender = dbUser.Gender.ToString();
				uInfo.roles = dbUser.PermissionGroups.Where( p => !p.IsDeleted ).Select( p => p.GroupID );
				uInfo.imageFileName = dbUser.ImageFileName;
				uInfo.languageId = dbUser.LanguageID;
				uInfo.hireDate = dbUser.HireDate;
				uInfo.departments = dbUser.CustomerDepartments.Where( p => !p.IsDeleted ).Select( d => d.DepartmentID );
				uInfo.locations = dbUser.CustomerLocations.Where( p => !p.IsDeleted ).Select( d => d.LocationID );

				return uInfo;
			}

			throw new GDWException( "ErrorUserNotFound" );

		}

		public void AddUser( UserInformation uInfo, bool isEmailRequired )
		{
		    if ( !string.IsNullOrEmpty( uInfo.emailAddress ) )
		    {
		        if ( database.Users.Any( u => u.EmailAddress == uInfo.emailAddress && !u.IsDeleted ) )
		        {
		            throw new GDWException( "ErrorEmailAlreadyInUse" );
		        }
		    }
            else if ( isEmailRequired )
            {
		        throw new GDWException( "ErrorEmailIsRequired" );
            }

		    var newUser = new User();

			newUser.FirstName = uInfo.firstName;
			newUser.LastName = uInfo.lastName;
			newUser.EmailAddress = uInfo.emailAddress;
			newUser.IsDeleted = !uInfo.isActive;
			newUser.PhoneNumber = uInfo.phoneNumber;
			newUser.Password = "";
			newUser.Gender = (GenderType)Enum.Parse( typeof( GenderType ), uInfo.gender );
			newUser.PermissionGroups = database.PermissionGroups.Where( p => uInfo.roles.Contains( p.GroupID ) ).ToList();
			newUser.ImageFileName = uInfo.imageFileName;
			newUser.LanguageID = uInfo.languageId;
			newUser.HireDate = uInfo.hireDate;

		    ResetEmail resetEmail = null;
		    if ( uInfo.setupEmailSent )
		    {
		        resetEmail = new ResetEmail();
		        resetEmail.EmailID = Guid.NewGuid();
		        resetEmail.ExpireDate = DateTime.UtcNow.AddDays( 3 );
		        resetEmail.IsActive = true;

		        newUser.ResetEmails.Add( resetEmail );
		        newUser.SetupEmailSent = true;
		    }
		    else
		    {
		        newUser.SetupEmailSent = false;
		    }

		    if( uInfo is EmployeeInformation )
			{
				List<int> locations = new List<int>();
				if( ((uInfo as EmployeeInformation).locations) != null )
					locations = ((uInfo as EmployeeInformation).locations).ToList();
				List<int> departments = new List<int>();
				if( ((uInfo as EmployeeInformation).departments) != null )
					departments = ((uInfo as EmployeeInformation).departments).ToList();
				newUser.CustomerLocations = database.CustomerLocations.Where( l => locations.Contains( l.LocationID ) ).ToList();
				newUser.CustomerDepartments = database.CustomerDepartments.Where( l => departments.Contains( l.DepartmentID ) ).ToList();
			}

			database.Users.Add( newUser );

			database.SaveChanges();

		    if ( resetEmail != null )
		    {
		        var emailRecipients = GetEmailRecipientsForUser( newUser );
		        foreach ( var recip in emailRecipients )
		        {
		            var recipLang = recip.Language;
		            if ( recipLang == null )
		                recipLang = database.Languages.First( l => l.LanguageID == recip.LanguageID );
		            (new NewAccountEmailSender( recipLang.StringClass )).SubmitNewAccountEmail( recip.EmailAddress, newUser.UserName, resetEmail.EmailID,
		                newUser.FirstName, newUser.LastName );
		        }
		    }
		}

		public void EditProfile( UserInformation uInfo )
		{
		    if ( !string.IsNullOrEmpty( uInfo.emailAddress ) )
		    {
		        if( database.Users.Any( u => u.EmailAddress == uInfo.emailAddress && !u.IsDeleted && u.UserID != uInfo.userId ) )
		        {
		            throw new GDWException( "ErrorEmailAlreadyInUse" );
		        }
		    }

			var dbUser = database.Users.FirstOrDefault( u => u.UserID == uInfo.userId );

			if( dbUser != null )
			{
                // Removing one's email address is not allowed.
			    if ( !string.IsNullOrEmpty( dbUser.EmailAddress ) && string.IsNullOrEmpty( uInfo.emailAddress ) )
			    {
			        throw new GDWException( "ErrorEmailIsRequired" );
			    }

			    dbUser.FirstName = uInfo.firstName;
				dbUser.LastName = uInfo.lastName;
				dbUser.EmailAddress = uInfo.emailAddress;
				dbUser.PhoneNumber = uInfo.phoneNumber;
				dbUser.Gender = (GenderType)Enum.Parse( typeof( GenderType ), uInfo.gender );
				dbUser.ImageFileName = uInfo.imageFileName;
				dbUser.LanguageID = uInfo.languageId;
				dbUser.HireDate = uInfo.hireDate;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorUserNotFound" );
		}

		public void EditUser( UserInformation uInfo, bool isEmailRequired )
		{
		    if ( !string.IsNullOrEmpty( uInfo.emailAddress ) )
		    {
		        if( database.Users.Any( u => u.EmailAddress == uInfo.emailAddress && !u.IsDeleted && u.UserID != uInfo.userId ) )
		        {
		            throw new GDWException( "ErrorEmailAlreadyInUse" );
		        }
		    }
            else if ( isEmailRequired )
            {
		        throw new GDWException( "ErrorEmailIsRequired" );
            }

			var dbUser = database.Users.FirstOrDefault( u => u.UserID == uInfo.userId );

			if( dbUser != null )
			{
				dbUser.FirstName = uInfo.firstName;
				dbUser.LastName = uInfo.lastName;
				dbUser.EmailAddress = uInfo.emailAddress;
				dbUser.IsDeleted = !uInfo.isActive;
				dbUser.PhoneNumber = uInfo.phoneNumber;
				dbUser.Gender = (GenderType)Enum.Parse( typeof( GenderType ), uInfo.gender );
				dbUser.ImageFileName = uInfo.imageFileName;
				dbUser.LanguageID = uInfo.languageId;
				dbUser.HireDate = uInfo.hireDate;

				foreach( var newPGroup in uInfo.roles.Where( p => !dbUser.PermissionGroups.Select( pg => pg.GroupID ).Contains( p ) ) )
				{
					dbUser.PermissionGroups.Add( database.PermissionGroups.First( p => p.GroupID == newPGroup ) );
				}

				foreach( var oldPGroup in dbUser.PermissionGroups.Where( pg => !uInfo.roles.Contains( pg.GroupID ) ).ToList() )
				{
					dbUser.PermissionGroups.Remove( oldPGroup );
				}

			    ResetEmail resetEmail = null;
			    if ( uInfo.resetPassword && dbUser.SetupEmailSent )
			    {
			        resetEmail = new ResetEmail();
			        resetEmail.EmailID = Guid.NewGuid();

			        resetEmail.ExpireDate = DateTime.UtcNow.AddDays( 3 );
			        resetEmail.IsActive = true;

			        dbUser.ResetEmails.Add( resetEmail );
			    }

			    if( uInfo is EmployeeInformation )
				{
					if( (uInfo as EmployeeInformation).locations != null )
					{
						foreach( var newLocation in (uInfo as EmployeeInformation).locations.Where( p => !dbUser.CustomerLocations.Select( pg => pg.LocationID ).Contains( p ) ) )
						{
							dbUser.CustomerLocations.Add( database.CustomerLocations.First( p => p.LocationID == newLocation ) );
						}

						foreach( var oldLocation in dbUser.CustomerLocations.Where( pg => !(uInfo as EmployeeInformation).locations.Contains( pg.LocationID ) ).ToList() )
						{
							dbUser.CustomerLocations.Remove( oldLocation );
						}
					}
					else
					{
						foreach( var oldLocation in dbUser.CustomerLocations.ToList() )
						{
							dbUser.CustomerLocations.Remove( oldLocation );
						}
					}

					if( (uInfo as EmployeeInformation).departments != null )
					{
						foreach( var newDepartment in (uInfo as EmployeeInformation).departments.Where( p => !dbUser.CustomerDepartments.Select( pg => pg.DepartmentID ).Contains( p ) ) )
						{
							dbUser.CustomerDepartments.Add( database.CustomerDepartments.First( p => p.DepartmentID == newDepartment ) );
						}

						foreach( var oldPGroup in dbUser.CustomerDepartments.Where( pg => !(uInfo as EmployeeInformation).departments.Contains( pg.DepartmentID ) ).ToList() )
						{
							dbUser.CustomerDepartments.Remove( oldPGroup );
						}
					}
					else
					{
						foreach( var oldPGroup in dbUser.CustomerDepartments.ToList() )
						{
							dbUser.CustomerDepartments.Remove( oldPGroup );
						}
					}
				}

				database.SaveChanges();

				if( resetEmail != null )
				{
				    var emailRecipients = GetEmailRecipientsForUser( dbUser );
				    foreach ( var recip in emailRecipients )
				    {
				        (new AdminResetPasswordEmailSender( recip.Language.StringClass )).SubmitPasswordChangeEmail( recip.EmailAddress, resetEmail.EmailID, uInfo.firstName, uInfo.lastName );
				    }
				}

				return;
			}

			throw new GDWException( "ErrorUserNotFound" );
		}

		public void DeleteUser( int userId )
		{
			var dbUser = database.Users.FirstOrDefault( u => u.UserID == userId );

			if( dbUser != null )
			{
				dbUser.IsDeleted = true;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorUserNotFound" );
		}

		public IEnumerable<UserSummary> GetFullEmployeeList( EmployeeTableParams param, int currentUserId, bool allowInactive,
			out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var userList = database.Users
				.Include( u => u.UserClasses )
				.Include( u => u.PermissionGroups )
				.Include( u => u.UserLoginActivities )
				.Include( u => u.CustomerLocations )
				.Include( u => u.CustomerDepartments )
				.Where( u => u.CustomerLocations.Any( l => l.CustomerID == param.customerId ) )
				.AsQueryable();

			var currentUser = database.Users.First( u => u.UserID == currentUserId );
			if( currentUser.CustomerLocations.Any() )
			{
				if( !currentUser.PermissionGroups.SelectMany( g => g.PermissionGroupItems ).Any( i => i.PermissionID == GDWPermissionTypes.Permissions.ManageAllLocations ) )
				{
					var locationIds = currentUser.CustomerLocations.Select( l => l.LocationID ).ToList();
					userList = userList.Where( u => u.CustomerLocations.Select( l => l.LocationID ).Intersect( locationIds ).Any() );
				}
			}
			if( !allowInactive )
			{
				userList = userList.Where( u => !u.IsDeleted );
			}
			totalRecords = userList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				userList = userList.Where( i =>
					i.FirstName.Contains( param.sSearch ) ||
					i.LastName.Contains( param.sSearch ) ||
					i.EmailAddress.Contains( param.sSearch ) ||
					i.PermissionGroups.Any( p => p.Name.Contains( param.sSearch ) ) );
			}
			switch( (param.activeState ?? "active").ToLower() )
			{
				case "active":
					userList = userList.Where( u => !u.IsDeleted );
					break;
				case "needsemail":
					userList = userList.Where( u => !u.IsDeleted && !u.SetupEmailSent );
					break;
				case "inactive":
					userList = userList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}
			if( param.locationId.HasValue )
			{
				userList = userList.Where( u => u.CustomerLocations.Any( l => l.LocationID == param.locationId.Value ) );
			}
			if( param.departmentId.HasValue )
			{
				userList = userList.Where( u => u.CustomerDepartments.Any( l => l.DepartmentID == param.departmentId.Value ) );
			}

			displayedRecords = userList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<User> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "fullname":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = userList.OrderBy( v => v.FirstName ).ThenBy( v => v.LastName ).ThenBy( v => v.EmailAddress );
					}
					else
					{
						filteredAndSorted = userList.OrderByDescending( v => v.FirstName ).ThenByDescending( v => v.LastName ).ThenByDescending( v => v.EmailAddress );
					}
					break;
				case "locations":
                    // Sorting by the concatenated (comma-separated) values for multiple locations is too tricky for LINQ.  Just sort by the first location name.
			        if ( param.sSortDir_0.ToLower() == "asc" )
			        {
                        filteredAndSorted = userList.OrderBy( v => v.CustomerLocations.OrderBy( l => l.Name ).Select( l => l.Name ).FirstOrDefault() );
			        }
			        else
			        {
			            filteredAndSorted = userList.OrderByDescending( v => v.CustomerLocations.OrderBy( l => l.Name ).Select( l => l.Name ).FirstOrDefault() );
                    }
			        break;
				case "departments":
			        if ( param.sSortDir_0.ToLower() == "asc" )
			        {
			            filteredAndSorted = userList.OrderBy( v => v.CustomerDepartments.OrderBy( l => l.Name ).Select( l => l.Name ).FirstOrDefault() );
			        }
			        else
			        {
			            filteredAndSorted = userList.OrderByDescending( v => v.CustomerDepartments.OrderBy( l => l.Name ).Select( l => l.Name ).FirstOrDefault() );
			        }
			        break;
				case "lastlogindate":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = userList.OrderBy( v => v.SetupEmailSent ? 1 : 0 ).ThenBy( v => v.UserLoginActivities.Max( a => a.LoginDateTime ) );
					}
					else
					{
						filteredAndSorted = userList.OrderByDescending( v => v.SetupEmailSent ? 1 : 0 ).ThenByDescending( v => v.UserLoginActivities.Max( a => a.LoginDateTime ) );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

		    return filteredAndSorted.ToList().Select( v => new UserSummary()
		    {
		        userId = v.UserID,
                userName = v.UserName,
		        fullName = v.FirstName + " " + v.LastName,
		        emailAddress = v.EmailAddress,
		        locations = string.Join( ", ", v.CustomerLocations.OrderBy( l => l.Name ).Select( l => l.Name ) ),
		        departments = string.Join( ", ", v.CustomerDepartments.OrderBy( l => l.Name ).Select( l => l.Name ) ),
		        isActive = !v.IsDeleted,
		        assignmentCount = v.UserClasses.Count(),
		        newAssignmentCount = v.UserClasses.Count( uc => uc.Status == GDWClassStatus.Status.New ),
		        role = string.Join( ", ", v.PermissionGroups.Where( p => !p.IsDeleted ).Select( p => p.Name ) ),
		        lastLoginDate = v.UserLoginActivities.Select( a => a.LoginDateTime ).DefaultIfEmpty( DateTime.UtcNow.AddYears( 1 ) ).Max(),
                setupEmailSent = v.SetupEmailSent
		    } );
		}

	    public IEnumerable<UserSummary> FindEmployees(int customerId, IList<int> locationIds, IList<int> departmentIds)
	    {
			var userQuery = database.Users
				.Include( u => u.UserClasses )
				.Include( u => u.PermissionGroups )
				.Include( u => u.UserLoginActivities )
				.Include( u => u.CustomerLocations )
				.Include( u => u.CustomerDepartments )
				.Where( u => u.CustomerLocations.Any( l => l.CustomerID == customerId ) )
				.AsQueryable();

	        // NOTE: Do we need to restrict the location matching to those that are accessible to the requesting user?
#if false
			var currentUser = database.Users.First( u => u.UserID == currentUserId );
			if( currentUser.CustomerLocations.Any() )
			{
				if( !currentUser.PermissionGroups.SelectMany( g => g.PermissionGroupItems ).Any( i => i.PermissionID == GDWPermissionTypes.Permissions.ManageAllLocations ) )
				{
					var limitLocationIds = currentUser.CustomerLocations.Select( l => l.LocationID ).ToList();
					userList = userList.Where( u => u.CustomerLocations.Select( l => l.LocationID ).Intersect( limitLocationIds ).Any() );
				}
			}
#endif

            // Use "Any" here to do some filtering, but we will need to further restrict users to those that
            // match *all* of the provided location IDs and department IDs.
	        locationIds = locationIds ?? new int[0];
	        departmentIds = departmentIds ?? new int[0];
			if( locationIds.Any() )
			{
				userQuery = userQuery.Where( u => u.CustomerLocations.Any( l => locationIds.Contains( l.LocationID ) ) );
			}
			if( departmentIds.Any() )
			{
				userQuery = userQuery.Where( u => u.CustomerDepartments.Any( l => departmentIds.Contains( l.DepartmentID ) ) );
			}

	        var userList = userQuery.OrderBy(v => v.FirstName).ThenBy(v => v.LastName).ThenBy(v => v.EmailAddress).ToList();
	        var results = new List<UserSummary>();
	        foreach (var user in userList)
	        {
	            // Restrict returned users to those that match all of the provided location IDs and department IDs.
	            if (locationIds.Any(lid => user.CustomerLocations.All(l => l.LocationID != lid)))
	                continue;
	            if (departmentIds.Any(did => user.CustomerDepartments.All(d => d.DepartmentID != did)))
	                continue;

	            var userInfo = new UserSummary
	                {
	                    userId = user.UserID,
	                    userName = user.UserName,
	                    fullName = user.FirstName + " " + user.LastName,
	                    emailAddress = user.EmailAddress,
	                    locations = string.Join(", ", user.CustomerLocations.OrderBy(l => l.Name).Select(l => l.Name)),
	                    departments = string.Join(", ", user.CustomerDepartments.OrderBy(l => l.Name).Select(l => l.Name)),
	                    isActive = !user.IsDeleted,
	                    assignmentCount = user.UserClasses.Count(),
	                    newAssignmentCount = user.UserClasses.Count(uc => uc.Status == GDWClassStatus.Status.New),
	                    role = string.Join(", ", user.PermissionGroups.Where(p => !p.IsDeleted).Select(p => p.Name)),
	                    lastLoginDate = user.UserLoginActivities.Select(a => a.LoginDateTime).DefaultIfEmpty(DateTime.UtcNow.AddYears(1)).Max(),
	                    setupEmailSent = user.SetupEmailSent
	                };
	            results.Add(userInfo);
	        }

	        return results;
	    }

		public IEnumerable<UserSummary> GetFullUserList( UserTableParams param, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var userList = database.Users
				.Include( u => u.PermissionGroups )
				.Where( u => !u.CustomerLocations.Any() )
				.AsQueryable();

			totalRecords = userList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				userList = userList.Where( i =>
					i.FirstName.Contains( param.sSearch ) ||
					i.LastName.Contains( param.sSearch ) ||
					i.EmailAddress.Contains( param.sSearch ) ||
					i.PermissionGroups.Any( p => p.Name.Contains( param.sSearch ) ) );
			}
			switch( (param.activeState ?? "active").ToLower() )
			{
				case "active":
					userList = userList.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					userList = userList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}

			displayedRecords = userList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<User> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "fullname":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = userList.OrderBy( v => v.FirstName ).ThenBy( v => v.LastName );
					}
					else
					{
						filteredAndSorted = userList.OrderByDescending( v => v.FirstName ).ThenByDescending( v => v.LastName );
					}
					break;
				case "emailaddress":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = userList.OrderBy( v => v.EmailAddress );
					}
					else
					{
						filteredAndSorted = userList.OrderByDescending( v => v.EmailAddress );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new UserSummary()
			{
				userId = v.UserID,
                userName = v.UserName,
				fullName = v.FirstName + " " + v.LastName,
				emailAddress = v.EmailAddress,
				isActive = !v.IsDeleted,
				role = string.Join( ", ", v.PermissionGroups.Where( p => !p.IsDeleted ).Select( p => p.Name ) )
			} );
		}
		#endregion

		#region Permissions

		public IEnumerable<PermissionGroupSummary> GetFullPermissionList( PermissionTableParams param, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var groupList = database.PermissionGroups
				.Include( u => u.Users )
				.Where( u => u.CustomerID == param.customerId )
				.AsQueryable();

			totalRecords = groupList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				groupList = groupList.Where( i =>
					i.Name.Contains( param.sSearch ) ||
					i.Description.Contains( param.sSearch ) );
			}
			switch( (param.activeState ?? "active").ToLower() )
			{
				case "active":
					groupList = groupList.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					groupList = groupList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}

			displayedRecords = groupList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<PermissionGroup> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "name":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = groupList.OrderBy( v => v.Name );
					}
					else
					{
						filteredAndSorted = groupList.OrderByDescending( v => v.Name );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new PermissionGroupSummary()
			{
				groupId = v.GroupID,
				name = v.Name,
				description = v.Description,
				userCount = v.Users.Where( u => !u.IsDeleted ).Count(),
				isActive = !v.IsDeleted
			} );
		}

		public PermissionGroupInformation GetPermissionGroup( int groupId )
		{
			var dbPermissionGroup = database.PermissionGroups
				.Include( p => p.PermissionGroupItems )
				.FirstOrDefault( u => u.GroupID == groupId );

			if( dbPermissionGroup != null )
			{
				var gInfo = new PermissionGroupInformation();

				gInfo.groupId = dbPermissionGroup.GroupID;
				gInfo.name = dbPermissionGroup.Name;
				gInfo.description = dbPermissionGroup.Description;
				gInfo.permissions = dbPermissionGroup.PermissionGroupItems.Select( p => p.PermissionID.ToString() ).ToList();
				gInfo.isActive = !dbPermissionGroup.IsDeleted;
				gInfo.isCustomer = dbPermissionGroup.IsAccountGroup;
				gInfo.customerId = dbPermissionGroup.CustomerID;

				return gInfo;
			}

			throw new GDWException( "ErrorPermissionGroupNotFound" );

		}

		public void AddPermissionGroup( PermissionGroupInformation gInfo )
		{
			var newPermissionGroup = new PermissionGroup();

			newPermissionGroup.Name = gInfo.name;
			newPermissionGroup.Description = gInfo.description;
			newPermissionGroup.IsDeleted = !gInfo.isActive;
			newPermissionGroup.IsAccountGroup = gInfo.isCustomer;
			if( gInfo.isCustomer )
			{
				newPermissionGroup.CustomerID = gInfo.customerId;
			}
			else
			{
				newPermissionGroup.CustomerID = null;
			}

			foreach( var p in gInfo.permissions )
			{
				newPermissionGroup.PermissionGroupItems.Add( new PermissionGroupItem()
				{
					PermissionID = (GDWPermissionTypes.Permissions)Enum.Parse( typeof( GDWPermissionTypes.Permissions ), p )
				} );
			}

			database.PermissionGroups.Add( newPermissionGroup );

			database.SaveChanges();

		}

		public void EditPermissionGroup( PermissionGroupInformation gInfo )
		{
			var dbPermissionGroup = database.PermissionGroups
				.Include( p => p.PermissionGroupItems )
				.FirstOrDefault( u => u.GroupID == gInfo.groupId );

			if( dbPermissionGroup != null )
			{
				dbPermissionGroup.Name = gInfo.name;
				dbPermissionGroup.Description = gInfo.description;
				dbPermissionGroup.IsDeleted = !gInfo.isActive;
				dbPermissionGroup.IsAccountGroup = gInfo.isCustomer;
				if( gInfo.isCustomer )
				{
					dbPermissionGroup.CustomerID = gInfo.customerId;
				}
				else
				{
					dbPermissionGroup.CustomerID = null;
				}

				var pList = gInfo.permissions.Select( p => (GDWPermissionTypes.Permissions)Enum.Parse( typeof( GDWPermissionTypes.Permissions ), p ) );

				foreach( var newPermission in pList.Where( p => !dbPermissionGroup.PermissionGroupItems.Select( pgi => pgi.PermissionID ).Contains( p ) ) )
				{
					dbPermissionGroup.PermissionGroupItems.Add( new PermissionGroupItem()
					{
						PermissionID = newPermission
					} );
				}

				foreach( var oldPermission in dbPermissionGroup.PermissionGroupItems.Where( pgi => !pList.Contains( pgi.PermissionID ) ).ToList() )
				{
					dbPermissionGroup.PermissionGroupItems.Remove( oldPermission );
				}

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorPermissionGroupNotFound" );
		}

		public void DeletePermissionGroup( int groupId )
		{
			var dbPermissionGroup = database.PermissionGroups.FirstOrDefault( u => u.GroupID == groupId );

			if( dbPermissionGroup != null )
			{
				dbPermissionGroup.IsDeleted = true;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorPermissionGroupNotFound" );
		}

		public IEnumerable<PermissionInformation> GetPermissionList()
		{
			return new List<PermissionInformation>()
			{
				// isCustomer = false
				new PermissionInformation() {
					objectName = GetUserString( "Users" ),
					isCustomer = false,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewUser.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Add" ), permissionName = GDWPermissionTypes.Permissions.AddUser.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditUser.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Deactivate" ), permissionName = GDWPermissionTypes.Permissions.DeactivateUser.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "PermissionGroups" ),
					isCustomer = false,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewPermissionGroup.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Add" ), permissionName = GDWPermissionTypes.Permissions.AddPermissionGroup.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditPermissionGroup.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Deactivate" ), permissionName = GDWPermissionTypes.Permissions.DeactivatePermissionGroup.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "Languages" ),
					isCustomer = false,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewLanguage.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Add" ), permissionName = GDWPermissionTypes.Permissions.AddLanguage.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditLanguage.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Deactivate" ), permissionName = GDWPermissionTypes.Permissions.DeactivateLanguage.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "ManageClasses" ),
					isCustomer = false,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewClass.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Add" ), permissionName = GDWPermissionTypes.Permissions.AddClass.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditClass.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Deactivate" ), permissionName = GDWPermissionTypes.Permissions.DeactivateClass.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "ManageCreditTiers" ),
					isCustomer = false,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewCreditTier.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Add" ), permissionName = GDWPermissionTypes.Permissions.AddCreditTier.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditCreditTier.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Deactivate" ), permissionName = GDWPermissionTypes.Permissions.DeactivateCreditTier.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "ManageCustomers" ),
					isCustomer = false,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewCustomer.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Add" ), permissionName = GDWPermissionTypes.Permissions.AddCustomer.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditCustomer.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Deactivate" ), permissionName = GDWPermissionTypes.Permissions.DeactivateCustomer.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "ManageAccount" ), permissionName = GDWPermissionTypes.Permissions.ManageCustomerAccount.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Impersonate" ), permissionName = GDWPermissionTypes.Permissions.ImpersonateCustomer.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "DiscountCodes" ),
					isCustomer = false,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewDiscountCode.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Add" ), permissionName = GDWPermissionTypes.Permissions.AddDiscountCode.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditDiscountCode.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Deactivate" ), permissionName = GDWPermissionTypes.Permissions.DeactivateDiscountCode.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "Configuration" ),
					isCustomer = false,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Manage" ), permissionName = GDWPermissionTypes.Permissions.ManageConfiguration.ToString() },
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "Widgets" ),
					isCustomer = false,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewWidgets.ToString() },
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "Videos" ),
					isCustomer = false,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewVideo.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Add" ), permissionName = GDWPermissionTypes.Permissions.AddVideo.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditVideo.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Deactivate" ), permissionName = GDWPermissionTypes.Permissions.DeactivateVideo.ToString() }
					}
				},
				// isCustomer = true
				new PermissionInformation() {
					objectName = GetUserString( "CreditsAndUserAccounts" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Manage" ), permissionName = GDWPermissionTypes.Permissions.ManageCreditsAndEmployees.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "ManageEmployees" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewEmployee.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Add" ), permissionName = GDWPermissionTypes.Permissions.AddEmployee.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditEmployee.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Deactivate" ), permissionName = GDWPermissionTypes.Permissions.DeactivateEmployee.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "ViewInactive" ), permissionName = GDWPermissionTypes.Permissions.ViewInactiveEmployee.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "PermissionGroups" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewCustomerPermissionGroup.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Add" ), permissionName = GDWPermissionTypes.Permissions.AddCustomerPermissionGroup.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditCustomerPermissionGroup.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Deactivate" ), permissionName = GDWPermissionTypes.Permissions.DeactivateCustomerPermissionGroup.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "ManageLocations" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewLocation.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Add" ), permissionName = GDWPermissionTypes.Permissions.AddLocation.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditLocation.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Deactivate" ), permissionName = GDWPermissionTypes.Permissions.DeactivateLocation.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "ManageAll" ), permissionName = GDWPermissionTypes.Permissions.ManageAllLocations.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "ManageDepartments" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewDepartment.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Add" ), permissionName = GDWPermissionTypes.Permissions.AddDepartment.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditDepartment.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Deactivate" ), permissionName = GDWPermissionTypes.Permissions.DeactivateDepartment.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "Injuries" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewInjury.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Add" ), permissionName = GDWPermissionTypes.Permissions.AddInjury.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditInjury.ToString() },
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "Assignments" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Manage" ), permissionName = GDWPermissionTypes.Permissions.ManageAssignments.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "Scores" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Import" ), permissionName = GDWPermissionTypes.Permissions.ImportScores.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "MyAccount" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Manage" ), permissionName = GDWPermissionTypes.Permissions.ManageMyAccount.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "Classes" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Take" ), permissionName = GDWPermissionTypes.Permissions.TakeClass.ToString() },
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "FAQs" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Manage" ), permissionName = GDWPermissionTypes.Permissions.ManageFAQs.ToString() },
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "ScreeningRoom" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewScreeningRoom.ToString() },
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "Library" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewLibrary.ToString() },
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "OwnEmployeeDocuments" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() {
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewOwnEmployeeDocument.ToString() },
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "AllEmployeeDocuments" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() {
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewEmployeeDocument.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Manage" ), permissionName = GDWPermissionTypes.Permissions.ManageEmployeeDocument.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "ViewRestrictedItems" ), permissionName = GDWPermissionTypes.Permissions.ViewRestrictedEmployeeDocument.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "ManageRestrictedItems" ), permissionName = GDWPermissionTypes.Permissions.ManageRestrictedEmployeeDocument.ToString() }
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "AllEmployeeNotes" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() {
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewEmployeeNote.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Manage" ), permissionName = GDWPermissionTypes.Permissions.ManageEmployeeNote.ToString() }
					}
				},
                new PermissionInformation() {
                    objectName = GetUserString( "CompanyDocuments" ),
                    isCustomer = true,
                    buttons = new List<PermissionInformation.IndividualPermission>() {
                        new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewCompanyDocument.ToString() },
                        new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Manage" ), permissionName = GDWPermissionTypes.Permissions.ManageCompanyDocument.ToString() },
                        new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "ViewRestrictedItems" ), permissionName = GDWPermissionTypes.Permissions.ViewRestrictedCompanyDocument.ToString() },
                        new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "ManageRestrictedItems" ), permissionName = GDWPermissionTypes.Permissions.ManageRestrictedCompanyDocument.ToString() }
                    }
                },
                new PermissionInformation() {
	                objectName = GetUserString( "CompanyNotes" ),
	                isCustomer = true,
	                buttons = new List<PermissionInformation.IndividualPermission>() {
		                new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "View" ), permissionName = GDWPermissionTypes.Permissions.ViewCompanyNote.ToString() },
		                new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Manage" ), permissionName = GDWPermissionTypes.Permissions.ManageCompanyNote.ToString() }
	                }
                },
                new PermissionInformation() {
					objectName = GetUserString( "Alerts" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "ThreeFailedClasses" ), permissionName = GDWPermissionTypes.Permissions.AlertThreeFailed.ToString() },
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "AccountExpiration" ), permissionName = GDWPermissionTypes.Permissions.AlertAccountExpiration.ToString() },
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "EmailMessages" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "ReceiveEmailOnBehalfOfEmployees" ), permissionName = GDWPermissionTypes.Permissions.ReceiveEmailOnBehalfOfEmployees.ToString() },
					}
				},
				new PermissionInformation() {
					objectName = GetUserString( "Signature" ),
					isCustomer = true,
					buttons = new List<PermissionInformation.IndividualPermission>() { 
						new PermissionInformation.IndividualPermission() { buttonName = GetUserString( "Edit" ), permissionName = GDWPermissionTypes.Permissions.EditSignature.ToString() },
					}
				}
			};
		}

		public IEnumerable<GDWListItem> GetGroupDropDownList( bool bAccount, int? customerId )
		{
			return database.PermissionGroups
				.Where( p => !p.IsDeleted )
				.Where( p => p.IsAccountGroup == bAccount && (p.CustomerID == customerId || !p.CustomerID.HasValue) )
				.Select( p => new GDWListItem() { id = p.GroupID, name = p.Name } )
				.ToList();
		}

		#endregion

		public ResetPasswordInfo GetResetPasswordInfo( Guid id )
		{
			var emailInfo = database.ResetEmails.FirstOrDefault( e => e.EmailID == id );
			if( emailInfo != null )
			{
				return new ResetPasswordInfo()
				{
					resetId = id,
					isActive = emailInfo.IsActive && (emailInfo.ExpireDate > DateTime.UtcNow)
				};
			}

			return new ResetPasswordInfo()
			{
				isActive = false
			};
		}

		public void ResetPassword( ResetPasswordInfo info )
		{
			var emailInfo = database.ResetEmails.FirstOrDefault( e => e.EmailID == info.resetId && e.IsActive );
			if( emailInfo != null )
			{
				emailInfo.IsActive = false;

				emailInfo.User.Password = EncodePassword( info.newPassword );

				database.SaveChanges();

				var emailRecipients = GetEmailRecipientsForUser( emailInfo.User );
			    foreach ( var recip in emailRecipients )
			    {
			        (new ConfirmPasswordChangeEmailSender( recip.Language.StringClass )).SubmitConfirmPasswordChangeEmail( recip.EmailAddress, emailInfo.User.FirstName, emailInfo.User.LastName );
			    }

			    return;
			}

			throw new GDWException( "ErrorResetRequestNotValid" );
		}

		public void ForgotPassword( string fpUserName )
		{
		    var dbUser = FindUserByUserName( fpUserName );

			if( dbUser != null && dbUser.SetupEmailSent )
			{
				var resetEmail = new ResetEmail();
				resetEmail.EmailID = Guid.NewGuid();

				resetEmail.ExpireDate = DateTime.UtcNow.AddDays( 3 );
				resetEmail.IsActive = true;

				dbUser.ResetEmails.Add( resetEmail );

				database.SaveChanges();

				var emailRecipients = GetEmailRecipientsForUser( dbUser );
			    foreach ( var recip in emailRecipients )
			    {
			        (new UserResetPasswordEmailSender( recip.Language.StringClass )).SubmitPasswordChangeEmail( recip.EmailAddress, resetEmail.EmailID, dbUser.FirstName, dbUser.LastName );
			    }

			    return;
			}

			throw new GDWException( "ErrorUserNameNotFound" );
		}

		#region Language Information
		public IEnumerable<GDWListItem> GetLanguageDropDownList()
		{
			return database.Languages
				.Where( p => !p.IsDeleted )
				.Select( p => new GDWListItem() { id = p.LanguageID, name = p.Name } )
				.ToList();
		}

		public IEnumerable<GDWListItem> GetLanguageDropDownList( int classId, int? versionId )
		{
			if( versionId.HasValue )
			{
				var dbVersion = database.ClassVersions.FirstOrDefault( v => v.VersionID == versionId );
				if( dbVersion != null )
				{
					return new List<GDWListItem>() { new GDWListItem() { id = dbVersion.LanguageID, name = dbVersion.Language.Name } };
				}
			}

			return database.Languages
				.Where( p => !p.IsDeleted )
				.Where( p => !p.ClassVersions.Any( v => v.ClassID == classId && !v.IsDeleted ) )
				.Select( p => new GDWListItem() { id = p.LanguageID, name = p.Name } )
				.ToList();
		}

		public object GetFullLanguageList( LanguageTableParams param, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var languageList = database.Languages
				.Include( u => u.Users )
				.AsQueryable();

			totalRecords = languageList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				languageList = languageList.Where( i =>
					i.Name.Contains( param.sSearch ) );
			}
			switch( (param.activeState ?? "active").ToLower() )
			{
				case "active":
					languageList = languageList.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					languageList = languageList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}

			displayedRecords = languageList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<Language> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "name":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = languageList.OrderBy( v => v.Name );
					}
					else
					{
						filteredAndSorted = languageList.OrderByDescending( v => v.Name );
					}
					break;
				case "usercount":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = languageList.OrderBy( v => v.Users.Where( u => !u.IsDeleted ).Count() );
					}
					else
					{
						filteredAndSorted = languageList.OrderByDescending( v => v.Users.Where( u => !u.IsDeleted ).Count() );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new LanguageSummary()
			{
				languageId = v.LanguageID,
				name = v.Name,
				userCount = v.Users.Where( u => !u.IsDeleted ).Count(),
				isActive = !v.IsDeleted
			} );
		}

		public void AddLanguage( LanguageInformation lInfo )
		{
			var newLanguage = new Language();

			newLanguage.Name = lInfo.name;
			newLanguage.StringClass = "EnglishStrings";
			newLanguage.IsDeleted = !lInfo.isActive;

			database.Languages.Add( newLanguage );

			database.SaveChanges();
		}

		public void EditLanguage( LanguageInformation lInfo )
		{
			var dbLanguage = database.Languages.FirstOrDefault( l => l.LanguageID == lInfo.languageId );

			if( dbLanguage != null )
			{
				dbLanguage.Name = lInfo.name;
				dbLanguage.IsDeleted = !lInfo.isActive;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorLanguageNotFound" );
		}

		public LanguageInformation GetLanguage( int id )
		{
			var dbUser = database.Languages
				.FirstOrDefault( u => u.LanguageID == id );

			if( dbUser != null )
			{
				var langInfo = new LanguageInformation();

				langInfo.languageId = dbUser.LanguageID;
				langInfo.name = dbUser.Name;
				langInfo.isActive = !dbUser.IsDeleted;

				return langInfo;
			}

			throw new GDWException( "ErrorLanguageNotFound" );
		}

		public void DeleteLanguage( int id )
		{
			var dbLanguage = database.Languages.FirstOrDefault( l => l.LanguageID == id );

			if( dbLanguage != null )
			{
				dbLanguage.IsDeleted = true;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorLanguageNotFound" );
		}
		#endregion

		private NotificationSummary ToNotificationSummary( Notification alert, string resClass )
		{
			return new NotificationSummary()
			{
				alertId = alert.NotificationID,
				header = OSHALMSStrings.StringManager.GetStringFromResourceFile( resClass, alert.NotificationHeader ),
				text = string.Format( OSHALMSStrings.StringManager.GetStringFromResourceFile( resClass, alert.NotificationString ), args: alert.NotificationParameters.OrderBy( p => p.DisplayOrder ).Select( p => p.TextData ).ToArray() ),
				noteDateTime = alert.NotificationDateTime,
				isNew = alert.IsNew,
				isRead = alert.IsRead
			};
		}

		public NotificationList GetMyNotifications( int userId )
		{
			var dbUser = database.Users.FirstOrDefault( u => u.UserID == userId );

			if( dbUser != null )
			{
				var list = new NotificationList();

				list.theList.AddRange( dbUser
					.Notifications
					.OrderByDescending( n => n.NotificationDateTime )
					.Take( 3 )
					.ToList()
					.Select( n => ToNotificationSummary( n, dbUser.Language.StringClass ) )
					.ToList() );

				list.newCount = dbUser.Notifications.Count( n => n.IsNew );

				return list;
			}

			return new NotificationList();
		}

		public IEnumerable<NotificationSummary> GetAllMyNotifications( int userId, long startDate, long endDate )
		{
			var dbUser = database.Users.FirstOrDefault( u => u.UserID == userId );

			if( dbUser != null )
			{
				var startFilter = new DateTime( 1970, 1, 1 ).AddMilliseconds( startDate );
				var endFilter = new DateTime( 1970, 1, 1 ).AddMilliseconds( endDate );
				var retList = dbUser
					.Notifications
					.Where( n => n.NotificationDateTime >= startFilter && n.NotificationDateTime < endFilter )
					.OrderByDescending( n => n.NotificationDateTime )
					.ToList()
					.Select( n => ToNotificationSummary( n, dbUser.Language.StringClass ) )
					.ToList();

				var idList = retList.Select( n => n.alertId );
				foreach( var notification in dbUser.Notifications.Where( a => idList.Contains( a.NotificationID ) ) )
				{
					notification.IsRead = true;
				}

				database.SaveChanges();

				return retList;
			}

			return new List<NotificationSummary>();
		}

		public void ClearMyNotifications( int userId, int maxAlertId )
		{
			var dbUser = database.Users.FirstOrDefault( u => u.UserID == userId );

			if( dbUser != null )
			{
				foreach( var notif in dbUser.Notifications
					.Where( n => n.IsNew && n.NotificationID <= maxAlertId ) )
				{
					notif.IsNew = false;
				}

				database.SaveChanges();
			}			
		}

		public bool DoesEmailAddressExist( string email )
		{
			return database.Users.Any( u => u.EmailAddress == email && !u.IsDeleted );
		}

		public IEnumerable<GDWListItem> GetEmployeeDropDownList( int customerId, int currentUserId, string search, bool showDeleted )
		{
			var userList = database.Users
				.Where( c => ((!c.IsDeleted) || (showDeleted)) && c.PermissionGroups.SelectMany( p => p.PermissionGroupItems ).Any( i => i.PermissionID == GDWPermissionTypes.Permissions.TakeClass ) )
				.Where( u => u.CustomerLocations.Any( l => l.CustomerID == customerId ) )
				.AsQueryable();

			var currentUser = database.Users.First( u => u.UserID == currentUserId );
			if( currentUser.CustomerLocations.Any() )
			{
				if( !currentUser.PermissionGroups.SelectMany( g => g.PermissionGroupItems ).Any( i => i.PermissionID == GDWPermissionTypes.Permissions.ManageAllLocations ) )
				{
					var locationIds = currentUser.CustomerLocations.Select( l => l.LocationID ).ToList();
					userList = userList.Where( u => u.CustomerLocations.Select( l => l.LocationID ).Intersect( locationIds ).Any() );
				}
			}

			if( !string.IsNullOrEmpty( search ) )
			{
				userList = userList.Where( i =>
					i.FirstName.Contains( search ) ||
					i.LastName.Contains( search ) );
			}

			return userList
				.ToList()
				.Select( u => new GDWListItem() { id = u.UserID, name = u.FirstName + " " + u.LastName } );
		}

		public IEnumerable<EmployeeAssignmentSummary> GetFullEmployeeAssignmentList( EmployeeDetailTableParams param, out int totalRecords, out int displayedRecords, List<GDWPermissionTypes.Permissions> permissions )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var dbUser = database.Users
				.Include( u => u.UserClasses.Select( uc => uc.UserTests ) )
				.FirstOrDefault( u => u.UserID == param.employeeId );
			if( dbUser == null )
			{
				return new List<EmployeeAssignmentSummary>();
			}

			var classList = dbUser
				.UserClasses
				.AsQueryable();

			totalRecords = classList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				classList = classList.Where( i =>
					i.Name.Contains( param.sSearch ) );
			}

			displayedRecords = classList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<UserClass> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "name":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = classList.OrderBy( v => v.Name );
					}
					else
					{
						filteredAndSorted = classList.OrderByDescending( v => v.Name );
					}
					break;
				case "status":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = classList.OrderBy( v => v.Status ).ThenBy( v => v.DueDate );
					}
					else
					{
						filteredAndSorted = classList.OrderByDescending( v => v.Status ).ThenByDescending( v => v.DueDate );
					}
					break;
				case "duedate":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = classList.OrderBy( v => v.DueDate );
					}
					else
					{
						filteredAndSorted = classList.OrderByDescending( v => v.DueDate );
					}
					break;
				case "score":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = classList.OrderBy( v => v.Score );
					}
					else
					{
						filteredAndSorted = classList.OrderByDescending( v => v.Score );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new EmployeeAssignmentSummary()
			{
				userClassId = v.UserClassID,
				name = v.Name,
				status = GDWClassStatus.DisplayString( v.Status ),
				dueDate = v.DueDate.ToShortDateString(),
				score = v.Status == GDWClassStatus.Status.TestPassed || v.Status == GDWClassStatus.Status.TestComplete ? v.Score.ToString() : "",
				employeeName = dbUser.FirstName + " " + dbUser.LastName,
				canReclaim = (v.Status == GDWClassStatus.Status.New) || ((v.Status != GDWClassStatus.Status.TestPassed) && permissions.Contains( GDWPermissionTypes.Permissions.ReclaimStartedClass ))
			} );
		}

		public EmployeeAssignmentSummary GetEmployeeClass( int userClassId )
		{
			var dbUserClass = database.UserClasses.First( c => c.UserClassID == userClassId );

			return new EmployeeAssignmentSummary()
			{
				userClassId = dbUserClass.UserClassID,
				name = dbUserClass.Name,
				status = GDWClassStatus.DisplayString( dbUserClass.Status ),
				dueDate = dbUserClass.DueDate.ToShortDateString(),
				score = dbUserClass.Status == GDWClassStatus.Status.TestPassed || dbUserClass.Status == GDWClassStatus.Status.TestComplete ? dbUserClass.Score.ToString() : "",
				employeeName = dbUserClass.User.FirstName + " " + dbUserClass.User.LastName
			};
		}

		public void EditEmployeeClass( EmployeeAssignmentSummary eInfo )
		{
			var dbUserClass = database.UserClasses.FirstOrDefault( c => c.UserClassID == eInfo.userClassId );
			
			if( dbUserClass != null )
			{
				dbUserClass.DueDate = eInfo.realDueDate.Value;

				database.SaveChanges();

				return;
			}

			throw new Exception();
		}

		public IEnumerable<CalendarEventInformation> GetCalendarData( int userId, bool onlyMe, List<GDWPermissionTypes.Permissions> permissionList, 
			DateTime startDate, DateTime endDate )
		{
			var theList = new List<CalendarEventInformation>();
			var dbUser = database.Users.FirstOrDefault( u => u.UserID == userId );

			if( permissionList.Contains( GDWPermissionTypes.Permissions.TakeClass ) )
			{
				// my class due dates
				theList.AddRange( dbUser.UserClasses
					.Where( uc => uc.Status != GDWClassStatus.Status.TestPassed )
					.Where( uc => uc.DueDate >= startDate && uc.DueDate <= endDate )
					.Select( uc => new CalendarEventInformation()
					{
						title = string.Format( "{0} is due", uc.Name ),
						startDate = uc.DueDate
					} )
					.ToList() );
			}

			if( permissionList.Contains( GDWPermissionTypes.Permissions.ViewEmployee ) && !onlyMe )
			{
				// class due dates of everyone at my locations
				var locations = new List<int>();
				if( permissionList.Contains( GDWPermissionTypes.Permissions.ManageAllLocations ) )
				{
					locations = dbUser.CustomerLocations
						.First()
						.Customer
						.CustomerLocations
						.Where( cl => !cl.IsDeleted )
						.Select( cl => cl.LocationID )
						.ToList();
				}
				else
				{
					locations = dbUser.CustomerLocations
						.Select( cl => cl.LocationID )
						.ToList();
				}

				var dueClasses = database.CustomerLocations
					.Where( cl => locations.Contains( cl.LocationID ) )
					.SelectMany( cl => cl.Users )
					.Where( u => !u.IsDeleted )
					.SelectMany( u => u.UserClasses )					
					.Where( uc => uc.Status != GDWClassStatus.Status.TestPassed )
					.Where( uc => uc.DueDate >= startDate && uc.DueDate <= endDate )
					.GroupBy( uc => uc.DueDate )
					.ToList();

				theList.AddRange( dueClasses.Select( dc => new CalendarEventInformation()
					{
						title = string.Format( "{0} employee(s) have a class that is due", dc.Count() ),
						startDate = dc.Key
					} )
					.ToList() );
			}

			if( permissionList.Contains( GDWPermissionTypes.Permissions.AlertAccountExpiration ) && !onlyMe )
			{
				// expiration dates of all customers
				var dbCustomer = dbUser
					.CustomerLocations
					.First()
					.Customer;
				
				if( dbCustomer.ExpirationDate >= startDate && dbCustomer.ExpirationDate <= endDate )
				{
				theList.Add( new CalendarEventInformation()
					{
						title = string.Format( "Your account expires" ),
						startDate = dbCustomer.ExpirationDate,
						backgroundColor = "#a94442"
					} );
				}
			}

			if( permissionList.Contains( GDWPermissionTypes.Permissions.ViewCustomer ) && !onlyMe )
			{
				// expiration dates of all customers
				theList.AddRange( database.Customers
					.Where( c => !c.IsDeleted )
					.Where( c => c.ExpirationDate >= startDate && c.ExpirationDate <= endDate )
					.ToList()
					.Select( c => new CalendarEventInformation()
					{
						title = string.Format( "{0} account expiration", c.Name ),
						startDate = c.ExpirationDate,
						backgroundColor = "#a94442"
					} ) );
			}

			return theList;
		}

		private class ImportBoolConverter : ITypeConverter
		{
			#region ITypeConverter Members

			public bool CanConvertFrom( Type type )
			{
				return type == typeof(bool);
			}

			public bool CanConvertTo( Type type )
			{
				return type == typeof( bool );
			}

			public object ConvertFromString( TypeConverterOptions options, string text )
			{
				switch( text.ToLower() )
				{
					case "y":
					case "yes":
					case "true":
					case "1":
					case "x":
						return true;
				}

				return false;
			}

			public string ConvertToString( TypeConverterOptions options, object value )
			{
				return value.ToString();
			}

			#endregion
		}

		public IEnumerable<string> ImportEmployees( Stream fStream, int customerId, out int userCount )
		{
			using( var textReader = new StreamReader( fStream ) )
			{
				var csvReader = new CsvReader( textReader, new CsvConfiguration() { HasHeaderRecord = true } );

				int i = 1;
				var errors = new List<string>();
				var emails = new List<ResetEmail>();
				var newEmailAddressList = new List<string>();
				userCount = 0;

				while( csvReader.Read() )
				{
					try
					{
						var newUser = new User();

						newUser.FirstName = csvReader.GetField<string>( "First Name" );
						newUser.LastName = csvReader.GetField<string>( "Last Name" );
						newUser.EmailAddress = csvReader.GetField<string>( "Email Address" );
						newUser.PhoneNumber = csvReader.GetField<string>( "Phone Number" );
						try
						{
							newUser.Gender = (GenderType)Enum.Parse( typeof( GenderType ), csvReader.GetField<string>( "Gender" ) );
						}
						catch( ArgumentException )
						{
							errors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "InvalidGender" ) ) );
						}
						var languageName = csvReader.GetField<string>( "Language" );
						newUser.Language = database.Languages.FirstOrDefault( l => l.Name == languageName );
                        // Convert hire date to UTC (pretending input is EST/EDT) to work around display issue in browser
						newUser.HireDate = csvReader.GetField<DateTime?>( "Hire Date" ).ConvertFromEasternTime();
					    bool sendSetupEmail;
						if( !csvReader.TryGetField<bool, ImportBoolConverter>( "Send Setup Email", out sendSetupEmail ) )
						{
						    sendSetupEmail = false;
						}

						bool bIncludeField = false;
						foreach( var pGroup in database.PermissionGroups.Where( pg => !pg.IsDeleted && pg.IsAccountGroup && ((!pg.CustomerID.HasValue) || (pg.CustomerID == customerId)) ) )
						{
							if( csvReader.TryGetField<bool, ImportBoolConverter>( string.Format( "Role - {0}", pGroup.Name ), out bIncludeField ) )
							{
								if( bIncludeField )
								{
									newUser.PermissionGroups.Add( pGroup );
								}
							}
						}

						foreach( var location in database.CustomerLocations.Where( cl => !cl.IsDeleted && (cl.CustomerID == customerId) ) )
						{
							if( csvReader.TryGetField<bool, ImportBoolConverter>( string.Format( "Location - {0}", location.Name ), out bIncludeField ) )
							{
								if( bIncludeField )
								{
									newUser.CustomerLocations.Add( location );
								}
							}
						}

						foreach( var department in database.CustomerDepartments.Where( cl => !cl.IsDeleted && (cl.CustomerID == customerId) ) )
						{
							if( csvReader.TryGetField<bool, ImportBoolConverter>( string.Format( "Department - {0}", department.Name ), out bIncludeField ) )
							{
								if( bIncludeField )
								{
									newUser.CustomerDepartments.Add( department );
								}
							}
						}

						if( !newUser.FirstName.Any() )
						{
							errors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "FirstNameRequiredField" ) ) );
						}
						if( !newUser.LastName.Any() )
						{
							errors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "LastNameRequiredField" ) ) );
						}
					    if ( newUser.EmailAddress.Any() )
					    {
					        if ( !Regex.IsMatch( newUser.EmailAddress, "^[A-Za-z0-9](([_\\.\\-\\+]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\\.\\-]?[a-zA-Z0-9]+)*)\\.([A-Za-z]{2,})$" ) )
					        {
					            errors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "EmailAddresPatternError" ) ) );
					        }
					        else if ( database.Users.Any( u => u.EmailAddress == newUser.EmailAddress && !u.IsDeleted ) ||
					                  newEmailAddressList.Contains( newUser.EmailAddress.ToLower() ) )
					        {
					            errors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "ErrorEmailAlreadyInUse" ) ) );
					        }
					    }
					    if( newUser.PhoneNumber.Any() && !Regex.IsMatch( newUser.PhoneNumber, @"^(\d{3})[-](\d{3})[-](\d{4})$" ) )
						{
							errors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "PhoneNumberPatternError" ) ) );
						}
						if( !newUser.PermissionGroups.Any() )
						{
							errors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "UserRoleRequiredField" ) ) );
						}
						if( !newUser.CustomerLocations.Any() )
						{
							errors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "LocationsRequiredField" ) ) );
						}
						if( newUser.Language == null )
						{
							errors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "LanguageRequiredField" ) ) );							
						}

					    ResetEmail resetEmail = null;
					    if ( sendSetupEmail )
					    {
					        resetEmail = new ResetEmail();
					        resetEmail.EmailID = Guid.NewGuid();
					        resetEmail.ExpireDate = DateTime.UtcNow.AddDays( 3 );
					        resetEmail.IsActive = true;

					        newUser.ResetEmails.Add( resetEmail );
					        newUser.SetupEmailSent = true;
					    }
					    else
					    {
					        newUser.SetupEmailSent = false;
					    }

					    newUser.IsDeleted = false;
						newUser.Password = "";
						newUser.ImageFileName = null;

						database.Users.Add( newUser );
						userCount++;

                        if ( resetEmail != null )
						    emails.Add( resetEmail );

                        if (!string.IsNullOrEmpty( newUser.EmailAddress ))
						    newEmailAddressList.Add( newUser.EmailAddress.ToLower() );
					}
					catch
					{
						errors.Add( string.Format( "Line {0} - An unknown error has occured", i ) );
					}

					i++;
				}

				var activeEmployees = database.CustomerLocations
					.Where( cl => cl.CustomerID == customerId )
					.SelectMany( l => l.Users ).Distinct()
					.Count( e => !e.IsDeleted );
				var maxEmployees = database.Customers.First( c => c.CustomerID == customerId ).EmployeeCount;

				if( activeEmployees + userCount > maxEmployees )
				{
					throw new GDWException( "ImportFailedEmployeeLimit" );
				}

				if( !errors.Any() )
				{
					database.SaveChanges();

					foreach( var newEmail in emails )
					{
		                var emailRecipients = GetEmailRecipientsForUser( newEmail.User );
					    foreach ( var recip in emailRecipients )
					    {
					        (new NewAccountEmailSender( recip.Language.StringClass )).SubmitNewAccountEmail( recip.EmailAddress, newEmail.User.UserName, newEmail.EmailID,
                                newEmail.User.FirstName, newEmail.User.LastName );
					    }
					}
				}

				return errors;
			}
		}

		public IEnumerable<string> GetBlankUploadHeaders( int customerId )
		{
			var theList = new List<string>();

			theList.Add( "First Name" );
			theList.Add( "Last Name" );
			theList.Add( "Email Address" );
			theList.Add( "Phone Number" );
			theList.Add( "Gender" );
			theList.Add( "Language" );
			theList.Add( "Hire Date" );
			theList.Add( "Send Setup Email" );

			foreach( var pGroup in database.PermissionGroups.Where( pg => !pg.IsDeleted && pg.IsAccountGroup && ((!pg.CustomerID.HasValue) || (pg.CustomerID == customerId)) ) )
			{
				theList.Add( string.Format( "Role - {0}", pGroup.Name ) );
			}

			foreach( var location in database.CustomerLocations.Where( cl => !cl.IsDeleted && (cl.CustomerID == customerId) ) )
			{
				theList.Add( string.Format( "Location - {0}", location.Name ) );
			}

			foreach( var department in database.CustomerDepartments.Where( cl => !cl.IsDeleted && (cl.CustomerID == customerId) ) )
			{
				theList.Add( string.Format( "Department - {0}", department.Name ) );
			}

			return theList;
		}

	    public int GetPendingSetupEmailsCount( int customerId, int currentUserId )
	    {
	        var query = database.Users
	            .Where( u => !u.IsDeleted && !u.SetupEmailSent )
	            .Where( u => u.CustomerLocations.Any( l => l.CustomerID == customerId ) );

            var currentUser = database.Users.Include( u => u.CustomerLocations ).First( u => u.UserID == currentUserId );
			if( currentUser.CustomerLocations.Any() )
			{
				if( !currentUser.PermissionGroups.SelectMany( g => g.PermissionGroupItems ).Any( i => i.PermissionID == GDWPermissionTypes.Permissions.ManageAllLocations ) )
				{
					var locationIds = currentUser.CustomerLocations.Select( l => l.LocationID ).ToList();
					query = query.Where( u => u.CustomerLocations.Select( l => l.LocationID ).Intersect( locationIds ).Any() );
				}
			}

	        return query.Count();
	    }
        
	    public int SendPendingSetupEmails( int customerId, int currentUserId, IEnumerable<int> userIds = null )
	    {
	        var query = database.Users
	            .Where( u => !u.IsDeleted && !u.SetupEmailSent )
	            .Where( u => u.CustomerLocations.Any( l => l.CustomerID == customerId ) );

	        if ( userIds != null )
	        {
	            query = query.Where( u => userIds.Contains( u.UserID ) );
	        }

            var currentUser = database.Users.Include( u => u.CustomerLocations ).First( u => u.UserID == currentUserId );
			if( currentUser.CustomerLocations.Any() )
			{
				if( !currentUser.PermissionGroups.SelectMany( g => g.PermissionGroupItems ).Any( i => i.PermissionID == GDWPermissionTypes.Permissions.ManageAllLocations ) )
				{
					var locationIds = currentUser.CustomerLocations.Select( l => l.LocationID ).ToList();
					query = query.Where( u => u.CustomerLocations.Select( l => l.LocationID ).Intersect( locationIds ).Any() );
				}
			}

	        var users = query.ToArray();
	        var resetEmails = new List<ResetEmail>();
            foreach (var user in users)
            {
		        var resetEmail = new ResetEmail();
		        resetEmail.EmailID = Guid.NewGuid();
		        resetEmail.ExpireDate = DateTime.UtcNow.AddDays( 3 );
		        resetEmail.IsActive = true;

		        user.ResetEmails.Add( resetEmail );
		        user.SetupEmailSent = true;

                resetEmails.Add( resetEmail );
		    }
            
			database.SaveChanges();

            foreach (var resetEmail in resetEmails)
            {
                var user = resetEmail.User;
		        var emailRecipients = GetEmailRecipientsForUser( user );
		        foreach ( var recip in emailRecipients )
		        {
		            var recipLang = recip.Language;
		            if ( recipLang == null )
		                recipLang = database.Languages.First( l => l.LanguageID == recip.LanguageID );
		            (new NewAccountEmailSender( recipLang.StringClass )).SubmitNewAccountEmail( recip.EmailAddress, user.UserName, resetEmail.EmailID,
		                user.FirstName, user.LastName );
		        }
		    }

	        return GetPendingSetupEmailsCount( customerId, currentUserId );
	    }

	    public IList<User> GetEmailRecipientsForUser( User user )
	    {
	        if ( !string.IsNullOrEmpty( user.EmailAddress ) )
	        {
	            return new[] { user };
	        }

	        var locationsIds = database.CustomerLocations.Where( l => l.Users.Any( u => u.UserID == user.UserID ) ).Select( l => l.LocationID ).ToArray();
	        var departmentIds = database.CustomerDepartments.Where( p => p.Users.Any( u => u.UserID == user.UserID ) ).Select( p => p.DepartmentID ).ToArray();

	        var recipsQuery = database.Users
                .Include( u => u.Language )
	            .Where( u => !u.IsDeleted && !string.IsNullOrEmpty( u.EmailAddress ) )
	            .Where( u => u.PermissionGroups.SelectMany( pg => pg.PermissionGroupItems ).Select( pgi => pgi.PermissionID )
	                .Contains( GDWPermissionTypes.Permissions.ReceiveEmailOnBehalfOfEmployees ) )
	            .Where( u => u.CustomerLocations.Any( l => locationsIds.Contains( l.LocationID ) ) );
	        if ( departmentIds.Any() )
	        {
	            recipsQuery = recipsQuery.Where( u => u.CustomerDepartments.Any( p => departmentIds.Contains( p.DepartmentID ) ) );
	        }

	        return recipsQuery.ToArray();
	    }

	    public User FindUserByUserName( string userName )
	    {
	        User user = null;
		    if ( !string.IsNullOrEmpty( userName ) )
		    {
		        if ( userName.Contains( "@" ) )
		            user = database.Users.FirstOrDefault( u => u.EmailAddress == userName && !u.IsDeleted );
		        else
		            user = FindUserByNonEmailUserName( userName );
		    }
	        return user;
	    }

	    private User FindUserByNonEmailUserName( string userName )
	    {
            if ( userName != null && userName.Length >= 3 )
            {
                int? userId = User.ParseIdFromNonEmailUserName( userName );
                if ( userId.HasValue )
                {
		            var user = database.Users.SingleOrDefault( u => u.UserID == userId.Value && !u.IsDeleted );
                    // Initials in userName must be correct as well.
                    if ( user != null && userName.ToLower() == user.UserName )
                        return user;
                }
            }
            return null;
	    }

        #region Employee documents

        public IEnumerable<DocumentSummary> GetFullDocumentList( EmployeeDocumentTableParams param, GDWWebUser currentUser, out int totalRecords, out int displayedRecords )
		{
            totalRecords = 0;
			displayedRecords = 0;

			int userId = param.userId == 0 || !currentUser.HasPermission(GDWPermissionTypes.Permissions.ViewEmployeeDocument)
				? currentUser.UserId
				: param.userId;

			var documentList = database.Documents
				.Where( d => d.CustomerID == null && d.UserID != null && d.UserID == userId )
				.AsQueryable();

			if (!currentUser.HasPermission( GDWPermissionTypes.Permissions.ViewRestrictedEmployeeDocument ))
			{
				documentList = documentList.Where(e => !e.IsRestricted);
			}

			totalRecords = documentList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				documentList = documentList.Where( i => i.Name.Contains( param.sSearch ) || i.Description.Contains( param.sSearch ) );
			}

			if (currentUser.HasPermission(GDWPermissionTypes.Permissions.ManageEmployeeDocument))
			{
				switch ((param.activeState ?? "active").ToLower())
				{
				case "active":
					documentList = documentList.Where(u => !u.IsDeleted);
					break;
				case "inactive":
					documentList = documentList.Where(u => u.IsDeleted);
					break;
				case "all":
					break;
				}
			}
			else
			{
				documentList = documentList.Where(u => !u.IsDeleted);
			}

			displayedRecords = documentList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<Document> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "name":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = documentList.OrderBy( v => v.Name );
					}
					else
					{
						filteredAndSorted = documentList.OrderByDescending( v => v.Name );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new DocumentSummary()
			{
				documentId = v.DocumentID,
				name = v.Name,
				description = v.Description,
				isRestricted = v.IsRestricted,
				isActive = !v.IsDeleted,
				lastUpdateDate = v.LastUpateDateTime
			} );
		}
		
        public void AddDocument( GDWWebUser currentUser, DocumentInformation pInfo )
        {
	        int userId = currentUser.HasPermission(GDWPermissionTypes.Permissions.ViewEmployeeDocument)
		        ? pInfo.userId
		        : currentUser.UserId;

	        var dbUser = database.Users.FirstOrDefault(u => u.UserID == userId);

	        if (dbUser == null)
		        throw new GDWException("ErrorUserNotFound");

	        var newDocument = new Document { UserID = dbUser.UserID };

	        newDocument.LastUpateDateTime = DateTime.UtcNow;
	        newDocument.Name = pInfo.name;
	        newDocument.Description = pInfo.description;
	        newDocument.IsDeleted = !pInfo.isActive;
				
	        if (currentUser.HasPermission( GDWPermissionTypes.Permissions.ManageRestrictedEmployeeDocument ))
	        {
		        newDocument.IsRestricted = pInfo.isRestricted;
	        }
			
	        if ( !string.IsNullOrEmpty( pInfo.fileName ) )
	        {
		        newDocument.FileName = pInfo.fileName;
		        newDocument.OriginalName = pInfo.originalFileName;
	        }

	        dbUser.Documents.Add( newDocument );

	        database.SaveChanges();
        }

        public void EditDocument( GDWWebUser currentUser, DocumentInformation pInfo )
        {
	        int userId = pInfo.userId != 0 && currentUser.HasPermission(GDWPermissionTypes.Permissions.ViewEmployeeDocument)
		        ? pInfo.userId
		        : currentUser.UserId;

	        var dbUser = database.Users.FirstOrDefault(u => u.UserID == userId);

	        if (dbUser == null)
		        throw new GDWException("ErrorUserNotFound");

	        var dbDocument = database.Documents.FirstOrDefault( d => d.DocumentID == pInfo.documentId && d.CustomerID == null && d.UserID != null && d.UserID == userId );

	        if (dbDocument == null)
		        throw new GDWException("ErrorDocumentNotFound");

	        if (dbDocument.IsRestricted && !currentUser.HasPermission(GDWPermissionTypes.Permissions.ManageRestrictedEmployeeDocument))
	        {
		        throw new GDWException("ErrorDocumentNotFound");
	        }

	        dbDocument.LastUpateDateTime = DateTime.UtcNow;
	        dbDocument.Name = pInfo.name;
	        dbDocument.Description = pInfo.description;
	        dbDocument.IsDeleted = !pInfo.isActive;
				
	        if (currentUser.HasPermission(GDWPermissionTypes.Permissions.ManageRestrictedEmployeeDocument))
	        {
		        dbDocument.IsRestricted = pInfo.isRestricted;
	        }

	        if ( !string.Equals( pInfo.fileName, dbDocument.FileName, StringComparison.InvariantCultureIgnoreCase ) )
	        {
		        if ( !string.IsNullOrEmpty( dbDocument.FileName ) )
		        {
			        var fileStorage = new AzureFileStorage();
			        fileStorage.DeleteFile( "Files", dbDocument.FileName );
		        }
	        }
	        if ( !string.IsNullOrEmpty( pInfo.fileName ) )
	        {
		        dbDocument.FileName = pInfo.fileName;
		        dbDocument.OriginalName = pInfo.originalFileName;
	        }
	        else
	        {
		        dbDocument.FileName = null;
		        dbDocument.OriginalName = null;
	        }

	        database.SaveChanges();
        }

        public DocumentInformation GetDocument( GDWWebUser currentUser, int id, int userId )
        {
	        if (userId == 0 || !currentUser.HasPermission(GDWPermissionTypes.Permissions.ViewEmployeeDocument))
				userId = currentUser.UserId;

	        var dbDocument = database.Documents.FirstOrDefault( d => d.DocumentID == id && d.CustomerID == null && d.UserID != null && d.UserID == userId );

	        if (dbDocument == null)
		        throw new GDWException("ErrorDocumentNotFound");

	        if (dbDocument.IsRestricted && !currentUser.HasPermission(GDWPermissionTypes.Permissions.ViewRestrictedEmployeeDocument))
	        {
		        throw new GDWException("ErrorDocumentNotFound");
	        }

	        return new DocumentInformation
	        {
		        documentId = dbDocument.DocumentID,
		        userId = dbDocument.UserID ?? 0,
		        name = dbDocument.Name,
				description = dbDocument.Description,
				isRestricted = dbDocument.IsRestricted,
		        isActive = !dbDocument.IsDeleted,
				fileName = dbDocument.FileName,
				originalFileName = dbDocument.OriginalName
	        };

        }

        public void DeleteDocument(GDWWebUser currentUser, int id, int userId)
        {
	        if (userId == 0 || !currentUser.HasPermission(GDWPermissionTypes.Permissions.ViewEmployeeDocument))
		        userId = currentUser.UserId;

	        var dbDocument = database.Documents.FirstOrDefault( d => d.DocumentID == id && d.CustomerID == null && d.UserID != null && d.UserID == userId );

	        if (dbDocument == null)
		        throw new GDWException("ErrorDocumentNotFound");

	        if (dbDocument.IsRestricted && !currentUser.HasPermission(GDWPermissionTypes.Permissions.ManageRestrictedEmployeeDocument))
	        {
		        throw new GDWException("ErrorDocumentNotFound");
	        }

	        dbDocument.IsDeleted = true;
	        database.SaveChanges();
        }

        #endregion

        #region Employee notes

        public IEnumerable<NoteSummary> GetFullNoteList( EmployeeNoteTableParams param, GDWWebUser currentUser, out int totalRecords, out int displayedRecords )
		{
            totalRecords = 0;
			displayedRecords = 0;

			var noteList = database.Notes
			                       .Include(n => n.LastUpdateByUser)
			                       .Where(n => n.CustomerID == null && n.UserID != null && n.UserID == param.userId)
			                       .Where(n => !n.IsDeleted)
			                       .AsQueryable();

			totalRecords = noteList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				noteList = noteList.Where(i => i.Text.Contains(param.sSearch) ||
				                               i.LastUpdateByUser.FirstName.Contains(param.sSearch) || i.LastUpdateByUser.LastName.Contains(param.sSearch));
			}

			displayedRecords = noteList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<Note> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
			case "lastUpdatedByUser":
				if (param.sSortDir_0.ToLower() == "asc")
				{
					filteredAndSorted = noteList.OrderBy( v => v.LastUpdateByUser.FirstName ).ThenBy( v => v.LastUpdateByUser.LastName );
				}
				else
				{
					filteredAndSorted = noteList.OrderByDescending( v => v.LastUpdateByUser.FirstName ).ThenByDescending( v => v.LastUpdateByUser.LastName );
				}

				break;

			// case "lastUpdateDate":
			default:
				if (param.sSortDir_0.ToLower() == "asc")
				{
					filteredAndSorted = noteList.OrderBy(v => v.LastUpateDateTime);
				}
				else
				{
					filteredAndSorted = noteList.OrderByDescending(v => v.LastUpateDateTime);
				}

				break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new NoteSummary()
			{
				noteId = v.NoteID,
				text = v.Text,
				lastUpdateDate = v.LastUpateDateTime,
				lastUpdatedByUser = v.LastUpdateByUser.FullName
			} );
		}
		
        public void AddNote( GDWWebUser currentUser, NoteInformation pInfo )
        {
	        var dbUser = database.Users.FirstOrDefault(u => u.UserID == pInfo.userId);
	        if (dbUser == null)
		        throw new GDWException("ErrorUserNotFound");

	        var newNote = new Note { UserID = dbUser.UserID, LastUpdateByUserID = currentUser.UserId };

	        newNote.LastUpateDateTime = DateTime.UtcNow;
	        newNote.Text = pInfo.text;

	        dbUser.Notes.Add( newNote );

	        database.SaveChanges();
        }

        public NoteInformation GetNote( GDWWebUser currentUser, int id, int userId )
        {
	        var dbNote = database.Notes
	                             .Include( n => n.LastUpdateByUser )
	                             .FirstOrDefault( n => n.NoteID == id && n.CustomerID == null && n.UserID != null && n.UserID == userId );
	        if (dbNote == null)
		        throw new GDWException("ErrorNoteNotFound");

	        return new NoteInformation
	        {
		        noteId = dbNote.NoteID,
		        customerId = dbNote.CustomerID ?? 0,
		        userId = dbNote.UserID ?? 0,
		        text = dbNote.Text,
		        lastUpdatedByUser = dbNote.LastUpdateByUser.FullName,
		        lastUpdated = dbNote.LastUpateDateTime
	        };

        }

        public void DeleteNote(GDWWebUser currentUser, int id, int userId)
        {
	        var dbNote = database.Notes.FirstOrDefault( n => n.NoteID == id && n.CustomerID == null && n.UserID != null && n.UserID == userId );
	        if (dbNote == null)
		        throw new GDWException("ErrorNoteNotFound");

	        dbNote.IsDeleted = true;
	        database.SaveChanges();
        }

        #endregion
	}
}
