﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Discount;

namespace GDWRepositories
{
	public class DiscountRepository : BaseRepository
	{
		public IEnumerable<DiscountSummary> GetFullDiscountList( DiscountTableParams param, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var discountList = database.DiscountCodes
				.Include( dc => dc.CustomerPurchases )
				.AsQueryable();

			totalRecords = discountList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				discountList = discountList.Where( i =>
					i.Name.Contains( param.sSearch ) ||
					i.CodeText.Contains( param.sSearch ) );
			}
			switch( (param.activeState ?? "active").ToLower() )
			{
				case "active":
					discountList = discountList.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					discountList = discountList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}

			displayedRecords = discountList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<DiscountCode> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "name":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = discountList.OrderBy( v => v.Name );
					}
					else
					{
						filteredAndSorted = discountList.OrderByDescending( v => v.Name );
					}
					break;
				case "codetext":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = discountList.OrderBy( v => v.CodeText );
					}
					else
					{
						filteredAndSorted = discountList.OrderByDescending( v => v.CodeText );
					}
					break;
				case "usecount":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = discountList.OrderBy( v => v.CustomerPurchases.Count() );
					}
					else
					{
						filteredAndSorted = discountList.OrderByDescending( v => v.CustomerPurchases.Count() );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( dc => new DiscountSummary()
			{
				discountCodeId = dc.DiscountCodeID,
				name = dc.Name,
				codeText = dc.CodeText,
				useCount = dc.CustomerPurchases.Count(),
				isActive = !dc.IsDeleted
			} );
		}


		public void AddDiscountCode( DiscountInformation dcInfo )
		{
			var newDiscountCode = new DiscountCode();

			newDiscountCode.Name = dcInfo.name;
			newDiscountCode.Description = dcInfo.description;
			newDiscountCode.CodeType = (GDWDiscountTypes.DiscountType)dcInfo.codeType;
			switch( newDiscountCode.CodeType )
			{
				case GDWDiscountTypes.DiscountType.DollarOffAccounts:
				case GDWDiscountTypes.DiscountType.DollarOffCredits:
				case GDWDiscountTypes.DiscountType.DollarOffPurchase:
					newDiscountCode.OffAmount = dcInfo.dollarOffAmount;
					newDiscountCode.FirstAmount = dcInfo.minimumPurchase;
					break;
				case GDWDiscountTypes.DiscountType.PercOffAccounts:
				case GDWDiscountTypes.DiscountType.PercOffCredits:
				case GDWDiscountTypes.DiscountType.PercOffPurchase:
					newDiscountCode.OffAmount = dcInfo.percOffAmount;
					newDiscountCode.FirstAmount = 0;
					break;
				case GDWDiscountTypes.DiscountType.PercOffSomeAccounts:
				case GDWDiscountTypes.DiscountType.PercOffSomeCredits:
					newDiscountCode.OffAmount = dcInfo.percOffAmount;
					newDiscountCode.FirstAmount = dcInfo.firstAmount;
					break;
			}
			newDiscountCode.CodeText = dcInfo.codeText;
			newDiscountCode.StartDate = dcInfo.startDate;
			newDiscountCode.EndDate = dcInfo.endDate;
			newDiscountCode.IsExistingCustomer = dcInfo.isExistingCustomer;
			newDiscountCode.IsMultiUse = dcInfo.isMultiUse;
			newDiscountCode.IsNewPurchase = dcInfo.isNewPurchase;
			newDiscountCode.IsRenewal = dcInfo.isRenewal;
			newDiscountCode.IsDeleted = !dcInfo.isActive;

			database.DiscountCodes.Add( newDiscountCode );

			database.SaveChanges();
		}

		public void EditDiscountCode( DiscountInformation dcInfo )
		{
			var dbDiscountCode = database.DiscountCodes.FirstOrDefault( dc => dc.DiscountCodeID == dcInfo.discountCodeId );

			if( dbDiscountCode != null )
			{
				dbDiscountCode.Name = dcInfo.name;
				dbDiscountCode.Description = dcInfo.description;
				dbDiscountCode.CodeType = (GDWDiscountTypes.DiscountType)dcInfo.codeType;
				switch( dbDiscountCode.CodeType )
				{
					case GDWDiscountTypes.DiscountType.DollarOffAccounts:
					case GDWDiscountTypes.DiscountType.DollarOffCredits:
					case GDWDiscountTypes.DiscountType.DollarOffPurchase:
						dbDiscountCode.OffAmount = dcInfo.dollarOffAmount;
						dbDiscountCode.FirstAmount = dcInfo.minimumPurchase;
						break;
					case GDWDiscountTypes.DiscountType.PercOffAccounts:
					case GDWDiscountTypes.DiscountType.PercOffCredits:
					case GDWDiscountTypes.DiscountType.PercOffPurchase:
						dbDiscountCode.OffAmount = dcInfo.percOffAmount;
						dbDiscountCode.FirstAmount = 0;
						break;
					case GDWDiscountTypes.DiscountType.PercOffSomeAccounts:
					case GDWDiscountTypes.DiscountType.PercOffSomeCredits:
						dbDiscountCode.OffAmount = dcInfo.percOffAmount;
						dbDiscountCode.FirstAmount = dcInfo.firstAmount;
						break;
				}
				dbDiscountCode.CodeText = dcInfo.codeText;
				dbDiscountCode.StartDate = dcInfo.startDate;
				dbDiscountCode.EndDate = dcInfo.endDate;
				dbDiscountCode.IsExistingCustomer = dcInfo.isExistingCustomer;
				dbDiscountCode.IsMultiUse = dcInfo.isMultiUse;
				dbDiscountCode.IsNewPurchase = dcInfo.isNewPurchase;
				dbDiscountCode.IsRenewal = dcInfo.isRenewal;
				dbDiscountCode.IsDeleted = !dcInfo.isActive;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorUserNotFound" );
		}

		public DiscountInformation GetDiscountCode( int id )
		{
			var dbDiscountCode = database.DiscountCodes.FirstOrDefault( dc => dc.DiscountCodeID == id );

			if( dbDiscountCode != null )
			{
				var dcInfo = new DiscountInformation();

				dcInfo.discountCodeId = dbDiscountCode.DiscountCodeID;
				dcInfo.name = dbDiscountCode.Name;
				dcInfo.description = dbDiscountCode.Description;
				dcInfo.codeType = (int)dbDiscountCode.CodeType;
				switch( dbDiscountCode.CodeType )
				{
					case GDWDiscountTypes.DiscountType.DollarOffAccounts:
					case GDWDiscountTypes.DiscountType.DollarOffCredits:
					case GDWDiscountTypes.DiscountType.DollarOffPurchase:
						dcInfo.dollarOffAmount = dbDiscountCode.OffAmount;
						dcInfo.firstAmount = 0;
						dcInfo.minimumPurchase = dbDiscountCode.FirstAmount;
						break;
					case GDWDiscountTypes.DiscountType.PercOffAccounts:
					case GDWDiscountTypes.DiscountType.PercOffCredits:
					case GDWDiscountTypes.DiscountType.PercOffPurchase:
						dcInfo.percOffAmount = dbDiscountCode.OffAmount;
						dcInfo.firstAmount = 0;
						dcInfo.minimumPurchase = 0;
						break;
					case GDWDiscountTypes.DiscountType.PercOffSomeAccounts:
					case GDWDiscountTypes.DiscountType.PercOffSomeCredits:
						dcInfo.percOffAmount = dbDiscountCode.OffAmount;
						dcInfo.firstAmount = dbDiscountCode.FirstAmount;
						dcInfo.minimumPurchase = 0;
						break;
				}
				dcInfo.codeText = dbDiscountCode.CodeText;
				dcInfo.startDate = dbDiscountCode.StartDate;
				dcInfo.endDate = dbDiscountCode.EndDate;
				dcInfo.isExistingCustomer = dbDiscountCode.IsExistingCustomer;
				dcInfo.isMultiUse = dbDiscountCode.IsMultiUse;
				dcInfo.isNewPurchase = dbDiscountCode.IsNewPurchase;
				dcInfo.isRenewal = dbDiscountCode.IsRenewal;
				dcInfo.isActive = !dbDiscountCode.IsDeleted;

				return dcInfo;
			}

			throw new GDWException( "ErrorUserNotFound" );
		}

		public void DeleteDiscountCode( int id )
		{
			var dbCode = database.DiscountCodes.FirstOrDefault( u => u.DiscountCodeID == id );

			if( dbCode != null )
			{
				dbCode.IsDeleted = true;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorUserNotFound" );
		}

		public bool IsValidCode( int? discountCodeId, string codeText )
		{
			codeText = (codeText ?? "").Trim();

			if( string.IsNullOrEmpty( codeText ) )
				return false;

			return !database.DiscountCodes.Any( dc => dc.DiscountCodeID != discountCodeId && dc.CodeText == codeText );

		}

		private DiscountDetail ToDiscountDetail( DiscountCode dbDiscountCode )
		{
			var dcDetail = new DiscountDetail();

			dcDetail.discountCodeId = dbDiscountCode.DiscountCodeID;
			dcDetail.codeType = (int)dbDiscountCode.CodeType;
			dcDetail.codeText = dbDiscountCode.CodeText;
			switch( dbDiscountCode.CodeType )
			{
				case GDWDiscountTypes.DiscountType.DollarOffAccounts:
				case GDWDiscountTypes.DiscountType.DollarOffCredits:
				case GDWDiscountTypes.DiscountType.DollarOffPurchase:
					dcDetail.dollarOffAmount = dbDiscountCode.OffAmount;
					dcDetail.firstAmount = 0;
					dcDetail.minimumPurchase = dbDiscountCode.FirstAmount;
					break;
				case GDWDiscountTypes.DiscountType.PercOffAccounts:
				case GDWDiscountTypes.DiscountType.PercOffCredits:
				case GDWDiscountTypes.DiscountType.PercOffPurchase:
					dcDetail.percOffAmount = dbDiscountCode.OffAmount;
					dcDetail.firstAmount = 0;
					dcDetail.minimumPurchase = 0;
					break;
				case GDWDiscountTypes.DiscountType.PercOffSomeAccounts:
				case GDWDiscountTypes.DiscountType.PercOffSomeCredits:
					dcDetail.percOffAmount = dbDiscountCode.OffAmount;
					dcDetail.firstAmount = dbDiscountCode.FirstAmount;
					dcDetail.minimumPurchase = 0;
					break;
			}

			return dcDetail;
		}

		public DiscountDetail GetDiscountCode( string code, GDWPurchaseTypes.PurchaseType pType, int? customerId )
		{
			var dbCode = database.DiscountCodes.FirstOrDefault( dc => dc.CodeText == code );

			if( dbCode != null )  // code exists
			{
				if( dbCode.IsMultiUse || !dbCode.CustomerPurchases.Any() )  // is multi use or hasn't been used before
				{
					if( !customerId.HasValue || !dbCode.CustomerPurchases.Any( cp => cp.CustomerID == customerId ) )  // is for new customer or has been used by customer
					{
						if( dbCode.StartDate.Date <= DateTime.Now.Date && DateTime.Now.Date <= dbCode.EndDate.Date )
						{
							switch( pType )
							{
								case GDWPurchaseTypes.PurchaseType.Original:
									if( dbCode.IsNewPurchase )
									{
										return ToDiscountDetail( dbCode );
									}
									break;
								case GDWPurchaseTypes.PurchaseType.AddOns:
									if( dbCode.IsExistingCustomer )
									{
										return ToDiscountDetail( dbCode );
									}
									break;
								case GDWPurchaseTypes.PurchaseType.Renewal:
									if( dbCode.IsRenewal )
									{
										return ToDiscountDetail( dbCode );
									}
									break;
							}
						}
					}
				}
			}

			throw new GDWEnglishException( "The discount code that you entered is not valid." );
		}
	}
}
