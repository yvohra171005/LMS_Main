﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWDatabase;
using GDWInfrastructure.DataTables;
using GDWModels.Dashboard;

namespace GDWRepositories
{
	public class DashboardRepository : BaseRepository
	{
		public IEnumerable<WidgetDefinition> GetMyWidgets( int userId )
		{
			var dbUser = database.Users.First( u => u.UserID == userId );
			var dbWidgets = dbUser.UserDashboardWidgets;

			var fullList = WidgetDefinition.GetFullList()
				.Where( w => dbUser.PermissionGroups.SelectMany( g => g.PermissionGroupItems )
					.Select( i => i.PermissionID )
					.Contains( w.requiredPermission ) ||
					(w.allCustomerUsers && dbUser.CustomerLocations.Any()) ||
					w.allUsers )
				.ToList();

			fullList.ForEach( w =>
			{
				var dbWidget = dbWidgets.FirstOrDefault( dbw => dbw.WidgetID == w.widgetId );
				if( dbWidget != null )
				{
					w.displayOrder = dbWidget.DisplayOrder;
				}
				w.widgetName = GetUserString( w.widgetNameKey );
			} );

			return fullList.OrderBy( w => w.displayOrder ).ThenBy( w => w.widgetName );
		}

		public void AddMyWidget( int userId, int widgetId )
		{
			database.UserDashboardWidgets
				.Add( new UserDashboardWidget()
				{
					DisplayOrder = database.UserDashboardWidgets.Count( w => w.UserID == userId ),
					UserID = userId,
					WidgetID = widgetId
				} );

			database.SaveChanges();
		}

		public void UpdateMyWidgets( int userId, List<WidgetDefinition> widgets )
		{
			var dbWidgets = database.UserDashboardWidgets
				.Where( w => w.UserID == userId );

			int i = 0;
			foreach( var uiWidget in widgets )
			{
				var dbWidget = dbWidgets.FirstOrDefault( w => w.WidgetID == uiWidget.widgetId );	// yes, we're doing the widget id, not the pk
				if( dbWidget != null )
				{
					dbWidget.DisplayOrder = i;
				}
				i++;
			}

			database.SaveChanges();
		}

		public void DeleteMyWidget( int userId, int widgetId )
		{
			var dbWidgets = database.UserDashboardWidgets
				.Where( w => w.UserID == userId )
				.OrderBy( w => w.DisplayOrder );

			int i = 0;
			foreach( var widget in dbWidgets.ToList() )
			{
				if( widget.WidgetID == widgetId )
				{
					database.UserDashboardWidgets.Remove( widget );
				}
				else
				{
					widget.DisplayOrder = i;
					i++;
				}
			}

			database.SaveChanges();
		}

		public IEnumerable<WidgetSummary> GetWidgetList( WidgetTableParams param, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var widgetList = WidgetDefinition.GetFullList().ToList();

			totalRecords = widgetList.Count();
			displayedRecords = widgetList.Count();

			return widgetList.Select( w => new WidgetSummary()
			{
				name = GetUserString( w.widgetNameKey ),
				permission = GetUserString( w.allUsers ? "AllUsers" : (w.allCustomerUsers ? "AllCustomerUsers" : w.requiredPermission.ToString()) ),
				widthDisplay = (w.widgetWidth / 12.0).ToString( "P0" )
			} )
			.OrderBy( w => w.name );
		}
	}
}
