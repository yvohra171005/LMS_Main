﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Report;

namespace GDWRepositories
{
	public class ReportRepository : BaseRepository
	{
		public IEnumerable<ReportSummary> GetFullReportList( ReportDataTableParams param, IEnumerable<GDWPermissionTypes.Permissions> permissions, int? customerId,
			out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var reportList = ReportDefinition.GetFullList()
				.Where( r => permissions.Contains( r.requiredPermission ) )
				.ToList();

			if( customerId.HasValue )
			{
				var dbCustomer = database.Customers.First( c => c.CustomerID == customerId.Value );
				if( !dbCustomer.TracksCredits )
				{
					reportList.RemoveAll( c => c.creditBased );
				}
			}

			totalRecords = reportList.Count();
			displayedRecords = reportList.Count();

			return reportList.Select( w => new ReportSummary()
			{
				reportId = w.reportId,
				name = GetUserString( w.nameKey ),
				description = GetUserString( w.descriptionKey )
			} )
			.OrderBy( w => w.name );
		}

		public ReportInformation GetReport( int id )
		{
			var dbReport = ReportDefinition.GetFullList()
				.Where( r => r.reportId == id )
				.FirstOrDefault();

			if( dbReport != null )
			{
				var retInfo = new ReportInformation()
				{
					reportId = dbReport.reportId,
					name = GetUserString( dbReport.nameKey ),
					filterSet = dbReport.filterSet,
					viewURL = dbReport.viewURL,
					downloadURL = dbReport.downloadURL
				};

				retInfo.filterSet.sortByValues = dbReport.sortByKeys.Select( k => new GDWStringListItem() { id = k, name = GetUserString( k ) } ).ToList();

				return retInfo;
			}

			throw new NotImplementedException();
		}

		public List<SnapshotInformation> GetSnapshotReport( ReportFilter filter )
		{
			if( filter.isBlank )
			{
				return new List<SnapshotInformation>();
			}

			var classList = database.Classes
				.Where( c => !c.IsDeleted )
				.AsQueryable();

			if( filter.classId.HasValue )
			{
				classList = classList
					.Where( c => c.ClassID == filter.classId.Value );
			}

			var classIdList = classList
				.Select( c => c.ClassID )
				.Distinct()
				.ToList();

			var employeeList = database.Users
				.Where( e => e.CustomerLocations.Any( l => l.CustomerID == filter.customerId ) )
				.AsQueryable();

			switch( (filter.employeeStatus ?? "active").ToLower() )
			{
				case "active":
					employeeList = employeeList.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					employeeList = employeeList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}

			var employeeIdList = employeeList
				.Select( e => e.UserID )
				.Distinct()
				.ToList();

			var startDate = filter.startDate.Value.ToUniversalTime();
			var endDate = filter.endDate.Value.ToUniversalTime().AddDays( 1 ).AddMilliseconds( -1 );

			return database.UserClasses
				.Include( uc => uc.User )
				.Where( uc => uc.AssignDate >= startDate && uc.AssignDate <= endDate )
				.Where( uc => employeeIdList.Contains( uc.UserID ) && classIdList.Contains( uc.ClassID ) )
				.OrderBy( uc => uc.User.LastName )
				.ThenBy( uc => uc.User.FirstName )
				.ThenByDescending( uc => uc.AssignDate )
				.ToList()
				.Select( uc => new SnapshotInformation()
				{
					EmployeeName = uc.User.FullName,
					EmailOrUserID = uc.User.UserName,
					ClassName = uc.Name,
					AssignedDate = uc.AssignDate?.ToShortDateString() ?? "",
					DueDate = uc.DueDate.ToShortDateString(),
					Status = uc.Status == GDWClassStatus.Status.TestPassed ? "Passed" : (uc.Status == GDWClassStatus.Status.New ? "Not Started" : "In Progress"),
					CompletedDate = uc.Status == GDWClassStatus.Status.TestPassed
						? (uc.UserTests.OrderByDescending( t => t.TestID ).FirstOrDefault()?.CompleteDate?.ToShortDateString() ?? "")
						: "",
					DaysOverDue = uc.DueDate < DateTime.Now && uc.Status != GDWClassStatus.Status.TestPassed ? (DateTime.Now - uc.DueDate).Days.ToString() : "",
					FinalScore = uc.Score.HasValue ? Math.Round( uc.Score.Value ).ToString() : "",
					Location = string.Join( ", ", uc.User.CustomerLocations.Select( l => l.Name ) ),
					Department = string.Join( ", ", uc.User.CustomerDepartments.Select( l => l.Name ) ),
					ActiveState = uc.User.IsDeleted ? "Inactive" : "Active",
					FirstName = uc.User.FirstName,
					LastName = uc.User.LastName,
					PhoneNumber = uc.User.PhoneNumber ?? "",
					HireDate = uc.User.HireDate?.ToShortDateString() ?? "",
					Gender = uc.User.Gender.ToString(),
					Role = string.Join( ", ", uc.User.PermissionGroups.Select( g => g.Name ) ),
					Language = uc.PrefLanguageID.HasValue ? uc.Language.Name : "",
					Category = uc.Class.IsBaseClass ? "OSHA" : "Non-OSHA",
					AverageScore = uc.UserTests.Any() ? Math.Round( uc.UserTests.Average( ut => ut.Score ).GetValueOrDefault( 0 ) ).ToString() : "",

					Scores = uc.UserTests.OrderBy( ut => ut.TestID ).Select( ut => ut.Score ).ToList(),
					Imports = uc.UserTests.OrderBy( ut => ut.TestID ).Select( ut => ut.IsImport ).ToList(),
				} )
				.ToList();
		}

		public List<CustomerCreditInformation> GetCustomerCreditReport( ReportFilter filter )
		{
			if( filter.isBlank )
			{
				return new List<CustomerCreditInformation>();
			}

			var dbCustomers = database.Customers
				.Include( c => c.CustomerPurchases )
				.Include( c => c.CustomerLocations.Select( cl => cl.Users.Select( u => u.UserClasses.Select( uc => uc.Class ) ) ) )
				.Where( c => !c.IsDeleted && c.ExpirationDate >= DateTime.Now && c.TracksCredits )
				.Where( c => c.CustomerID == filter.customerId || !filter.customerId.HasValue );

			var retList = dbCustomers
				.ToList()
				.Select( c => new CustomerCreditInformation()
				{
					customerName = c.Name,
					purchaseDate = c.CustomerPurchases.Min( cp => cp.PurchaseDate ).ToShortDateString(),
					expirationDate = c.ExpirationDate.ToShortDateString(),
					creditsPurchased = c.CustomerPurchases
						.Where( cp => (cp.PurchaseDate >= filter.startDate || !filter.startDate.HasValue) && (cp.PurchaseDate <= filter.endDate || !filter.endDate.HasValue) )
						.Sum( cp => cp.CreditCount ),
					creditsUsed = c.CustomerLocations
						.SelectMany( cl => cl.Users.Where( u => !u.IsDeleted ) )
						.Distinct()
						.SelectMany( u => u.UserClasses )
						.Where( uc => uc.Status != GDWClassStatus.Status.New )
						.Where( uc => (uc.AssignDate >= filter.startDate || !filter.startDate.HasValue) && (uc.AssignDate <= filter.endDate || !filter.endDate.HasValue) )
						.Sum( uc => uc.Class.Credits ),
					creditsUnassigned = c.CreditCount,
					creditsAssignedNew = c.CustomerLocations
						.SelectMany( cl => cl.Users.Where( u => !u.IsDeleted ) )
						.Distinct()
						.SelectMany( u => u.UserClasses )
						.Where( uc => uc.Status == GDWClassStatus.Status.New )
						.Where( uc => (uc.AssignDate >= filter.startDate || !filter.startDate.HasValue) && (uc.AssignDate <= filter.endDate || !filter.endDate.HasValue) )
						.Sum( uc => uc.Class.Credits ),
					userAccounts = c.EmployeeCount,
					totalCreditValue = c.CustomerPurchases
						.Where( cp => (cp.PurchaseDate >= filter.startDate || !filter.startDate.HasValue) && (cp.PurchaseDate <= filter.endDate || !filter.endDate.HasValue) )
						.Sum( cp => cp.CreditCount * cp.PerCreditCost )
				} );

			switch( filter.sortBy.ToLower() )
			{
				case "alphabetical":
				default:
					retList = retList.OrderBy( i => i.customerName );
					break;
				case "creditspurchased":
					retList = retList.OrderByDescending( i => i.creditsPurchased );
					break;
			}

			return retList.ToList();
		}

		public List<COClassReportInformation> GetCOClassReport( ReportFilter filter )
		{
			if( filter.isBlank )
			{
				return new List<COClassReportInformation>();
			}

			var dbCustomer = database.Customers.First( c => c.CustomerID == filter.customerId.Value );

			var retList = database.Classes
				.Where( c => !c.IsDeleted && (c.CustomerID == filter.customerId.Value || !c.CustomerID.HasValue) )
				.Where( c => (c.IsBaseClass && filter.oshaOnly == "osha") || (!c.IsBaseClass && filter.oshaOnly == "nonOsha") || (filter.oshaOnly == "both") )
				.Where( c => c.ClassID == filter.classId || !filter.classId.HasValue )
				.Select( c => new COClassReportInformation()
				{
					classId = c.ClassID,
					className = c.Name,
					numScreenings = c.ClassScreenings.Count( cs => cs.User.CustomerLocations.Any( cl => cl.CustomerID == filter.customerId.Value ) )
				} )
				.ToList();

			var dbUserClasses = database.UserClasses
				.Include( uc => uc.UserTests )
				.Include( uc => uc.User.CustomerLocations )
				.Include( uc => uc.Class )
				.Where( uc => (uc.AssignDate >= filter.startDate || !filter.startDate.HasValue) && (uc.AssignDate <= filter.endDate || !filter.endDate.HasValue) )
				.Where( uc => uc.PrefLanguageID == filter.languageId || !filter.languageId.HasValue )
				.Where( uc => uc.User.CustomerLocations.Any( cl => cl.CustomerID == filter.customerId.Value ) );

			var sourceList = dbUserClasses
				.ToList()
				.Select( uc =>
					new
					{
						classId = uc.ClassID,
						className = uc.Class.Name,
						isStarted = uc.Status != GDWClassStatus.Status.New,
						isPassed = uc.Status == GDWClassStatus.Status.TestPassed,
						testCount = uc.UserTests.Count( ut => ut.CompleteDate.HasValue ),
						attempt1Score = uc.UserTests.Any( ut => ut.CompleteDate.HasValue ) ? uc.UserTests.OrderBy( ut => ut.TestID ).FirstOrDefault().Score : -1,
						attempt2Score = uc.UserTests.Count( ut => ut.CompleteDate.HasValue ) > 1 ? uc.UserTests.OrderBy( ut => ut.TestID ).Skip( 1 ).FirstOrDefault().Score : -1,
						attempt3Score = uc.UserTests.Count( ut => ut.CompleteDate.HasValue ) > 2 ? uc.UserTests.OrderBy( ut => ut.TestID ).Skip( 2 ).FirstOrDefault().Score : -1,
						moreThan3Attempts = uc.UserTests.Count() > 3 || (uc.UserTests.Count( ut => ut.CompleteDate.HasValue ) == 3 && uc.Status != GDWClassStatus.Status.TestPassed),
						completeByDueDate = uc.Status == GDWClassStatus.Status.TestPassed && !uc.UserTests.Any( ut => ut.CompleteDate > uc.DueDate ),
						overdue = ((uc.Status != GDWClassStatus.Status.TestPassed) && (DateTime.UtcNow > uc.DueDate)) || uc.UserTests.Any( ut => ut.CompleteDate > uc.DueDate )
					} )
				.ToList();

			retList.ForEach( c =>
			{
				c.numAssignments = sourceList.Count( s => s.classId == c.classId );
				c.numViews = sourceList.Count( s => s.isStarted && s.classId == c.classId );
				c.avgScoreAttempt1 = sourceList.Where( s => s.classId == c.classId && s.testCount >= 1 ).Select( s => s.attempt1Score ).DefaultIfEmpty( 0 ).Average() ?? 0;
				c.avgScoreAttempt2 = sourceList.Where( s => s.classId == c.classId && s.testCount >= 2 ).Select( s => s.attempt2Score ).DefaultIfEmpty( 0 ).Average() ?? 0;
				c.avgScoreAttempt3 = sourceList.Where( s => s.classId == c.classId && s.testCount >= 3 ).Select( s => s.attempt3Score ).DefaultIfEmpty( 0 ).Average() ?? 0;
				c.numPassedAttempt1 = sourceList.Count( s => s.classId == c.classId && s.testCount == 1 && s.isPassed );
				c.numPassedAttempt2 = sourceList.Count( s => s.classId == c.classId && s.testCount == 2 && s.isPassed );
				c.numPassedAttempt3 = sourceList.Count( s => s.classId == c.classId && s.testCount == 3 && s.isPassed );
				c.numMoreThanAttempt3 = sourceList.Count( s => s.classId == c.classId && s.moreThan3Attempts );
				c.numClassesCompletedByDueDate = sourceList.Count( s => s.classId == c.classId && s.completeByDueDate );
				c.numClassesOverdue = sourceList.Count( s => s.classId == c.classId && s.overdue );
				c.numUserAccounts = dbCustomer.EmployeeCount;
				c.numCompleteQuiz = sourceList.Count( s => s.classId == c.classId && s.testCount > 0 );
			} );

			switch( filter.sortBy.ToLower() )
			{
				case "alphabetical":
				default:
					retList = retList.OrderBy( c => c.className ).ToList();
					break;
				case "assignments":
					retList = retList.OrderByDescending( c => c.numAssignments ).ToList();
					break;
				case "videoviews":
					retList = retList.OrderByDescending( c => c.numViews ).ToList();
					break;
			}

			return retList
				.Where( c => c.numAssignments > 0 || c.classId == filter.classId )
				.ToList();
		}

		public List<COCreditSummaryInformation> GetCOCreditSummary( ReportFilter filter )
		{
			if( filter.isBlank )
			{
				return new List<COCreditSummaryInformation>();
			}

			var dbCustomer = database.Customers.First( c => c.CustomerID == filter.customerId.Value );

			if( !filter.endDate.HasValue )
			{
				filter.endDate = DateTime.Now;
			}
			if( !filter.endDate.HasValue )
			{
				filter.startDate = filter.endDate.Value.AddYears( -1 );
			}

			var retList = new List<COCreditSummaryInformation>();

			var firstOfMonth = new DateTime( filter.startDate.Value.Year, filter.startDate.Value.Month, 1 );
			while( firstOfMonth < filter.endDate.Value )
			{
				var newItem = new COCreditSummaryInformation()
				{
					monthYear = firstOfMonth.ToString( "MMMM yyyy" ),
					userAccounts = dbCustomer.EmployeeCount
				};

				var firstOfNextMonth = firstOfMonth.AddMonths( 1 );

				newItem.creditsPurchased = dbCustomer.CustomerPurchases
					.Where( cp => cp.PurchaseDate >= firstOfMonth && cp.PurchaseDate < firstOfNextMonth )
					.Select( cp => cp.CreditCount )
					.Sum();
				newItem.creditsAssigned = dbCustomer.CustomerLocations.SelectMany( cl => cl.Users.Where( u => (!u.IsDeleted == (filter.employeeStatus == "active")) || (filter.employeeStatus == "all") ) ).Distinct()
					.SelectMany( u => u.UserClasses
						.Where( uc => uc.AssignDate >= firstOfMonth && uc.AssignDate < firstOfNextMonth )
						.Select( uc => uc.Class.Credits ) )					
					.Sum();
				newItem.creditsUsed = dbCustomer.CustomerLocations.SelectMany( cl => cl.Users.Where( u => (!u.IsDeleted == (filter.employeeStatus == "active")) || (filter.employeeStatus == "all") ) ).Distinct()
					.SelectMany( u => u.UserClasses
						.Where( uc => uc.AssignDate >= firstOfMonth && uc.AssignDate < firstOfNextMonth )
						.Where( uc => uc.Status != GDWClassStatus.Status.New )
						.Select( uc => uc.Class.Credits ) )
					.Sum();

				retList.Add( newItem );

				firstOfMonth = firstOfNextMonth;
			}

			return retList;
		}

		public List<SystemWideClassInformation> GetSystemWideClassReport( ReportFilter filter )
		{
			if( filter.isBlank )
			{
				return new List<SystemWideClassInformation>();
			}

			var dbClasses = database.Classes
				.Include( c => c.UserClasses.Select( uc => uc.UserTests ) )
				.Where( c => !c.IsDeleted )
				.Where( c => (c.IsBaseClass && filter.oshaOnly == "osha") || (!c.IsBaseClass && filter.oshaOnly == "nonOsha") || (filter.oshaOnly == "both") )
				.Where( c => c.ClassID == filter.classId || !filter.classId.HasValue );

			var retList = dbClasses
				.ToList()
				.Select( c => new SystemWideClassInformation()
				{
					className = c.Name,
					numAssignments = c.UserClasses.Count(),
					avgScoreFirstAttempt = c.UserClasses.Where( uc => uc.Status == GDWClassStatus.Status.TestPassed || uc.Status == GDWClassStatus.Status.TestComplete )
						.Select( uc => uc.UserTests.OrderBy( ut => ut.TestID ).First().Score ).DefaultIfEmpty( 0 ).Average() ?? 0,
					avgAttemptsToPass = c.UserClasses.Where( uc => uc.Status == GDWClassStatus.Status.TestPassed )
						.Select( uc => uc.UserTests.Count() ).DefaultIfEmpty( 0 ).Average(),
					numAttemptsMoreThree = c.UserClasses.Count( uc => uc.UserTests.Count() >= 3 )
				} );

			switch( filter.sortBy.ToLower() )
			{
				case "alphabetical":
				default:
					retList = retList.OrderBy( c => c.className );
					break;
				case "assignments":
					retList = retList.OrderByDescending( c => c.numAssignments );
					break;
			}

			return retList.ToList();
		}

		public List<CustomerClassInformation> GetCustomerClassReport( ReportFilter filter )
		{
			if( filter.isBlank )
			{
				return new List<CustomerClassInformation>();
			}

			var dbCustomers = database.Customers
				.Where( c => !c.IsDeleted && c.ExpirationDate >= DateTime.Now )
				.Where( c => c.CustomerID == filter.customerId || !filter.customerId.HasValue )
				.ToList();

			var retList = new List<CustomerClassInformation>();
			foreach( var dbCustomer in dbCustomers )
			{
				var rptInfo = new CustomerClassInformation()
				{
					customerName = dbCustomer.Name,
					purchaseDate = dbCustomer.CustomerPurchases.Min( cp => cp.PurchaseDate ).ToShortDateString(),
					expirationDate = dbCustomer.ExpirationDate.ToShortDateString(),
				};


				rptInfo.classesAssigned = database.UserClasses
					.Where( uc => (!uc.User.IsDeleted == (filter.employeeStatus == "active")) || (filter.employeeStatus == "all") )
					.Where( uc => uc.User.CustomerLocations.Any( cl => cl.CustomerID == dbCustomer.CustomerID ) )
					.Where( uc => (uc.AssignDate >= filter.startDate || !filter.startDate.HasValue) && (uc.AssignDate <= filter.endDate || !filter.endDate.HasValue) )
					.Count();
				rptInfo.classesNoQuizAttempts = database.UserClasses
					.Where( uc => (!uc.User.IsDeleted == (filter.employeeStatus == "active")) || (filter.employeeStatus == "all") )
					.Where( uc => uc.User.CustomerLocations.Any( cl => cl.CustomerID == dbCustomer.CustomerID ) )
					.Where( uc => uc.Status != GDWClassStatus.Status.New )
					.Where( uc => (uc.AssignDate >= filter.startDate || !filter.startDate.HasValue) && (uc.AssignDate <= filter.endDate || !filter.endDate.HasValue) )
					.Where( uc => !uc.UserTests.Any() )
					.Count();
				rptInfo.classesViewed = database.UserClasses
					.Where( uc => (!uc.User.IsDeleted == (filter.employeeStatus == "active")) || (filter.employeeStatus == "all") )
					.Where( uc => uc.User.CustomerLocations.Any( cl => cl.CustomerID == dbCustomer.CustomerID ) )
					.Where( uc => uc.Status != GDWClassStatus.Status.New )
					.Where( uc => (uc.AssignDate >= filter.startDate || !filter.startDate.HasValue) && (uc.AssignDate <= filter.endDate || !filter.endDate.HasValue) )
					.Count();
				rptInfo.userAccounts = database.Users
					.Where( u => (!u.IsDeleted == (filter.employeeStatus == "active")) || (filter.employeeStatus == "all") )
					.Where( u => u.CustomerLocations.Any( cl => cl.CustomerID == dbCustomer.CustomerID ) )
					.Count();
				rptInfo.avgScoreFirstAttempt = database.UserClasses
					.Where( uc => (!uc.User.IsDeleted == (filter.employeeStatus == "active")) || (filter.employeeStatus == "all") )
					.Where( uc => uc.User.CustomerLocations.Any( cl => cl.CustomerID == dbCustomer.CustomerID ) )
					.Where( uc => uc.UserTests.Any( ut => ut.CompleteDate.HasValue ) )
						.Where( uc => (uc.AssignDate >= filter.startDate || !filter.startDate.HasValue) && (uc.AssignDate <= filter.endDate || !filter.endDate.HasValue) )
					.Select( uc => uc.UserTests.Where( ut => ut.CompleteDate.HasValue ).OrderBy( ut => ut.TestID ).FirstOrDefault().Score ).DefaultIfEmpty( 0 ).Average() ?? 0;

				retList.Add( rptInfo );
			}

			switch( filter.sortBy.ToLower() )
			{
				case "alphabetical":
				default:
					retList = retList.OrderBy( c => c.customerName ).ToList();
					break;
				case "assignments":
					retList = retList.OrderByDescending( c => c.classesAssigned ).ToList();
					break;
			}

			return retList;
		}

		public List<CustomerSummaryRptInformation> GetCustomerSummaryReport( ReportFilter filter )
		{
			if( filter.isBlank )
			{
				return new List<CustomerSummaryRptInformation>();
			}

			var dbCustomers = database.Customers
				.Where( c => !c.IsDeleted && c.ExpirationDate >= DateTime.Now )
				.Where( c => c.CustomerID == filter.customerId || !filter.customerId.HasValue )
				.ToList();

			var retList = new List<CustomerSummaryRptInformation>();
			foreach( var dbCustomer in dbCustomers )
			{
				var rptInfo = new CustomerSummaryRptInformation()
				{
					customerName = dbCustomer.Name,
					numCredits = dbCustomer.TracksCredits ? dbCustomer.CreditCount : (int?)null,
				};

				rptInfo.numQuizzesPassed = database.UserClasses
					.Where( uc => (!uc.User.IsDeleted == (filter.employeeStatus == "active")) || (filter.employeeStatus == "all") )
					.Where( uc => uc.User.CustomerLocations.Any( cl => cl.CustomerID == dbCustomer.CustomerID ))
					.Where( uc => uc.Status == GDWClassStatus.Status.TestPassed )
					.Where( uc => (uc.AssignDate >= filter.startDate || !filter.startDate.HasValue) && (uc.AssignDate <= filter.endDate || !filter.endDate.HasValue) )
					.Count();
				rptInfo.numVideoViews = database.UserClasses
					.Where( uc => (!uc.User.IsDeleted == (filter.employeeStatus == "active")) || (filter.employeeStatus == "all") )
					.Where( uc => uc.User.CustomerLocations.Any( cl => cl.CustomerID == dbCustomer.CustomerID ))
					.Where( uc => uc.Status != GDWClassStatus.Status.New )
					.Where( uc => (uc.AssignDate >= filter.startDate || !filter.startDate.HasValue) && (uc.AssignDate <= filter.endDate || !filter.endDate.HasValue) )
					.Count();
				rptInfo.avgScoreLastAttempt = database.UserClasses
					.Where( uc => (!uc.User.IsDeleted == (filter.employeeStatus == "active")) || (filter.employeeStatus == "all") )
					.Where( uc => uc.User.CustomerLocations.Any( cl => cl.CustomerID == dbCustomer.CustomerID ) )
					.Where( uc => uc.UserTests.Any( ut => ut.CompleteDate.HasValue ) )
						.Where( uc => (uc.AssignDate >= filter.startDate || !filter.startDate.HasValue) && (uc.AssignDate <= filter.endDate || !filter.endDate.HasValue) )
					.Select( uc => uc.UserTests.Where( ut => ut.CompleteDate.HasValue ).OrderByDescending( ut => ut.TestID ).FirstOrDefault().Score ).DefaultIfEmpty( 0 ).Average() ?? 0;

				retList.Add( rptInfo );
			}

			switch( filter.sortBy.ToLower() )
			{
				case "alphabetical":
				default:
					retList = retList.OrderBy( c => c.customerName ).ToList();
					break;
				case "credits":
					retList = retList.OrderByDescending( c => c.numCredits ).ToList();
					break;
				case "videoviews":
					retList = retList.OrderByDescending( c => c.numVideoViews ).ToList();
					break;
				case "quizzespassed":
					retList = retList.OrderByDescending( c => c.numQuizzesPassed ).ToList();
					break;
			}

			return retList;
		}

		public List<PurchaseReportInformation> GetPurchaseReport( ReportFilter filter )
		{
			if( filter.isBlank )
			{
				return new List<PurchaseReportInformation>();
			}

			var purchaseList = database.CustomerPurchases
				.Include( cp => cp.Customer )
				.AsQueryable();

			if( filter.customerId.HasValue )
			{
				purchaseList = purchaseList.Where( cp => cp.CustomerID == filter.customerId.Value );
			}

			if( filter.startDate.HasValue )
			{
				purchaseList = purchaseList.Where( cp => cp.PurchaseDate >= filter.startDate.Value );
			}

			if( filter.endDate.HasValue )
			{
				var endDate = filter.endDate.Value.AddDays( 1 );
				purchaseList = purchaseList.Where( cp => cp.PurchaseDate < endDate );
			}

			return purchaseList.ToList()
				.Select( cp => new PurchaseReportInformation()
				{
					customerName = cp.Customer.Name,
					customerAddress = cp.Customer.Address1 + " " + cp.Customer.Address2 + " " + cp.Customer.City + ", " + cp.Customer.State + " " + cp.Customer.ZipCode,
					customerContact = cp.Customer.ContactFirstName + " " + cp.Customer.ContactLastName,
					phoneNumber = cp.Customer.PhoneNumber,
					totalAmount = ((cp.PerCreditCost * cp.CreditCount) + (cp.PerEmployeeCost * cp.EmployeeCount) + (cp.DiscountCodeAmount ?? 0) + cp.SalesTax),
					invoiceNumber = cp.PurchaseID,
					transactionNumber = cp.TransactionId,
					orderDate = cp.PurchaseDate,
					paymentDate = cp.Customer.PaidDate,
					paymentType = cp.PaymentMethod.ToDisplayString(),
					credits = cp.CreditCount,
					userAccounts = cp.EmployeeCount,
					couponCode = cp.DiscountCodeText
				} )
				.OrderBy( cp => cp.orderDate )
				.ToList();
		}
	}
}
