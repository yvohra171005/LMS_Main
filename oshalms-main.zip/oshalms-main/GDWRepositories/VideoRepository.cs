﻿using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWInfrastructure.EmailSenders;
using GDWModels.Video;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWRepositories
{
	public class VideoRepository : BaseRepository
	{
		public IEnumerable<VideoSummary> GetFullVideoList( VideoTableParams param, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var videoList = database.Videos
				.AsQueryable();

			totalRecords = videoList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				videoList = videoList.Where( i =>
					i.Name.Contains( param.sSearch ) );
			}
			switch( (param.activeState ?? "active").ToLower() )
			{
				case "active":
					videoList = videoList.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					videoList = videoList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}

			displayedRecords = videoList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<Video> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "name":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = videoList.OrderBy( v => v.Name );
					}
					else
					{
						filteredAndSorted = videoList.OrderByDescending( v => v.Name );
					}
					break;
				case "createdate":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = videoList.OrderBy( v => v.DateCreated );
					}
					else
					{
						filteredAndSorted = videoList.OrderByDescending( v => v.DateCreated );
					}
					break;
				case "status":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = videoList.OrderBy( v => !string.IsNullOrEmpty( v.JobID ) ).ThenBy( v => !string.IsNullOrEmpty( v.StreamName ) );
					}
					else
					{
						filteredAndSorted = videoList.OrderByDescending( v => !string.IsNullOrEmpty( v.JobID ) ).ThenByDescending( v => !string.IsNullOrEmpty( v.StreamName ) );
					}
					break;
				case "classes":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = videoList.OrderBy( v => v.ClassVersions.Count( c => !c.IsDeleted ) );
					}
					else
					{
						filteredAndSorted = videoList.OrderByDescending( v => v.ClassVersions.Count( c => !c.IsDeleted ) );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( dc => new VideoSummary()
			{
				videoId = dc.VideoID,
				name = dc.Name,
				status = !string.IsNullOrEmpty( dc.StreamName ) ? "Ready" : (!string.IsNullOrEmpty( dc.JobID ) ? "Encoding" : "Pending"),
				classes = dc.ClassVersions.Count( c => !c.IsDeleted ),
				isActive = !dc.IsDeleted,
				createDate = dc.DateCreated
			} ).ToList();
		}


		public void AddVideo( VideoInformation vInfo )
		{
			var newVideo = new Video();

			newVideo.Name = vInfo.name;
			newVideo.OriginalFileName = vInfo.originalVideoName;
			newVideo.BlobFileName = vInfo.newVideoName;
			newVideo.IsDeleted = !vInfo.isActive;
			newVideo.DateCreated = DateTime.UtcNow;

			database.Videos.Add( newVideo );

			database.SaveChanges();
		}

		public void EditVideo( VideoInformation vInfo )
		{
			var dbVideo = database.Videos.FirstOrDefault( dc => dc.VideoID == vInfo.videoId );

			if( dbVideo != null )
			{
				dbVideo.Name = vInfo.name;
				dbVideo.IsDeleted = !vInfo.isActive;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorUserNotFound" );
		}

		public VideoInformation GetVideo( int id )
		{
			var dbVideo = database.Videos.FirstOrDefault( dc => dc.VideoID == id );

			if( dbVideo != null )
			{
				var dcInfo = new VideoInformation();

				dcInfo.videoId = dbVideo.VideoID;
				dcInfo.name = dbVideo.Name;
				dcInfo.originalVideoName = dbVideo.OriginalFileName;
				dcInfo.newVideoName = dbVideo.BlobFileName;
				dcInfo.isActive = !dbVideo.IsDeleted;

				return dcInfo;
			}

			throw new GDWException( "ErrorUserNotFound" );
		}

		public void DeleteVideo( int id )
		{
			var dbCode = database.Videos.FirstOrDefault( u => u.VideoID == id );

			if( dbCode != null )
			{
				dbCode.IsDeleted = true;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorUserNotFound" );
		}

		public List<PendingVideoSummary> GetPendingVideos()
		{
			return database.Videos
				.Where( v => !v.IsDeleted )
				.Where( v => v.StreamName == null )
				.ToList()
				.Select( v => new PendingVideoSummary()
				{
					videoId = v.VideoID,
					blobName = v.BlobFileName,
					jobId = v.JobID,
					streamName = v.StreamName
				} )
				.ToList();
		}

		public void UpdateVideoJobID( int videoId, string jobId )
		{
			var dbVideo = database.Videos.FirstOrDefault( v => v.VideoID == videoId );
			if( dbVideo != null )
			{
				if( string.IsNullOrEmpty( dbVideo.JobID ) )
				{
					dbVideo.JobID = jobId;

					database.SaveChanges();
				}
			}
		}

		public void UpdateVideoStreamURL( int videoId, string streamURL )
		{
			var dbVideo = database.Videos.FirstOrDefault( v => v.VideoID == videoId );
			if( dbVideo != null )
			{
				if( string.IsNullOrEmpty( dbVideo.StreamName ) )
				{
					dbVideo.StreamName = streamURL;

					database.SaveChanges();

					foreach( var dbUser in database.Users.Where( u => !u.IsDeleted && 
						u.PermissionGroups.Any( pg => !pg.IsDeleted && 
							pg.PermissionGroupItems.Any( pgi => pgi.PermissionID == GDWPermissionTypes.Permissions.AddVideo ) ) ) )
					{
						(new VideoEncodingCompleteEmailSender( dbUser.Language.StringClass )).SubmitVideoEncodingCompleteEmail( dbUser.EmailAddress, dbVideo.Name );
					}
				}
			}
		}
	}
}
