﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

using CsvHelper;
using CsvHelper.Configuration;

using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWInfrastructure.EmailSenders;
using GDWModels.Customer;
using GDWModels.Class;

using OSHALMSStrings;

namespace GDWRepositories
{
	public class CustomerRepository : BaseRepository
	{
		#region Tiers
		public IEnumerable<TierSummary> GetTierList()
		{
			return database.CreditTiers
				.ToList()
				.Select( v => new TierSummary()
					{
						tierId = v.TierID,
						minimumCredits = v.MinimumCreditPurchase,
						costPerCredit = v.CostPerCredit
					} )
				.OrderBy( t => t.minimumCredits );
		}

		public IEnumerable<TierSummary> GetFullTierList( TierTableParams param, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var tierList = database.CreditTiers
				.AsQueryable();

			totalRecords = tierList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
			}

			displayedRecords = tierList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<CreditTier> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "minimumcredits":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = tierList.OrderBy( v => v.MinimumCreditPurchase );
					}
					else
					{
						filteredAndSorted = tierList.OrderByDescending( v => v.MinimumCreditPurchase );
					}
					break;
				case "costpercredit":
				case "costpercreditdisplay":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = tierList.OrderBy( v => v.CostPerCredit );
					}
					else
					{
						filteredAndSorted = tierList.OrderByDescending( v => v.CostPerCredit );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new TierSummary()
			{
				tierId = v.TierID,
				minimumCredits = v.MinimumCreditPurchase,
				costPerCredit = v.CostPerCredit
			} );
		}

		private TierInformation ToTierInformation( CreditTier dbTier )
		{
			var uInfo = new TierInformation();

			uInfo.tierId = dbTier.TierID;
			uInfo.minimumCredits = dbTier.MinimumCreditPurchase;
			uInfo.costPerCredit = dbTier.CostPerCredit;

			return uInfo;
		}

		public TierInformation GetCreditTier( int tierId )
		{
			var dbTier = database.CreditTiers
				.FirstOrDefault( u => u.TierID == tierId );

			if( dbTier != null )
			{
				return ToTierInformation( dbTier );
			}

			throw new GDWException( "ErrorTierNotFound" );

		}

		public void AddTier( TierInformation uInfo )
		{
			var newTier = new CreditTier();

			newTier.MinimumCreditPurchase = uInfo.minimumCredits;
			newTier.CostPerCredit = uInfo.costPerCredit;

			database.CreditTiers.Add( newTier );

			database.SaveChanges();
		}

		public void EditTier( TierInformation uInfo )
		{
			var dbTier = database.CreditTiers.FirstOrDefault( u => u.TierID == uInfo.tierId );

			if( dbTier != null )
			{
				dbTier.MinimumCreditPurchase = uInfo.minimumCredits;
				dbTier.CostPerCredit = uInfo.costPerCredit;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorTierNotFound" );
		}

		public void DeleteTier( int tierId )
		{
			var dbTier = database.CreditTiers.FirstOrDefault( u => u.TierID == tierId );

			if( dbTier != null )
			{
				database.CreditTiers.Remove( dbTier );

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorTierNotFound" );
		}

		#endregion

		public int CreateNewAccount( NewAccountInformation aInfo, string transactionId, out string invoiceNumber )
		{
		    if ( !string.IsNullOrEmpty( aInfo.accountInfo.emailAddress ) )
		    {
		        if ( database.Users.Any( u => u.EmailAddress == aInfo.accountInfo.emailAddress && !u.IsDeleted ) )
		        {
		            throw new GDWException( "ErrorEmailAlreadyInUse" );
		        }
		    }
            else
            {
		        throw new GDWException( "ErrorEmailIsRequired" );
            }

            var dbConfig = database.ConfigurationOptions.First();

			var newCustomer = new Customer();

			newCustomer.Name = aInfo.accountInfo.companyName;
			newCustomer.Address1 = aInfo.accountInfo.companyAddress1;
			newCustomer.Address2 = aInfo.accountInfo.companyAddress2;
			newCustomer.City = aInfo.accountInfo.companyCity;
			newCustomer.State = aInfo.accountInfo.companyState;
			newCustomer.ZipCode = aInfo.accountInfo.companyZipCode;
			newCustomer.PhoneNumber = aInfo.accountInfo.companyPhone;
			newCustomer.IsDeleted = false;
			newCustomer.ExpirationDate = DateTime.Now.AddYears( 1 ).Date;
			newCustomer.PaymentMethod = (GDWPaymentMethods.PaymentMethod)Enum.Parse( typeof( GDWPaymentMethods.PaymentMethod ), aInfo.payment.method );
			switch( newCustomer.PaymentMethod )
			{
				case GDWPaymentMethods.PaymentMethod.BillMeLater:
					newCustomer.IsPaid = false;
					break;
				case GDWPaymentMethods.PaymentMethod.CreditCard:
					newCustomer.IsPaid = true;
					break;
				case GDWPaymentMethods.PaymentMethod.eCheck:
					newCustomer.IsPaid = true;
					break;
			}

			newCustomer.CreditCount = aInfo.credits;
			newCustomer.EmployeeCount = aInfo.employees;
			newCustomer.ContactFirstName = aInfo.accountInfo.firstName;
			newCustomer.ContactLastName = aInfo.accountInfo.lastName;
			newCustomer.ContactEmailAddress = aInfo.accountInfo.emailAddress;
			newCustomer.ContactGender = (ContactGenderType)Enum.Parse( typeof( ContactGenderType ), aInfo.accountInfo.gender );
			newCustomer.ContactDateOfBirth = aInfo.accountInfo.dateOfBirth;

			newCustomer.CreditWarning = dbConfig.DefaultCreditWarning;
			newCustomer.EmployeeWarning = dbConfig.DefaultEmployeeWarning;

			var newLocation = new CustomerLocation();
			newLocation.Name = aInfo.accountInfo.locationName;
			newLocation.Customer = newCustomer;
			newLocation.Address1 = aInfo.accountInfo.companyAddress1;
			newLocation.Address2 = aInfo.accountInfo.companyAddress2;
			newLocation.City = aInfo.accountInfo.companyCity;
			newLocation.State = aInfo.accountInfo.companyState;
			newLocation.ZipCode = aInfo.accountInfo.companyZipCode;
			newLocation.IsDeleted = false;

			var newUser = new User();

			newUser.FirstName = aInfo.accountInfo.firstName;
			newUser.LastName = aInfo.accountInfo.lastName;
			newUser.EmailAddress = aInfo.accountInfo.emailAddress;
			newUser.IsDeleted = false;
			newUser.PhoneNumber = aInfo.accountInfo.companyPhone;
			newUser.Password = "";
			newUser.Gender = (GenderType)Enum.Parse( typeof( GenderType ), aInfo.accountInfo.gender );
			newUser.PermissionGroups.Add( dbConfig.PermissionGroup );
			newUser.ImageFileName = null;
			newUser.Language = database.Languages.Where( l => !l.IsDeleted ).OrderBy( l => l.LanguageID ).First();
			newUser.HireDate = null;

			var resetEmail = new ResetEmail();
			resetEmail.EmailID = Guid.NewGuid();
			resetEmail.ExpireDate = DateTime.UtcNow.AddDays( 3 );
			resetEmail.IsActive = true;

			newUser.ResetEmails.Add( resetEmail );
		    newUser.SetupEmailSent = true;

			newUser.CustomerLocations.Add( newLocation );

			database.Users.Add( newUser );

			var newPurchase = new CustomerPurchase()
			{
				PurchaseDate = DateTime.UtcNow,
				CreditCount = aInfo.credits,
				EmployeeCount = aInfo.employees,
				PerCreditCost = aInfo.costPerCredit,
				PerEmployeeCost = aInfo.costPerEmployee,

				CustomerName = newCustomer.Name,
				CustomerContact = newCustomer.ContactFirstName + " " + newCustomer.ContactLastName,
				CustomerEmail = newCustomer.ContactEmailAddress,
				CustomerPhone = newCustomer.PhoneNumber,

				PurchaseType = GDWPurchaseTypes.PurchaseType.Original,
				DiscountCodeID = aInfo.discountCodeId,
				DiscountCodeAmount = aInfo.discountCodeAmount,
				DiscountCodeText = aInfo.discountCode,
				TransactionId = transactionId,

				SalesTax = aInfo.salesTax
			};

			if( aInfo.payment.method == GDWPaymentMethods.PaymentMethod.CreditCard.ToString() )
			{
				newPurchase.PaymentMethod = GDWPaymentMethods.PaymentMethod.CreditCard;
				newPurchase.PaymentDetail = aInfo.payment.maskedCCNumber;
			}
			else if( aInfo.payment.method == GDWPaymentMethods.PaymentMethod.eCheck.ToString() )
			{
				newPurchase.PaymentMethod = GDWPaymentMethods.PaymentMethod.eCheck;
				newPurchase.PaymentDetail = aInfo.payment.maskedECheckNumber;
			}
			else if( aInfo.payment.method == GDWPaymentMethods.PaymentMethod.BillMeLater.ToString() )
			{
				newPurchase.PaymentMethod = GDWPaymentMethods.PaymentMethod.BillMeLater;
			}

			newCustomer.CustomerPurchases.Add( newPurchase );

			database.SaveChanges();

			(new NewAccountEmailSender( newUser.Language.StringClass )).SubmitNewAccountEmail( newUser.EmailAddress, newUser.EmailAddress, resetEmail.EmailID,
                newUser.FirstName, newUser.LastName );

			// (new NewAccountDocumentSender()).SubmitNewAccountDocumentEmail( newUser.EmailAddress );

			(new NewCustomerEmailSender()).SubmitNewCustomerEmail( newCustomer.Name );

			database.Entry<Customer>( newCustomer ).Reload();
			database.Entry<CustomerPurchase>( newPurchase ).Reload();

			invoiceNumber = newPurchase.PurchaseID.ToString();

			return newCustomer.CustomerID;
		}

		public IEnumerable<CustomerSummary> GetFullCustomerList( CustomerTableParams param, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var customerList = database.Customers
				.Include( c => c.CustomerLocations.Select( l => l.Users ) )
				.Include( c => c.AvailableClasses )
				.AsQueryable();

			totalRecords = customerList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				customerList = customerList.Where( i =>
					i.Name.Contains( param.sSearch ) );
			}
			switch( (param.activeState ?? "active").ToLower() )
			{
				case "active":
					customerList = customerList.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					customerList = customerList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}
			if( param.unPaidOnly )
			{
				customerList = customerList.Where( c => !c.IsPaid );
			}
			if( param.expirationDate.HasValue )
			{
				var eDate = new DateTime( 1970, 1, 1 ).AddMilliseconds( param.expirationDate.Value );
				customerList = customerList.Where( c => c.ExpirationDate <= eDate );
			}

			displayedRecords = customerList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<Customer> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "customername":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = customerList.OrderBy( v => v.Name );
					}
					else
					{
						filteredAndSorted = customerList.OrderByDescending( v => v.Name );
					}
					break;
				case "employeecount":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = customerList.OrderBy( v => v.CustomerLocations.SelectMany( l => l.Users.Where( u => !u.IsDeleted ) ).Distinct().Count() );
					}
					else
					{
						filteredAndSorted = customerList.OrderByDescending( v => v.CustomerLocations.SelectMany( l => l.Users.Where( u => !u.IsDeleted ) ).Distinct().Count() );
					}
					break;
				case "employeesremainingcount":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = customerList.OrderBy( v => v.EmployeeCount - v.CustomerLocations.SelectMany( l => l.Users.Where( u => !u.IsDeleted ) ).Distinct().Count() );
					}
					else
					{
						filteredAndSorted = customerList.OrderByDescending( v => v.EmployeeCount - v.CustomerLocations.SelectMany( l => l.Users.Where( u => !u.IsDeleted ) ).Distinct().Count() );
					}
					break;
				case "creditcount":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = customerList.OrderBy( v => v.TracksCredits ? v.CreditCount : -1 );
					}
					else
					{
						filteredAndSorted = customerList.OrderByDescending( v => v.TracksCredits ? v.CreditCount : -1 );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new CustomerSummary()
			{
				customerId = v.CustomerID,
				customerName = v.Name,
				creditCount = v.TracksCredits ? v.CreditCount : (int?)null,
				employeeCount = v.CustomerLocations.SelectMany( l => l.Users.Where( u => !u.IsDeleted ) ).Distinct().Count(),
                employeesRemainingCount = v.EmployeeCount - v.CustomerLocations.SelectMany( l => l.Users.Where( u => !u.IsDeleted ) ).Distinct().Count(),
				isActive = !v.IsDeleted,
				isPaid = v.IsPaid,
				enterpriseLevel = v.EnterpriseLevel.ToDisplayString(),
				availableClassCount = v.EnterpriseLevel == GDWEnterpriseLevels.EnterpriseLevel.Basic ? v.AvailableClasses.Count() : (int?)null
			} );
		}

		public void AddCustomer( CustomerInformation cInfo )
		{
			var newAccount = new NewAccountInformation();

			newAccount.accountInfo = new NewAccountSummary()
			{
				companyName = cInfo.name,
				companyAddress1 = cInfo.address1,
				companyAddress2 = cInfo.address2,
				companyCity = cInfo.city,
				companyState = cInfo.state,
				companyZipCode = cInfo.zipCode,
				companyPhone = cInfo.phoneNumber,
				locationName = cInfo.primaryLocation,
				firstName = cInfo.firstName,
				lastName = cInfo.lastName,
				emailAddress = cInfo.emailAddress,
				dateOfBirth = cInfo.dateOfBirth,
				gender = cInfo.gender,
				enterpriseLevel = cInfo.enterpriseLevel
			};

			newAccount.payment = new PaymentInformation() { billMeConfirm = true, method = GDWPaymentMethods.PaymentMethod.BillMeLater.ToString() };

			string invoiceNumber = "";

			CreateNewAccount( newAccount, null, out invoiceNumber );
		}

		public void EditCustomer( CustomerInformation cInfo )
		{
			var dbCustomer = database.Customers
			                         .Include(c => c.AvailableClasses)
			                         .FirstOrDefault(c => c.CustomerID == cInfo.customerId);

		    if ( dbCustomer != null )
		    {
		        if ( !string.Equals( cInfo.logoFileName, dbCustomer.LogoFileName, StringComparison.InvariantCultureIgnoreCase ) )
		        {
		            if ( !string.IsNullOrEmpty( dbCustomer.LogoFileName ) )
		            {
	                    var fileStorage = new AzureFileStorage();
	                    fileStorage.DeleteFile( "Files", dbCustomer.LogoFileName );
		            }
		        }
		        dbCustomer.Name = cInfo.name;
		        dbCustomer.Address1 = cInfo.address1;
		        dbCustomer.Address2 = cInfo.address2;
		        dbCustomer.City = cInfo.city;
		        dbCustomer.State = cInfo.state;
		        dbCustomer.ZipCode = cInfo.zipCode;
		        dbCustomer.PhoneNumber = cInfo.phoneNumber;
		        dbCustomer.LogoFileName = cInfo.logoFileName;
		        dbCustomer.OriginalLogoFileName = cInfo.originalLogoFileName;
		        dbCustomer.ContactFirstName = cInfo.firstName;
		        dbCustomer.ContactLastName = cInfo.lastName;
		        dbCustomer.ContactEmailAddress = cInfo.emailAddress;
		        dbCustomer.ContactDateOfBirth = cInfo.dateOfBirth;
		        dbCustomer.ContactGender = (ContactGenderType)Enum.Parse( typeof( ContactGenderType ), cInfo.gender );
		        dbCustomer.IsDeleted = !cInfo.isActive;
		        dbCustomer.CreditWarning = cInfo.creditsWarning;
		        dbCustomer.EmployeeWarning = cInfo.employeesWarning;
		        dbCustomer.ExpirationDate = cInfo.expirationDate;
		        dbCustomer.TracksCredits = cInfo.trackCredits;
		        dbCustomer.ClassEmailFrequency =
                    (GDWClassEmailFrequencies.ClassEmailFrequency)Enum.Parse( typeof( GDWClassEmailFrequencies.ClassEmailFrequency ), cInfo.classEmailFrequency );
				dbCustomer.EnterpriseLevel =
					(GDWEnterpriseLevels.EnterpriseLevel)Enum.Parse( typeof( GDWEnterpriseLevels.EnterpriseLevel ), cInfo.enterpriseLevel );

				if (cInfo.availableClasses != null && dbCustomer.EnterpriseLevel == GDWEnterpriseLevels.EnterpriseLevel.Basic)
				{
					var classesById = database.Classes
					                          .Where(c => !c.IsDeleted)
					                          .Where(c => (c.CustomerID == dbCustomer.CustomerID) || !c.CustomerID.HasValue)
					                          .ToDictionary(c => c.ClassID);
					dbCustomer.AvailableClasses.Clear();
					foreach (var av in cInfo.availableClasses)
					{
						Class aClass;
						if (classesById.TryGetValue(av.id, out aClass))
							dbCustomer.AvailableClasses.Add(aClass);
					}
				}

		        database.SaveChanges();

		        return;
		    }

		    throw new GDWException( "ErrorCustomerNotFound" );
		}

		public CustomerInformation GetCustomer( int id )
		{
			var dbCustomer = database.Customers
			                         .Include(c => c.AvailableClasses)
			                         .FirstOrDefault(c => c.CustomerID == id);

			if( dbCustomer != null )
			{
				return new CustomerInformation()
				{
					customerId = dbCustomer.CustomerID,
					name = dbCustomer.Name,
					address1 = dbCustomer.Address1,
					address2 = dbCustomer.Address2,
					city = dbCustomer.City,
					state = dbCustomer.State,
					zipCode = dbCustomer.ZipCode,
					phoneNumber = dbCustomer.PhoneNumber,
                    logoFileName = dbCustomer.LogoFileName,
                    originalLogoFileName = dbCustomer.OriginalLogoFileName,
					firstName = dbCustomer.ContactFirstName,
					lastName = dbCustomer.ContactLastName,
					emailAddress = dbCustomer.ContactEmailAddress,
					dateOfBirth = dbCustomer.ContactDateOfBirth,
					gender = dbCustomer.ContactGender.ToString(),
					isActive = !dbCustomer.IsDeleted,
					enterpriseLevel = dbCustomer.EnterpriseLevel.ToString(),
					maxEmployeeCount = dbCustomer.EmployeeCount,
					expirationDate = dbCustomer.ExpirationDate,
					creditCount = dbCustomer.CreditCount,
					trackCredits = dbCustomer.TracksCredits,
					primaryLocation = "testing",
					creditsWarning = dbCustomer.CreditWarning,
					employeesWarning = dbCustomer.EmployeeWarning,
                    classEmailFrequency = dbCustomer.ClassEmailFrequency.ToString(),
					availableClasses = dbCustomer.AvailableClasses.OrderBy( c => c.Name ).Select( c => new GDWListItem { id = c.ClassID, name = c.Name }).ToArray()
				};
			}

			throw new GDWException( "ErrorCustomerNotFound" );
		}
		
		public void DeleteCustomer( int customerId )
		{
			var dbCustomer = database.Customers.FirstOrDefault( u => u.CustomerID == customerId );

			if( dbCustomer != null )
			{
				dbCustomer.IsDeleted = true;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorCustomerNotFound" );
		}

		public void MarkCustomerPaid( int customerId )
		{
			var dbCustomer = database.Customers.FirstOrDefault( u => u.CustomerID == customerId );

			if( dbCustomer != null )
			{
				dbCustomer.IsPaid = true;
				dbCustomer.PaidDate = DateTime.UtcNow;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorCustomerNotFound" );
		}

		public void AddCustomerCredits( int customerId, int credits, int userId )
		{
			var dbCustomer = database.Customers.FirstOrDefault( u => u.CustomerID == customerId );

			if( dbCustomer != null )
			{
				dbCustomer.CreditCount += credits;

				dbCustomer.CustomerAccountChanges.Add( new CustomerAccountChange()
				{
					ChangeDateTime = DateTime.UtcNow,
					UserID = userId,
					Credits = credits
				} );

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorCustomerNotFound" );
		}

		public void AddCustomerEmployees( int customerId, int employees, int userId )
		{
			var dbCustomer = database.Customers.FirstOrDefault( u => u.CustomerID == customerId );

			if( dbCustomer != null )
			{
				if (employees < 0)
				{
					if (dbCustomer.EmployeeCount + employees < 0)
						throw new GDWException( "EmployeeCountCannotBeNegative" );

					int remainingCount = dbCustomer.EmployeeCount - dbCustomer.CustomerLocations.SelectMany(l => l.Users.Where(u => !u.IsDeleted)).Distinct().Count();
					if (remainingCount + employees < 0)
						throw new GDWException( "EmployeesInUseCountCannotBeNegative" );
				}
				dbCustomer.EmployeeCount += employees;

				dbCustomer.CustomerAccountChanges.Add( new CustomerAccountChange()
				{
					ChangeDateTime = DateTime.UtcNow,
					UserID = userId,
					UserAccounts = employees
				} );

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorCustomerNotFound" );
		}

		public void SetCustomerCCProfile( int customerId, string profileId, string ccProfileID, string maskedCCNumber, GDWPaymentMethods.PaymentMethod paymentMethod )
		{
			var dbCustomer = database.Customers.FirstOrDefault( u => u.CustomerID == customerId );

			if( dbCustomer != null )
			{
				dbCustomer.ProfileID = profileId;

				dbCustomer.CustomerCreditCards.Add( new CustomerCreditCard()
				{
					CCProfileID = ccProfileID,
					MaskedCCNumber = maskedCCNumber,
					IsDeleted = false,
					PaymentMethod = paymentMethod
				} );

				database.SaveChanges();
			}
		}

		public void DeleteCustomerPaymentProfile( int customerId, string profileId )
		{
			var dbCustomer = database.Customers.FirstOrDefault( u => u.CustomerID == customerId );

			if( dbCustomer != null )
			{
				var cc = dbCustomer.CustomerCreditCards.FirstOrDefault( c => c.CCProfileID == profileId );
				if( cc != null )
				{
					cc.IsDeleted = true;
				}

				database.SaveChanges();
			}
		}

		public IEnumerable<PaymentTypeInformation> GetPaymentTypeList( int customerId )
		{
			var dbCustomer = database.Customers.FirstOrDefault( u => u.CustomerID == customerId );

			if( dbCustomer != null )
			{
				return dbCustomer.CustomerCreditCards
					.Where( c => !c.IsDeleted )
					.ToList()
					.Select( c => new PaymentTypeInformation()
					{
						profileId = c.CCProfileID,
						paymentMethod = c.PaymentMethod.ToString(),
						maskedAccount = c.MaskedCCNumber
					} );
			}

			return new List<PaymentTypeInformation>();
		}

		public string GetCustomerProfileID( int customerId )
		{
			var dbCustomer = database.Customers.FirstOrDefault( u => u.CustomerID == customerId );

			if( dbCustomer != null )
			{
				return dbCustomer.ProfileID;
			}

			throw new GDWException( "ErrorCustomerNotFound" );
		}

		public IEnumerable<PurchaseSummary> GetFullPurchaseList( int? customerId, PurchaseTableParams param, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			if( !customerId.HasValue )
			{
				return new List<PurchaseSummary>();
			}

			var purchaseList = database.CustomerPurchases
				.Where( cp => cp.CustomerID == customerId.Value )
				.AsQueryable();

			totalRecords = purchaseList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
			}

			displayedRecords = purchaseList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<CustomerPurchase> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "purchaseDate":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = purchaseList.OrderBy( v => v.PurchaseDate );
					}
					else
					{
						filteredAndSorted = purchaseList.OrderByDescending( v => v.PurchaseDate );
					}
					break;
				case "amount":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = purchaseList.OrderBy( v => (v.PerCreditCost * v.CreditCount) + (v.PerEmployeeCost * v.EmployeeCount) + (v.DiscountCodeAmount ?? 0) + v.SalesTax );
					}
					else
					{
						filteredAndSorted = purchaseList.OrderByDescending( v => (v.PerCreditCost * v.CreditCount) + (v.PerEmployeeCost * v.EmployeeCount) + (v.DiscountCodeAmount ?? 0) + v.SalesTax );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new PurchaseSummary()
			{
				purchaseId = v.PurchaseID,
				amount = ((v.PerCreditCost * v.CreditCount) + (v.PerEmployeeCost * v.EmployeeCount) + (v.DiscountCodeAmount ?? 0) + v.SalesTax).ToCurrency(),
				purchaseDate = v.PurchaseDate,
				transactionDetails = string.Join( "<br/>", v.TransactionDetails )
			} );
		}

		public bool AddInvoice( NewInvoiceInformation iInfo, int customerId )
		{
			var dbCustomer = database.Customers
				.FirstOrDefault( c => c.CustomerID == customerId );

			if( dbCustomer != null )
			{
				var newPurchase = new CustomerPurchase()
				{
					PurchaseDate = DateTime.UtcNow,
					CreditCount = iInfo.credits,
					EmployeeCount = iInfo.employees,
					PerCreditCost = iInfo.creditCost,
					PerEmployeeCost = iInfo.employeeCost,

					CustomerName = dbCustomer.Name,
					CustomerContact = dbCustomer.ContactFirstName + " " + dbCustomer.ContactLastName,
					CustomerEmail = dbCustomer.ContactEmailAddress,
					CustomerPhone = dbCustomer.PhoneNumber,

					PurchaseType = GDWPurchaseTypes.PurchaseType.AddOns,

					DiscountCodeAmount = iInfo.discountAmt,
					DiscountCodeText = iInfo.discountCode,
					TransactionId = iInfo.transactionNumber,

					SalesTax = iInfo.salesTax
				};

				newPurchase.PaymentMethod = iInfo.paymentMethod;
				newPurchase.PaymentDetail = iInfo.paymentDetail;

				dbCustomer.CustomerPurchases.Add( newPurchase );

				database.SaveChanges();

				return true;
			}

			throw new GDWException( "ErrorCustomerNotFound" );
		}

		public PurchaseInformation GetPurchaseDetails( int customerId, int purchaseId )
		{
			var dbPurchase = database.CustomerPurchases
				.FirstOrDefault( cp => cp.CustomerID == customerId && cp.PurchaseID == purchaseId );

			if( dbPurchase != null )
			{
				return new PurchaseInformation()
				{
					purchaseID = dbPurchase.PurchaseID,
					purchaseDate = dbPurchase.PurchaseDate,

					creditCount = dbPurchase.CreditCount,
					employeeCount = dbPurchase.EmployeeCount,
					perCreditCost = dbPurchase.PerCreditCost,
					perEmployeeCost = dbPurchase.PerEmployeeCost,

					customerName = dbPurchase.CustomerName,
					customerContact = dbPurchase.CustomerContact,
					customerEmail = dbPurchase.CustomerEmail,
					customerPhone = dbPurchase.CustomerPhone,

					paymentMethod = dbPurchase.PaymentMethod.ToDisplayString(),
					paymentDetail = dbPurchase.PaymentDetail,

					discountCode = dbPurchase.DiscountCodeText,
					discountAmount = dbPurchase.DiscountCodeAmount ?? 0,

					salesTax = dbPurchase.SalesTax
				};
			}

			throw new GDWException( "ErrorCustomerNotFound" );
		}

		public IEnumerable<GDWListItem> GetLocationDropDownList( int customerId, int currentUserId )
		{
			var dbUser = database.Users.FirstOrDefault( u => u.UserID == currentUserId );
			var query = database.CustomerLocations.AsQueryable();
			if( dbUser != null )
			{
				if( dbUser.CustomerLocations.Any() )
				{
					if( !dbUser.PermissionGroups.SelectMany( g => g.PermissionGroupItems ).Any( i => i.PermissionID == GDWPermissionTypes.Permissions.ManageAllLocations ) )
					{
						query = dbUser.CustomerLocations.AsQueryable();
					}
				}
			}

			return query
				.Where( p => !p.IsDeleted )
				.Where( p => p.CustomerID == customerId )
				.Select( p => new GDWListItem() { id = p.LocationID, name = p.Name } )
				.ToList();
		}

		public IEnumerable<GDWListItem> GetDepartmentDropDownList( int customerId )
		{
			return database.CustomerDepartments
				.Where( p => !p.IsDeleted )
				.Where( p => p.CustomerID == customerId )
				.Select( p => new GDWListItem() { id = p.DepartmentID, name = p.Name } )
				.ToList();
		}

		public IEnumerable<LocationSummary> GetFullLocationList( LocationTableParams param, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var locationList = database.CustomerLocations
				.Include( c => c.Users )
				.Where( c => c.CustomerID == param.customerId )
				.AsQueryable();

			totalRecords = locationList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				locationList = locationList.Where( i =>
					i.Name.Contains( param.sSearch ) );
			}
			switch( (param.activeState ?? "active").ToLower() )
			{
				case "active":
					locationList = locationList.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					locationList = locationList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}

			displayedRecords = locationList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<CustomerLocation> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "name":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = locationList.OrderBy( v => v.Name );
					}
					else
					{
						filteredAndSorted = locationList.OrderByDescending( v => v.Name );
					}
					break;
				case "employeecount":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = locationList.OrderBy( v => v.Users.Where( u => !u.IsDeleted ).Count() );
					}
					else
					{
						filteredAndSorted = locationList.OrderByDescending( v => v.Users.Where( u => !u.IsDeleted ).Count() );
					}
					break;
				case "citystate":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = locationList.OrderBy( v => v.City );
					}
					else
					{
						filteredAndSorted = locationList.OrderByDescending( v => v.City );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new LocationSummary()
			{
				locationId = v.LocationID,
				name = v.Name,
				cityState = string.Join( ", ", v.City, v.State ),
				employeeCount = v.Users.Where( u => !u.IsDeleted ).Count(),
				isActive = !v.IsDeleted
			} );
		}

		public void AddLocation( LocationInformation pInfo )
		{
			var dbCustomer = database.Customers.FirstOrDefault( c => c.CustomerID == pInfo.customerId );

			if( dbCustomer != null )
			{
				var newLocation = new CustomerLocation();

				newLocation.Name = pInfo.name;
				newLocation.Address1 = pInfo.address1;
				newLocation.Address2 = pInfo.address2;
				newLocation.City = pInfo.city;
				newLocation.State = pInfo.state;
				newLocation.ZipCode = pInfo.zipCode;
				newLocation.IsDeleted = !pInfo.isActive;
				newLocation.SDName = pInfo.sdName;
				newLocation.SDPhone = pInfo.sdPhone;
				newLocation.SDCellPhone = pInfo.sdCell;
				newLocation.SDEmail = pInfo.sdEmail;

				dbCustomer.CustomerLocations.Add( newLocation );

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorCustomerNotFound" );
		}

		public void EditLocation( LocationInformation pInfo )
		{
			var dbLocation = database.CustomerLocations.FirstOrDefault( c => c.LocationID == pInfo.locationId );

			if( dbLocation != null )
			{
				dbLocation.Name = pInfo.name;
				dbLocation.Address1 = pInfo.address1;
				dbLocation.Address2 = pInfo.address2;
				dbLocation.City = pInfo.city;
				dbLocation.State = pInfo.state;
				dbLocation.ZipCode = pInfo.zipCode;
				dbLocation.IsDeleted = !pInfo.isActive;
				dbLocation.SDName = pInfo.sdName;
				dbLocation.SDPhone = pInfo.sdPhone;
				dbLocation.SDCellPhone = pInfo.sdCell;
				dbLocation.SDEmail = pInfo.sdEmail;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorLocationNotFound" );
		}

		public LocationInformation GetLocation( int id )
		{
			var dbLocation = database.CustomerLocations.FirstOrDefault( c => c.LocationID == id );

			if( dbLocation != null )
			{
				return new LocationInformation()
				{
					locationId = dbLocation.LocationID,
					customerId = dbLocation.CustomerID,
					name = dbLocation.Name,
					address1 = dbLocation.Address1,
					address2 = dbLocation.Address2,
					city = dbLocation.City,
					state = dbLocation.State,
					zipCode = dbLocation.ZipCode,
					isActive = !dbLocation.IsDeleted,
					sdName = dbLocation.SDName,
					sdPhone = dbLocation.SDPhone,
					sdCell = dbLocation.SDCellPhone,
					sdEmail = dbLocation.SDEmail
				};
			}

			throw new GDWException( "ErrorLocationNotFound" );
		}

		public void DeleteLocation( int id )
		{
			var dbLocation = database.CustomerLocations.FirstOrDefault( c => c.LocationID == id );

			if( dbLocation != null )
			{
				dbLocation.IsDeleted = true;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorLocationNotFound" );
		}

		public IEnumerable<DepartmentSummary> GetFullDepartmentList( DepartmentTableParams param, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var departmentList = database.CustomerDepartments
				.Include( c => c.Users )
				.Where( c => c.CustomerID == param.customerId )
				.AsQueryable();

			totalRecords = departmentList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				departmentList = departmentList.Where( i =>
					i.Name.Contains( param.sSearch ) );
			}
			switch( (param.activeState ?? "active").ToLower() )
			{
				case "active":
					departmentList = departmentList.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					departmentList = departmentList.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}

			displayedRecords = departmentList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<CustomerDepartment> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "name":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = departmentList.OrderBy( v => v.Name );
					}
					else
					{
						filteredAndSorted = departmentList.OrderByDescending( v => v.Name );
					}
					break;
				case "employeecount":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = departmentList.OrderBy( v => v.Users.Where( u => !u.IsDeleted ).Count() );
					}
					else
					{
						filteredAndSorted = departmentList.OrderByDescending( v => v.Users.Where( u => !u.IsDeleted ).Count() );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new DepartmentSummary()
			{
				departmentId = v.DepartmentID,
				name = v.Name,
				employeeCount = v.Users.Where( u => !u.IsDeleted ).Count(),
				isActive = !v.IsDeleted
			} );
		}

		public void AddDepartment( DepartmentInformation pInfo )
		{
			var dbCustomer = database.Customers.FirstOrDefault( c => c.CustomerID == pInfo.customerId );

			if( dbCustomer != null )
			{
				var newDepartment = new CustomerDepartment();

				newDepartment.Name = pInfo.name;
				newDepartment.IsDeleted = !pInfo.isActive;

				dbCustomer.CustomerDepartments.Add( newDepartment );

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorCustomerNotFound" );
		}

		public void EditDepartment( DepartmentInformation pInfo )
		{
			var dbDepartment = database.CustomerDepartments.FirstOrDefault( c => c.DepartmentID == pInfo.departmentId );

			if( dbDepartment != null )
			{
				dbDepartment.Name = pInfo.name;
				dbDepartment.IsDeleted = !pInfo.isActive;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorDepartmentNotFound" );
		}

		public DepartmentInformation GetDepartment( int id )
		{
			var dbDepartment = database.CustomerDepartments.FirstOrDefault( c => c.DepartmentID == id );

			if( dbDepartment != null )
			{
				return new DepartmentInformation()
				{
					departmentId = dbDepartment.DepartmentID,
					customerId = dbDepartment.CustomerID,
					name = dbDepartment.Name,
					isActive = !dbDepartment.IsDeleted
				};
			}

			throw new GDWException( "ErrorDepartmentNotFound" );
		}

		public void DeleteDepartment( int id )
		{
			var dbDepartment = database.CustomerDepartments.FirstOrDefault( c => c.DepartmentID == id );

			if( dbDepartment != null )
			{
				dbDepartment.IsDeleted = true;

				database.SaveChanges();

				return;
			}

			throw new GDWException( "ErrorDepartmentNotFound" );
		}

		public IEnumerable<AssignClassSummary> GetClassAssignmentList( ClassAssignmentTableParams param, out int totalRecords, out int displayedRecords, out int totalCredits, int? customerId )
		{
			totalRecords = 0;
			displayedRecords = 0;
			totalCredits = 0;

			var theList = new List<AssignClassSummary>();

			if( param.categories != null )
			{
				theList.AddRange( database.ClassCategories
					.Where( c => param.categories.Contains( c.Name ) )
					.Select( c => new AssignClassSummary()
					{
						id = c.Name,
						name = c.Name,
						creditsPerEmployee = c.Classes.Where( ca => !ca.IsDeleted && (ca.CustomerID == customerId || !ca.CustomerID.HasValue || !customerId.HasValue) ).Sum( ca => ca.Credits ),
						classCount = c.Classes.Where( ca => !ca.IsDeleted ).Count(),
						isCategory = true
					} ) );
			}
			else
			{
				param.categories = new List<string>();
			}

			if( param.classes != null )
			{
				theList.AddRange( database.Classes
					.Where( c => param.classes.Contains( c.ClassID ) )
					.Select( c => new AssignClassSummary()
					{
						id = c.ClassID.ToString(),
						name = c.Name,
						creditsPerEmployee = c.Credits,
						classCount = 1,
						isCategory = false
					} ) );
			}
			else
			{
				param.classes = new List<int>();
			}

			totalCredits = database.Classes
				.Where( c => !c.IsDeleted && (c.CustomerID == customerId || !c.CustomerID.HasValue || !customerId.HasValue) )
				.Where( c => param.classes.Contains( c.ClassID ) || param.categories.Intersect( c.ClassCategories.Select( ca => ca.Name ) ).Any() )
				.Distinct()
				.Sum( c => (int?)c.Credits ) ?? 0;

			totalRecords = theList.Count();
			displayedRecords = totalRecords;

			return theList.OrderBy( i => i.name );
		}

		public void UpdateCustomerStatus( NewPurchaseInformation pInfo, string transactionId, out string invoiceNumber )
		{
			var dbCustomer = database.Customers
				.FirstOrDefault( c => c.CustomerID == pInfo.customerId );

			invoiceNumber = "";

			if( dbCustomer != null )
			{
				if( pInfo.isRenew )
				{
					dbCustomer.EmployeeCount = pInfo.newEmployees;
					if( dbCustomer.TracksCredits )
					{
						dbCustomer.CreditCount += pInfo.newCredits;
					}
					dbCustomer.ExpirationDate = dbCustomer.ExpirationDate.AddYears( 1 );
				}
				else
				{
					dbCustomer.EmployeeCount += pInfo.newEmployees;
					if( dbCustomer.TracksCredits )
					{
						dbCustomer.CreditCount += pInfo.newCredits;
					}
				}

				var newPurchase = new CustomerPurchase()
				{
					PurchaseDate = DateTime.UtcNow,
					CreditCount = pInfo.newCredits,
					EmployeeCount = pInfo.newEmployees,
					PerCreditCost = pInfo.costPerCredit,
					PerEmployeeCost = pInfo.costPerEmployee,
	
					CustomerName = dbCustomer.Name,
					CustomerContact = dbCustomer.ContactFirstName + " " + dbCustomer.ContactLastName,
					CustomerEmail = dbCustomer.ContactEmailAddress,
					CustomerPhone = dbCustomer.PhoneNumber,

					PurchaseType = pInfo.isRenew ? GDWPurchaseTypes.PurchaseType.Renewal : GDWPurchaseTypes.PurchaseType.AddOns,

					DiscountCodeID = pInfo.discountCodeId,
					DiscountCodeAmount = pInfo.discountCodeAmount,
					DiscountCodeText = pInfo.discountCode,
					TransactionId = transactionId,

					SalesTax = pInfo.salesTax
				};

				if( string.IsNullOrEmpty( pInfo.profileId ) )
				{
					if( pInfo.method == GDWPaymentMethods.PaymentMethod.CreditCard.ToString() )
					{
						newPurchase.PaymentMethod = GDWPaymentMethods.PaymentMethod.CreditCard;
						newPurchase.PaymentDetail = pInfo.maskedCCNumber;
					}
					else if( pInfo.method == GDWPaymentMethods.PaymentMethod.eCheck.ToString() )
					{
						newPurchase.PaymentMethod = GDWPaymentMethods.PaymentMethod.eCheck;
						newPurchase.PaymentDetail = pInfo.maskedECheckNumber;
					}
				}
				else
				{
					var ccProfile = dbCustomer.CustomerCreditCards.FirstOrDefault( c => c.CCProfileID == pInfo.profileId );
					if( ccProfile != null )
					{
						newPurchase.PaymentMethod = ccProfile.PaymentMethod;
						newPurchase.PaymentDetail = ccProfile.MaskedCCNumber;
					}
				}

				dbCustomer.CustomerPurchases.Add( newPurchase );

				database.SaveChanges();

				database.Entry<CustomerPurchase>( newPurchase ).Reload();

				invoiceNumber = newPurchase.PurchaseID.ToString();				
			}
		}

		public CustomerStatus GetAccountStatus( int? customerId )
		{
			if( customerId.HasValue )
			{
				var dbCustomer = database.Customers
					.FirstOrDefault( c => c.CustomerID == customerId.Value );

				if( dbCustomer != null )
				{
					return new CustomerStatus()
					{
						creditCount = dbCustomer.TracksCredits ? dbCustomer.CreditCount : int.MaxValue,
						activeEmployees = dbCustomer.CustomerLocations.SelectMany( l => l.Users ).Distinct()
							.Count( e => !e.IsDeleted ),
						maxEmployees = dbCustomer.EmployeeCount,
						expirationDays = (dbCustomer.ExpirationDate - DateTime.Now).Days,
						trackCredits = dbCustomer.TracksCredits
					};
				}
			}

			return new CustomerStatus();
		}

		public IEnumerable<AssignEmployeeSummary> GetEmployeeAssignmentList( EmployeeAssignmentTableParams param,
			out int totalRecords, out int displayedRecords, out int totalEmployees, out int creditsUsed, int? customerId )
		{
			totalRecords = 0;
			displayedRecords = 0;
			totalEmployees = 0;

			var theList = new List<AssignEmployeeSummary>();

			if( param.locations != null )
			{
				theList.AddRange( database.CustomerLocations
					.Where( c => param.locations.Contains( c.LocationID ) )
					.Select( c => new AssignEmployeeSummary()
					{
						id = c.LocationID,
						name = c.Name,
						employeeCount = c.Users.Where( u => ((param.status == "active" && !u.IsDeleted) || (param.status == "inactive" && u.IsDeleted) || (param.status == "all")) && 
							u.PermissionGroups.SelectMany( p => p.PermissionGroupItems ).Any( i => i.PermissionID == GDWPermissionTypes.Permissions.TakeClass ) ).Count(),
						isLocation = true
					} ) );
			}
			else
			{
				param.locations = new List<int>();
			}

			if( param.departments != null )
			{
				theList.AddRange( database.CustomerDepartments
					.Where( c => param.departments.Contains( c.DepartmentID ) )
					.Select( c => new AssignEmployeeSummary()
					{
						id = c.DepartmentID,
						name = c.Name,
						employeeCount = c.Users.Where( u => ((param.status == "active" && !u.IsDeleted) || (param.status == "inactive" && u.IsDeleted) || (param.status == "all")) && 
							u.PermissionGroups.SelectMany( p => p.PermissionGroupItems ).Any( i => i.PermissionID == GDWPermissionTypes.Permissions.TakeClass ) ).Count(),
						isDepartment = true
					} ) );
			}
			else
			{
				param.departments = new List<int>();
			}

			if( param.employees != null )
			{
				theList.AddRange( database.Users
					.Where( c => param.employees.Contains( c.UserID ) )
					.Select( c => new AssignEmployeeSummary()
					{
						id = c.UserID,
						name = c.FirstName + " " + c.LastName,
						employeeCount = 1
					} ) );
			}
			else
			{
				param.employees = new List<int>();
			}

			var users = database.Users
				.Where( c => c.PermissionGroups.SelectMany( p => p.PermissionGroupItems ).Any( i => i.PermissionID == GDWPermissionTypes.Permissions.TakeClass ) )
				.Where( c => param.locations.Intersect( c.CustomerLocations.Select( l => l.LocationID ) ).Any() ||
					param.departments.Intersect( c.CustomerDepartments.Select( d => d.DepartmentID ) ).Any() ||
					param.employees.Contains( c.UserID ) );

			switch( (param.status ?? "active").ToLower() )
			{
				case "active":
					users = users.Where( u => !u.IsDeleted );
					break;
				case "inactive":
					users = users.Where( u => u.IsDeleted );
					break;
				case "all":
					break;
			}

			var employees =	users.Distinct()
				.Select( u => u.UserID )
				.ToList();

			if( param.categories == null )
			{
				param.categories = new List<string>();
			}

			if( param.classes == null )
			{
				param.classes = new List<int>();
			}

			totalEmployees = employees.Count();
			creditsUsed = 0;
			foreach( var classDetail in database.Classes
				.Where( c => !c.IsDeleted && (c.CustomerID == customerId || !c.CustomerID.HasValue || !customerId.HasValue) )
				.Where( c => param.classes.Contains( c.ClassID ) || param.categories.Intersect( c.ClassCategories.Select( ca => ca.Name ) ).Any() )
				.Distinct() )
			{
				creditsUsed += (totalEmployees - database.UserClasses
					.Where( uc => uc.ClassID == classDetail.ClassID && employees.Contains( uc.UserID ) && uc.Status != GDWClassStatus.Status.TestPassed )
					.Count()) * classDetail.Credits;
			}

			totalRecords = theList.Count();
			displayedRecords = totalRecords;

			return theList.OrderBy( i => i.name );
		}

		private UserClass NewUserClass( Class classDetail, DateTime dueDate )
		{
			var newClass = new UserClass()
			{
				ClassID = classDetail.ClassID,
				Name = classDetail.Name,
				Description = classDetail.Description,
				PassPercent = classDetail.PassPercent,

				RandomizeQuestions = classDetail.RandomizeQuestions,
				TotalQuestionMinimum = classDetail.TotalQuestionMinimum,
				TotalQuestionMaximum = classDetail.TotalQuestionMaximum,

				DueDate = dueDate,
				AssignDate = DateTime.UtcNow,
				Status = GDWClassStatus.Status.New,
			};

			foreach( var dbVersion in classDetail.ClassVersions.Where( v => !v.IsDeleted ) )
			{
				var newVersion = new UserClassVersion()
				{
					CaptionFileName = dbVersion.CaptionFileName,
					Language = dbVersion.Language,

					ClassType = dbVersion.ClassType,
					VideoID = dbVersion.ClassType == GDWClassTypes.ClassType.Video ? dbVersion.VideoID : null,
					ScormClassID = dbVersion.ClassType == GDWClassTypes.ClassType.Scorm ? dbVersion.ScormClassID : null,
					PDFFileName = dbVersion.ClassType == GDWClassTypes.ClassType.Pdf ? dbVersion.PDFFileName : null,
				};

				foreach( var dbDoc in dbVersion.ClassVersionDocuments.Where( d => !d.IsDeleted ) )
				{
					newVersion.UserClassVersionDocuments.Add( new UserClassVersionDocument()
					{
						FileName = dbDoc.FileName,
						OriginalName = dbDoc.OriginalName
					} );
				}

				foreach( var dbQuestion in dbVersion.ClassQuestions.Where( q => !q.IsDeleted ) )
				{
					var newQuestion = new UserClassQuestion()
					{
						Text = dbQuestion.Text,
						Narrative = dbQuestion.Narrative,
						DisplayOrder = dbQuestion.DisplayOrder,
						ImageFileName = dbQuestion.ImageFileName,
						AudioFileName = dbQuestion.AudioFileName,
					};

					foreach( var dbAnswer in dbQuestion.ClassAnswers.Where( a => !a.IsDeleted ) )
					{
						newQuestion.UserClassAnswers.Add( new UserClassAnswer()
						{
							Text = dbAnswer.Text,
							IsCorrect = dbAnswer.IsCorrect,
							AudioFileName = dbAnswer.AudioFileName,
						} );
					}

					newVersion.UserClassQuestions.Add( newQuestion );
				}

				newClass.UserClassVersions.Add( newVersion );
			}

			return newClass;
		}

	    public AssignmentResultInformation AssignClassesToUsers(NewAssignmentInformation aInfo)
	    {
	        if (aInfo.categories == null)
	        {
	            aInfo.categories = new List<string>();
	        }

	        if (aInfo.classes == null)
	        {
	            aInfo.classes = new List<int>();
	        }

	        if (aInfo.locations == null)
	        {
	            aInfo.locations = new List<int>();
	        }

	        if (aInfo.departments == null)
	        {
	            aInfo.departments = new List<int>();
	        }

	        var employeeIdList = new List<int>();
	        if (aInfo.employees != null)
	        {
	            employeeIdList = aInfo.employees.Select(e => e.id).ToList();
	        }
			
	        var dbCustomer = database.Customers.Include(c => c.AvailableClasses).FirstOrDefault(c => c.CustomerID == aInfo.customerId);
	        if (dbCustomer == null)
		        throw new GDWException("ErrorCustomerNotFound");

	        var creditsSpent = 0;
	        var newAssignments = new List<UserClass>();
	        var existingAssignments = new List<UserClass>();

	        foreach (var classDetail in database.Classes
	            .Where(c => !c.IsDeleted && (c.CustomerID == aInfo.customerId || !c.CustomerID.HasValue))
	            .Where(c => aInfo.classes.Contains(c.ClassID) || aInfo.categories.Intersect(c.ClassCategories.Select(ca => ca.Name)).Any())
	            .Distinct())
	        {
		        if (dbCustomer.EnterpriseLevel == GDWEnterpriseLevels.EnterpriseLevel.Basic &&
		            dbCustomer.AvailableClasses.All(ac => ac.ClassID != classDetail.ClassID))
		        {
			        continue; // unavailable class
		        }

	            foreach (var userDetail in database.Users
	                .Where(
	                    c =>
	                        !c.IsDeleted &&
	                        c.PermissionGroups.SelectMany(p => p.PermissionGroupItems)
	                            .Any(i => i.PermissionID == GDWPermissionTypes.Permissions.TakeClass))
	                .Where(c => aInfo.locations.Intersect(c.CustomerLocations.Select(l => l.LocationID)).Any() ||
	                            aInfo.departments.Intersect(c.CustomerDepartments.Select(d => d.DepartmentID)).Any() ||
	                            employeeIdList.Contains(c.UserID))
	                .Distinct())
	            {
	                var ucExisting = userDetail.UserClasses
	                    .Where(uc => uc.ClassID == classDetail.ClassID && uc.Status != GDWClassStatus.Status.TestPassed)
	                    .ToArray();
	                if (!ucExisting.Any())
	                {
	                    var newClass = NewUserClass(classDetail, aInfo.dueDate);

	                    userDetail.UserClasses.Add(newClass);

	                    newAssignments.Add(newClass);

	                    creditsSpent += classDetail.Credits;
	                }
	                else
	                {
	                    existingAssignments.Add(ucExisting.OrderByDescending(x => x.DueDate).First());
	                }
	            }
	        }

	        var results = new AssignmentResultInformation
	            {
	                AssignedUserClasses = existingAssignments.Select(a => new UserClassSummary
	                    {
	                        userID = a.UserID,
	                        classID = a.ClassID,
	                        dueDate = a.DueDate,
	                        userClassID = a.UserClassID
	                    }).ToList(),
	                RemainingCreditCount = dbCustomer.TracksCredits ? dbCustomer.CreditCount : int.MaxValue
	            };

	        if (creditsSpent > 0)
	        {
	            if (dbCustomer.CreditCount < creditsSpent && dbCustomer.TracksCredits)
	                throw new GDWException("UnableToAssignClasses");

	            var previousCreditCount = dbCustomer.CreditCount;
	            if (dbCustomer.TracksCredits)
	            {
	                dbCustomer.CreditCount -= creditsSpent;
	            }

	            database.SaveChanges();

	            results.AssignedUserClasses.AddRange(newAssignments.Select(a => new UserClassSummary
	                {
	                    userID = a.UserID,
	                    classID = a.ClassID,
	                    dueDate = a.DueDate,
	                    userClassID = a.UserClassID
	                }));
	            results.RemainingCreditCount = dbCustomer.TracksCredits ? dbCustomer.CreditCount : int.MaxValue;

	            if (dbCustomer.ClassEmailFrequency != GDWClassEmailFrequencies.ClassEmailFrequency.None)
	            {
	                foreach (var employeeId in newAssignments.Select(a => a.UserID).Distinct())
	                {
	                    var employee = database.Users.First(u => u.UserID == employeeId);
	                    var newList = new List<NewAssignmentEmailSender.NewAssignmentEmailDetail>();
	                    foreach (var addedClass in newAssignments.Where(a => a.UserID == employee.UserID))
	                    {
	                        database.Entry(addedClass).Reload();

	                        newList.Add(new NewAssignmentEmailSender.NewAssignmentEmailDetail()
	                            {
	                                userClassId = addedClass.UserClassID,
	                                className = addedClass.Name
	                            });
	                    }

	                    using (var aRepo = new AccountRepository())
	                    {
	                        var emailRecipients = aRepo.GetEmailRecipientsForUser(employee);
	                        foreach (var recip in emailRecipients)
	                        {
	                            (new NewAssignmentEmailSender(recip.Language.StringClass)).SubmitNewAssignmentEmail(recip.EmailAddress,
	                                employee.FirstName, employee.LastName,
	                                aInfo.dueDate, newList);
	                        }
	                    }
	                }
	            }

	            if (dbCustomer.TracksCredits && dbCustomer.CreditCount <= dbCustomer.CreditWarning && previousCreditCount > dbCustomer.CreditWarning)
	            {
	                (new CreditCountLowEmailSender()).SubmitCreditCountLowEmail(dbCustomer.ContactEmailAddress, dbCustomer.CreditWarning);
	            }

	            if (dbCustomer.TracksCredits && dbCustomer.EmployeeCount - dbCustomer.CustomerLocations.SelectMany(l => l.Users).Distinct()
	                .Count(e => !e.IsDeleted) <= dbCustomer.EmployeeWarning)
	            {
	                (new EmployeeLimitNearEmailSender()).SubmitEmployeeLimitNearEmail(dbCustomer.ContactEmailAddress, dbCustomer.EmployeeWarning);
	            }
	        }

	        return results;
	    }

	    public void ImportScore( ScoreImportDetail detail, int? customerId, int classId, DateTime completedDate, bool replaceInProgress )
		{
			if( !detail.score.HasValue )
			{
				throw new GDWEnglishException( "Invalid score provided" );
			}

			// find the employee
			var dbUser = database.Users.FirstOrDefault( u => !u.IsDeleted && u.FirstName == detail.firstName && u.LastName == detail.lastName &&
				u.CustomerLocations.Any( l => l.CustomerID == customerId ) );
			if( dbUser == null )
			{
				throw new GDWEnglishException( "Unable to find employee" );
			}

			var dbClass = database.Classes.FirstOrDefault( c => c.ClassID == classId );
			if( dbClass == null )
			{
				throw new GDWEnglishException( "Unable to find class information" );
			}

			// check for an existing userclass
			var dbUserClass = dbUser.UserClasses.OrderByDescending( uc => uc.AssignDate ).FirstOrDefault( uc => uc.ClassID == classId );
			if( dbUserClass == null )
			{
				// never been assigned
			}
			else if( dbUserClass.Status == GDWClassStatus.Status.TestPassed )
			{
				// passed the class previously - new class
				dbUserClass = null;
			}
			else if (dbUserClass.Status != GDWClassStatus.Status.TestComplete)
			{
				if (!replaceInProgress)
					throw new GDWEnglishException("Employee is already in the process of taking this class");
			}
			else if (!dbUserClass.UserTests.OrderByDescending(ut => ut.CompleteDate).FirstOrDefault()?.IsImport ?? false)
			{
				if (!replaceInProgress)
					throw new GDWEnglishException("Employee is already in the process of taking this class");

				// allow the import if the class was imported the previous time
			}

			if( dbUserClass == null )
			{
				// add new assignment
				// use completed date as the due date
				dbUserClass = NewUserClass( dbClass, completedDate );

				dbUserClass.StartDate = DateTime.UtcNow;
				dbUserClass.OverdueWarning = null;
				dbUserClass.PrefLanguageID = dbUser.LanguageID;

				dbUser.UserClasses.Add( dbUserClass );
			}
			else
			{
				// use completed date as the due date
				dbUserClass.DueDate = completedDate;
			}

			dbUserClass.Status = detail.score >= dbClass.PassPercent ? GDWClassStatus.Status.TestPassed : GDWClassStatus.Status.TestComplete;

			dbUserClass.UserTests.Add( new UserTest()
			{
				CompleteDate = completedDate,
				Score = detail.score,
				IsImport = true
			} );

			database.SaveChanges();
		}

		public void RecordImport( int customerId, int classId, string originalFileName, string sourceFileName, string errorFileName, int successCount, int errorCount, int userId,
            string originalSignatureFileName, string signatureFileName )
		{
			database.ScoreImports.Add( new ScoreImport()
			{
				CustomerID = customerId,
				ClassID = classId,
				OriginalSourceFileName = originalFileName,
				SourceFileName = sourceFileName,
				ErrorFileName = errorFileName,
				ImportCount = successCount,
				ErrorCount = errorCount,
				DateImported = DateTime.UtcNow,
				UserID = userId,
                OriginalSignatureFileName = originalSignatureFileName,
                SignatureFileName = signatureFileName
			} );

			database.SaveChanges();
		}

		public void CheckCustomerStatus()
		{
			var overdueWarnings = new int[] { 30, 14, 7, 2, 1 };
			var soonDate = DateTime.Now.AddDays( overdueWarnings.Max() );

			foreach( var expSoonCustomer in database.Customers
				.Where( c => c.ExpirationDate <= soonDate ) )
			{
				var daysToDue = (expSoonCustomer.ExpirationDate - DateTime.Now.Date).Days;

				var neededWarning = overdueWarnings.Where( w => w >= daysToDue ).DefaultIfEmpty( 60 ).Min();	// the smallest warning greater than the number of days left

				if( neededWarning < 60 )
				{
					if( neededWarning < expSoonCustomer.RenewWarning || !expSoonCustomer.RenewWarning.HasValue )
					{
						// send alert
						var emailList = expSoonCustomer.CustomerLocations
							.SelectMany( cl => cl.Users )
							.Where( u => !u.IsDeleted && !string.IsNullOrEmpty( u.EmailAddress ) )
							.Where( u => u.PermissionGroups.SelectMany( pg => pg.PermissionGroupItems ).Select( pgi => pgi.PermissionID ).Contains( GDWPermissionTypes.Permissions.AlertAccountExpiration ) )
							.ToList();

						if( !emailList.Any() )
						{
							(new ExpiringCustomerEmailSender( "EnglishStrings" )).SubmitExpiringSoonWarningEmail( expSoonCustomer.ContactEmailAddress, neededWarning );
						}
						else
						{
						    using ( var aRepo = new AccountRepository() )
						    {
						        foreach ( var user in emailList )
						        {
						            var emailRecipients = aRepo.GetEmailRecipientsForUser( user );
						            foreach ( var recip in emailRecipients )
						            {
						                (new ExpiringCustomerEmailSender( recip.Language.StringClass )).SubmitExpiringSoonWarningEmail( recip.EmailAddress, neededWarning );
						            }
						        }
						    }
						}

						// update warning setting
						expSoonCustomer.RenewWarning = neededWarning;
					}
				}
			}

			database.SaveChanges();
		}

		public IEnumerable<LocationContactSummary> GetMySafetyDirectors( int userId )
		{
			var dbUser = database.Users.FirstOrDefault( u => u.UserID == userId );

			if( dbUser != null )
			{
				return dbUser.CustomerLocations
					.Where( c => !c.IsDeleted )
					.ToList()
					.Select( c => new LocationContactSummary()
					{
						location = c.Name,
						name = c.SDName ?? "",
						email = c.SDEmail ?? "",
						phone = c.SDPhone ?? "",
						cell = c.SDCellPhone ?? ""
					} )
					.OrderBy( s => s.location );
			}

			throw new GDWException( "ErrorUserNotFound" );
		}

		public CreditReportStatus GetCreditReport( int? customerId = null )
		{
			var dbCustomers = database.Customers
				.Where( c => c.CustomerID == customerId || customerId == null );

			var thisTimeLastYear = DateTime.Now.AddYears( -1 );

			var dbUserClasses = dbCustomers
					.Where( c => c.TracksCredits )
					.SelectMany( c => c.CustomerLocations )
					.SelectMany( cl => cl.Users )
					.Distinct()
					.SelectMany( u => u.UserClasses )
					.Include( uc => uc.Class )
					.Where( uc => uc.AssignDate >= thisTimeLastYear )
					.ToList();

			return new CreditReportStatus()
			{
				unassigned = dbCustomers.Where( c => c.TracksCredits ).Sum( c => c.CreditCount ),
				assigned = dbUserClasses
					.Where( uc => uc.Status == GDWClassStatus.Status.New )
					.Sum( uc => uc.Class.Credits ),
				used = dbUserClasses
					.Where( uc => uc.Status != GDWClassStatus.Status.New )
					.Sum( uc => uc.Class.Credits )
			};
		}

		public SubscriberInformation GetSubscriberAnalytics()
		{
			var today = DateTime.Now;
			var thirtyDaysOut = today.AddDays( 30 );
			var dbCustomers = database.Customers.Where( c => !c.IsDeleted && c.ExpirationDate >= today );

			return new SubscriberInformation()
			{
				customers = dbCustomers.Count( c => !c.IsDeleted && c.ExpirationDate >= today ),
				renewalSoon = dbCustomers.Where( c => !c.IsDeleted && c.ExpirationDate <= thirtyDaysOut && c.ExpirationDate >= today ).Count(),
				userAccounts = dbCustomers.Where( c => !c.IsDeleted && c.ExpirationDate >= today ).Sum( c => c.EmployeeCount ),
				activeEmployees = dbCustomers
					.Where( c => !c.IsDeleted && c.ExpirationDate >= today )
					.SelectMany( c => c.CustomerLocations )
					.Where( cl => !cl.IsDeleted )
					.SelectMany( cl => cl.Users )
					.Where( cl => !cl.IsDeleted )
					.Distinct()
					.Count(),
				purchasedCredits = dbCustomers
					.Where( c => !c.IsDeleted && c.ExpirationDate >= today && c.TracksCredits )
					.SelectMany( c => c.CustomerPurchases )
					.Sum( cp => cp.CreditCount ),
				outstandingCredits = dbCustomers
					.Where( c => !c.IsDeleted && c.ExpirationDate >= today && c.TracksCredits )
					.Sum( c => c.CreditCount )
			};
		}

		public IEnumerable<GDWListItem> GetReportDropDownList( int? fixedId )
		{
			return database.Customers
				.Where( c => !c.IsDeleted && c.ExpirationDate >= DateTime.Now )
				.Where( c => c.CustomerID == fixedId || !fixedId.HasValue )
				.Select( c => new GDWListItem() { id = c.CustomerID, name = c.Name } )
				.OrderBy( c => c.name )
				.ToList();
		}

	    public CustomerSignatureInformation GetCustomerSignature( int id )
	    {
	        var dbSignature = database.CustomerSignatures
	            .FirstOrDefault( c => c.CustomerID == id );

	        if ( dbSignature != null )
	        {
	            return new CustomerSignatureInformation
	                {
	                    signatureId = dbSignature.SignatureID,
	                    customerId = dbSignature.CustomerID,
	                    signatureName = dbSignature.Name,
	                    signatureTitle = dbSignature.Title,
	                    signatureImageFileName = dbSignature.ImageFileName,
	                    originalSignatureImageFileName = dbSignature.OriginalImageFileName
	                };
	        }

	        return new CustomerSignatureInformation
	            {
	                signatureId = 0,
	                customerId = id,
                    signatureName = string.Empty,
                    signatureTitle = String.Empty
	            };
	    }

	    public void EditCustomerSignature( int id, CustomerSignatureInformation csInfo )
	    {
	        var dbSignature = database.CustomerSignatures
	            .FirstOrDefault( c => c.CustomerID == id );
	        if ( dbSignature == null )
	        {
	            dbSignature = new CustomerSignature { CustomerID = id };
	        }

	        dbSignature.Name = csInfo.signatureName ?? string.Empty;
	        dbSignature.Title = csInfo.signatureTitle ?? string.Empty;
	        if ( !string.Equals( csInfo.signatureImageFileName, dbSignature.ImageFileName, StringComparison.InvariantCultureIgnoreCase ) )
	        {
	            if ( !string.IsNullOrEmpty( dbSignature.ImageFileName ) )
	            {
	                var fileStorage = new AzureFileStorage();
	                fileStorage.DeleteFile( "Files", dbSignature.ImageFileName );
	            }
	        }
	        if ( !string.IsNullOrEmpty( csInfo.signatureImageFileName ) )
	        {
	            dbSignature.ImageFileName = csInfo.signatureImageFileName;
	            dbSignature.OriginalImageFileName = csInfo.originalSignatureImageFileName;
	        }
	        else
	        {
	            dbSignature.ImageFileName = null;
	            dbSignature.OriginalImageFileName = null;
	        }

	        if ( dbSignature.SignatureID == 0 )
	        {
	            database.CustomerSignatures.Add( dbSignature );
	        }

			database.SaveChanges();
	    }

		public IEnumerable<ScheduledClassAssignmentSummary> GetScheduledAssignmentList( ScheduledAssignmentTableParams param, out int totalRecords, out int displayedRecords, int customerId )
		{
			var query = database.ScheduledClassAssignments
                .Include( x => x.ScheduledUserClasses )
				.Where( x => !x.IsDeleted && x.CustomerID == customerId )
                .AsQueryable();

		    totalRecords = query.Count();

		    if (string.Equals(param.status, "pending"))
		    {
		        query = query.Where(x => !x.IsComplete);
		    }
            else if (string.Equals(param.status, "completed"))
            {
                query = query.Where(x => x.IsComplete);
            }

		    if (!string.IsNullOrEmpty(param.sSearch))
		    {
		        query = query.Where(x => x.ClassName.Contains(param.sSearch) ||
		                                 x.Locations.Contains(param.sSearch) ||
		                                 x.Departments.Contains(param.sSearch));
		    }

            displayedRecords = query.Count();

			string[] sortCols = param.sColumns.Split( ',' );
		    string sortCol0 = param.iSortingCols > 0 ? sortCols[param.iSortCol_0] : string.Empty;
		    string sortCol1 = param.iSortingCols > 1 ? sortCols[param.iSortCol_1] : string.Empty;

			IOrderedQueryable<ScheduledClassAssignment> filteredAndSorted = null;
			switch( sortCol0.ToLowerInvariant() )
			{
				case "classname":
				default:
					if( param.sSortDir_0.ToLowerInvariant() == "asc" )
					{
						filteredAndSorted = query.OrderBy( x => x.ClassName );
					}
					else
					{
						filteredAndSorted = query.OrderByDescending( x => x.ClassName );
					}
					break;
				case "assignmentDate":
					if( param.sSortDir_0.ToLowerInvariant() == "asc" )
					{
						filteredAndSorted = query.OrderBy( x => x.AssignmentDate );
					}
					else
					{
						filteredAndSorted = query.OrderByDescending( x => x.AssignmentDate );
					}
					break;
				case "locations":
					if( param.sSortDir_0.ToLowerInvariant() == "asc" )
					{
						filteredAndSorted = query.OrderBy( x => x.Locations );
					}
					else
					{
						filteredAndSorted = query.OrderByDescending( x => x.Locations );
					}
					break;
				case "departments":
					if( param.sSortDir_0.ToLowerInvariant() == "asc" )
					{
						filteredAndSorted = query.OrderBy( x => x.Departments );
					}
					else
					{
						filteredAndSorted = query.OrderByDescending( x => x.Departments );
					}
					break;
			}
            switch( sortCol1.ToLowerInvariant() )
			{
				case "classname":
					if( param.sSortDir_1.ToLowerInvariant() == "asc" )
					{
						filteredAndSorted = filteredAndSorted.ThenBy( x => x.ClassName );
					}
					else
					{
						filteredAndSorted = filteredAndSorted.ThenByDescending( x => x.ClassName );
					}
					break;
				case "assignmentDate":
					if( param.sSortDir_1.ToLowerInvariant() == "asc" )
					{
						filteredAndSorted = filteredAndSorted.ThenBy( x => x.AssignmentDate );
					}
					else
					{
						filteredAndSorted = filteredAndSorted.ThenByDescending( x => x.AssignmentDate );
					}
					break;
				case "locations":
					if( param.sSortDir_1.ToLowerInvariant() == "asc" )
					{
						filteredAndSorted = filteredAndSorted.ThenBy( x => x.Locations );
					}
					else
					{
						filteredAndSorted = filteredAndSorted.ThenByDescending( x => x.Locations );
					}
					break;
				case "departments":
					if( param.sSortDir_1.ToLowerInvariant() == "asc" )
					{
						filteredAndSorted = filteredAndSorted.ThenBy( x => x.Departments );
					}
					else
					{
						filteredAndSorted = filteredAndSorted.ThenByDescending( x => x.Departments );
					}
					break;
			}

		    List<ScheduledClassAssignment> assignments;
		    if (param.iDisplayLength == 0) param.iDisplayLength = displayedRecords;
		    if ((displayedRecords > param.iDisplayLength) || (param.iDisplayStart > 0))
		    {
		        assignments = filteredAndSorted.Skip(param.iDisplayStart).Take(param.iDisplayLength).ToList();
		    }
		    else
		    {
		        assignments = filteredAndSorted.ToList();
		    }

			return assignments.Select( v => new ScheduledClassAssignmentSummary()
			{
                scheduleId = v.ScheduledAssignmentID,
                whenCreated = v.WhenCreated.ToString("u"),
                className = v.ClassName,
                assignmentDate = v.AssignmentDate.ToString("yyyy-MM-dd"),
                dueDate = v.DueDate.ToString("yyyy-MM-dd"),
                locations = v.Locations,
                departments = v.Departments,
                isCompleted = v.IsComplete,
                isStarted = v.CreatedScheduledUserClasses,
                hasErrors = v.FailureCount != 0,
                totalAssignmentsScheduled = v.ScheduledUserClasses.Count,
                numberOfAssignmentsCompleted = v.ScheduledUserClasses.Count(x => x.WhenCompleted.HasValue)
			} );
		}

		public IEnumerable<string> GetBlankScheduledAssignmentUploadHeaders()
		{
			var theList = new List<string>();

			theList.Add( "Class Name" );
			theList.Add( "Assignment Date" );
			theList.Add( "Due Date" );
			theList.Add( "Locations" );
			theList.Add( "Departments" );

			return theList;
		}

	    public IEnumerable<string> ImportScheduledAssignments(int currentUserId, Stream fStream, int customerId, out int recordCount)
	    {
            using( var textReader = new StreamReader( fStream ) )
			{
				var csvReader = new CsvReader( textReader, new CsvConfiguration() { HasHeaderRecord = true } );

				int i = 1;
				var errors = new List<string>();
				recordCount = 0;

				var customer = database.Customers.Include(c => c.AvailableClasses).Single(c => c.CustomerID == customerId);

				HashSet<string> knownClasses;
				if (customer.EnterpriseLevel == GDWEnterpriseLevels.EnterpriseLevel.Basic)
				{
					knownClasses = new HashSet<string>(
						customer.AvailableClasses.Where(c => !c.IsDeleted).Select(c => c.Name),
						StringComparer.CurrentCultureIgnoreCase);
				}
				else
				{
					knownClasses = new HashSet<string>(
						database.Classes.Where(c => !c.IsDeleted && (c.CustomerID == customerId || !c.CustomerID.HasValue)).Select(c => c.Name),
						StringComparer.CurrentCultureIgnoreCase);
				}

                var knownLocations = new HashSet<string>(
                    GetLocationDropDownList(customerId, currentUserId).Select(v => v.name),
			        StringComparer.CurrentCultureIgnoreCase);

			    var knownDepartments = new HashSet<string>(
                    GetDepartmentDropDownList(customerId).Select(cd => cd.name),
                    StringComparer.CurrentCultureIgnoreCase);

				while( csvReader.Read() )
				{
					try
					{
						string className = csvReader.GetField<string>( "Class Name" );
						DateTime? assignmentDate = csvReader.GetField<DateTime?>( "Assignment Date" ).RemoveTimeAndTimeZone();
						DateTime? dueDate = csvReader.GetField<DateTime?>( "Due Date" ).RemoveTimeAndTimeZone();
						string locations = csvReader.GetField<string>( "Locations" );
						string departments = csvReader.GetField<string>( "Departments" );

				        var recordErrors = new List<string>();

						if( string.IsNullOrEmpty(className) )
						{
							recordErrors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "ClassNameRequiredField" ) ) );
						}
						else if (!knownClasses.Contains(className))
						{
							recordErrors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "UnknownClassName" ) ) );
						}

						if( !assignmentDate.HasValue )
						{
							recordErrors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "AssignmentDateRequiredField" ) ) );
						}

						if( !dueDate.HasValue )
						{
							recordErrors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "DueDateRequiredField" ) ) );
						}

					    if ( assignmentDate.HasValue && dueDate.HasValue && dueDate <= assignmentDate )
					    {
							recordErrors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "DueDateMustBeAfterAssignmentDate" ) ) );
					    }

					    if ( string.IsNullOrEmpty( locations ) )
					    {
					        recordErrors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "LocationsListRequiredField" ) ) );
					    }
					    else
					    {
					        var locationNames = locations.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
					        if (!locationNames.Any())
					        {
					            recordErrors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "LocationsListRequiredField" ) ) );
					        }
					        foreach (var locationName in locationNames)
					        {
					            if (!knownLocations.Contains(locationName))
					            {
					                recordErrors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "UnknownLocationName" ) ) );
					                break;
					            }
					        }
					    }

					    if ( !string.IsNullOrEmpty( departments ) )
					    {
						    var deptNames = departments.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
						    foreach (var deptName in deptNames)
						    {
						        if (!knownDepartments.Contains(deptName))
						        {
							        recordErrors.Add( string.Format( "Line {0} - {1}", i, GetUserString( "UnknownDepartmentName" ) ) );
						            break;
						        }
						    }
					    }

					    if (!recordErrors.Any())
					    {
					        var scheduledAssignment = new ScheduledClassAssignment
					            {
                                    CreatedByUserID = currentUserId,
                                    WhenCreated = DateTime.UtcNow,
                                    CustomerID = customerId,
					                ClassName = className,
					                AssignmentDate = assignmentDate.Value.RemoveTimeAndTimeZone(),
					                DueDate = dueDate.Value.RemoveTimeAndTimeZone(),
					                Locations = locations,
					                Departments = departments
					            };

					        database.ScheduledClassAssignments.Add(scheduledAssignment);
					        recordCount++;
					    }
					    else
					    {
					        errors.AddRange(recordErrors);
					    }
					}
					catch
					{
						errors.Add( string.Format( "Line {0} - An unknown error has occured", i ) );
					}

					i++;
				}

				if( !errors.Any() )
				{
					database.SaveChanges();
				}

				return errors;
			}
	    }

	    public void CancelScheduledAssignment(int scheduledAssignmentId, int customerId)
	    {
			var scheduledAssignment = database.ScheduledClassAssignments
				.SingleOrDefault( x => !x.IsDeleted && x.CustomerID == customerId && x.ScheduledAssignmentID == scheduledAssignmentId );

	        if (scheduledAssignment != null)
	        {
	            scheduledAssignment.IsDeleted = true;
				database.SaveChanges();
	        }
	    }

	    public IList<IncompleteScheduledAssignmentSummary> GetPendingScheduledAssignmentsDue(DateTime today)
	    {
            var list = database.ScheduledClassAssignments
				.Where( x => !x.IsDeleted && !x.IsComplete && x.AssignmentDate <= today && !x.CreatedScheduledUserClasses )
                .ToArray();

	        return list.Select(x => new IncompleteScheduledAssignmentSummary
	            {
                    ScheduledAssignmentID = x.ScheduledAssignmentID,
                    CreatedByUserID = x.CreatedByUserID,
                    CustomerID = x.CustomerID,
                    ClassName = x.ClassName,
                    AssignmentDate = x.AssignmentDate,
                    DueDate = x.DueDate,
                    LocationNames = (x.Locations ?? string.Empty).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries),
                    DepartmentNames = (x.Departments ?? string.Empty).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries),
                    CreatedScheduledUserClasses = x.CreatedScheduledUserClasses,
                    FailureCount = x.FailureCount
	            }).ToArray();
	    }

	    public IList<IncompleteScheduledAssignmentSummary> GetInProgressScheduledAssignments()
	    {
            var list = database.ScheduledClassAssignments
				.Where( x => !x.IsDeleted && !x.IsComplete && x.CreatedScheduledUserClasses )
                .ToArray();

	        return list.Select(x => new IncompleteScheduledAssignmentSummary
	            {
                    ScheduledAssignmentID = x.ScheduledAssignmentID,
                    CreatedByUserID = x.CreatedByUserID,
                    CustomerID = x.CustomerID,
                    ClassName = x.ClassName,
                    AssignmentDate = x.AssignmentDate,
                    DueDate = x.DueDate,
                    LocationNames = (x.Locations ?? string.Empty).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries),
                    DepartmentNames = (x.Departments ?? string.Empty).Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries),
                    CreatedScheduledUserClasses = x.CreatedScheduledUserClasses,
                    FailureCount = x.FailureCount
	            }).ToArray();
	    }

	    public void CompleteScheduledAssignment(int scheduledAssignmentId)
	    {
	        var schedAssign = database.ScheduledClassAssignments.SingleOrDefault(x => x.ScheduledAssignmentID == scheduledAssignmentId);
	        if (schedAssign != null)
	        {
	            schedAssign.FailureCount = 0;
	            schedAssign.LastError = null;
	            schedAssign.LastErrorDateTime = null;

	            schedAssign.IsComplete = true;
	            schedAssign.WhenCompleted = DateTime.UtcNow;

	            database.SaveChanges();
	        }
	    }

	    public void AbandonScheduledAssignment(int scheduledAssignmentId)
	    {
	        var schedAssign = database.ScheduledClassAssignments.SingleOrDefault(x => x.ScheduledAssignmentID == scheduledAssignmentId);
	        if (schedAssign != null)
	        {
	            ++schedAssign.FailureCount;
	            schedAssign.IsComplete = true;
	            schedAssign.WhenCompleted = DateTime.UtcNow;
	            schedAssign.LastError = StringManager.GetStringFromResourceFile("EnglishStrings", "ScheduledAssignmentAbandoned");
	            schedAssign.LastErrorDateTime = DateTime.UtcNow;

	            database.SaveChanges();

                // Always send this email regardless of failure count.
	            var dbUser = database.Users.FirstOrDefault(u => u.UserID == schedAssign.CreatedByUserID);
	            if (dbUser != null)
	            {
                    new ScheduledAssignmentAbandonedEmailSender(dbUser.Language.StringClass)
                        .SubmitScheduledAssignmentAbandonedEmail(dbUser.EmailAddress, schedAssign.ClassName, schedAssign.DueDate, schedAssign.Locations, schedAssign.Departments);
	            }
	        }
	    }

	    public void FailScheduledAssignment(int scheduledAssignmentId, IList<string> errorStringIds)
	    {
	        var schedAssign = database.ScheduledClassAssignments.SingleOrDefault(x => x.ScheduledAssignmentID == scheduledAssignmentId);
	        if (schedAssign != null)
	        {
	            ++schedAssign.FailureCount;
	            if (errorStringIds.Any())
	                schedAssign.LastError = StringManager.GetStringFromResourceFile("EnglishStrings", errorStringIds.First());
	            else
	                schedAssign.LastError = "Unknown error";
	            schedAssign.LastErrorDateTime = DateTime.UtcNow;

	            database.SaveChanges();

	            if (schedAssign.FailureCount == 1)
	            {
	                var dbUser = database.Users.FirstOrDefault(u => u.UserID == schedAssign.CreatedByUserID);
	                if (dbUser != null)
	                {
                        new ScheduledAssignmentErrorEmailSender(dbUser.Language.StringClass)
                            .SubmitScheduledAssignmentErrorEmail(dbUser.EmailAddress, schedAssign.ClassName, schedAssign.DueDate, schedAssign.Locations, schedAssign.Departments, errorStringIds);
	                }
	            }
	        }
	    }

	    public void CreateScheduledUserClasses(int scheduledAssignmentId, int classId, DateTime dueDate, IEnumerable<int> userIds)
	    {
	        var schedAssign = database.ScheduledClassAssignments.SingleOrDefault(x => x.ScheduledAssignmentID == scheduledAssignmentId);
	        if (schedAssign == null)
                throw new GDWException("ErrorScheduledAssignmentNotFound");

	        var alreadyScheduledUserIds = new HashSet<int>(
	            database.ScheduledUserClasses
	                .Where(x => x.ScheduledClassAssignmentID == schedAssign.ScheduledAssignmentID && x.ClassID == classId)
	                .Select(x => x.UserID));

	        foreach (var userId in userIds)
	        {
	            if (!alreadyScheduledUserIds.Contains(userId))
	            {
	                database.ScheduledUserClasses.Add(new ScheduledUserClass
	                    {
	                        ScheduledClassAssignmentID = schedAssign.ScheduledAssignmentID,
	                        ClassID = classId,
	                        UserID = userId,
	                        DueDate = schedAssign.DueDate,
	                        WhenCreated = DateTime.UtcNow
	                    });
	            }
	        }

	        schedAssign.CreatedScheduledUserClasses = true;
	        schedAssign.FailureCount = 0;
	        schedAssign.LastError = null;
	        schedAssign.LastErrorDateTime = null;

	        database.SaveChanges();
	    }

	    public IList<ScheduledUserClassSummary> GetScheduledUserClasses(int scheduledAssignmentId)
	    {
	        var schedAssign = database.ScheduledClassAssignments.SingleOrDefault(x => x.ScheduledAssignmentID == scheduledAssignmentId);
	        if (schedAssign == null)
                throw new GDWException("ErrorScheduledAssignmentNotFound");

	        var list = database.ScheduledUserClasses
	            .Where(x => x.ScheduledClassAssignmentID == scheduledAssignmentId && !x.ScheduledClassAssignment.IsDeleted)
	            .ToArray();

	        return list.Select(x => new ScheduledUserClassSummary
	            {
                    ScheduledUserClassID = x.ScheduledUserClassID,
                    ScheduledClassAssignmentID = x.ScheduledClassAssignmentID,
                    ClassID = x.ClassID,
                    UserID = x.UserID,
                    DueDate = x.DueDate,
                    WhenCreated = x.WhenCreated,
                    WhenCompleted = x.WhenCompleted,
                    UserClassID = x.UserClassID
	            }).ToArray();
	    }

	    public void CompleteScheduledUserClass(int scheduledUserClassId, int userClassId)
	    {
	        var suc = database.ScheduledUserClasses.SingleOrDefault(x => x.ScheduledUserClassID == scheduledUserClassId);
	        if (suc != null)
	        {
	            suc.UserClassID = userClassId;
	            suc.WhenCompleted = DateTime.UtcNow;
	            database.SaveChanges();
	        }
	    }

        #region Company documents

        public IEnumerable<DocumentSummary> GetFullDocumentList( CompanyDocumentTableParams param, GDWWebUser currentUser, out int totalRecords, out int displayedRecords )
		{
            totalRecords = 0;
			displayedRecords = 0;

			var documentList = database.Documents
				.Where( d => d.CustomerID != null && d.UserID == null && d.CustomerID == currentUser.CustomerID )
				.AsQueryable();

			if (!currentUser.HasPermission( GDWPermissionTypes.Permissions.ViewRestrictedCompanyDocument ))
			{
				documentList = documentList.Where(e => !e.IsRestricted);
			}

			totalRecords = documentList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				documentList = documentList.Where( i => i.Name.Contains( param.sSearch ) || i.Description.Contains( param.sSearch ) );
			}

			if (currentUser.HasPermission(GDWPermissionTypes.Permissions.ManageCompanyDocument))
			{
				switch ((param.activeState ?? "active").ToLower())
				{
				case "active":
					documentList = documentList.Where(u => !u.IsDeleted);
					break;
				case "inactive":
					documentList = documentList.Where(u => u.IsDeleted);
					break;
				case "all":
					break;
				}
			}
			else
			{
				documentList = documentList.Where(u => !u.IsDeleted);
			}

			displayedRecords = documentList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<Document> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "name":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = documentList.OrderBy( v => v.Name );
					}
					else
					{
						filteredAndSorted = documentList.OrderByDescending( v => v.Name );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new DocumentSummary()
			{
				documentId = v.DocumentID,
				name = v.Name,
				description = v.Description,
				isRestricted = v.IsRestricted,
				isActive = !v.IsDeleted,
				lastUpdateDate = v.LastUpateDateTime
			} );
		}
		
        public void AddDocument( GDWWebUser currentUser, DocumentInformation pInfo )
        {
	        var dbCustomer = database.Customers.FirstOrDefault( c => c.CustomerID == currentUser.CustomerID );

	        if (dbCustomer == null)
		        throw new GDWException("ErrorCustomerNotFound");

	        var newDocument = new Document { CustomerID = dbCustomer.CustomerID };

	        newDocument.LastUpateDateTime = DateTime.UtcNow;
	        newDocument.Name = pInfo.name;
	        newDocument.Description = pInfo.description;
	        newDocument.IsDeleted = !pInfo.isActive;
				
	        if (currentUser.HasPermission( GDWPermissionTypes.Permissions.ManageRestrictedCompanyDocument ))
	        {
		        newDocument.IsRestricted = pInfo.isRestricted;
	        }
			
	        if ( !string.IsNullOrEmpty( pInfo.fileName ) )
	        {
		        newDocument.FileName = pInfo.fileName;
		        newDocument.OriginalName = pInfo.originalFileName;
	        }

	        dbCustomer.Documents.Add( newDocument );

	        database.SaveChanges();
        }

        public void EditDocument( GDWWebUser currentUser, DocumentInformation pInfo )
        {
	        var dbDocument = database.Documents.FirstOrDefault( d => d.DocumentID == pInfo.documentId && d.CustomerID != null && d.UserID == null && d.CustomerID == currentUser.CustomerID );

	        if (dbDocument == null)
		        throw new GDWException("ErrorDocumentNotFound");

	        if (dbDocument.IsRestricted && !currentUser.HasPermission(GDWPermissionTypes.Permissions.ManageRestrictedCompanyDocument))
	        {
		        throw new GDWException("ErrorDocumentNotFound");
	        }

	        dbDocument.LastUpateDateTime = DateTime.UtcNow;
	        dbDocument.Name = pInfo.name;
	        dbDocument.Description = pInfo.description;
	        dbDocument.IsDeleted = !pInfo.isActive;
				
	        if (currentUser.HasPermission(GDWPermissionTypes.Permissions.ManageRestrictedCompanyDocument))
	        {
		        dbDocument.IsRestricted = pInfo.isRestricted;
	        }

	        if ( !string.Equals( pInfo.fileName, dbDocument.FileName, StringComparison.InvariantCultureIgnoreCase ) )
	        {
		        if ( !string.IsNullOrEmpty( dbDocument.FileName ) )
		        {
			        var fileStorage = new AzureFileStorage();
			        fileStorage.DeleteFile( "Files", dbDocument.FileName );
		        }
	        }
	        if ( !string.IsNullOrEmpty( pInfo.fileName ) )
	        {
		        dbDocument.FileName = pInfo.fileName;
		        dbDocument.OriginalName = pInfo.originalFileName;
	        }
	        else
	        {
		        dbDocument.FileName = null;
		        dbDocument.OriginalName = null;
	        }

	        database.SaveChanges();
        }

        public DocumentInformation GetDocument( GDWWebUser currentUser, int id )
        {
	        var dbDocument = database.Documents.FirstOrDefault( d => d.DocumentID == id && d.CustomerID != null && d.UserID == null && d.CustomerID == currentUser.CustomerID );

	        if (dbDocument == null)
		        throw new GDWException("ErrorDocumentNotFound");

	        if (dbDocument.IsRestricted && !currentUser.HasPermission(GDWPermissionTypes.Permissions.ViewRestrictedCompanyDocument))
	        {
		        throw new GDWException("ErrorDocumentNotFound");
	        }

	        return new DocumentInformation
	        {
		        documentId = dbDocument.DocumentID,
		        customerId = dbDocument.CustomerID ?? 0,
		        name = dbDocument.Name,
				description = dbDocument.Description,
				isRestricted = dbDocument.IsRestricted,
		        isActive = !dbDocument.IsDeleted,
				fileName = dbDocument.FileName,
				originalFileName = dbDocument.OriginalName
	        };

        }

        public void DeleteDocument(GDWWebUser currentUser, int id)
        {
	        var dbDocument = database.Documents.FirstOrDefault( d => d.DocumentID == id && d.CustomerID != null && d.UserID == null && d.CustomerID == currentUser.CustomerID );

	        if (dbDocument == null)
		        throw new GDWException("ErrorDocumentNotFound");

	        if (dbDocument.IsRestricted && !currentUser.HasPermission(GDWPermissionTypes.Permissions.ManageRestrictedCompanyDocument))
	        {
		        throw new GDWException("ErrorDocumentNotFound");
	        }

	        dbDocument.IsDeleted = true;
	        database.SaveChanges();
        }

        #endregion

        #region Company notes

        public IEnumerable<NoteSummary> GetFullNoteList( CompanyNoteTableParams param, GDWWebUser currentUser, out int totalRecords, out int displayedRecords )
		{
            totalRecords = 0;
			displayedRecords = 0;

			var noteList = database.Notes
			    .Include( n => n.LastUpdateByUser )
				.Where( n => n.CustomerID != null && n.UserID == null && n.CustomerID == currentUser.CustomerID )
				.Where( n => !n.IsDeleted )
				.AsQueryable();

			totalRecords = noteList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				noteList = noteList.Where(i => i.Text.Contains(param.sSearch) ||
				                               i.LastUpdateByUser.FirstName.Contains(param.sSearch) || i.LastUpdateByUser.LastName.Contains(param.sSearch));
			}

			displayedRecords = noteList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<Note> filteredAndSorted = null;
			switch (sortCol.ToLower())
			{
			case "lastUpdatedByUser":
				if (param.sSortDir_0.ToLower() == "asc")
				{
					filteredAndSorted = noteList.OrderBy( v => v.LastUpdateByUser.FirstName ).ThenBy( v => v.LastUpdateByUser.LastName );
				}
				else
				{
					filteredAndSorted = noteList.OrderByDescending( v => v.LastUpdateByUser.FirstName ).ThenByDescending( v => v.LastUpdateByUser.LastName );
				}

				break;

			// case "lastUpdateDate":
			default:
				if (param.sSortDir_0.ToLower() == "asc")
				{
					filteredAndSorted = noteList.OrderBy(v => v.LastUpateDateTime);
				}
				else
				{
					filteredAndSorted = noteList.OrderByDescending(v => v.LastUpateDateTime);
				}

				break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			return filteredAndSorted.ToList().Select( v => new NoteSummary()
			{
				noteId = v.NoteID,
				text = v.Text,
				lastUpdateDate = v.LastUpateDateTime,
				lastUpdatedByUser = v.LastUpdateByUser.FullName
			} );
		}
		
        public void AddNote( GDWWebUser currentUser, NoteInformation pInfo )
        {
	        var dbCustomer = database.Customers.FirstOrDefault( c => c.CustomerID == currentUser.CustomerID );

	        if (dbCustomer == null)
		        throw new GDWException("ErrorCustomerNotFound");

	        var newNote = new Note { CustomerID = dbCustomer.CustomerID, LastUpdateByUserID = currentUser.UserId };

	        newNote.LastUpateDateTime = DateTime.UtcNow;
	        newNote.Text = pInfo.text;
				
	        dbCustomer.Notes.Add( newNote );

	        database.SaveChanges();
        }

        public NoteInformation GetNote( GDWWebUser currentUser, int id )
        {
	        var dbNote = database.Notes
	                             .Include( n => n.LastUpdateByUser )
	                             .FirstOrDefault( n => n.NoteID == id && n.CustomerID != null && n.UserID == null && n.CustomerID == currentUser.CustomerID );

	        if (dbNote == null)
		        throw new GDWException("ErrorNoteNotFound");

	        return new NoteInformation
	        {
		        noteId = dbNote.NoteID,
		        customerId = dbNote.CustomerID ?? 0,
				userId = dbNote.UserID ?? 0,
				text = dbNote.Text,
				lastUpdatedByUser = dbNote.LastUpdateByUser.FullName,
				lastUpdated = dbNote.LastUpateDateTime
	        };

        }

        public void DeleteNote(GDWWebUser currentUser, int id)
        {
	        var dbNote = database.Notes.FirstOrDefault( n => n.NoteID == id && n.CustomerID != null && n.UserID == null && n.CustomerID == currentUser.CustomerID );

	        if (dbNote == null)
		        throw new GDWException("ErrorNoteNotFound");

	        dbNote.IsDeleted = true;
	        database.SaveChanges();
        }

        #endregion
    }
}
