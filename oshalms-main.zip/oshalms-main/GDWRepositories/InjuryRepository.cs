﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWDatabase;
using GDWInfrastructure;
using GDWInfrastructure.DataTables;
using GDWModels.Injury;

namespace GDWRepositories
{
	public class InjuryRepository : BaseRepository
	{
		public IEnumerable<InjurySummary> GetFullInjuryList( InjuryTableParams param, int currentUserId, out int totalRecords, out int displayedRecords )
		{
			totalRecords = 0;
			displayedRecords = 0;

			var injuryVersionList = database.InjuryIncidents
				.Include( ii => ii.InjuryIncidentVersions )
				.Where( ii => ii.CustomerID == param.customerId )
				.Select( ii => ii.InjuryIncidentVersions.OrderByDescending( iiv => iiv.VersionID ).FirstOrDefault() )
				.AsQueryable()
				.Include( iiv => iiv.InjuredUser )
				.Include( iiv => iiv.InjuryIncident.InjuryIncidentVersions );

			var currentUser = database.Users.First( u => u.UserID == currentUserId );
			if( currentUser.CustomerLocations.Any() )
			{
				if( !currentUser.PermissionGroups.SelectMany( g => g.PermissionGroupItems ).Any( i => i.PermissionID == GDWPermissionTypes.Permissions.ManageAllLocations ) )
				{
					var locationIds = currentUser.CustomerLocations.Select( l => l.LocationID ).ToList();
					injuryVersionList = injuryVersionList.Where( iiv => iiv.InjuredUser.CustomerLocations.Select( l => l.LocationID ).Intersect( locationIds ).Any() );
				}
			}
			totalRecords = injuryVersionList.Count();

			if( !string.IsNullOrEmpty( param.sSearch ) )
			{
				int caseNumberFilter = 0;
				int.TryParse( param.sSearch, out caseNumberFilter );

				injuryVersionList = injuryVersionList.Where( i =>
					i.InjuredUser.FirstName.Contains( param.sSearch ) ||
					i.InjuredUser.LastName.Contains( param.sSearch ) ||
					i.IncidentID == caseNumberFilter );
			}
			switch( (param.activeState ?? "active").ToLower() )
			{
				case "active":
					injuryVersionList = injuryVersionList.Where( u => !u.InjuredUser.IsDeleted );
					break;
				case "inactive":
					injuryVersionList = injuryVersionList.Where( u => u.InjuredUser.IsDeleted );
					break;
				case "all":
					break;
			}

			displayedRecords = injuryVersionList.Count();

			string sortCol = param.sColumns.Split( ',' )[param.iSortCol_0];

			IQueryable<InjuryIncidentVersion> filteredAndSorted = null;
			switch( sortCol.ToLower() )
			{
				case "employeename":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = injuryVersionList.OrderBy( v => v.IsPrivacy ).ThenBy( v => v.InjuredUser.FirstName ).ThenBy( v => v.InjuredUser.LastName );
					}
					else
					{
						filteredAndSorted = injuryVersionList.OrderByDescending( v => v.IsPrivacy ).ThenByDescending( v => v.InjuredUser.FirstName ).ThenByDescending( v => v.InjuredUser.LastName );
					}
					break;
				case "casenumber":
				default:
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = injuryVersionList.OrderBy( v => v.IncidentID );
					}
					else
					{
						filteredAndSorted = injuryVersionList.OrderByDescending( v => v.IncidentID );
					}
					break;
				case "injurydate":
					if( param.sSortDir_0.ToLower() == "asc" )
					{
						filteredAndSorted = injuryVersionList.OrderBy( v => v.DateOfInjury );
					}
					else
					{
						filteredAndSorted = injuryVersionList.OrderByDescending( v => v.DateOfInjury );
					}
					break;
			}

			if( (displayedRecords > param.iDisplayLength) && (param.iDisplayLength > 0) )
			{
				filteredAndSorted = filteredAndSorted.Skip( param.iDisplayStart ).Take( param.iDisplayLength );
			}

			var privacyCase = GetUserString( "PrivacyCase" );
			return filteredAndSorted.ToList().Select( iiv => new InjurySummary()
			{
				caseNumber = iiv.IncidentID,
				employeeName = (!iiv.IsPrivacy || param.showPrivacyNames) ? iiv.InjuredUser.FullName : privacyCase,
				classification = iiv.CaseClassification.ToDisplayString(),
				injuryDate = iiv.DateOfInjury.ToShortDateString(),
				revisions = iiv.InjuryIncident.InjuryIncidentVersions.Count( oldIIV => oldIIV.VersionID != iiv.VersionID )
			} );
		}

		private InjuryIncidentVersion Create( InjuryInformation iInfo, int currentUserId )
		{
			var injuryCaseVersion = new InjuryIncidentVersion();

			injuryCaseVersion.EnteredByUserID = currentUserId;
			injuryCaseVersion.EnteredOnDate = DateTime.UtcNow;
			injuryCaseVersion.InjuredUserID = iInfo.employee.id;
			injuryCaseVersion.JobTitle = iInfo.jobTitle;
			injuryCaseVersion.DateOfInjury = iInfo.dateOfInjury;
			injuryCaseVersion.WhereEventOccurred = iInfo.whereEventOccurred;
			injuryCaseVersion.CaseClassification = (InjuryConstants.CaseClassificationType)iInfo.caseClassification;
			switch( injuryCaseVersion.CaseClassification )
			{
				case InjuryConstants.CaseClassificationType.DaysAwayFromWork:
					injuryCaseVersion.DaysLost = iInfo.daysAwayFromWork;
					break;
				case InjuryConstants.CaseClassificationType.JobTransfer:
					injuryCaseVersion.DaysLost = iInfo.daysTransferred;
					break;
				case InjuryConstants.CaseClassificationType.Death:
					injuryCaseVersion.DateOfDeath = iInfo.dateOfDeath;
					break;
				default:
					break;
			}
			injuryCaseVersion.TypeOfIllness = (InjuryConstants.InjuryIllnessType)iInfo.typeOfIllness;
			injuryCaseVersion.Address1 = iInfo.address1;
			injuryCaseVersion.Address2 = iInfo.address2;
			injuryCaseVersion.City = iInfo.city;
			injuryCaseVersion.State = iInfo.state;
			injuryCaseVersion.ZipCode = iInfo.zipCode;
			injuryCaseVersion.DateOfBirth = iInfo.birth.AsDateTime;
			injuryCaseVersion.HCName = iInfo.hcName;
			injuryCaseVersion.HCAddress1 = iInfo.hcAddress1;
			injuryCaseVersion.HCAddress2 = iInfo.hcAddress2;
			injuryCaseVersion.HCCity = iInfo.hcCity;
			injuryCaseVersion.HCState = iInfo.hcState;
			injuryCaseVersion.HCZipCode = iInfo.hcZipCode;
			injuryCaseVersion.MDAddress1 = iInfo.mdAddress1;
			injuryCaseVersion.MDAddress2 = iInfo.mdAddress2;
			injuryCaseVersion.MDCity = iInfo.mdCity;
			injuryCaseVersion.MDState = iInfo.mdState;
			injuryCaseVersion.MDZipCode = iInfo.mdZipCode;
			injuryCaseVersion.HCEmergencyRoom = iInfo.hcEmergencyRoom;
			injuryCaseVersion.HCHospitalized = iInfo.hcHospitalized;
			injuryCaseVersion.StartWorkTime = iInfo.startWorkTime;
			injuryCaseVersion.EventTime = iInfo.eventTime;
			injuryCaseVersion.LocationID = iInfo.locationID;
			injuryCaseVersion.IsPrivacy = iInfo.isPrivacy;
			injuryCaseVersion.HCPhysician = iInfo.hcPhysician;
			injuryCaseVersion.SummaryDescription = iInfo.summaryDescription;
			injuryCaseVersion.DoingActivity = iInfo.doingActivity;
			injuryCaseVersion.WhatHappened = iInfo.whatHappened;
			injuryCaseVersion.InjuryOrIllness = iInfo.injuryOrIllness;
			injuryCaseVersion.ObjectHarmedEmployee = iInfo.objectHarmedEmployee;

			return injuryCaseVersion;
		}

		public void AddInjuryCase( InjuryInformation iInfo, int customerId, int currentUserId )
		{
			var injuryCase = new InjuryIncident();
			injuryCase.CustomerID = customerId;
						
			injuryCase.InjuryIncidentVersions.Add( Create( iInfo, currentUserId ) );

			database.InjuryIncidents.Add( injuryCase );

			database.SaveChanges();
		}

		public void AddInjuryCaseVersion( InjuryInformation iInfo, int currentUserId )
		{
			var injuryCase = database.InjuryIncidents.FirstOrDefault( ii => ii.IncidentID == iInfo.caseNumber );
			if( injuryCase != null )
			{
				injuryCase.InjuryIncidentVersions.Add( Create( iInfo, currentUserId ) );

				database.SaveChanges();
			}
		}

		private InjuryInformation ToInjuryInformation( InjuryIncidentVersion caseVersion )
		{
			return new InjuryInformation()
			{
				caseNumber = caseVersion.IncidentID,
				employee = new GDWInfrastructure.GDWListItem() { id = caseVersion.InjuredUser.UserID, name = caseVersion.InjuredUser.FullName },
				jobTitle = caseVersion.JobTitle,
				dateOfInjury = caseVersion.DateOfInjury,
				whereEventOccurred = caseVersion.WhereEventOccurred,
				caseClassification = (int)caseVersion.CaseClassification,
				daysAwayFromWork = (caseVersion.CaseClassification == InjuryConstants.CaseClassificationType.DaysAwayFromWork) ? caseVersion.DaysLost : null,
				daysTransferred = (caseVersion.CaseClassification == InjuryConstants.CaseClassificationType.JobTransfer) ? caseVersion.DaysLost : null,
				dateOfDeath = (caseVersion.CaseClassification == InjuryConstants.CaseClassificationType.Death) ? caseVersion.DateOfDeath : null,
				typeOfIllness = (int)caseVersion.TypeOfIllness,
				address1 = caseVersion.Address1,
				address2 = caseVersion.Address2,
				city = caseVersion.City,
				state = caseVersion.State,
				zipCode = caseVersion.ZipCode,
				birth = new GDWDateObject( caseVersion.DateOfBirth ),
				hcName = caseVersion.HCName,
				hcAddress1 = caseVersion.HCAddress1,
				hcAddress2 = caseVersion.HCAddress2,
				hcCity = caseVersion.HCCity,
				hcState = caseVersion.HCState,
				hcZipCode = caseVersion.HCZipCode,
				hcEmergencyRoom = caseVersion.HCEmergencyRoom,
				hcHospitalized = caseVersion.HCHospitalized,
				startWorkTime = caseVersion.StartWorkTime,
				eventTime = caseVersion.EventTime,
				locationID = caseVersion.LocationID,
				isPrivacy = caseVersion.IsPrivacy,
				hcPhysician = caseVersion.HCPhysician,
				mdAddress1 = caseVersion.MDAddress1,
				mdAddress2 = caseVersion.MDAddress2,
				mdCity = caseVersion.MDCity,
				mdState = caseVersion.MDState,
				mdZipCode = caseVersion.MDZipCode,
				summaryDescription = caseVersion.SummaryDescription,
				doingActivity = caseVersion.DoingActivity,
				whatHappened = caseVersion.WhatHappened,
				injuryOrIllness = caseVersion.InjuryOrIllness,
				objectHarmedEmployee = caseVersion.ObjectHarmedEmployee,

				dateHired = caseVersion.InjuredUser.HireDate.HasValue ? caseVersion.InjuredUser.HireDate.Value.ToShortDateString() : "",
				gender = caseVersion.InjuredUser.Gender.ToString(),
				completedByName = caseVersion.EnteredByUser.FullName,
				completedByPhone = caseVersion.EnteredByUser.PhoneNumber,
				completedOnDate = caseVersion.EnteredOnDate.ToShortDateString()
			};
		}

		public InjuryInformation GetInjuryCase( int id )
		{
			var injuryCase = database.InjuryIncidents.FirstOrDefault( ii => ii.IncidentID == id );
			if( injuryCase != null )
			{
				var caseVersion = injuryCase.InjuryIncidentVersions
					.OrderByDescending( iiv => iiv.VersionID )
					.FirstOrDefault();
				if( caseVersion != null )
				{
					return ToInjuryInformation( caseVersion );
				}
			}

			throw new NotImplementedException();
		}

		public List<InjuryInformation> GetInjuryCase( string startDate, string endDate, int locationId, int customerId, string activeState )
		{
			var sDate = new DateTime( int.Parse( startDate.Substring( 4, 4 ) ), int.Parse( startDate.Substring( 0, 2 ) ), int.Parse( startDate.Substring( 2, 2 ) ) );
			var eDate = new DateTime( int.Parse( endDate.Substring( 4, 4 ) ), int.Parse( endDate.Substring( 0, 2 ) ), int.Parse( endDate.Substring( 2, 2 ) ) );

			return database.InjuryIncidents
				.Include( ii => ii.InjuryIncidentVersions )
				.Where( ii => ii.CustomerID == customerId )
				.Select( ii => ii.InjuryIncidentVersions.OrderByDescending( iiv => iiv.VersionID ).FirstOrDefault() )
				.AsQueryable()
				.Include( iiv => iiv.InjuredUser )
				.Include( iiv => iiv.EnteredByUser )
				.Where( iiv => iiv.DateOfInjury >= sDate && iiv.DateOfInjury <= eDate && (locationId == 0 || iiv.LocationID == locationId) )
				.Where( iiv => (iiv.InjuredUser.IsDeleted && activeState == "inactive") || (!iiv.InjuredUser.IsDeleted && activeState == "active") || (activeState == "all") )
				.ToList()
				.Select( iiv => ToInjuryInformation( iiv ) )
				.ToList();

			throw new NotImplementedException();
		}

		public IEnumerable<int> GetInjuryYearList( int customerId )
		{
			var injuryDates = database.InjuryIncidents
				.Where( ii => ii.CustomerID == customerId )
				.Select( ii => ii.InjuryIncidentVersions
					.OrderByDescending( iiv => iiv.VersionID )
					.FirstOrDefault() )
				.Select( iiv => iiv.DateOfInjury );

			var retList = new List<int>();
			if( injuryDates.Any() )
			{
				var firstDate = injuryDates.Min();

				for( int i = firstDate.Year; i <= DateTime.Now.Year; i++ )
				{
					retList.Add( i );
				}
			}

			return retList;
		}

		public InjuryDetailList GetInjuryCases( int customerId, int year, int locationId, bool showPrivacyForms, string activeState )
		{
			var startDate = new DateTime( year, 1, 1 );
			var endDate = startDate.AddYears( 1 );

			var dbCustomer = database.Customers.FirstOrDefault( c => c.CustomerID == customerId );
			var dbLocation = dbCustomer.CustomerLocations.FirstOrDefault( l => l.LocationID == locationId );

			var retList = new InjuryDetailList()
			{
				year = year,
				customerName = dbCustomer.Name,
				customerAddress = dbCustomer.Address1 + " " + dbCustomer.Address2,
				customerCity = dbCustomer.City,
				customerState = dbCustomer.State,
				customerZipCode = dbCustomer.ZipCode,
				locationName = dbLocation.Name,
				locationAddress = dbLocation.Address1 + " " + dbLocation.Address2,
				locationCity = dbLocation.City,
				locationState = dbLocation.State,
				locationZipCode = dbLocation.ZipCode
			};

			var injuryVersionList = database.InjuryIncidents
				.Include( ii => ii.InjuryIncidentVersions )
				.Where( ii => ii.CustomerID == customerId )
				.Select( ii => ii.InjuryIncidentVersions.OrderByDescending( iiv => iiv.VersionID ).FirstOrDefault() )
				.AsQueryable()
				.Include( iiv => iiv.InjuredUser )
				.Where( iiv => iiv.LocationID == locationId )
				.Where( iiv => iiv.DateOfInjury >= startDate && iiv.DateOfInjury < endDate );

			switch( (activeState ?? "active").ToLower() )
			{
				case "active":
					injuryVersionList = injuryVersionList.Where( u => !u.InjuredUser.IsDeleted );
					break;
				case "inactive":
					injuryVersionList = injuryVersionList.Where( u => u.InjuredUser.IsDeleted );
					break;
				case "all":
					break;
			}

			retList.AddRange( injuryVersionList.ToList()
				.OrderBy( iiv => iiv.DateOfInjury )
				.Select( iiv => new InjuryDetail()
			{
				caseNumber = iiv.IncidentID,
				employeeName = showPrivacyForms ? iiv.InjuredUser.FullName : "Privacy Case",
				jobTitle = iiv.JobTitle,
				dateOfInjury = iiv.DateOfInjury.ToShortDateString(),
				whereOccurred = iiv.WhereEventOccurred,
				describeInjury = iiv.SummaryDescription,
				caseClassification = iiv.CaseClassification,
				daysAwayFromWork = iiv.CaseClassification == InjuryConstants.CaseClassificationType.DaysAwayFromWork ? (iiv.DaysLost ?? 0) : 0,
				daysTransferred = iiv.CaseClassification == InjuryConstants.CaseClassificationType.JobTransfer ? (iiv.DaysLost ?? 0) : 0,
				injuryType = iiv.TypeOfIllness
			} ) );

			return retList;
		}
	}
}
