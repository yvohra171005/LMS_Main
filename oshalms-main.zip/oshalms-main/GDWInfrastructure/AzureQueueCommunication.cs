﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;
using Microsoft.WindowsAzure;

namespace GDWInfrastructure
{
	public class AzureQueueCommunication
	{
		public static readonly string PDFQueueName = "PDFQueue";

		public void GetInvoice( string inputFileName, string outputFileName, string homeURL, 
			string directoryName, string orientation = "Portrait", bool includeFooter = false,
			string emailAddresses = null, float topPadding = 0f )
		{
			string connectionString = ConfigurationHelper.GetServiceBusConnectionString();

			QueueClient Client = QueueClient.CreateFromConnectionString( connectionString, PDFQueueName );

			BrokeredMessage message = new BrokeredMessage( Guid.NewGuid().ToString() );

			// Set some addtional custom app-specific properties
			message.Properties["InputFileName"] = inputFileName;
			message.Properties["OutputFileName"] = outputFileName;
			message.Properties["HomeURL"] = homeURL;
			message.Properties["DirectoryName"] = directoryName;
			message.Properties["Orientation"] = orientation;
			message.Properties["IncludeFooter"] = includeFooter;
			message.Properties["EmailAddresses"] = emailAddresses;
			message.Properties["TopPadding"] = topPadding;

			// Send message to the queue
			Client.Send( message );
		}
	}
}
