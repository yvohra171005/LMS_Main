﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GDWDatabase;

namespace GDWInfrastructure
{
	public class ReportDefinition
	{
		public class ReportFilterSet
		{
			public ReportFilterSet()
			{
				dateRange = false;
				customer = false;
				oshaClasses = false;
				sortBy = false;
				classes = false;
				language = false;
				employees = false;
				sortByValues = new List<GDWStringListItem>();
			}

			public bool dateRange { get; set; }
			public bool customer { get; set; }
			public bool oshaClasses { get; set; }
			public bool sortBy { get; set; }
			public bool classes { get; set; }
			public bool language { get; set; }
			public bool employees { get; set; }
			public List<GDWStringListItem> sortByValues { get; set; }
		}

		public ReportDefinition()
		{
			sortByKeys = new List<string>();
			creditBased = false;
		}

		public int reportId { get; set; }
		public string nameKey { get; set; }
		public string descriptionKey { get; set; }
		public GDWPermissionTypes.Permissions requiredPermission { get; set; }
		public ReportFilterSet filterSet { get; set; }
		public List<string> sortByKeys { get; set; }
		public string viewURL { get; set; }
		public string downloadURL { get; set; }
		public bool creditBased { get; set; }

		public static IEnumerable<ReportDefinition> GetFullList()
		{
			return new List<ReportDefinition>()
			{
				new ReportDefinition() { reportId = 1, nameKey = "CustomerCreditReport", descriptionKey = "", 
					requiredPermission = GDWPermissionTypes.Permissions.ManageCustomerAccount,
					filterSet = new ReportFilterSet() { dateRange = true, customer = true, sortBy = true }, 
					sortByKeys = new List<string>() { "Alphabetical", "CreditsPurchased" },
					viewURL = "/Report/CustomerCreditReport", downloadURL = "/Report/DownloadCustomerCreditReport" },

				new ReportDefinition() { reportId = 2, nameKey = "SystemWideClassReport", descriptionKey = "", 
					requiredPermission = GDWPermissionTypes.Permissions.ImpersonateCustomer,
					filterSet = new ReportFilterSet() { oshaClasses = true, classes = true, sortBy = true }, 
					sortByKeys = new List<string>() { "Alphabetical", "Assignments" },
					viewURL = "/Report/SystemWideClassReport", downloadURL = "/Report/DownloadSystemWideClassReport" },

				new ReportDefinition() { reportId = 3, nameKey = "CustomerClassReport", descriptionKey = "", 
					requiredPermission = GDWPermissionTypes.Permissions.ImpersonateCustomer,
					filterSet = new ReportFilterSet() { dateRange = true, customer = true, sortBy = true, employees = true }, 
					sortByKeys = new List<string>() { "Alphabetical", "Assignments" },
					viewURL = "/Report/CustomerClassReport", downloadURL = "/Report/DownloadCustomerClassReport" },

				new ReportDefinition() { reportId = 4, nameKey = "CustomerSummaryReport", descriptionKey = "", 
					requiredPermission = GDWPermissionTypes.Permissions.ManageCustomerAccount,
					filterSet = new ReportFilterSet() { dateRange = true, customer = true, sortBy = true, employees = true }, 
					sortByKeys = new List<string>() { "Alphabetical", "Credits", "VideoViews", "QuizzesPassed" },
					viewURL = "/Report/CustomerSummaryReport", downloadURL = "/Report/DownloadCustomerSummaryReport" },

				new ReportDefinition() { reportId = 5, nameKey = "ClassReport", descriptionKey = "", 
					requiredPermission = GDWPermissionTypes.Permissions.ViewEmployee,
					filterSet = new ReportFilterSet() { dateRange = true, oshaClasses = true, classes = true, sortBy = true, language = true }, 
					sortByKeys = new List<string>() { "Alphabetical", "Assignments", "VideoViews" },
					viewURL = "/Report/COClassReport", downloadURL = "/Report/DownloadCOClassReport" },

				new ReportDefinition() { reportId = 6, nameKey = "CreditSummary", descriptionKey = "", 
					requiredPermission = GDWPermissionTypes.Permissions.ViewEmployee,
					filterSet = new ReportFilterSet() { dateRange = true, employees = true }, 
					viewURL = "/Report/COCreditSummary", downloadURL = "/Report/DownloadCOCreditSummary", creditBased = true },

				new ReportDefinition() { reportId = 7, nameKey = "PurchaseListing", descriptionKey = "", 
					requiredPermission = GDWPermissionTypes.Permissions.ManageCustomerAccount,
					filterSet = new ReportFilterSet() { dateRange = true, customer = true }, 
					viewURL = "/Report/PurchaseReport", downloadURL = "/Report/DownloadPurchaseReport" },

				new ReportDefinition() { reportId = 8, nameKey = "SnapshotReport", descriptionKey = "", 
					requiredPermission = GDWPermissionTypes.Permissions.ViewEmployee,
					filterSet = new ReportFilterSet() { dateRange = true, employees = true, classes = true, oshaClasses = true }, 
					viewURL = "/Report/SnapshotReport", downloadURL = "/Report/DownloadSnapshotReport" },

			};
		}
	}
}
