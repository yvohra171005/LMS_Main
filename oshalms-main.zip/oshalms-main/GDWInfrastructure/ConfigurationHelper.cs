﻿using System.Configuration;
using System.Net;
using System.Net.Mail;

namespace GDWInfrastructure
{
	public static class ConfigurationHelper
	{
		public static string GetStorageConnectionString()
		{
			return ConfigurationManager.AppSettings["StorageConnectionString"];
		}

		public static string GetBaseSiteURL()
		{
			return ConfigurationManager.AppSettings["BaseSiteURL"];
		}

		public static string GetGatewayAPILogin()
		{
			return ConfigurationManager.AppSettings["GatewayAPILogin"];
		}

		public static string GetGatewayTransactionKey()
		{
			return ConfigurationManager.AppSettings["GatewayTransKey"];
		}

		public static bool GetGatewayMode()
		{
			return ConfigurationManager.AppSettings["GatewayTestMode"] == "true";
		}

		public static string GetServiceBusConnectionString()
		{
			return ConfigurationManager.AppSettings["Microsoft.ServiceBus.ConnectionString"];
		}

		public static string GetMediaServiceTenantDomain()
		{
			return ConfigurationManager.AppSettings["MediaServiceTenantDomain"];
		}

		public static string GetMediaServiceClientID()
		{
			return ConfigurationManager.AppSettings["MediaServiceClientID"];
		}

		public static string GetMediaServiceClientKey()
		{
			return ConfigurationManager.AppSettings["MediaServiceClientKey"];
		}

		public static string GetMediaServiceEndpoint()
		{
			return ConfigurationManager.AppSettings["MediaServiceEndpoint"];
		}

		public static string GetScormCloudUsername()
        {
			return ConfigurationManager.AppSettings["ScormCloudUsername"];
        }

		public static string GetScormCloudPassword()
        {
			return ConfigurationManager.AppSettings["ScormCloudPassword"];
        }
	}
}