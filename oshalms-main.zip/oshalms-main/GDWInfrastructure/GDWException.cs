﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWInfrastructure
{
	public class GDWException : ApplicationException
	{
		public string StringID { get; private set; }

		public GDWException( string stringId )
			: base( stringId )
		{
			StringID = stringId;
		}
	}

	public class GDWEnglishException : ApplicationException
	{
		public GDWEnglishException( string errorMessage )
			: base( errorMessage )
		{
		}
	}
}
