﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Xml.Serialization;
using GDWDatabase;

namespace GDWInfrastructure
{
	public class GDWWebUser : IPrincipal
	{
		private const string ImpersonateDataCookie = "GDWImp";
		
		public class GDWImpersonateData
		{
			private const string MKProtectPurpose = "GDWImpersonate";

			public int customerId { get; set; }
			public string customerName { get; set; }
			public string enterpriseLevel { get; set; }

			public string SerializeObject()
			{
				XmlSerializer xmlSerializer = new XmlSerializer( this.GetType() );

				using( StringWriter textWriter = new StringWriter() )
				{
					xmlSerializer.Serialize( textWriter, this );

					return Convert.ToBase64String( MachineKey.Protect( UTF8Encoding.UTF8.GetBytes( textWriter.ToString() ), MKProtectPurpose ) );
				}
			}

			public static GDWImpersonateData DeserializeObject( string toDeserialize )
			{
				XmlSerializer xmlSerializer = new XmlSerializer( typeof( GDWImpersonateData ) );

				using( StringReader textReader = new StringReader( UTF8Encoding.UTF8.GetString( MachineKey.Unprotect( Convert.FromBase64String( toDeserialize ), MKProtectPurpose ) ) ) )
				{
					return xmlSerializer.Deserialize( textReader ) as GDWImpersonateData;
				}
			}
		}

		private class GDWWebIdentity : IIdentity
		{
			public GDWWebIdentity( string userName, string authType )
			{
				Name = userName;
				AuthenticationType = authType;
			}

			#region IIdentity Members

			public string Name { get; private set; }
			public string AuthenticationType { get; private set; }
			public bool IsAuthenticated { get { return true; } }

			#endregion
		}

		public GDWWebUser( string userName, string authType, int userId, string firstName, string lastName, string resClass,
			IEnumerable<GDWPermissionTypes.Permissions> permissions, int? customerID, string enterpriseLevel )
        {
			_identity = new GDWWebIdentity( userName, authType );
            UserId = userId;
			FirstName = firstName;
			LastName = lastName;
			ResourceClass = resClass;
			_permissionList = new List<GDWPermissionTypes.Permissions>( permissions );
			_customerID = customerID;
			_enterpriseLevel = enterpriseLevel;
        }

		public void ImpersonateCustomer( int customerId, string customerName, string enterpriseLevel )
		{
			var newCookie = new HttpCookie( ImpersonateDataCookie, new GDWImpersonateData() { customerId = customerId, customerName = customerName, enterpriseLevel = enterpriseLevel }.SerializeObject() );
			
			HttpContext.Current.Response.AppendCookie( newCookie );
		}

		public void ClearImpersonate()
		{
			if( HttpContext.Current.Request.Cookies[ImpersonateDataCookie] != null )
			{
				HttpCookie myCookie = new HttpCookie( ImpersonateDataCookie );
				myCookie.Expires = DateTime.Now.AddDays( -1d );
				HttpContext.Current.Response.Cookies.Add( myCookie );
			}
		}

		private GDWWebIdentity _identity { get; set; }
		public int UserId { get; private set; }
		public string FullName { get { return FirstName + " " + LastName; } }
		public string FirstName { get; private set; }
		public string LastName { get; private set; }
		public string ResourceClass { get; private set; }
		private List<GDWPermissionTypes.Permissions> _permissionList { get; set; }
		private int? _customerID { get; set; }
		private string _enterpriseLevel { get; set; }

		public int? CustomerID
		{
			get
			{
				if( HttpContext.Current.Request != null )
				{
					if( HttpContext.Current.Request.Cookies[ImpersonateDataCookie] != null )
					{
						var impData = GDWImpersonateData.DeserializeObject( HttpContext.Current.Request.Cookies[ImpersonateDataCookie].Value );
						if( impData != null )
						{
							return impData.customerId;
						}
					}
				}
				return _customerID;
			}
		}

		public string EnterpriseLevel
		{
			get
			{
				if( HttpContext.Current.Request != null )
				{
					if( HttpContext.Current.Request.Cookies[ImpersonateDataCookie] != null )
					{
						var impData = GDWImpersonateData.DeserializeObject( HttpContext.Current.Request.Cookies[ImpersonateDataCookie].Value );
						if( impData != null )
						{
							return impData.enterpriseLevel;
						}
					}
				}
				return _enterpriseLevel;
			}
		}

		public List<GDWPermissionTypes.Permissions> PermissionList
		{
			get
			{
				if( IsImpersonating )
				{
					return GDWPermissionTypes.ImpersonateList.ToList();
				}
				return _permissionList;
			}
		}
		public bool IsImpersonating
		{
			get
			{
				if( HttpContext.Current.Request != null )
				{
					if( HttpContext.Current.Request.Cookies[ImpersonateDataCookie] != null )
					{
						var impData = GDWImpersonateData.DeserializeObject( HttpContext.Current.Request.Cookies[ImpersonateDataCookie].Value );
						if( impData != null )
						{
							return true;
						}
					}
				}

				return false;
			}
		}
		public string ICustomerName
		{
			get
			{
				if( IsImpersonating )
				{
					var impData = GDWImpersonateData.DeserializeObject( HttpContext.Current.Request.Cookies[ImpersonateDataCookie].Value );
					if( impData != null )
					{
						return impData.customerName;
					}
				}
				return null;
			}
		}

		#region IPrincipal Members

		public IIdentity Identity
		{
			get { return _identity; }
		}

		public bool IsInRole( string role )
		{
			return true;
		}

		#endregion

		public static GDWWebUser CurrentUser
		{
			get
			{
				return HttpContext.Current.User as GDWWebUser;
			}
		}

		public string GetResourceString( string stringId )
		{
			return OSHALMSStrings.StringManager.GetStringFromResourceFile( ResourceClass, stringId );
		}

		public bool HasPermission( IEnumerable<GDWPermissionTypes.Permissions> permissions )
		{
			return PermissionList.Intersect( permissions ).Any();
		}

		public bool HasPermission( GDWPermissionTypes.Permissions permission )
		{
			return PermissionList.Contains( permission );
		}

		public bool HasReportMenuOption()
		{
			return HasPermission( ReportDefinition.GetFullList().Select( r => r.requiredPermission ) );
		}
	}
}