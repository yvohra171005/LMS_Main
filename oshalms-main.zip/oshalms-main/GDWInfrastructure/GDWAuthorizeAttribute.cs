﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using GDWDatabase;

namespace GDWInfrastructure
{
	public class GDWAuthorizeAttribute : AuthorizeAttribute
	{
		protected List<GDWPermissionTypes.Permissions> RequiredPermissions { get; set; }
		public GDWAuthorizeAttribute( params GDWPermissionTypes.Permissions[] permissions )
		{
			RequiredPermissions = new List<GDWPermissionTypes.Permissions>( permissions );
		}

		protected override bool AuthorizeCore( System.Web.HttpContextBase httpContext )
		{
			if( !httpContext.User.Identity.IsAuthenticated )
				return false;

			if( !RequiredPermissions.Any() )
				return true;

			var currentUser = GDWWebUser.CurrentUser;

			if( currentUser != null )
				return currentUser.HasPermission( RequiredPermissions );

			return false;
		}

		protected override void HandleUnauthorizedRequest( AuthorizationContext filterContext )
		{
			if( filterContext.HttpContext.User.Identity.IsAuthenticated )
			{
				var urlHelper = new UrlHelper( filterContext.RequestContext );
				filterContext.Result = new RedirectResult( urlHelper.Action( "DoLogout", "Account" ), false );
			}
			else
			{
				base.HandleUnauthorizedRequest( filterContext );
			}
		}
	}
}
