﻿using System;
using System.Globalization;
using System.IO;

namespace GDWInfrastructure
{
    public static class PrimitiveExtensions
    {
        private static readonly TimeZoneInfo EasternTzInfo;

        static PrimitiveExtensions()
        {
            EasternTzInfo = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time") ?? TimeZoneInfo.Local;
        }

        public static string ToCurrency( this decimal v )
        {
            return v.ToString( "C" );
        }

        public static string Truncate( this string value, int maxLength )
        {
            if ( value == null || value.Length <= maxLength )
                return value;

            var idx = StringInfo.ParseCombiningCharacters( value );
            if ( idx.Length <= maxLength )
                return value;

            return value.Substring( 0, idx[maxLength] );
        }

        public static string SanitizeForFileName( this string fileName, int maxLength = 0 )
        {
            if ( fileName == null )
                return null;

            var newName = fileName.Trim( '"', '\'' ).Trim();
            var invalids = Path.GetInvalidFileNameChars();
            newName = string.Join( "_", newName.Split( invalids, StringSplitOptions.RemoveEmptyEntries ) );
            if ( maxLength > 0 && newName.Length > maxLength )
                newName = newName.Truncate( maxLength );
            return newName.TrimEnd( '.', '/', '\\', ' ' );
        }

        public static DateTime ConvertFromEasternTime(this DateTime value)
        {
            if (value.Kind == DateTimeKind.Utc)
                return value;

            var dt = DateTime.SpecifyKind(value, DateTimeKind.Unspecified);
            return TimeZoneInfo.ConvertTimeToUtc(dt, EasternTzInfo);
        }

        public static DateTime? ConvertFromEasternTime(this DateTime? value)
        {
            if (!value.HasValue || value.Value.Kind == DateTimeKind.Utc)
                return value;

            var dt = DateTime.SpecifyKind(value.Value, DateTimeKind.Unspecified);
            return TimeZoneInfo.ConvertTimeToUtc(dt, EasternTzInfo);
        }
        
        public static DateTime ConvertToEasternTime(this DateTime value)
        {
            if (value.Kind != DateTimeKind.Utc)
                return value;

            var dt = DateTime.SpecifyKind(value, DateTimeKind.Unspecified);
            return TimeZoneInfo.ConvertTimeFromUtc(dt, EasternTzInfo);
        }
        
        public static DateTime? ConvertToEasternTime(this DateTime? value)
        {
            return !value.HasValue ? (DateTime?)null : value.Value.ConvertToEasternTime();
        }

        // For date-only values, force to unspecified time zone to prevent unwanted time zone adjustments.
        public static DateTime RemoveTimeAndTimeZone(this DateTime value)
        {
            return DateTime.SpecifyKind(value.Date, DateTimeKind.Unspecified);
        }

        // For date-only values, force to unspecified time zone to prevent unwanted time zone adjustments.
        public static DateTime? RemoveTimeAndTimeZone(this DateTime? value)
        {
            return value.HasValue ? RemoveTimeAndTimeZone(value.Value) : (DateTime?) null;
        }

        public static DateTime? SpecifyAsUtc(this DateTime? value)
        {
            return value.HasValue ? SpecifyAsUtc(value.Value) : (DateTime?) null;
        }

        public static DateTime SpecifyAsUtc(this DateTime value)
        {
            return DateTime.SpecifyKind(value, DateTimeKind.Utc);
        }
    }
}