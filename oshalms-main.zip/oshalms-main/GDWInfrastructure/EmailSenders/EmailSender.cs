﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;
using System.IO;
using System.Text.RegularExpressions;

namespace GDWInfrastructure.EmailSenders
{
	public abstract class EmailSender
	{
		protected string languageString { get; set; }

		public EmailSender( string language )
		{
			languageString = language;
		}

		protected EmailSender()
		{
		}

		protected bool SubmitEmail(
			IList<string> toList,
			IList<string> ccList,
			IList<string> bccList,
			string messageSubject,
			StringBuilder messageBodyTemplate,
			Stream file = null,
			string fileName = null )
		{
			MailMessage msg = new MailMessage();

			if( (toList != null) && toList.Any() )
				msg.To.Add( string.Join( ",", toList ) );
			else
				return false;

			if( ccList != null )
				msg.CC.Add( string.Join( ",", ccList ) );
			if( bccList != null )
				msg.Bcc.Add( string.Join( ",", bccList ) );

			msg.Subject = messageSubject;
			msg.Body = messageBodyTemplate.ToString();
			msg.From = new MailAddress( "noreply@gooddayswork.ag", "Good Day's Work" );
			msg.ReplyToList.Add( msg.From );
			msg.IsBodyHtml = true;
			if( file != null )
			{
				msg.Attachments.Add( new Attachment( file, fileName ?? "file" ) );
			}

			try
			{
				SmtpClient smtp = new SmtpClient();

				smtp.Send( msg );

				return true;
			}
			catch( Exception e )
			{
				System.Diagnostics.Debug.WriteLine( "Unable to send email: {0}", e.Message );
			}

			return false;
		}

		protected abstract Dictionary<string, string> TemplateTextMap { get; }

		protected StringBuilder ReadEmailTemplate()
		{
			try
			{
				var templateText = "";
				if( TemplateTextMap.Keys.Contains( languageString ) )
				{
					templateText = TemplateTextMap[languageString];
				}
				else
				{
					templateText = TemplateTextMap[TemplateTextMap.Keys.First()];
				}

				var template = new StringBuilder( templateText );

				template.Replace( "[{BaseSiteURL}]", ConfigurationHelper.GetBaseSiteURL() );

				return template;
			}
			catch( Exception ex )
			{
				System.Diagnostics.Debug.WriteLine( "Unable to read email template: {0}", ex.Message );
				throw ex;
			}
		}

		protected string GetSubject( StringBuilder template )
		{
			string pattern = Regex.Escape( "<title>" ) + "(.*?)" + Regex.Escape( "</title>" );
			var matching = Regex.Match( template.ToString(), pattern, RegexOptions.Singleline | RegexOptions.IgnoreCase );

			if( matching.Success )
			{
				return matching.Groups[1].ToString();
			}

			return "Good Day's Work Email";
		}
/*
		protected void PerformMachineNameAdditions( StringBuilder template )
		{
			var extraInfo = "";
			if( Environment.MachineName.ToLower().Contains( "matt3400" ) )
				extraInfo = "<p>(from Matt's Development machine)</p>";
			else if( Environment.MachineName.ToLower().Contains( "paoli-test01" ) )
				extraInfo = "<p>(from WDD Test Server)</p>";

			template.Replace( "[{MachineName}]", extraInfo );
		}
 */
	}
}
