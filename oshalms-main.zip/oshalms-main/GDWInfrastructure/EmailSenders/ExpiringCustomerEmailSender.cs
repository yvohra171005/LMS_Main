﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWInfrastructure.EmailSenders
{
	public class ExpiringCustomerEmailSender : EmailSender
	{
		public ExpiringCustomerEmailSender( string language )
			: base( language )
		{
		}

		public bool SubmitExpiringSoonWarningEmail(
			string emailAddress,
			int days )
		{
			try
			{
				var template = ReadEmailTemplate();

				// perform substitutions
				template.Replace( "[{Days}]", days.ToString() );

				return SubmitEmail( new List<string>() { emailAddress }, null, null, GetSubject( template ), template );
			}
			catch( Exception ex )
			{
				System.Diagnostics.Debug.WriteLine( "Unable to send email: {0}", ex.Message );
			}

			return false;
		}

		protected override Dictionary<string, string> TemplateTextMap
		{
			get
			{
				return new Dictionary<string, string>() { { "EnglishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Account Expiring Soon on Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hello,</p>
	<p>We wanted to let you know that your account with Good Day's Work will be expiring in less than [{Days}] days.</p>
	<p>Please visit [{BaseSiteURL}]/#/myaccount to renew your account before it expires.</p>
	<p>Thank you,</p>
	<p>Good Day's Work</p>
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" }, { "SpanishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Tu Cuenta en Good Day's Work se Vencerá Pronto</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hola,</p>
	<p>Queremos informarte que tu cuenta con Good Day's Work se vencerá en menos de [{Days}] días.</p>
	<p>Por favor visita [{BaseSiteURL}]/#/myaccount para renovar tu cuenta antes de que finalice.</p>
	<p>Gracias,</p>
	<p>Good Day's Work</p>

    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" }  };
			}
		}

	}
}
