﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWInfrastructure.EmailSenders
{
    public class NewAccountDocumentSender : EmailSender
    {
		public NewAccountDocumentSender( string language )
			: base( language )
		{
		}

        public bool SubmitNewAccountDocumentEmail(
            string emailAddress)
        {
            try
            {
                var template = ReadEmailTemplate();

                // perform substitutions
                template.Replace("[{DeskStartupURL}]", "https://gooddayswork.desk.com/customer/portal/articles/2029003-account-setup-guide" );
                
                return SubmitEmail(new List<string>() { emailAddress }, null, null, GetSubject(template), template);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Unable to send email: {0}", ex.Message);
            }

            return false;
        }

		protected override Dictionary<string, string> TemplateTextMap
		{
            get
            {
                return new Dictionary<string, string>() { { "EnglishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Startup Information for Your New Account on Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hello,</p>
	<p><strong>Welcome</strong></p>
    <p>Thank you for selecting Good Day's Work as your ag safety training and compliance system.</p>
    <p>Listen, we’re farm kids too. We know what it’s like to get a new piece of equipment and have the urge to just hop on and see what it can do. The operations manual can wait, right?</p>
    <p>But this software breaks the mold a little bit.</p>
    <p><strong>For Your Best User Experience</strong></p>
    <p>We strongly encourage you to download and print our step-by-step <a href=""[{DeskStartupURL}]"">Account Setup Guide</a>, so you can have it on hand when you log in for the first time.</p>
    <p>Using it is the easiest, most convenient way to get started, and the fastest way to get back to your other more pressing duties.</p>
    <p><strong>Questions? We’re here to help.</strong></p>
    <p>If you’d prefer to have a member of our team walk you through the setup process, just send an e-mail to support@gooddayswork.ag or give us a call, toll-free, at 1-844-GDW-SAFE (1-844-439-7233).</p>
    <p>You’ll be assigning videos and meeting compliance standards in no time! Thanks again.</p>
    <p><strong><a href=""[{DeskStartupURL}]"">Take me to my Account Setup Guide!</a></strong></p>
	<p>Thank you,</p>
	<p>Good Day's Work</p>
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" } };
            }
        }
    }
}