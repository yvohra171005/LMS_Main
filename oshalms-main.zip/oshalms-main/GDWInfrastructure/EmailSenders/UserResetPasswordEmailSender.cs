﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWInfrastructure.EmailSenders
{
	public class UserResetPasswordEmailSender : EmailSender
	{
		public UserResetPasswordEmailSender( string language )
			: base( language )
		{
		}

		public bool SubmitPasswordChangeEmail(
			string emailAddress,
			Guid resetId,
            string firstName,
            string lastName )
		{
			try
			{
				var template = ReadEmailTemplate();

				// perform substitutions
				template.Replace( "[{ResetID}]", resetId.ToString() );
				template.Replace( "[{FirstName}]", firstName ?? string.Empty );
				template.Replace( "[{LastName}]", lastName ?? string.Empty );

				return SubmitEmail( new List<string>() { emailAddress }, null, null, GetSubject( template ), template );
			}
			catch( Exception ex )
			{
				System.Diagnostics.Debug.WriteLine( "Unable to send email: {0}", ex.Message );
			}

			return false;
		}

		protected override Dictionary<string, string> TemplateTextMap
		{
			get
			{
				return new Dictionary<string, string>() { { "EnglishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Reset Password for Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hello [{FirstName}] [{LastName}],</p>
	<p>As you requested, your password to GoodDaysWork.ag has been reset.</p>
	<p>Please visit [{BaseSiteURL}]/Account/NewPassword/[{ResetID}] to complete this process.</p>
	<p>For security reasons this link will expire 72 hours from when it was sent. After that, you'll need to click “Forgot Password” in the login page to generate a new link.</p>
	<p>Thank you,</p>
	<p>Good Day's Work</p>
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" }, { "SpanishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Restablecer contraseña para Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hola [{FirstName}] [{LastName}],</p>
	<p>Como tú lo solicitaste, tu contraseña para GoodDaysWork.ag ha sido restablecida.</p>
	<p>Por favor visita [{BaseSiteURL}]/Account/NewPassword/[{ResetID}] para completar el proceso.</p>
	<p>Por razones de seguridad este enlace solo es válido por 72 horas a partir de cuando fue enviado.  Después de eso, necesitarás hacer clic en “Olvidó Su Contraseña” en la página de entrada para crear un nuevo enlace.</p>
	<p>Gracias,</p>
	<p>Good Day's Work</p>
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" }  };
			}
		}
	}
}
