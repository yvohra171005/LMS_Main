﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWInfrastructure.EmailSenders
{
	public class NewPurchaseEmailSender : EmailSender
	{
		public NewPurchaseEmailSender()
			: base( "EnglishStrings" )
		{
		}

		public bool SubmitNewPurchaseEmail(
			IEnumerable<string> emailAddresses,
			Stream invoice )
		{
			try
			{
				var template = ReadEmailTemplate();

				// perform substitutions

				return SubmitEmail( emailAddresses.ToList(), null, null, GetSubject( template ), template, invoice, "invoice.pdf" );
			}
			catch( Exception ex )
			{
				System.Diagnostics.Debug.WriteLine( "Unable to send email: {0}", ex.Message );
			}

			return false;
		}

		protected override Dictionary<string, string> TemplateTextMap
		{
			get
			{
				return new Dictionary<string, string>() { { "EnglishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Invoice for new purchase on Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hello,</p>
	<p>Attached is a copy of the invoice for your recent purchase at Good Day's Work.</p>
	<p>Please visit <a href=""[{BaseSiteURL}]/#/myaccount"">here</a> to view additional details regarding this and other purchases.</p>
	<p>Thank you,</p>
	<p>Good Day's Work</p>
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" } };
			}
		}

	}
}
