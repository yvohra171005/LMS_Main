﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWInfrastructure.EmailSenders
{
	public class NewAccountEmailSender : EmailSender
	{
		public NewAccountEmailSender( string language )
			: base( language )
		{
		}

		public bool SubmitNewAccountEmail(
            string emailAddress,
			string userName,
			Guid resetId,
            string firstName,
            string lastName )
		{
			try
			{
				var template = ReadEmailTemplate();

				// perform substitutions
				template.Replace( "[{ResetID}]", resetId.ToString() );
				template.Replace( "[{UserName}]", userName );
				template.Replace( "[{FirstName}]", firstName ?? string.Empty );
				template.Replace( "[{LastName}]", lastName ?? string.Empty );

				return SubmitEmail( new List<string>() { emailAddress }, null, null, GetSubject( template ), template );
			}
			catch( Exception ex )
			{
				System.Diagnostics.Debug.WriteLine( "Unable to send email: {0}", ex.Message );
			}

			return false;
		}

		protected override Dictionary<string, string> TemplateTextMap
		{
			get
			{
				return new Dictionary<string, string>() { { "EnglishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Establish Password for Good Day’s Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hello [{FirstName}] [{LastName}],</p>
	<p>I'm excited to let you know that a new user account has been created for you at GoodDaysWork.ag.</p>
	<p>Your user name [{UserName}] has already been established.</p>
	<p>Please visit [{BaseSiteURL}]/Account/NewPassword/[{ResetID}] to establish your password.  For security reasons, this link is only good for 72 hours.</p>
	<p>For return visits to the site, use the following link to the login page: https://lms.gooddayswork.ag/Account/Login?ReturnUrl=%2f </p>
	<p>Thank you,</p>
	<p>Good Day's Work</p>
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" }, { "SpanishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Establecer contraseña para Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hola [{FirstName}] [{LastName}],</p>
	<p>Con gusto te informo que una nueva cuenta de usuario ha sido creada para ti en GoodDaysWork.ag.</p>
	<p>Tu nombre de usuario [{UserName}] ya ha sido establecido.</p>
	<p>Por favor visita [{BaseSiteURL}]/Account/NewPassword/[{ResetID}] para establecer tu contraseña.  Por razones de seguridad, este enlace solo es válido por 72 horas.</p>
	<p>Para visitar la pagina nuevamente, usa el siguiente enlace: https://lms.gooddayswork.ag/Account/Login?ReturnUrl=%2f</p>
	<p>Gracias,</p>
	<p>Good Day's Work</p>
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" }  };
			}
		}
	}
}
