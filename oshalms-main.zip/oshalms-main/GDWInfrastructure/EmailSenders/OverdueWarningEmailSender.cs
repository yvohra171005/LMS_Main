﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWInfrastructure.EmailSenders
{
	public class OverdueWarningEmailSender : EmailSender
	{
		public OverdueWarningEmailSender( string language )
			: base( language )
		{
		}

		private int DaysRemaining { get; set; }

		public bool SubmitOverdueWarningEmail(
			string emailAddress,
            string firstName,
            string lastName,
			int days,
			int userClassId,
			string className )
		{
			DaysRemaining = days;

			try
			{
				var template = ReadEmailTemplate();

				// perform substitutions
				template.Replace( "[{Days}]", days.ToString() );
				template.Replace( "[{UserClassID}]", userClassId.ToString() );
				template.Replace( "[{ClassName}]", className.ToString() );
				template.Replace( "[{FirstName}]", firstName ?? string.Empty );
				template.Replace( "[{LastName}]", lastName ?? string.Empty );

				return SubmitEmail( new List<string>() { emailAddress }, null, null, GetSubject( template ), template );
			}
			catch( Exception ex )
			{
				System.Diagnostics.Debug.WriteLine( "Unable to send email: {0}", ex.Message );
			}

			return false;
		}

		protected override Dictionary<string, string> TemplateTextMap
		{
			get
			{
				if( DaysRemaining > 0 )
				{
					return new Dictionary<string, string>() { { "EnglishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Class Nearing Due Date on Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hello [{FirstName}] [{LastName}],</p>
	<p>We wanted to let you know that [{ClassName}] is due in less than [{Days}] day(s).</p>
	<p>Please visit [{BaseSiteURL}]/#/myclasses/[{UserClassID}] to complete the class before the due date.</p>
	<p>Thank you,</p>
	<p>Good Day's Work</p>
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" }, { "SpanishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Ya casi es el último día para que tomes la clase en Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hola [{FirstName}] [{LastName}],</p>
	<p>Queremos informarte que te quedan menos de [{Days}] días para tomar la clase [{ClassName}].</p>
	<p>Por favor visita [{BaseSiteURL}]/#/myclasses/[{UserClassID}] para completar la clase antes de la fecha de vencimiento.</p>
	<p>Gracias,</p>
	<p>Good Day's Work</p>

    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" }  };
				}
				else
				{
					return new Dictionary<string, string>() { { "EnglishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Class Overdue on Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hello [{FirstName}] [{LastName}],</p>
	<p>We wanted to let you know that [{ClassName}] is now overdue based on the date set by your Safety Contact.</p>
	<p>Please visit [{BaseSiteURL}]/#/myclasses/[{UserClassID}] to complete the class as soon as possible.</p>
	<p>Thank you,</p>
	<p>Good Day's Work</p>
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" }, { "SpanishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Se pasó el último día para tomar la clase en Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hola [{FirstName}] [{LastName}],
	<p>Queremos informarte que de acuerdo con la fecha establecida por la persona encargada de seguridad, el último día para tomar la clase [{ClassName}] ya se pasó. 
	<p>Por favor visita [{BaseSiteURL}]/#/myclasses/[{UserClassID}] para completar la clase lo más pronto posible.
	<p>Gracias,
	<p>Good Day's Work
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" }  };
				}
			}
		}

	}
}
