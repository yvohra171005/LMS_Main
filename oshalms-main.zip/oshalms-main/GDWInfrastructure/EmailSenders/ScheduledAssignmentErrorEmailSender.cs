﻿using System;
using System.Collections.Generic;
using System.Text;

using OSHALMSStrings;

namespace GDWInfrastructure.EmailSenders
{
    public class ScheduledAssignmentErrorEmailSender : EmailSender
    {
		public ScheduledAssignmentErrorEmailSender( string language )
			: base( language )
		{
		}

		public bool SubmitScheduledAssignmentErrorEmail(
			string emailAddress,
            string className,
            DateTime dueDate,
            string locationNames,
            string departmentNames,
            IEnumerable<string> errorStringIds )
		{
			try
			{
				var template = ReadEmailTemplate();

				// perform substitutions
				template.Replace( "[{ClassName}]", className );
				template.Replace( "[{DueDate}]", dueDate.ToString("M/d/yyyy") );
				template.Replace( "[{LocationNames}]", locationNames );
				template.Replace( "[{DepartmentNames}]", departmentNames );
			    if (errorStringIds != null)
			    {
			        var sb = new StringBuilder();
			        foreach (var id in errorStringIds)
			        {
			            var errorString = StringManager.GetStringFromResourceFile(languageString, id);
			            if (!string.IsNullOrEmpty(errorString))
			                sb.Append("<li>").Append(errorString).Append("</li>");
			        }
				    template.Replace( "[{ErrorStringsListItems}]", sb.ToString() );
			    }
			    else
			    {
				    template.Replace( "[{ErrorStringsListItems}]", string.Empty );
			    }

				return SubmitEmail( new List<string>() { emailAddress }, null, null, GetSubject( template ), template );
			}
			catch( Exception ex )
			{
				System.Diagnostics.Debug.WriteLine( "Unable to send email: {0}", ex.Message );
			}

			return false;
		}

		protected override Dictionary<string, string> TemplateTextMap
		{
			get
			{
				return new Dictionary<string, string>() { { "EnglishStrings",
@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Scheduled Assignment Canceled on Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hello,</p>
	<p>We wanted to let you know that the following scheduled class assignment has not been completed due to errors.</p>
    <ul>
        <li>Class Name: [{ClassName}]</li>
        <li>Dute Date: [{DueDate}]</li>
        <li>Location Names: [{LocationNames}]</li>
        <li>Department Names: [{DepartmentNames}]</li>
        <li>Errors: <ul style='list-style-type: circle;'>[{ErrorStringsListItems}]</ul></li>
    </ul>
    <p>The system will continue to periodically attempt completion of this scheduled assignment in case you are able
       to correct the above error(s). Alternatively, you may delete this scheduled assignment if you know that the
       error(s) will not be corrected.</p>
	<p>Please visit [{BaseSiteURL}]/#/scheduled_assignments to manage scheduled class assignments.</p>
	<p>Thank you,</p>
	<p>Good Day's Work</p>
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" }  };
			}
		}
    }
}
