﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GDWInfrastructure.EmailSenders
{
	public class NewAssignmentEmailSender : EmailSender
	{
		public class NewAssignmentEmailDetail
		{
			public int userClassId { get; set; }
			public string className { get; set; }
		}

		public NewAssignmentEmailSender( string language )
			: base( language )
		{
		}

		public bool SubmitNewAssignmentEmail(
			string emailAddress,
            string firstName,
            string lastName,
			DateTime dueDate,
			IEnumerable<NewAssignmentEmailDetail> classes )
		{
			try
			{
				var template = ReadEmailTemplate();

				// perform substitutions
				template.Replace( "[{DueDate}]", dueDate.ToShortDateString() );
				template.Replace( "[{FirstName}]", firstName ?? string.Empty );
				template.Replace( "[{LastName}]", lastName ?? string.Empty );

				{
					string pattern = Regex.Escape( "[{NewClassTemplate}]" ) + "(.*?)" + Regex.Escape( "[{/NewClassTemplate}]" );
					var matching = Regex.Match( template.ToString(), pattern, RegexOptions.Multiline );

					string fullClassList = string.Empty;
					if( matching.Success )
					{
						foreach( var newClass in classes )
						{
							var newClassItem = matching.Groups[1].ToString();

							newClassItem = newClassItem.Replace( "[{ClassName}]", newClass.className );
							newClassItem = newClassItem.Replace( "[{UserClassID}]", newClass.userClassId.ToString() );
							
							fullClassList += newClassItem;
						}
					}
					template.Replace( "[{NewClassList}]", fullClassList );
				}

				return SubmitEmail( new List<string>() { emailAddress }, null, null, GetSubject( template ), template );
			}
			catch( Exception ex )
			{
				System.Diagnostics.Debug.WriteLine( "Unable to send email: {0}", ex.Message );
			}

			return false;
		}

		protected override Dictionary<string, string> TemplateTextMap
		{
			get
			{
				return new Dictionary<string, string>() { { "EnglishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>New Class Assignment on Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hello [{FirstName}] [{LastName}],</p>
	<p>We wanted to let you know that you have been assigned the following classes on GoodDaysWork.ag:</p>
	<p><ul>[{NewClassList}]</ul></p>
	<p>Each of these classes is due on [{DueDate}].</p>
	<p>Thank you,</p>
	<p>Good Day's Work</p>
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
<!-- [{NewClassTemplate}]<li><a href=""[{BaseSiteURL}]/#/myclasses/[{UserClassID}]"">[{ClassName}]</a></li>[{/NewClassTemplate}] -->
</body>
</html>" }, { "SpanishStrings", @"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Nueva Clase que Debes Tomar en Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hola [{FirstName}] [{LastName}],</p>
	<p>Queremos informarte que debes tomar las siguientes clases en GoodDaysWork.ag:</p>
	<p><ul>[{NewClassList}]</ul></p>
	<p>El último día para que tomes estas clases es [{DueDate}]</p>
	<p>Gracias,</p>
	<p>Good Day's Work</p>
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
<!-- [{NewClassTemplate}]<li><a href=""[{BaseSiteURL}]/#/myclasses/[{UserClassID}]"">[{ClassName}]</a></li>[{/NewClassTemplate}] -->
</body>
</html>" }  };
			}
		}

	}
}
