﻿using System;
using System.Collections.Generic;

namespace GDWInfrastructure.EmailSenders
{
    public class ScheduledAssignmentAbandonedEmailSender : EmailSender
    {
		public ScheduledAssignmentAbandonedEmailSender( string language )
			: base( language )
		{
		}

		public bool SubmitScheduledAssignmentAbandonedEmail(
			string emailAddress,
            string className,
            DateTime dueDate,
            string locationNames,
            string departmentNames )
		{
			try
			{
				var template = ReadEmailTemplate();

				// perform substitutions
				template.Replace( "[{ClassName}]", className );
				template.Replace( "[{DueDate}]", dueDate.ToString("M/d/yyyy") );
				template.Replace( "[{LocationNames}]", locationNames );
				template.Replace( "[{DepartmentNames}]", departmentNames );

				return SubmitEmail( new List<string>() { emailAddress }, null, null, GetSubject( template ), template );
			}
			catch( Exception ex )
			{
				System.Diagnostics.Debug.WriteLine( "Unable to send email: {0}", ex.Message );
			}

			return false;
		}

		protected override Dictionary<string, string> TemplateTextMap
		{
			get
			{
				return new Dictionary<string, string>() { { "EnglishStrings",
@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.01 Transitional//EN"" ""http://www.w3.org/TR/html4/loose.dtd"">
<html>
<!-- html tag will most likely be stripped so no inline styles here-->
<head>
    <!-- head tag will most likely be stripped so no inline styles here-->
    <meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/>
    <!-- can't hurt to keep the character encoding -->
    <title>Scheduled Assignment Canceled on Good Day's Work</title>
    <!-- Titles are the the intended Subject Line for the email -->
</head>
<body>
    <!-- body tag will most likely be stripped so no inline styles here either-->
    <!-- /////////////////////////////////////////////////////////-->
    <!-- START OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
	<p>Hello,</p>
	<p>We wanted to let you know that the following scheduled class assignment was canceled because the due date is in the past.</p>
    <ul>
        <li>Class Name: [{ClassName}]</li>
        <li>Dute Date: [{DueDate}]</li>
        <li>Location Names: [{LocationNames}]</li>
        <li>Department Names: [{DepartmentNames}]</li>
    </ul>
    <p>Any classes that have already been assigned to employees are not affected.</p>
	<p>Please visit [{BaseSiteURL}]/#/scheduled_assignments to view the status of scheduled class assignments.</p>
	<p>Thank you,</p>
	<p>Good Day's Work</p>
    <!-- /////////////////////////////////////////////////////////-->
    <!-- END OF CODE EMAIL CLIENTS WILL DEFINATELY RENDER-->
    <!-- /////////////////////////////////////////////////////////-->
</body>
</html>" }  };
			}
		}
    }
}
