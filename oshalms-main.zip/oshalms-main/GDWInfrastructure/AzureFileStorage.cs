﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;

namespace GDWInfrastructure
{
	public class AzureFileStorage
	{
		public long UploadFile( string containerName, string fileName, string mediaType, Stream fileContents )
		{			
			var blobClient = GetBlobClient();
			var container = blobClient.GetContainerReference( containerName.ToLowerInvariant() );
			if( container.CreateIfNotExist() )
			{
			}

			var blockBlob = container.GetBlockBlobReference( fileName );
			blockBlob.Properties.ContentType = mediaType;
	
			blockBlob.UploadFromStream( fileContents );

			return blockBlob.Properties.Length;
		}

		public string DownloadFileToStream( string containerName, string fileName, Stream stream )
		{
			var blobClient = GetBlobClient();
			var container = blobClient.GetContainerReference( containerName.ToLowerInvariant() );

			var blockBlob = container.GetBlockBlobReference( fileName );
			try
			{
				blockBlob.DownloadToStream( stream );
				stream.Seek( 0, SeekOrigin.Begin );

				return blockBlob.Properties.ContentType;
			}
			catch
			{
			}

			return null;
		}

		public void DeleteFile( string containerName, string fileName )
		{
			var blobClient = GetBlobClient();
			var container = blobClient.GetContainerReference( containerName.ToLowerInvariant() );

			var blockBlob = container.GetBlockBlobReference( fileName );
			try
			{
			    blockBlob.Delete();
			}
			catch
			{
			}
		}

		private CloudStorageAccount GetStorageAccount()
		{
			var connectionString = ConfigurationHelper.GetStorageConnectionString();
			var storageAccount = CloudStorageAccount.Parse( connectionString );
			return storageAccount;
		}

		private CloudBlobClient GetBlobClient()
		{
			var storageAccount = GetStorageAccount();
			var blobClient = storageAccount.CreateCloudBlobClient();
			return blobClient;
		}
	}
}
