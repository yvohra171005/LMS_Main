﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWInfrastructure
{
	public class GDWDateObject
	{
		public GDWDateObject()
			: this( DateTime.Now )
		{
		}

		public GDWDateObject( DateTime? dateTime )
			: this( dateTime ?? DateTime.Now )
		{
		}

		public GDWDateObject( DateTime dateTime )
		{
			year = dateTime.Year;
			month = dateTime.Month;
			day = dateTime.Day;
		}

		public int month { get; set; }
		public int day { get; set; }
		public int year { get; set; }

		public DateTime AsDateTime { get { return new DateTime( year, month, day ); } }
	}
}
