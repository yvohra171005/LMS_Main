﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using GDWDatabase;

namespace GDWInfrastructure
{
	public class GDWAuthorizeJSONAttribute : GDWAuthorizeAttribute
	{
		public GDWAuthorizeJSONAttribute( params GDWPermissionTypes.Permissions[] permissions )
			: base( permissions )
		{
		}

		protected override void HandleUnauthorizedRequest( AuthorizationContext filterContext )
		{
			filterContext.HttpContext.Response.StatusCode = 403;
			filterContext.Result = new JsonResult
			{
				Data = new { success = false, message = "You are not authorized for this action" },
				JsonRequestBehavior = JsonRequestBehavior.AllowGet
			};
		}
	}
}
