﻿namespace GDWInfrastructure.DataTables
{
    public class EmployeeNoteTableParams : DataTableParams
    {
        public int userId { get; set; }
    }
}