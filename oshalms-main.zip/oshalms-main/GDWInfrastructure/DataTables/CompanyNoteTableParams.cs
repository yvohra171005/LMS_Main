﻿namespace GDWInfrastructure.DataTables
{
    public class CompanyNoteTableParams : DataTableParams
    {
        public int customerId { get; set; }
    }
}