﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWInfrastructure.DataTables
{
	public class EmployeeAssignmentTableParams : DataTableParams
	{
		public IEnumerable<int> locations { get; set; }
		public IEnumerable<int> departments { get; set; }
		public IEnumerable<int> employees { get; set; }
		public IEnumerable<string> categories { get; set; }
		public IEnumerable<int> classes { get; set; }
		public string status { get; set; }
	}
}
