﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWInfrastructure.DataTables
{
	public class ClassAssignmentTableParams : DataTableParams
	{
		public IEnumerable<string> categories { get; set; }
		public IEnumerable<int> classes { get; set; }
	}
}
