﻿namespace GDWInfrastructure.DataTables
{
    public class CompanyDocumentTableParams : DataTableParams
    {
        public string activeState { get; set; }
        public int customerId { get; set; }
    }
}