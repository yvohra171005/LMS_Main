﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GDWInfrastructure.DataTables
{
	public class ScreeningRoomTableParams : DataTableParams
	{
		public int languageId { get; set; }
	}
}
