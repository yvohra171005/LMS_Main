﻿namespace GDWInfrastructure.DataTables
{
    public class ScheduledAssignmentTableParams : DataTableParams
    {
        public string status { get; set; }
    }
}