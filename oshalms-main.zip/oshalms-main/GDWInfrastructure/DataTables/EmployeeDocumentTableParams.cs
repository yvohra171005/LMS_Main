﻿namespace GDWInfrastructure.DataTables
{
    public class EmployeeDocumentTableParams : DataTableParams
    {
        public string activeState { get; set; }
        public int userId { get; set; }
    }
}