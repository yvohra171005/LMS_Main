alter table [Customers] add [TracksCredits] [bit] not null constraint [defTC] default(1)
alter table [Customers] drop constraint [defTC] 
go

alter table [UserTests] add [Score] [float] null
go

create function TestScore( @TestID int )
returns [float]
as
begin
	declare @total int
	select @total = count(*) from UserTestQuestions where TestID = @TestID
	
	if( @total > 0 )
	begin
		declare @correct int
		
		select @correct = count(*) from UserTestQuestions utq
				inner join UserTestAnswers uta on utq.TQuestionID = uta.TQuestionID and uta.IsChosen = 1 and utq.TestID = @TestID
				inner join UserClassAnswers uca on uta.AnswerID = uca.AnswerID and uca.IsCorrect = 1

		return (100.0 * @correct) / @total;
	end

	return 0.0
end
go

create procedure GetTestScore @TestID int
as
begin
	select dbo.TestScore( @TestID ) as Score
end
go

update [UserTests] set [Score] = dbo.TestScore( TestID ) where CompleteDate is not null
go

alter table [UserClassActivity] drop constraint [FK_Activity_UserClass]
alter table [UserClassVersions] drop constraint [FK_UserClass_Version]
alter table [UserClassVersionDocuments] drop constraint [FK_UCVDocument_Version]
alter table [UserClassQuestions] drop constraint [FK_UCQuestion_Version]
alter table [UserClassAnswers] drop constraint [FK_UCAnswer_Question]
alter table [UserTests] drop constraint [FK_UserTest_UserClass]
alter table [UserTestQuestions] drop constraint [FK_TQuestion_Test]
alter table [UserTestAnswers] drop constraint [FK_TAnswer_TQuestion]
go

alter table [UserClassActivity] add constraint [FK_Activity_UserClass] foreign key ([UserClassID]) references [UserClasses]([UserClassID]) on delete cascade
alter table [UserClassVersions] add constraint [FK_UserClass_Version] foreign key ([UserClassID]) references [UserClasses]([UserClassID]) on delete cascade
alter table [UserClassVersionDocuments] add constraint [FK_UCVDocument_Version] foreign key ([VersionID]) references [UserClassVersions]([VersionID]) on delete cascade
alter table [UserClassQuestions] add constraint [FK_UCQuestion_Version] foreign key ([VersionID]) references [UserClassVersions]([VersionID]) on delete cascade
alter table [UserClassAnswers] add constraint [FK_UCAnswer_Question] foreign key ([QuestionID]) references [UserClassQuestions]([QuestionID]) on delete cascade
alter table [UserTests] add constraint [FK_UserTest_UserClass] foreign key ([UserClassID]) references [UserClasses]([UserClassID]) on delete cascade
alter table [UserTestQuestions] add constraint [FK_TQuestion_Test] foreign key ([TestID]) references [UserTests]([TestID]) on delete cascade
alter table [UserTestAnswers] add constraint [FK_TAnswer_TQuestion] foreign key ([TQuestionID]) references [UserTestQuestions]([TQuestionID]) on delete cascade
go