create table [Customers] (
	[CustomerID] [int] not null identity(1,1),
	[Name] [nvarchar](100) not null,
	[Address1] [nvarchar](100) not null,
	[Address2] [nvarchar](100) null,
	[City] [nvarchar](50) not null,
	[State] [nvarchar](2) not null,
	[ZipCode] [nvarchar](10) not null,
	[PhoneNumber] [nvarchar](20) not null,
	[IsDeleted] [bit] not null,
	[PaidThroughDate] [datetime] not null,
	[ExpirationDate] [datetime] not null,
	[PlanID] [int] not null CONSTRAINT [FK_Customer_Plan] FOREIGN KEY REFERENCES [CustomerPlans] ([PlanID]),
	[PaymentMethod] [int] not null,
	constraint [pkCustomers] primary key clustered ([CustomerID])
) on [primary]
go

create table [CustomerLocations] (
	[LocationID] [int] not null identity(1,1),
	[Name] [nvarchar](100) not null,
	[Description] [ntext] null,
	[CustomerID] [int] not null CONSTRAINT [FK_Locations_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[IsDeleted] [bit] not null,
	constraint [pkCustomerLocations] primary key clustered ([LocationID])
) on [primary]
go

create table [CustomerDepartments] (
	[DepartmentID] [int] not null identity(1,1),
	[Name] [nvarchar](100) not null,
	[Description] [ntext] null,
	[CustomerID] [int] not null CONSTRAINT [FK_Departments_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[IsDeleted] [bit] not null,
	constraint [pkCustomerDepartments] primary key clustered ([DepartmentID])
) on [primary]
go

alter table [Customers] add [CreditCount] [int] not null
go

create table [UserLocations] (
	[UserID] [int] not null CONSTRAINT [FK_UserLocations_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[LocationID] [int] not null CONSTRAINT [FK_UserLocations_Location] FOREIGN KEY REFERENCES [CustomerLocations] ([LocationID]),
	constraint [pkUserLocations] primary key clustered ([UserID], [LocationID])
) on [primary]
go

create table [UserDepartments] (
	[UserID] [int] not null CONSTRAINT [FK_UserDepartments_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[DepartmentID] [int] not null CONSTRAINT [FK_UserDepartments_Department] FOREIGN KEY REFERENCES [CustomerDepartments] ([DepartmentID]),
	constraint [pkUserDepartments] primary key clustered ([UserID], [DepartmentID])
) on [primary]
go

create table [ConfigurationOptions] (
	[OptionID] [int] not null identity(1,1),
	[DefaultPermissionGroupID] [int] not null CONSTRAINT [FK_Options_DefPermGroup] FOREIGN KEY REFERENCES [PermissionGroups] ([GroupID]),
	constraint [pkConfigurationOptions] primary key clustered ([OptionID])
) on [primary]
go

alter table [PermissionGroups] add [IsAccountGroup] [bit] not null constraint [defIsAcctGrp] default(0)
alter table [PermissionGroups] drop constraint [defIsAcctGrp]
go

delete from [PermissionGroupItems] where [PermissionID] = 21
go

alter table [Customers] add
	[ContactFirstName] [nvarchar](50) null,
	[ContactLastName] [nvarchar](50) null,
	[ContactEmailAddress] [nvarchar](50) null,
	[ContactGender] [int] null,
	[ContactDateOfBirth] [datetime] null
go

alter table [Customers] add [IsPaid] [bit] not null constraint [defIsPaid] default(0)
alter table [Customers] drop constraint [defIsPaid]
alter table [Customers] drop column [PaidThroughDate]
go

alter table [CustomerLocations] add
	[Address1] [nvarchar](100) null,
	[Address2] [nvarchar](100) null,
	[City] [nvarchar](50) null,
	[State] [nvarchar](2) null,
	[ZipCode] [nvarchar](10) null
go

alter table [Customers] add [AdditionalEmployees] [int] not null constraint [defAE] default(0)
alter table [Customers] drop constraint [defAE]
go
