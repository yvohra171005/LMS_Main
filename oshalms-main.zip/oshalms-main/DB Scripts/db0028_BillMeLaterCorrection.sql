select * from CustomerPurchases where TransactionId is null
/*
update CustomerPurchases set PaymentMethod = 0 where TransactionId is null
*/