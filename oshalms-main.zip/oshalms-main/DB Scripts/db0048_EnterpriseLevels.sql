alter table [Customers] add [EnterpriseLevel] [int] not null default(0)
go

update [Customers] set [EnterpriseLevel] = 1
go

create table [AvailableClasses] (
	[CustomerID] [int] not null CONSTRAINT [FK_AvailableClass_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[ClassID] [int] not null CONSTRAINT [FK_AvailableClass_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID])
	constraint [pkAvailableClasses] primary key clustered ([CustomerID], [ClassID])	 
) on [primary]
go
