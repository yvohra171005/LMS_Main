alter table [ConfigurationOptions] add [EULAVersion] [nvarchar](50) null
go
alter table [Users] add [EULAVersion] [nvarchar](50) null
go