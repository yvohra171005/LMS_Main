create table [Users] (
	[UserID] [int] not null identity(1,1),
	[EmailAddress] [nvarchar](50) not null,
	[FirstName] [nvarchar](50) null,
	[LastName] [nvarchar](50) null,
	[Password] [nvarchar](100) not null,
	[IsDeleted] [bit] not null,
	CONSTRAINT [pkUserRoles] PRIMARY KEY CLUSTERED ([UserID])
) on [primary]
go

create table [Languages] (
	[LanguageID] [int] not null identity(1,1),
	[Name] [nvarchar](50) not null,
	[StringClass] [nvarchar](50) not null,
	CONSTRAINT [pkLanguages] PRIMARY KEY CLUSTERED ([LanguageID])
) on [primary]
go

insert into [Languages] ([Name], [StringClass]) values (N'English', 'EnglishStrings')
insert into [Languages] ([Name], [StringClass]) values (N'Spanish', 'SpanishStrings')
go

alter table [Users] add [LanguageID] [int] not null CONSTRAINT [FK_User_Language] FOREIGN KEY REFERENCES [Languages] ([LanguageID])
go

alter table [Users] add [PhoneNumber] [nvarchar](20) null
alter table [Users] add [IsActive] [bit] not null
go

alter table [Users] add [Gender] [int] not null constraint [defGender] default(1)
alter table [Users] drop constraint [defGender]
go

alter table [Users] drop column [IsActive]
go

create table [PermissionGroups] (
	[GroupID] [int] not null identity(1,1),
	[Name] [nvarchar](50) not null,
	[Description] [ntext] null,
	[IsDeleted] [bit] not null,
	CONSTRAINT [pkPermissionGroups] PRIMARY KEY CLUSTERED ([GroupID])
) on [primary]
go

create table [PermissionGroupItems] (
	[GroupID] [int] not null CONSTRAINT [FK_PGI_Group] FOREIGN KEY REFERENCES [PermissionGroups] ([GroupID]),
	[PermissionID] [int] not null,
	CONSTRAINT [pkPermissionGroupItems] PRIMARY KEY CLUSTERED ([GroupID], [PermissionID])
) on [primary]
go

create table [UserPermissionAssignments] (
	[UserID] [int] not null CONSTRAINT [FK_UPA_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[GroupID] [int] not null CONSTRAINT [FK_UPA_Group] FOREIGN KEY REFERENCES [PermissionGroups] ([GroupID]),
	CONSTRAINT [pkUserPermissionAssignments] PRIMARY KEY CLUSTERED ([UserID], [GroupID])
) on [primary]
go

alter table [Users] add [ImageFileName] [nvarchar](50) null
go

create table [ResetEmails] (
	[EmailID] [uniqueidentifier] not null,
	[UserID] [int] not null CONSTRAINT [FK_ResetEmail_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[ExpireDate] [datetime] not null,
	[IsActive] [bit] not null,
	CONSTRAINT [pkResetEmails] PRIMARY KEY CLUSTERED ([EmailID])
) on [primary]
go

declare @adminGroup int
insert into [PermissionGroups] ([Name], [Description], [IsDeleted]) values ('Administrator', '', 0)
select @adminGroup = @@IDENTITY
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 1)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 2)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 3)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 4)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 5)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 6)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 7)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 8)
go