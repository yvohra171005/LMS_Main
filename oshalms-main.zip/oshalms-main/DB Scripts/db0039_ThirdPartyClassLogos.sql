alter table [Classes] add [LogoFileName] [nvarchar](50) null, [OriginalLogoFileName] [nvarchar](100) null
go
