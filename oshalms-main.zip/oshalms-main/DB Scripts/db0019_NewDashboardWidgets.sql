alter table [CustomerLocations] add
	[SDName] [nvarchar](100) null,
	[SDPhone] [nvarchar](20) null,
	[SDCellPhone] [nvarchar](20) null,
	[SDEmail] [nvarchar](50) null
go

delete from [userdashboardwidgets]
go