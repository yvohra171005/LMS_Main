alter table [ClassQuestions] add 
	[ImageFileName] [nvarchar](50) null,
	[OriginalImageFileName] [nvarchar](50) null
go
alter table [Users] add
	[HireDate] [datetime] null
go

alter table [Classes] add
	[VideoFileName] [nvarchar](50) null,
	[OriginalVideoName] [nvarchar](50) null
go

update [Classes] 
set [Classes].[VideoFileName] = [ClassVersions].[VideoFileName],
	[Classes].[OriginalVideoName] = [ClassVersions].[OriginalVideoName]
from [Classes]
	inner join [ClassVersions] on [Classes].[ClassID] = [ClassVersions].[ClassID] and [ClassVersions].[IsDeleted] = 0 and [ClassVersions].[LanguageID] = 1

update [Classes] set [OriginalVideoName] = null where [VideoFileName] is null

alter table [ClassVersions] drop column [VideoFileName]
alter table [ClassVersions] drop column [OriginalVideoName]

alter table [ClassVersions] add
	[CaptionFileName] [nvarchar](50) null,
	[OriginalCaptionName] [nvarchar](50) null
go
