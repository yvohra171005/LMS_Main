create table [ClassFAQs] (
	[FAQID] [int] not null identity(1,1),
	[ClassID] [int] not null CONSTRAINT [fkClassFAQ_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[AskUserID] [int] not null CONSTRAINT [fkClassFAQ_AskUser] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[AskText] [ntext] null,
	[UpdatedAskText] [ntext] null,
	[DateAsked] [datetime] not null,
	[AnswerUserID] [int] null CONSTRAINT [fkClassFAQ_AnswerUser] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[AnswerText] [ntext] null,
	[DateAnswered] [datetime] null,
	[IsPublic] [bit] not null,
	constraint [pkClassFAQs] primary key clustered ([FAQID])	
) on [primary]
go