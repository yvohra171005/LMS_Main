alter table [Classes] add
	[IsVideo] [bit] not null constraint [defVideo] default(1),
	[PDFFileName] [nvarchar](50) null,
	[OriginalPDFName] [nvarchar](50) null,
	[CustomerID] [int] null constraint [FK_Class_Customer] foreign key references [Customers]([CustomerID])
alter table [Classes] drop constraint [defVideo]
go

alter table [UserClasses] add
	[IsVideo] [bit] not null constraint [defVideo] default(1),
	[PDFFileName] [nvarchar](50) null
alter table [UserClasses] drop constraint [defVideo]
go
