create table [UserLoginActivity] (
	[ActivityID] [int] not null identity(1,1),
	[UserID] [int] not null CONSTRAINT [FK_Activity_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[LoginDateTime] [datetime] not null,
	constraint [pkUserLoginActivity] primary key clustered ([ActivityID])
) on [primary]
go

create table [UserClassActivity] (
	[ActivityID] [int] not null identity(1,1),
	[UserClassID] [int] not null CONSTRAINT [FK_Activity_UserClass] FOREIGN KEY REFERENCES [UserClasses] ([UserClassID]),
	[PlayDateTime] [datetime] null,
	[PauseDateTime] [datetime] null,
	[TimeIndex] [float] not null,
	constraint [pkUserClassActivity] primary key clustered ([ActivityID])
) on [primary]
go

alter table [UserClasses] add [OverdueWarning] [int] null
go
alter table [Customers] add [RenewWarning] [int] null
go

alter table [ConfigurationOptions] 
	add [DefaultCreditWarning] [int] not null constraint [defDCW] default(100),
		[DefaultEmployeeWarning] [int] not null constraint [defDEW] default(5)
go
alter table [ConfigurationOptions] drop constraint [defDCW]
alter table [ConfigurationOptions] drop constraint [defDEW]
go

alter table [Customers] 
	add [CreditWarning] [int] not null constraint [defDCW] default(100),
		[EmployeeWarning] [int] not null constraint [defDEW] default(5)
go
alter table [Customers] drop constraint [defDCW]
alter table [Customers] drop constraint [defDEW]
go
