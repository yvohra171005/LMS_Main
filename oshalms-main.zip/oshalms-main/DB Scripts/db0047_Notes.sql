create table [Notes] (
	[NoteID] [int] not null identity(1,1),
	[CustomerID] [int] null CONSTRAINT [FK_Note_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[UserID] [int] null CONSTRAINT [FK_Note_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[Text] [ntext] null,
	[LastUpateDateTime] [datetime] not null,
	[LastUpdateByUserID] [int] not null CONSTRAINT [FK_Note_LastUpdateByUser] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[IsDeleted] [bit] not null
	constraint [pkNotes] primary key clustered ([NoteID])	 
) on [primary]
go
