alter table [ClassVersions] add [OriginalGuideName] [nvarchar](50) null,
	[GuideFileName] [nvarchar](50) null
go

update [ClassVersions] set [OriginalGuideName] = cl.[OriginalGuideName],
    [GuideFileName] = cl.[GuideFileName]
from [ClassVersions] cv
    inner join Classes cl on cv.ClassID = cl.ClassID
go

alter table [Classes] drop column [OriginalGuideName], [GuideFileName]
go
