alter table [Classes] add [Credits] [int] not null constraint [defCredits] default(20)
alter table [Classes] drop constraint [defCredits]
go

delete from UserTestAnswers
delete from UserTestQuestions
delete from UserTests
delete from UserClassAnswers
delete from UserClassQuestions
delete from UserClassVersionDocuments
delete from UserClassVersions
delete from UserClasses
go

alter table [Customers] add [CreditsSpent] [int] not null constraint [defCredits] default(0)
alter table [Customers] drop constraint [defCredits]
go