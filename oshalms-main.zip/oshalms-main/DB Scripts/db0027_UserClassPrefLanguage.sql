alter table [UserClasses] add [PrefLanguageID] [int] null constraint [FK_UserClass_Language] foreign key references [Languages] ([LanguageID])
go
update [UserClasses] set [PrefLanguageID] = [LanguageID]
	from [UserClasses] inner join [Users] on [UserClasses].[UserID] = [Users].[UserID]
	where [Status] <> 1
update [UserClasses] set [PrefLanguageID] = 1 
	where not exists( select * from [UserClassVersions] [ucv] where [ucv].[LanguageID] = [PrefLanguageID] )
	and [Status] <> 1
go

--select * from UserClasses