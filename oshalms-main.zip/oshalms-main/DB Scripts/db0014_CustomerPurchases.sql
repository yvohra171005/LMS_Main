create table [CustomerPurchases] (
	[PurchaseID] [int] identity(470024, 1) not null,
	[CustomerID] [int] not null CONSTRAINT [FK_Purchase_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[PurchaseDate] [datetime] not null,
	[PlanName] [nvarchar](50) not null,
	[CreditCount] [int] not null,
	[AddlEmployees] [int] not null,
	[PlanCost] [money] not null,
	[PerCreditCost] [money] not null,
	[PerEmployeeCost] [money] not null,
	
	[CustomerName] [nvarchar](100) null,
	[CustomerContact] [nvarchar](100) null,
	[CustomerEmail] [nvarchar](50) null,
	[CustomerPhone] [nvarchar](20) null,
	
	constraint [pkCustomerPurchases] primary key clustered ([PurchaseID])
) on [primary]
go

alter table [Customers] add [ProfileID] [nvarchar](50) null
go

create table [CustomerCreditCards] (
	[CCProfileID] [nvarchar](50) not null,
	[CustomerID] [int] not null CONSTRAINT [FK_CC_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[MaskedCCNumber] [nvarchar](50) not null,
	constraint [pkCustomerCreditCards] primary key clustered ([CCProfileID])
) on [primary]
go

alter table [CustomerCreditCards] add [IsDeleted] [bit] not null constraint [defIsDelete] default(0)
alter table [CustomerCreditCards] drop constraint [defIsDelete]
go

alter table [CustomerPurchases] add
	[PaymentMethod] [int] not null,
	[PaymentDetail] [nvarchar](50) null
go

insert into [CustomerPurchases] ([CustomerID], [PurchaseDate], [PlanName], [CreditCount], [AddlEmployees], [PlanCost], [PerCreditCost], [PerEmployeeCost],
	[CustomerName], [CustomerContact], [CustomerEmail], [CustomerPhone], [PaymentMethod])
(select CustomerID, DATEADD(year, -1, expirationdate), cp.name, [c].CreditCount - [cp].BaseCredits, [c].[AdditionalEmployees], [cp].BaseCost, [cp].CostPerCredit, [cp].CostPerExtra,
	[c].Name, [c].contactfirstname + ' ' + [c].contactlastname, [c].[contactemailaddress], [c].PhoneNumber, 0 /*BillMeLater*/
	from [Customers] [c]
		inner join [CustomerPlans] [cp] on [c].[PlanID] = [cp].[PlanID])
go

alter table [CustomerCreditCards] add [PaymentMethod] [int] not null constraint [defPM] default(1)
alter table [CustomerCreditCards] drop constraint [defPM]
go