create table [CustomerPlans] (
	[PlanID] [int] not null identity(1,1),
	[Name] [nvarchar](100) not null,
	[Description] [ntext] null,
	[MaxEmployees] [int] not null,
	[BaseCost] [money] not null,
	[CostPerExtra] [money] not null,
	[CostPerCredit] [money] not null,
	[IsDeleted] [bit] not null,
	constraint [pkCustomerPlans] primary key clustered ([PlanID])
) on [primary]
go
