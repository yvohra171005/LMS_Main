create table [CustomerSignatures] (
	[SignatureID] [int] not null identity(1,1),
	[CustomerID] [int] not null CONSTRAINT [FK_Signature_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[Name] [nvarchar](100) not null,
	[Title] [nvarchar](100) not null,
	[ImageFileName] [nvarchar](50) null,
	[OriginalImageFileName] [nvarchar](100) null
	constraint [pkCustomerSignatures] primary key clustered ([SignatureID])	 
) on [primary]
go
