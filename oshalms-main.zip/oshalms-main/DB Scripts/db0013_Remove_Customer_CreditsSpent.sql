alter table [Customers] drop column [CreditsSpent]
go