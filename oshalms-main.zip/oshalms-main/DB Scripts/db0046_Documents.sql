create table [Documents] (
	[DocumentID] [int] not null identity(1,1),
	[CustomerID] [int] null CONSTRAINT [FK_Document_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[UserID] [int] null CONSTRAINT [FK_Document_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[Name] [nvarchar](100) not null,
	[Description] [ntext] null,
	[FileName] [nvarchar](50) null,
	[OriginalName] [nvarchar](100) null,
	[IsRestricted] [bit] not null,
	[LastUpateDateTime] [datetime] not null,
	[IsDeleted] [bit] not null
	constraint [pkDocuments] primary key clustered ([DocumentID])	 
) on [primary]
go
