CREATE TABLE [ClassVersionSafetyDocuments](
	[SafetyDocumentID] [int] IDENTITY(1,1) NOT NULL,
	[VersionID] [int] NOT NULL CONSTRAINT [FK_CVSafetyDocument_Version] FOREIGN KEY REFERENCES [ClassVersions] ([VersionID]),
	[FileName] [nvarchar](50) NULL,
	[OriginalName] [nvarchar](50) NULL,
	[IsDeleted] [bit] NOT NULL,
	CONSTRAINT [pkClassVersionSafetyDocuments] PRIMARY KEY CLUSTERED ([SafetyDocumentID])
) ON [PRIMARY]
GO

delete from [UserClasses] where [UserClassID] not in (select [UserClassID] from [UserClassVersions])
go