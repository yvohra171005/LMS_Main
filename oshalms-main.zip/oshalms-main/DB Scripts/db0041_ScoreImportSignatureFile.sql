alter table [ScoreImports] add [SignatureFileName] [nvarchar](100) null, [OriginalSignatureFileName] [nvarchar](200) null
go
