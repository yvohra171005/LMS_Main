create table [Classes] (
	[ClassID] [int] not null identity(1,1),
	[Name] [nvarchar](100) not null,
	[Description] [ntext] null,
	[PassPercent] [int] not null,
	[RandomizeQuestions] [bit] not null,
	[TotalQuestionMinimum] [int] null,
	[TotalQuestionMaximum] [int] null,
	[IsDeleted] [bit] not null,
	constraint [pkClasses] primary key clustered ([ClassID])
) on [primary]

create table [ClassVersions] (
	[VersionID] [int] not null identity(1,1),
	[ClassID] [int] not null CONSTRAINT [FK_ClassVersion_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[LanguageID] [int] not null CONSTRAINT [FK_ClassVersion_Language] FOREIGN KEY REFERENCES [Languages] ([LanguageID]),
	[VideoFileName] [nvarchar](50) null,
	[OriginalVideoName] [nvarchar](50) null,
	[IsDeleted] [bit] not null,
	constraint [pkClassVersions] primary key clustered ([VersionID])
) on [primary]

create table [ClassVersionDocuments] (
	[DocumentID] [int] not null identity(1,1),
	[VersionID] [int] not null CONSTRAINT [FK_CVDocument_Version] FOREIGN KEY REFERENCES [ClassVersions] ([VersionID]),
	[FileName] [nvarchar](50) null,
	[OriginalName] [nvarchar](50) null,
	[IsDeleted] [bit] not null,
	constraint [pkClassVersionDocuments] primary key clustered ([DocumentID])	
) on [primary]

create table [ClassQuestions] (
	[QuestionID] [int] not null identity(1,1),
	[VersionID] [int] not null CONSTRAINT [FK_CQuestion_Version] FOREIGN KEY REFERENCES [ClassVersions] ([VersionID]),
	[Text] [ntext] not null,
	[Narrative] [ntext] null,
	[DisplayOrder] [int] not null,
	[IsDeleted] [bit] not null,
	constraint [pkClassQuestions] primary key clustered ([QuestionID])	
) on [primary]

create table [ClassAnswers] (
	[AnswerID] [int] not null identity(1,1),
	[QuestionID] [int] not null CONSTRAINT [FK_CAnswer_Question] FOREIGN KEY REFERENCES [ClassQuestions] ([QuestionID]),
	[Text] [ntext] not null,
	[IsCorrect] [bit] not null,
	[IsDeleted] [bit] not null,
	constraint [pkClassAnswers] primary key clustered ([AnswerID])	
) on [primary]

alter table [Classes] add 
	[DateCreated] [datetime] not null,
	[LastModified] [datetime] not null
go

alter table [ClassVersions] add 
	[DateCreated] [datetime] not null,
	[LastModified] [datetime] not null
go

declare @adminGroup int
select @adminGroup = Min(GroupID) from PermissionGroups
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 13)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 14)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 15)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 16)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 17)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 18)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 19)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 20)
go
