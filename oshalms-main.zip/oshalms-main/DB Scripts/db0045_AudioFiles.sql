alter table [ClassQuestions] add [AudioFileName] [nvarchar](50) null,
	[OriginalAudioFileName] [nvarchar](50) null
alter table [UserClassQuestions] add [AudioFileName] [nvarchar](50) null
go
alter table [ClassAnswers] add [AudioFileName] [nvarchar](50) null,
	[OriginalAudioFileName] [nvarchar](50) null
alter table [UserClassAnswers] add [AudioFileName] [nvarchar](50) null
go
alter table [ClassQuestions] add [FullAudioFileName] [nvarchar](50) null,
	[OriginalFullAudioFileName] [nvarchar](50) null
go
