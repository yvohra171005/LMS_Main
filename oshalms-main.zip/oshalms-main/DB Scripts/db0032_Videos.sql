create table [Videos] (
	[VideoID] [int] not null identity(1,1),
	[Name] [nvarchar](200) not null,
	[OriginalFileName] [nvarchar](100) not null,
	[BlobFileName] [nvarchar](100) not null,
	[JobID] [nvarchar](100) null,
	[StreamName] [nvarchar](500) null,
	[IsDeleted] [bit] not null,
	[DateCreated] [datetime] not null,
	CONSTRAINT [pkVideos] PRIMARY KEY CLUSTERED ([VideoID])
) on [primary]
go

insert into [Videos] ([Name], [OriginalFileName], [BlobFileName], [IsDeleted], [DateCreated])
	(select [Name], [OriginalVideoName], [VideoFileName], 0, getutcdate() from [Classes] where [IsVideo] = 1)
insert into [Videos] ([Name], [OriginalFileName], [BlobFileName], [IsDeleted], [DateCreated])
	(select [Name], 'unknown.mp4', [VideoFileName], 0, getutcdate() from [UserClasses] where [IsVideo] = 1)
delete from [Videos] where exists(select * from videos v2 where Videos.BlobFileName = v2.BlobFileName and v2.VideoID < videos.VideoID)
go

alter table [Classes] add [VideoID] [int] NULL constraint [FK_Class_Video] foreign key references [Videos] ([VideoID])
go

alter table [UserClasses] add [VideoID] [int] NULL constraint [FK_UserClass_Video] foreign key references [Videos] ([VideoID])
go

/*
update [Classes] set [Classes].[VideoID] = [Videos].[VideoID]
	from [Classes]
		inner join [Videos] on [Videos].[BlobFileName] = [Classes].[VideoFileName]
go

update [UserClasses] set [UserClasses].[VideoID] = [Videos].[VideoID]
	from [UserClasses]
		inner join [Videos] on [Videos].[BlobFileName] = [UserClasses].[VideoFileName]
go
*/
/*
alter table [Classes] drop column [OriginalVideoName], [VideoFileName]
alter table [UserClasses] drop column [VideoFileName]
go
*/