create table [UserDashboardWidgets] (
	[UDWidgetID] [int] identity(1,1) not null,
	[UserID] [int] not null CONSTRAINT [FK_UDWidget_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[WidgetID] [int] not null,
	[DisplayOrder] [int] not null,
	constraint [pkUserDashboardWidgets] primary key clustered ([UDWidgetID])
) on [primary]
go
