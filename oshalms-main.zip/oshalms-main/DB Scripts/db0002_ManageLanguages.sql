alter table [Languages] add [IsDeleted] [bit] not null constraint [defLangIsDeleted] default(0)
alter table [Languages] drop constraint [defLangIsDeleted]
go
declare @adminGroup int
select @adminGroup = Min(GroupID) from PermissionGroups
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 9)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 10)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 11)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 12)
go
