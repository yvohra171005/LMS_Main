alter table [CustomerPurchases] add [PurchaseType] [int] not null constraint [defPType] default(0)
alter table [CustomerPurchases] drop constraint [defPType]
go

update [CustomerPurchases] 
	set [PurchaseType] = 1 
where exists (select * from [CustomerPurchases] [prev] where [prev].[CustomerID] = [CustomerPurchases].[CustomerID] and [prev].[PurchaseID] < [CustomerPurchases].[PurchaseID])

--select * from [CustomerPurchases]
go

create table [DiscountCodes] (
	[DiscountCodeID] [int] not null identity(1,1),
	[Name] [nvarchar](50) not null,
	[Description] [ntext] null,
	[CodeType] [int] not null,
	[OffAmount] [float] not null,
	[FirstAmount] [float] not null,
	[CodeText] [nvarchar](20) not null,
	[StartDate] [datetime] not null,
	[EndDate] [datetime] not null,
	[IsMultiUse] [bit] not null,
	[IsNewPurchase] [bit] not null,
	[IsExistingCustomer] [bit] not null,
	[IsRenewal] [bit] not null,
	constraint [pkDiscountCodes] primary key clustered ([DiscountCodeID])	 
) on [primary]
go

alter table [CustomerPurchases] add [DiscountCodeID] [int] null CONSTRAINT [fkPurchase_Discount] FOREIGN KEY REFERENCES [DiscountCodes] ([DiscountCodeID])
go

alter table [DiscountCodes] add [IsDeleted] [bit] not null
go

alter table [CustomerPurchases] add [DiscountCodeAmount] [money] null, [DiscountCodeText] [nvarchar](20)
go

alter table [CustomerPurchases] add [TransactionId] [nvarchar](50)
go
