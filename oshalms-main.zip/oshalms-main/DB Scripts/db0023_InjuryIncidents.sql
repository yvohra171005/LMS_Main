-- actual injury information
create table [InjuryIncidents] (
	[IncidentID] [int] identity(17881, 1) not null,
	[CustomerID] [int] not null CONSTRAINT [fkInjuryIncidents_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	constraint [pkInjuryIncidents] primary key clustered ([IncidentID])
) on [primary]

create table [InjuryIncidentVersions] (
	[VersionID] [int] identity(1,1) not null,
	[IncidentID] [int] not null CONSTRAINT [fkIIVersion_Incident] FOREIGN KEY REFERENCES [InjuryIncidents] ([IncidentID]),
	[EnteredByUserID] [int] not null CONSTRAINT [fkIIVersion_EnterUser] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[EnteredOnDate] [datetime] not null,

	-- form 300 fields
	[InjuredUserID] [int] not null CONSTRAINT [fkIIVersion_InjuredUser] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[JobTitle] [nvarchar](50) null,
	[DateOfInjury] [datetime] not null,
	[WhereEventOccurred] [nvarchar](50) null,
	[CaseClassification] [int] not null,
	[DaysLost] [int] null,
	[TypeOfIllness] [int] not null,

	-- form 301 fields
	[Address1] [nvarchar](100) null,
	[Address2] [nvarchar](100) null,
	[City] [nvarchar](50) null,
	[State] [nvarchar](2) null,
	[ZipCode] [nvarchar](10) null,
	[DateOfBirth] [datetime] null,
	[HCName] [nvarchar](100) null,
	[HCAddress1] [nvarchar](100) null,
	[HCAddress2] [nvarchar](100) null,
	[HCCity] [nvarchar](50) null,
	[HCState] [nvarchar](2) null,
	[HCZipCode] [nvarchar](10) null,
	[HCEmergencyRoom] [bit] not null,
	[HCHospitalized] [bit] not null,
	[StartWorkTime] [datetime] null,
	[EventTime] [datetime] null,
	[TimeUnknown] [bit] not null,
	[DateOfDeath] [datetime] null,

	-- other fields
	[LocationID] [int] not null CONSTRAINT [fkIIVersion_Location] FOREIGN KEY REFERENCES [CustomerLocations] ([LocationID]),
	[IsPrivacy] [bit] not null,

	constraint [pkInjuryIncidentVersions] primary key clustered ([VersionID])
) on [primary]

go

alter table [InjuryIncidentVersions] add [HCPhysician] [nvarchar](100) null
go

alter table [InjuryIncidentVersions] drop column [TimeUnknown]
go

alter table [InjuryIncidentVersions] add 
	[SummaryDescription] [ntext] null,
	[DoingActivity] [ntext] null,
	[WhatHappened] [ntext] null,
	[InjuryOrIllness] [ntext] null,
	[ObjectHarmedEmployee] [ntext] null
go

alter table [InjuryIncidentVersions] add
	[MDAddress1] [nvarchar](100) null,
	[MDAddress2] [nvarchar](100) null,
	[MDCity] [nvarchar](50) null,
	[MDState] [nvarchar](2) null,
	[MDZipCode] [nvarchar](10) null
go
