alter table [ConfigurationOptions]
	add [CostPerEmployee] [money] not null constraint [defCPE] default(225)
go
alter table [ConfigurationOptions]
	drop constraint [defCPE]
go

create table [CreditTiers] (
	[TierID] [int] identity(1,1) not null,
	[MinimumCreditPurchase] [int] not null,
	[CostPerCredit] [money] not null,
	constraint [pkCreditTiers] primary key clustered ([TierID])
) on [primary]
go

alter table [Classes]
	add [IsBaseClass] [bit] not null constraint [defIBC] default(0)
go
alter table [Classes]
	drop constraint [defIBC]
go

delete from [CustomerPurchases]
alter table [CustomerPurchases] drop column [PlanName]
alter table [CustomerPurchases] drop column [PlanCost]
alter table [CustomerPurchases] drop column [AddlEmployees]
alter table [CustomerPurchases] add [EmployeeCount] [int] not null
go

alter table [Customers] add [EmployeeCount] [int] not null constraint [defEC] default(0)
go
alter table [Customers] drop constraint [defEC]
go
update [Customers] set [EmployeeCount] = [cp].[MaxEmployees] + [AdditionalEmployees]
	from [Customers]
		inner join [CustomerPlans] [cp] on [Customers].[PlanID] = [cp].[PlanID] 
go

insert into [CustomerPurchases] ([CustomerID], [PurchaseDate], [CreditCount], [EmployeeCount], [PerCreditCost], [PerEmployeeCost],
	[CustomerName], [CustomerContact], [CustomerEmail], [CustomerPhone], [PaymentMethod])
(select CustomerID, DATEADD(year, -1, expirationdate), [c].CreditCount, [c].[EmployeeCount], 1, 225,
	[c].Name, [c].contactfirstname + ' ' + [c].contactlastname, [c].[contactemailaddress], [c].PhoneNumber, 0 /*BillMeLater*/
	from [Customers] [c]
		inner join [CustomerPlans] [cp] on [c].[PlanID] = [cp].[PlanID])
go
alter table [Customers] drop column [AdditionalEmployees]
go

alter table [Customers] drop constraint [FK_Customer_Plan]
alter table [Customers] drop column [PlanID]
go
drop table [CustomerPlans]
go
