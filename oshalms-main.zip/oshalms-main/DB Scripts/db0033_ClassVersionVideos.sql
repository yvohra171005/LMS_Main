alter table [ClassVersions] add 
	[VideoID] [int] NULL constraint [FK_ClassVersion_Video] foreign key references [Videos] ([VideoID]),
	[IsVideo] [bit] not null constraint [defIV] default(0),
	[PDFFileName] [nvarchar](50) null,
	[OriginalPDFName] [nvarchar](50) null
go

alter table [ClassVersions] drop constraint [defIV]
go

alter table [UserClassVersions] add [VideoID] [int] NULL constraint [FK_UserClassVersion_Video] foreign key references [Videos] ([VideoID]),
	[IsVideo] [bit] not null constraint [defIV] default(0),
	[PDFFileName] [nvarchar](50) null
go

alter table [UserClassVersions] drop constraint [defIV]
go

update [ClassVersions] 
set [VideoID] = c.[VideoID],
	[IsVideo] = c.[IsVideo],
	[PDFFileName] = c.[PDFFileName],
	[OriginalPDFName] = c.[OriginalPDFName]
from [ClassVersions] cv
	inner join [Classes] c on cv.[ClassID] = c.[ClassID]
go

update [UserClassVersions] 
set [VideoID] = uc.[VideoID],
	[IsVideo] = uc.[IsVideo],
	[PDFFileName] = uc.[PDFFileName]
from [UserClassVersions] ucv
	inner join [UserClasses] uc on ucv.[UserClassID] = uc.[UserClassID]
go

alter table [Classes] drop constraint [FK_Class_Video]
alter table [UserClasses] drop constraint [FK_UserClass_Video]
go

alter table [Classes] drop column [VideoID],
	[IsVideo],
	[PDFFileName],
	[OriginalPDFName]
go

alter table [UserClasses] drop column [VideoID],
	[IsVideo],
	[PDFFileName]
go
