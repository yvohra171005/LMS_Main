alter table [Users] alter column [EmailAddress] [nvarchar](50) null
go
