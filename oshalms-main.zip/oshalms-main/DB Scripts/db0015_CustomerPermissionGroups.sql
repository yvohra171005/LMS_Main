alter table [PermissionGroups] 
	add [CustomerID] [int] null CONSTRAINT [FK_PGroup_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID])
go
