create table [ScormClasses] (
    [ScormClassID] [int] not null identity(1,1),
    [ClassHandle] [nvarchar](200) null,
    [ScormProvider] [nvarchar](50) not null,
    constraint [pkScormClasses] primary key clustered ([ScormClassID])
) on [primary]
go

/*
 * ClassType enum definition:
 * 0: Video
 * 1: Scorm file
 * 2: PDF
 */
alter table [ClassVersions] add
    [ClassType] [int] not null default(0),
    [ScormClassID] [int] null CONSTRAINT [FK_ClassVersion_ScormClass] FOREIGN KEY REFERENCES [ScormClasses] ([ScormClassID])
go

update [ClassVersions]
    set [ClassType] = 2
    where [IsVideo] = 0
go

alter table [ClassVersions]
    drop column [IsVideo]
go

alter table [UserClassVersions] add
    [ClassType] [int] not null default(0),
    [ScormClassID] [int] null CONSTRAINT [FK_UserClassVersion_ScormClass] FOREIGN KEY REFERENCES [ScormClasses] ([ScormClassID])
go

update [UserClassVersions]
    set [ClassType] = 2
    where [IsVideo] = 0
go

alter table [UserClassVersions]
    drop column [IsVideo]
go
