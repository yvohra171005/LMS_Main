create table [ClassCategories] (
	[CategoryID] [int] not null identity(1,1),
	[Name] [nvarchar](100) not null,
	constraint [pkClassCategories] primary key clustered ([CategoryID])
) on [primary]

create table [ClassCategoryAssignments] (
	[ClassID] [int] not null CONSTRAINT [FK_CCA_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[CategoryID] [int] not null CONSTRAINT [FK_CCA_Category] FOREIGN KEY REFERENCES [ClassCategories] ([CategoryID]),
	constraint [pkClassCategoryAssignments] primary key clustered ([ClassID], [CategoryID])
) on [primary]
go