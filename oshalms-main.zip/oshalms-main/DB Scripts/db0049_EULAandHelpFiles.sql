alter table [ConfigurationOptions] add [EULAFileName] [nvarchar](50) null
alter table [ConfigurationOptions] add [OriginalEULAFileName] [nvarchar](100) null
alter table [ConfigurationOptions] add [HelpFileName] [nvarchar](50) null
alter table [ConfigurationOptions] add [OriginalHelpFileName] [nvarchar](100) null
go
