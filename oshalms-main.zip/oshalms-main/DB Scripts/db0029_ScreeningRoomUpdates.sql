alter table [Classes] add [OriginalGuideName] [nvarchar](50) null,
	[GuideFileName] [nvarchar](50) null
go