alter table [Customers] add [PaidDate] [datetime] null
go