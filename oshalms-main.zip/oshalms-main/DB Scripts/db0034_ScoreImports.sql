create table [ScoreImports] (
	[ImportID] [int] not null identity(1,1),
	[CustomerID] [int] not null CONSTRAINT [FK_ScoreImport_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[ClassID] [int] not null CONSTRAINT [FK_ScoreImport_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[OriginalSourceFileName] [nvarchar](200) not null,
	[SourceFileName] [nvarchar](100) not null,
	[OriginalErrorFileName] [nvarchar](200) null,
	[ErrorFileName] [nvarchar](100) null,
	[ImportCount] [int] not null,
	[ErrorCount] [int] not null,
	[DateImported] [datetime] not null,
	CONSTRAINT [pkScoreImports] PRIMARY KEY CLUSTERED ([ImportID])	
) on [primary]
go

alter table [UserTests] add [IsImport] [bit] not null constraint [defII] default(0)
alter table [UserTests] drop constraint [defII]
go

alter table [ScoreImports] add [UserID] [int] not null constraint [FK_ScoreImport_User] foreign key references [Users]([UserID])
go