CREATE TABLE [ScheduledClassAssignments](
	[ScheduledAssignmentID] [int] IDENTITY(1,1) NOT NULL,
	[CustomerID] [int] NOT NULL,
	[ClassName] [nvarchar](100) NOT NULL,
	[AssignmentDate] [date] NOT NULL,
	[DueDate] [date] NOT NULL,
	[Locations] [nvarchar](max) NOT NULL,
	[Departments] [nvarchar](max) NOT NULL,
	[IsComplete] [bit] NOT NULL,
	[CreatedScheduledUserClasses] [bit] NOT NULL,
	[FailureCount] [int] NOT NULL,
	[IsDeleted] [bit] NOT NULL,
	[CreatedByUserID] [int] NOT NULL,
	[WhenCreated] [datetime] NOT NULL,
	[WhenCompleted] [datetime] NULL,
	[LastError] [nvarchar](max) NULL,
	[LastErrorDateTime] [datetime] NULL
	CONSTRAINT [PK_ScheduledClassAssignments] PRIMARY KEY CLUSTERED ([ScheduledAssignmentID])
) ON [PRIMARY]
GO

ALTER TABLE [ScheduledClassAssignments]  WITH CHECK ADD  CONSTRAINT [FK_ScheduledClassAssignments_Customers] FOREIGN KEY([CustomerID])
REFERENCES [Customers] ([CustomerID])
GO

ALTER TABLE [ScheduledClassAssignments] CHECK CONSTRAINT [FK_ScheduledClassAssignments_Customers]
GO

ALTER TABLE [ScheduledClassAssignments]  WITH CHECK ADD  CONSTRAINT [FK_ScheduledClassAssignments_Users] FOREIGN KEY([CreatedByUserID])
REFERENCES [Users] ([UserID])
GO

ALTER TABLE [ScheduledClassAssignments] CHECK CONSTRAINT [FK_ScheduledClassAssignments_Users]
GO

CREATE TABLE [ScheduledUserClasses](
	[ScheduledUserClassID] [int] IDENTITY(1,1) NOT NULL,
	[ScheduledClassAssignmentID] [int] NOT NULL,
	[ClassID] [int] NOT NULL,
	[UserID] [int] NOT NULL,
	[DueDate] [date] NOT NULL,
	[WhenCreated] [datetime] NOT NULL,
	[WhenCompleted] [datetime] NULL,
	[UserClassID] [int] NULL,
	CONSTRAINT [PK_ScheduledUserClasses] PRIMARY KEY CLUSTERED ([ScheduledUserClassID])
) ON [PRIMARY]
GO

ALTER TABLE [ScheduledUserClasses]  WITH CHECK ADD  CONSTRAINT [FK_ScheduledUserClasses_Classes] FOREIGN KEY([ClassID])
REFERENCES [Classes] ([ClassID])
GO

ALTER TABLE [ScheduledUserClasses] CHECK CONSTRAINT [FK_ScheduledUserClasses_Classes]
GO

ALTER TABLE [ScheduledUserClasses]  WITH CHECK ADD  CONSTRAINT [FK_ScheduledUserClasses_ScheduledClassAssignments] FOREIGN KEY([ScheduledClassAssignmentID])
REFERENCES [ScheduledClassAssignments] ([ScheduledAssignmentID])
GO

ALTER TABLE [ScheduledUserClasses] CHECK CONSTRAINT [FK_ScheduledUserClasses_ScheduledClassAssignments]
GO

ALTER TABLE [ScheduledUserClasses]  WITH CHECK ADD  CONSTRAINT [FK_ScheduledUserClasses_UserClasses] FOREIGN KEY([UserClassID])
REFERENCES [UserClasses] ([UserClassID])
GO

ALTER TABLE [ScheduledUserClasses] CHECK CONSTRAINT [FK_ScheduledUserClasses_UserClasses]
GO

ALTER TABLE [ScheduledUserClasses]  WITH CHECK ADD  CONSTRAINT [FK_ScheduledUserClasses_Users] FOREIGN KEY([UserID])
REFERENCES [Users] ([UserID])
GO

ALTER TABLE [ScheduledUserClasses] CHECK CONSTRAINT [FK_ScheduledUserClasses_Users]
GO

CREATE NONCLUSTERED INDEX [IX_ScheduledClassAssignments] ON [ScheduledUserClasses] ([ScheduledClassAssignmentID])
GO
