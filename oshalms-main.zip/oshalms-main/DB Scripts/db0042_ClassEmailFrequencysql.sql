alter table [Customers] add [ClassEmailFrequency] [int] not null default(0)
go
