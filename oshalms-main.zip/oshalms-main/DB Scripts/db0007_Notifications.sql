create table [Notifications] (
	[NotificationID] [int] not null identity(1,1),
	[NotificationHeader] [nvarchar](100) not null,
	[NotificationString] [nvarchar](100) not null,
	[NotificationDateTime] [datetime] not null,
	[UserID] [int] not null CONSTRAINT [FK_Notifications_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[IsNew] [bit] not null,
	[IsRead] [bit] not null,
	constraint [pkNotifications] primary key clustered ([NotificationID])
) on [primary]
go

create table [NotificationParameters] (
	[ParameterID] [int] not null identity(1,1),
	[NotificationID] [int] not null CONSTRAINT [FK_Parameters_Notifications] FOREIGN KEY REFERENCES [Notifications] ([NotificationID]),
	[TextData] [ntext] null,
	[DisplayOrder] [int] not null,
	constraint [pkNotificationParameters] primary key clustered ([ParameterID])
) on [primary]
go