create table [UserClasses] (
	[UserClassID] [int] not null identity(1,1),
	[ClassID] [int] not null CONSTRAINT [FK_UserClass_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[UserID] [int] not null CONSTRAINT [FK_UserClass_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[Name] [nvarchar](100) not null,
	[Description] [ntext] null,
	[PassPercent] [int] not null,
	[VideoFileName] [nvarchar](50) null,
	[RandomizeQuestions] [bit] not null,
	[TotalQuestionMinimum] [int] null,
	[TotalQuestionMaximum] [int] null,
	
	[DueDate] [datetime] not null,
	[Status] [int] not null,
	constraint [pkUserClasses] primary key clustered ([UserClassID])
) on [primary]

create table [UserClassVersions] (
	[VersionID] [int] not null identity(1,1),
	[UserClassID] [int] not null CONSTRAINT [FK_UserClass_Version] FOREIGN KEY REFERENCES [UserClasses] ([UserClassID]),
	[LanguageID] [int] not null CONSTRAINT [FK_UserClassVersion_Language] FOREIGN KEY REFERENCES [Languages] ([LanguageID]),
	[CaptionFileName] [nvarchar](50) null,
	constraint [pkUserClassVersions] primary key clustered ([VersionID])
) on [primary]

create table [UserClassVersionDocuments] (
	[DocumentID] [int] not null identity(1,1),
	[VersionID] [int] not null CONSTRAINT [FK_UCVDocument_Version] FOREIGN KEY REFERENCES [UserClassVersions] ([VersionID]),
	[FileName] [nvarchar](50) null,
	[OriginalName] [nvarchar](50) null,
	constraint [pkUserClassVersionDocuments] primary key clustered ([DocumentID])	
) on [primary]

create table [UserClassQuestions] (
	[QuestionID] [int] not null identity(1,1),
	[VersionID] [int] not null CONSTRAINT [FK_UCQuestion_Version] FOREIGN KEY REFERENCES [UserClassVersions] ([VersionID]),
	[Text] [ntext] not null,
	[Narrative] [ntext] null,
	[DisplayOrder] [int] not null,
	[ImageFileName] [nvarchar](50) null,
	constraint [pkUserClassQuestions] primary key clustered ([QuestionID])	
) on [primary]

create table [UserClassAnswers] (
	[AnswerID] [int] not null identity(1,1),
	[QuestionID] [int] not null CONSTRAINT [FK_UCAnswer_Question] FOREIGN KEY REFERENCES [UserClassQuestions] ([QuestionID]),
	[Text] [ntext] not null,
	[IsCorrect] [bit] not null,
	constraint [pkUserClassAnswers] primary key clustered ([AnswerID])	
) on [primary]

create table [UserTests] (
	[TestID] [int] not null identity(1,1),
	[UserClassID] [int] not null CONSTRAINT [FK_UserTest_UserClass] FOREIGN KEY REFERENCES [UserClasses] ([UserClassID]),
	constraint [pkUserTests] primary key clustered ([TestID])	
) on [primary]

create table [UserTestQuestions] (
	[TQuestionID] [int] not null identity(1,1),
	[QuestionID] [int] not null CONSTRAINT [FK_TQuestion_Question] FOREIGN KEY REFERENCES [UserClassQuestions] ([QuestionID]),
	[TestID] [int] not null CONSTRAINT [FK_TQuestion_Test] FOREIGN KEY REFERENCES [UserTests] ([TestID]),
	[DisplayOrder] [int] not null,
	constraint [pkUserTestQuestions] primary key clustered ([TQuestionID])	
) on [primary]

create table [UserTestAnswers] (
	[TAnswerID] [int] not null identity(1,1),
	[TQuestionID] [int] not null CONSTRAINT [FK_TAnswer_TQuestion] FOREIGN KEY REFERENCES [UserTestQuestions] ([TQuestionID]),
	[AnswerID] [int] not null CONSTRAINT [FK_TAnswer_Answer] FOREIGN KEY REFERENCES [UserClassAnswers] ([AnswerID]),
	[IsChosen] [bit] null,	
	constraint [pkUserTestAnswers] primary key clustered ([TAnswerID])	
) on [primary]

go

alter table [UserClasses] add 
	[AssignDate] [datetime] null,
	[StartDate] [datetime] null

alter table [UserTests] add
	[CompleteDate] [datetime] null
go