alter table [Classes] add [ReferenceNumber] [nvarchar](10) null
go

CREATE TABLE [CustomerAccountChanges] (
	[ChangeID] [int] IDENTITY(1,1) NOT NULL,
	[CustomerID] [int] NOT NULL CONSTRAINT [FK_CAC_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[UserID] [int] NOT NULL CONSTRAINT [FK_CAC_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[Credits] [int] NULL,
	[UserAccounts] [int] NULL,
	[ChangeDateTime] [datetime] not null,
	CONSTRAINT [pkCustomerAccountChanges] PRIMARY KEY CLUSTERED ([ChangeID])
) ON [PRIMARY]
GO

CREATE TABLE [CustomerReclaimClasses] (
	[ReclaimID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NOT NULL CONSTRAINT [FK_CRC_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[EmployeeID] [int] NOT NULL CONSTRAINT [FK_CRC_Employee] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[ClassID] [int] NOT NULL CONSTRAINT [FK_CRC_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[Credits] [int] NOT NULL,
	[ReclaimDateTime] [datetime] not null,
	CONSTRAINT [pkCustomerReclaimClasses] PRIMARY KEY CLUSTERED ([ReclaimID])
) ON [PRIMARY]
GO

create table [ClassScreenings] (
	[ScreeningID] [int] identity(1,1) not null,
	[UserID] [int] NOT NULL CONSTRAINT [FK_ClassScreen_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[ClassID] [int] NOT NULL CONSTRAINT [FK_ClassScreen_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[ScreenDateTime] [datetime] not null,
	constraint [pkClassScreenings] primary key clustered ([ScreeningID])
) on [primary]
go