alter table [CustomerPlans] add [BaseCredits] [int] not null constraint [defBaseCredits] default(0)
alter table [CustomerPlans] drop constraint [defBaseCredits]
go
alter table [CustomerPlans] add [Sequence] [int] not null constraint [defSequence] default(0)
alter table [CustomerPlans] drop constraint [defSequence]
go
update [CustomerPlans] set [Sequence] = (select COUNT(*) from [CustomerPlans] [cp] where [cp].[PlanID] <= [CustomerPlans].[PlanID])
go
