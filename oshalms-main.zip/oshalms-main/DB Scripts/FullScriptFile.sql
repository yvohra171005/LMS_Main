set nocount on
go

/*************************
 * db0001_UserTables.sql *
 *************************/
create table [Users] (
	[UserID] [int] not null identity(1,1),
	[EmailAddress] [nvarchar](50) not null,
	[FirstName] [nvarchar](50) null,
	[LastName] [nvarchar](50) null,
	[Password] [nvarchar](100) not null,
	[IsDeleted] [bit] not null,
	CONSTRAINT [pkUserRoles] PRIMARY KEY CLUSTERED ([UserID])
) on [primary]
go

create table [Languages] (
	[LanguageID] [int] not null identity(1,1),
	[Name] [nvarchar](50) not null,
	[StringClass] [nvarchar](50) not null,
	CONSTRAINT [pkLanguages] PRIMARY KEY CLUSTERED ([LanguageID])
) on [primary]
go

insert into [Languages] ([Name], [StringClass]) values (N'English', 'EnglishStrings')
insert into [Languages] ([Name], [StringClass]) values (N'Spanish', 'SpanishStrings')
go

alter table [Users] add [LanguageID] [int] not null CONSTRAINT [FK_User_Language] FOREIGN KEY REFERENCES [Languages] ([LanguageID])
go

alter table [Users] add [PhoneNumber] [nvarchar](20) null
alter table [Users] add [IsActive] [bit] not null
go

alter table [Users] add [Gender] [int] not null constraint [defGender] default(1)
alter table [Users] drop constraint [defGender]
go

alter table [Users] drop column [IsActive]
go

create table [PermissionGroups] (
	[GroupID] [int] not null identity(1,1),
	[Name] [nvarchar](50) not null,
	[Description] [ntext] null,
	[IsDeleted] [bit] not null,
	CONSTRAINT [pkPermissionGroups] PRIMARY KEY CLUSTERED ([GroupID])
) on [primary]
go

create table [PermissionGroupItems] (
	[GroupID] [int] not null CONSTRAINT [FK_PGI_Group] FOREIGN KEY REFERENCES [PermissionGroups] ([GroupID]),
	[PermissionID] [int] not null,
	CONSTRAINT [pkPermissionGroupItems] PRIMARY KEY CLUSTERED ([GroupID], [PermissionID])
) on [primary]
go

create table [UserPermissionAssignments] (
	[UserID] [int] not null CONSTRAINT [FK_UPA_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[GroupID] [int] not null CONSTRAINT [FK_UPA_Group] FOREIGN KEY REFERENCES [PermissionGroups] ([GroupID]),
	CONSTRAINT [pkUserPermissionAssignments] PRIMARY KEY CLUSTERED ([UserID], [GroupID])
) on [primary]
go

alter table [Users] add [ImageFileName] [nvarchar](50) null
go

create table [ResetEmails] (
	[EmailID] [uniqueidentifier] not null,
	[UserID] [int] not null CONSTRAINT [FK_ResetEmail_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[ExpireDate] [datetime] not null,
	[IsActive] [bit] not null,
	CONSTRAINT [pkResetEmails] PRIMARY KEY CLUSTERED ([EmailID])
) on [primary]
go

declare @adminGroup int
insert into [PermissionGroups] ([Name], [Description], [IsDeleted]) values ('Administrator', '', 0)
select @adminGroup = @@IDENTITY
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 1)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 2)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 3)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 4)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 5)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 6)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 7)
insert into [PermissionGroupItems] ([GroupID], [PermissionID]) values (@adminGroup, 8)
go

go
/******************************
 * db0002_ManageLanguages.sql *
 ******************************/
alter table [Languages] add [IsDeleted] [bit] not null constraint [defLangIsDeleted] default(0)
alter table [Languages] drop constraint [defLangIsDeleted]
go
declare @adminGroup int
select @adminGroup = Min(GroupID) from PermissionGroups
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 9)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 10)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 11)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 12)
go


go
/**********************
 * db0003_Classes.sql *
 **********************/
create table [Classes] (
	[ClassID] [int] not null identity(1,1),
	[Name] [nvarchar](100) not null,
	[Description] [ntext] null,
	[PassPercent] [int] not null,
	[RandomizeQuestions] [bit] not null,
	[TotalQuestionMinimum] [int] null,
	[TotalQuestionMaximum] [int] null,
	[IsDeleted] [bit] not null,
	constraint [pkClasses] primary key clustered ([ClassID])
) on [primary]

create table [ClassVersions] (
	[VersionID] [int] not null identity(1,1),
	[ClassID] [int] not null CONSTRAINT [FK_ClassVersion_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[LanguageID] [int] not null CONSTRAINT [FK_ClassVersion_Language] FOREIGN KEY REFERENCES [Languages] ([LanguageID]),
	[VideoFileName] [nvarchar](50) null,
	[OriginalVideoName] [nvarchar](50) null,
	[IsDeleted] [bit] not null,
	constraint [pkClassVersions] primary key clustered ([VersionID])
) on [primary]

create table [ClassVersionDocuments] (
	[DocumentID] [int] not null identity(1,1),
	[VersionID] [int] not null CONSTRAINT [FK_CVDocument_Version] FOREIGN KEY REFERENCES [ClassVersions] ([VersionID]),
	[FileName] [nvarchar](50) null,
	[OriginalName] [nvarchar](50) null,
	[IsDeleted] [bit] not null,
	constraint [pkClassVersionDocuments] primary key clustered ([DocumentID])	
) on [primary]

create table [ClassQuestions] (
	[QuestionID] [int] not null identity(1,1),
	[VersionID] [int] not null CONSTRAINT [FK_CQuestion_Version] FOREIGN KEY REFERENCES [ClassVersions] ([VersionID]),
	[Text] [ntext] not null,
	[Narrative] [ntext] null,
	[DisplayOrder] [int] not null,
	[IsDeleted] [bit] not null,
	constraint [pkClassQuestions] primary key clustered ([QuestionID])	
) on [primary]

create table [ClassAnswers] (
	[AnswerID] [int] not null identity(1,1),
	[QuestionID] [int] not null CONSTRAINT [FK_CAnswer_Question] FOREIGN KEY REFERENCES [ClassQuestions] ([QuestionID]),
	[Text] [ntext] not null,
	[IsCorrect] [bit] not null,
	[IsDeleted] [bit] not null,
	constraint [pkClassAnswers] primary key clustered ([AnswerID])	
) on [primary]

alter table [Classes] add 
	[DateCreated] [datetime] not null,
	[LastModified] [datetime] not null
go

alter table [ClassVersions] add 
	[DateCreated] [datetime] not null,
	[LastModified] [datetime] not null
go

declare @adminGroup int
select @adminGroup = Min(GroupID) from PermissionGroups
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 13)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 14)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 15)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 16)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 17)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 18)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 19)
insert into PermissionGroupItems ([GroupID], [PermissionID]) values (@adminGroup, 20)
go


go
/**********************************
 * db0004_ClassVersionUpdates.sql *
 **********************************/
alter table [ClassQuestions] add 
	[ImageFileName] [nvarchar](50) null,
	[OriginalImageFileName] [nvarchar](50) null
go
alter table [Users] add
	[HireDate] [datetime] null
go

alter table [Classes] add
	[VideoFileName] [nvarchar](50) null,
	[OriginalVideoName] [nvarchar](50) null
go

update [Classes] 
set [Classes].[VideoFileName] = [ClassVersions].[VideoFileName],
	[Classes].[OriginalVideoName] = [ClassVersions].[OriginalVideoName]
from [Classes]
	inner join [ClassVersions] on [Classes].[ClassID] = [ClassVersions].[ClassID] and [ClassVersions].[IsDeleted] = 0 and [ClassVersions].[LanguageID] = 1

update [Classes] set [OriginalVideoName] = null where [VideoFileName] is null

alter table [ClassVersions] drop column [VideoFileName]
alter table [ClassVersions] drop column [OriginalVideoName]

alter table [ClassVersions] add
	[CaptionFileName] [nvarchar](50) null,
	[OriginalCaptionName] [nvarchar](50) null
go


go
/**************************
 * db0005_UserClasses.sql *
 **************************/
create table [UserClasses] (
	[UserClassID] [int] not null identity(1,1),
	[ClassID] [int] not null CONSTRAINT [FK_UserClass_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[UserID] [int] not null CONSTRAINT [FK_UserClass_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[Name] [nvarchar](100) not null,
	[Description] [ntext] null,
	[PassPercent] [int] not null,
	[VideoFileName] [nvarchar](50) null,
	[RandomizeQuestions] [bit] not null,
	[TotalQuestionMinimum] [int] null,
	[TotalQuestionMaximum] [int] null,
	
	[DueDate] [datetime] not null,
	[Status] [int] not null,
	constraint [pkUserClasses] primary key clustered ([UserClassID])
) on [primary]

create table [UserClassVersions] (
	[VersionID] [int] not null identity(1,1),
	[UserClassID] [int] not null CONSTRAINT [FK_UserClass_Version] FOREIGN KEY REFERENCES [UserClasses] ([UserClassID]),
	[LanguageID] [int] not null CONSTRAINT [FK_UserClassVersion_Language] FOREIGN KEY REFERENCES [Languages] ([LanguageID]),
	[CaptionFileName] [nvarchar](50) null,
	constraint [pkUserClassVersions] primary key clustered ([VersionID])
) on [primary]

create table [UserClassVersionDocuments] (
	[DocumentID] [int] not null identity(1,1),
	[VersionID] [int] not null CONSTRAINT [FK_UCVDocument_Version] FOREIGN KEY REFERENCES [UserClassVersions] ([VersionID]),
	[FileName] [nvarchar](50) null,
	[OriginalName] [nvarchar](50) null,
	constraint [pkUserClassVersionDocuments] primary key clustered ([DocumentID])	
) on [primary]

create table [UserClassQuestions] (
	[QuestionID] [int] not null identity(1,1),
	[VersionID] [int] not null CONSTRAINT [FK_UCQuestion_Version] FOREIGN KEY REFERENCES [UserClassVersions] ([VersionID]),
	[Text] [ntext] not null,
	[Narrative] [ntext] null,
	[DisplayOrder] [int] not null,
	[ImageFileName] [nvarchar](50) null,
	constraint [pkUserClassQuestions] primary key clustered ([QuestionID])	
) on [primary]

create table [UserClassAnswers] (
	[AnswerID] [int] not null identity(1,1),
	[QuestionID] [int] not null CONSTRAINT [FK_UCAnswer_Question] FOREIGN KEY REFERENCES [UserClassQuestions] ([QuestionID]),
	[Text] [ntext] not null,
	[IsCorrect] [bit] not null,
	constraint [pkUserClassAnswers] primary key clustered ([AnswerID])	
) on [primary]

create table [UserTests] (
	[TestID] [int] not null identity(1,1),
	[UserClassID] [int] not null CONSTRAINT [FK_UserTest_UserClass] FOREIGN KEY REFERENCES [UserClasses] ([UserClassID]),
	constraint [pkUserTests] primary key clustered ([TestID])	
) on [primary]

create table [UserTestQuestions] (
	[TQuestionID] [int] not null identity(1,1),
	[QuestionID] [int] not null CONSTRAINT [FK_TQuestion_Question] FOREIGN KEY REFERENCES [UserClassQuestions] ([QuestionID]),
	[TestID] [int] not null CONSTRAINT [FK_TQuestion_Test] FOREIGN KEY REFERENCES [UserTests] ([TestID]),
	[DisplayOrder] [int] not null,
	constraint [pkUserTestQuestions] primary key clustered ([TQuestionID])	
) on [primary]

create table [UserTestAnswers] (
	[TAnswerID] [int] not null identity(1,1),
	[TQuestionID] [int] not null CONSTRAINT [FK_TAnswer_TQuestion] FOREIGN KEY REFERENCES [UserTestQuestions] ([TQuestionID]),
	[AnswerID] [int] not null CONSTRAINT [FK_TAnswer_Answer] FOREIGN KEY REFERENCES [UserClassAnswers] ([AnswerID]),
	[IsChosen] [bit] null,	
	constraint [pkUserTestAnswers] primary key clustered ([TAnswerID])	
) on [primary]

go

alter table [UserClasses] add 
	[AssignDate] [datetime] null,
	[StartDate] [datetime] null

alter table [UserTests] add
	[CompleteDate] [datetime] null
go

go
/***************************
 * db0006_AccountPlans.sql *
 ***************************/
create table [CustomerPlans] (
	[PlanID] [int] not null identity(1,1),
	[Name] [nvarchar](100) not null,
	[Description] [ntext] null,
	[MaxEmployees] [int] not null,
	[BaseCost] [money] not null,
	[CostPerExtra] [money] not null,
	[CostPerCredit] [money] not null,
	[IsDeleted] [bit] not null,
	constraint [pkCustomerPlans] primary key clustered ([PlanID])
) on [primary]
go


go
/****************************
 * db0007_Notifications.sql *
 ****************************/
create table [Notifications] (
	[NotificationID] [int] not null identity(1,1),
	[NotificationHeader] [nvarchar](100) not null,
	[NotificationString] [nvarchar](100) not null,
	[NotificationDateTime] [datetime] not null,
	[UserID] [int] not null CONSTRAINT [FK_Notifications_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[IsNew] [bit] not null,
	[IsRead] [bit] not null,
	constraint [pkNotifications] primary key clustered ([NotificationID])
) on [primary]
go

create table [NotificationParameters] (
	[ParameterID] [int] not null identity(1,1),
	[NotificationID] [int] not null CONSTRAINT [FK_Parameters_Notifications] FOREIGN KEY REFERENCES [Notifications] ([NotificationID]),
	[TextData] [ntext] null,
	[DisplayOrder] [int] not null,
	constraint [pkNotificationParameters] primary key clustered ([ParameterID])
) on [primary]
go

go
/********************************
 * db0008_MoreCustomerPlans.sql *
 ********************************/
alter table [CustomerPlans] add [BaseCredits] [int] not null constraint [defBaseCredits] default(0)
alter table [CustomerPlans] drop constraint [defBaseCredits]
go
alter table [CustomerPlans] add [Sequence] [int] not null constraint [defSequence] default(0)
alter table [CustomerPlans] drop constraint [defSequence]
go
update [CustomerPlans] set [Sequence] = (select COUNT(*) from [CustomerPlans] [cp] where [cp].[PlanID] <= [CustomerPlans].[PlanID])
go


go
/*******************************
 * db0009_CustomerAccounts.sql *
 *******************************/
create table [Customers] (
	[CustomerID] [int] not null identity(1,1),
	[Name] [nvarchar](100) not null,
	[Address1] [nvarchar](100) not null,
	[Address2] [nvarchar](100) null,
	[City] [nvarchar](50) not null,
	[State] [nvarchar](2) not null,
	[ZipCode] [nvarchar](10) not null,
	[PhoneNumber] [nvarchar](20) not null,
	[IsDeleted] [bit] not null,
	[PaidThroughDate] [datetime] not null,
	[ExpirationDate] [datetime] not null,
	[PlanID] [int] not null CONSTRAINT [FK_Customer_Plan] FOREIGN KEY REFERENCES [CustomerPlans] ([PlanID]),
	[PaymentMethod] [int] not null,
	constraint [pkCustomers] primary key clustered ([CustomerID])
) on [primary]
go

create table [CustomerLocations] (
	[LocationID] [int] not null identity(1,1),
	[Name] [nvarchar](100) not null,
	[Description] [ntext] null,
	[CustomerID] [int] not null CONSTRAINT [FK_Locations_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[IsDeleted] [bit] not null,
	constraint [pkCustomerLocations] primary key clustered ([LocationID])
) on [primary]
go

create table [CustomerDepartments] (
	[DepartmentID] [int] not null identity(1,1),
	[Name] [nvarchar](100) not null,
	[Description] [ntext] null,
	[CustomerID] [int] not null CONSTRAINT [FK_Departments_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[IsDeleted] [bit] not null,
	constraint [pkCustomerDepartments] primary key clustered ([DepartmentID])
) on [primary]
go

alter table [Customers] add [CreditCount] [int] not null
go

create table [UserLocations] (
	[UserID] [int] not null CONSTRAINT [FK_UserLocations_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[LocationID] [int] not null CONSTRAINT [FK_UserLocations_Location] FOREIGN KEY REFERENCES [CustomerLocations] ([LocationID]),
	constraint [pkUserLocations] primary key clustered ([UserID], [LocationID])
) on [primary]
go

create table [UserDepartments] (
	[UserID] [int] not null CONSTRAINT [FK_UserDepartments_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[DepartmentID] [int] not null CONSTRAINT [FK_UserDepartments_Department] FOREIGN KEY REFERENCES [CustomerDepartments] ([DepartmentID]),
	constraint [pkUserDepartments] primary key clustered ([UserID], [DepartmentID])
) on [primary]
go

create table [ConfigurationOptions] (
	[OptionID] [int] not null identity(1,1),
	[DefaultPermissionGroupID] [int] not null CONSTRAINT [FK_Options_DefPermGroup] FOREIGN KEY REFERENCES [PermissionGroups] ([GroupID]),
	constraint [pkConfigurationOptions] primary key clustered ([OptionID])
) on [primary]
go

alter table [PermissionGroups] add [IsAccountGroup] [bit] not null constraint [defIsAcctGrp] default(0)
alter table [PermissionGroups] drop constraint [defIsAcctGrp]
go

delete from [PermissionGroupItems] where [PermissionID] = 21
go

alter table [Customers] add
	[ContactFirstName] [nvarchar](50) null,
	[ContactLastName] [nvarchar](50) null,
	[ContactEmailAddress] [nvarchar](50) null,
	[ContactGender] [int] null,
	[ContactDateOfBirth] [datetime] null
go

alter table [Customers] add [IsPaid] [bit] not null constraint [defIsPaid] default(0)
alter table [Customers] drop constraint [defIsPaid]
alter table [Customers] drop column [PaidThroughDate]
go

alter table [CustomerLocations] add
	[Address1] [nvarchar](100) null,
	[Address2] [nvarchar](100) null,
	[City] [nvarchar](50) null,
	[State] [nvarchar](2) null,
	[ZipCode] [nvarchar](10) null
go

alter table [Customers] add [AdditionalEmployees] [int] not null constraint [defAE] default(0)
alter table [Customers] drop constraint [defAE]
go


go
/******************************
 * db0010_ClassCategories.sql *
 ******************************/
create table [ClassCategories] (
	[CategoryID] [int] not null identity(1,1),
	[Name] [nvarchar](100) not null,
	constraint [pkClassCategories] primary key clustered ([CategoryID])
) on [primary]

create table [ClassCategoryAssignments] (
	[ClassID] [int] not null CONSTRAINT [FK_CCA_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[CategoryID] [int] not null CONSTRAINT [FK_CCA_Category] FOREIGN KEY REFERENCES [ClassCategories] ([CategoryID]),
	constraint [pkClassCategoryAssignments] primary key clustered ([ClassID], [CategoryID])
) on [primary]
go

go
/***************************
 * db0011_ClassCredits.sql *
 ***************************/
alter table [Classes] add [Credits] [int] not null constraint [defCredits] default(20)
alter table [Classes] drop constraint [defCredits]
go

delete from UserTestAnswers
delete from UserTestQuestions
delete from UserTests
delete from UserClassAnswers
delete from UserClassQuestions
delete from UserClassVersionDocuments
delete from UserClassVersions
delete from UserClasses
go

alter table [Customers] add [CreditsSpent] [int] not null constraint [defCredits] default(0)
alter table [Customers] drop constraint [defCredits]
go

go
/**************************
 * db0012_EULAVersion.sql *
 **************************/
alter table [ConfigurationOptions] add [EULAVersion] [nvarchar](50) null
go
alter table [Users] add [EULAVersion] [nvarchar](50) null
go

go
/*******************************************
 * db0013_Remove_Customer_CreditsSpent.sql *
 *******************************************/
alter table [Customers] drop column [CreditsSpent]
go

go
/********************************
 * db0014_CustomerPurchases.sql *
 ********************************/
create table [CustomerPurchases] (
	[PurchaseID] [int] identity(470024, 1) not null,
	[CustomerID] [int] not null CONSTRAINT [FK_Purchase_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[PurchaseDate] [datetime] not null,
	[PlanName] [nvarchar](50) not null,
	[CreditCount] [int] not null,
	[AddlEmployees] [int] not null,
	[PlanCost] [money] not null,
	[PerCreditCost] [money] not null,
	[PerEmployeeCost] [money] not null,
	
	[CustomerName] [nvarchar](100) null,
	[CustomerContact] [nvarchar](100) null,
	[CustomerEmail] [nvarchar](50) null,
	[CustomerPhone] [nvarchar](20) null,
	
	constraint [pkCustomerPurchases] primary key clustered ([PurchaseID])
) on [primary]
go

alter table [Customers] add [ProfileID] [nvarchar](50) null
go

create table [CustomerCreditCards] (
	[CCProfileID] [nvarchar](50) not null,
	[CustomerID] [int] not null CONSTRAINT [FK_CC_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[MaskedCCNumber] [nvarchar](50) not null,
	constraint [pkCustomerCreditCards] primary key clustered ([CCProfileID])
) on [primary]
go

alter table [CustomerCreditCards] add [IsDeleted] [bit] not null constraint [defIsDelete] default(0)
alter table [CustomerCreditCards] drop constraint [defIsDelete]
go

alter table [CustomerPurchases] add
	[PaymentMethod] [int] not null,
	[PaymentDetail] [nvarchar](50) null
go

insert into [CustomerPurchases] ([CustomerID], [PurchaseDate], [PlanName], [CreditCount], [AddlEmployees], [PlanCost], [PerCreditCost], [PerEmployeeCost],
	[CustomerName], [CustomerContact], [CustomerEmail], [CustomerPhone], [PaymentMethod])
(select CustomerID, DATEADD(year, -1, expirationdate), cp.name, [c].CreditCount - [cp].BaseCredits, [c].[AdditionalEmployees], [cp].BaseCost, [cp].CostPerCredit, [cp].CostPerExtra,
	[c].Name, [c].contactfirstname + ' ' + [c].contactlastname, [c].[contactemailaddress], [c].PhoneNumber, 0 /*BillMeLater*/
	from [Customers] [c]
		inner join [CustomerPlans] [cp] on [c].[PlanID] = [cp].[PlanID])
go

alter table [CustomerCreditCards] add [PaymentMethod] [int] not null constraint [defPM] default(1)
alter table [CustomerCreditCards] drop constraint [defPM]
go

go
/***************************************
 * db0015_CustomerPermissionGroups.sql *
 ***************************************/
alter table [PermissionGroups] 
	add [CustomerID] [int] null CONSTRAINT [FK_PGroup_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID])
go


go
/***************************
 * db0016_ActivityLogs.sql *
 ***************************/
create table [UserLoginActivity] (
	[ActivityID] [int] not null identity(1,1),
	[UserID] [int] not null CONSTRAINT [FK_Activity_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[LoginDateTime] [datetime] not null,
	constraint [pkUserLoginActivity] primary key clustered ([ActivityID])
) on [primary]
go

create table [UserClassActivity] (
	[ActivityID] [int] not null identity(1,1),
	[UserClassID] [int] not null CONSTRAINT [FK_Activity_UserClass] FOREIGN KEY REFERENCES [UserClasses] ([UserClassID]),
	[PlayDateTime] [datetime] null,
	[PauseDateTime] [datetime] null,
	[TimeIndex] [float] not null,
	constraint [pkUserClassActivity] primary key clustered ([ActivityID])
) on [primary]
go

alter table [UserClasses] add [OverdueWarning] [int] null
go
alter table [Customers] add [RenewWarning] [int] null
go

alter table [ConfigurationOptions] 
	add [DefaultCreditWarning] [int] not null constraint [defDCW] default(100),
		[DefaultEmployeeWarning] [int] not null constraint [defDEW] default(5)
go
alter table [ConfigurationOptions] drop constraint [defDCW]
alter table [ConfigurationOptions] drop constraint [defDEW]
go

alter table [Customers] 
	add [CreditWarning] [int] not null constraint [defDCW] default(100),
		[EmployeeWarning] [int] not null constraint [defDEW] default(5)
go
alter table [Customers] drop constraint [defDCW]
alter table [Customers] drop constraint [defDEW]
go


go
/*******************************
 * db0017_DashboardWidgets.sql *
 *******************************/
create table [UserDashboardWidgets] (
	[UDWidgetID] [int] identity(1,1) not null,
	[UserID] [int] not null CONSTRAINT [FK_UDWidget_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[WidgetID] [int] not null,
	[DisplayOrder] [int] not null,
	constraint [pkUserDashboardWidgets] primary key clustered ([UDWidgetID])
) on [primary]
go


go
/****************************
 * db0018_TieredPricing.sql *
 ****************************/
alter table [ConfigurationOptions]
	add [CostPerEmployee] [money] not null constraint [defCPE] default(225)
go
alter table [ConfigurationOptions]
	drop constraint [defCPE]
go

create table [CreditTiers] (
	[TierID] [int] identity(1,1) not null,
	[MinimumCreditPurchase] [int] not null,
	[CostPerCredit] [money] not null,
	constraint [pkCreditTiers] primary key clustered ([TierID])
) on [primary]
go

alter table [Classes]
	add [IsBaseClass] [bit] not null constraint [defIBC] default(0)
go
alter table [Classes]
	drop constraint [defIBC]
go

delete from [CustomerPurchases]
alter table [CustomerPurchases] drop column [PlanName]
alter table [CustomerPurchases] drop column [PlanCost]
alter table [CustomerPurchases] drop column [AddlEmployees]
alter table [CustomerPurchases] add [EmployeeCount] [int] not null
go

alter table [Customers] add [EmployeeCount] [int] not null constraint [defEC] default(0)
go
alter table [Customers] drop constraint [defEC]
go
update [Customers] set [EmployeeCount] = [cp].[MaxEmployees] + [AdditionalEmployees]
	from [Customers]
		inner join [CustomerPlans] [cp] on [Customers].[PlanID] = [cp].[PlanID] 
go

insert into [CustomerPurchases] ([CustomerID], [PurchaseDate], [CreditCount], [EmployeeCount], [PerCreditCost], [PerEmployeeCost],
	[CustomerName], [CustomerContact], [CustomerEmail], [CustomerPhone], [PaymentMethod])
(select CustomerID, DATEADD(year, -1, expirationdate), [c].CreditCount, [c].[EmployeeCount], 1, 225,
	[c].Name, [c].contactfirstname + ' ' + [c].contactlastname, [c].[contactemailaddress], [c].PhoneNumber, 0 /*BillMeLater*/
	from [Customers] [c]
		inner join [CustomerPlans] [cp] on [c].[PlanID] = [cp].[PlanID])
go
alter table [Customers] drop column [AdditionalEmployees]
go

alter table [Customers] drop constraint [FK_Customer_Plan]
alter table [Customers] drop column [PlanID]
go
drop table [CustomerPlans]
go


go
/**********************************
 * db0019_NewDashboardWidgets.sql *
 **********************************/
alter table [CustomerLocations] add
	[SDName] [nvarchar](100) null,
	[SDPhone] [nvarchar](20) null,
	[SDCellPhone] [nvarchar](20) null,
	[SDEmail] [nvarchar](50) null
go

delete from [userdashboardwidgets]
go

go
/****************************
 * db0020_FAQManagement.sql *
 ****************************/
create table [ClassFAQs] (
	[FAQID] [int] not null identity(1,1),
	[ClassID] [int] not null CONSTRAINT [fkClassFAQ_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[AskUserID] [int] not null CONSTRAINT [fkClassFAQ_AskUser] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[AskText] [ntext] null,
	[UpdatedAskText] [ntext] null,
	[DateAsked] [datetime] not null,
	[AnswerUserID] [int] null CONSTRAINT [fkClassFAQ_AnswerUser] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[AnswerText] [ntext] null,
	[DateAnswered] [datetime] null,
	[IsPublic] [bit] not null,
	constraint [pkClassFAQs] primary key clustered ([FAQID])	
) on [primary]
go

go
/******************************
 * db0021_SafetyDocuments.sql *
 ******************************/
CREATE TABLE [ClassVersionSafetyDocuments](
	[SafetyDocumentID] [int] IDENTITY(1,1) NOT NULL,
	[VersionID] [int] NOT NULL CONSTRAINT [FK_CVSafetyDocument_Version] FOREIGN KEY REFERENCES [ClassVersions] ([VersionID]),
	[FileName] [nvarchar](50) NULL,
	[OriginalName] [nvarchar](50) NULL,
	[IsDeleted] [bit] NOT NULL,
	CONSTRAINT [pkClassVersionSafetyDocuments] PRIMARY KEY CLUSTERED ([SafetyDocumentID])
) ON [PRIMARY]
GO

delete from [UserClasses] where [UserClassID] not in (select [UserClassID] from [UserClassVersions])
go

go
/************************************
 * db0022_Class_ReferenceNumber.sql *
 ************************************/
alter table [Classes] add [ReferenceNumber] [nvarchar](10) null
go

CREATE TABLE [CustomerAccountChanges] (
	[ChangeID] [int] IDENTITY(1,1) NOT NULL,
	[CustomerID] [int] NOT NULL CONSTRAINT [FK_CAC_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[UserID] [int] NOT NULL CONSTRAINT [FK_CAC_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[Credits] [int] NULL,
	[UserAccounts] [int] NULL,
	[ChangeDateTime] [datetime] not null,
	CONSTRAINT [pkCustomerAccountChanges] PRIMARY KEY CLUSTERED ([ChangeID])
) ON [PRIMARY]
GO

CREATE TABLE [CustomerReclaimClasses] (
	[ReclaimID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NOT NULL CONSTRAINT [FK_CRC_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[EmployeeID] [int] NOT NULL CONSTRAINT [FK_CRC_Employee] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[ClassID] [int] NOT NULL CONSTRAINT [FK_CRC_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[Credits] [int] NOT NULL,
	[ReclaimDateTime] [datetime] not null,
	CONSTRAINT [pkCustomerReclaimClasses] PRIMARY KEY CLUSTERED ([ReclaimID])
) ON [PRIMARY]
GO

create table [ClassScreenings] (
	[ScreeningID] [int] identity(1,1) not null,
	[UserID] [int] NOT NULL CONSTRAINT [FK_ClassScreen_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[ClassID] [int] NOT NULL CONSTRAINT [FK_ClassScreen_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[ScreenDateTime] [datetime] not null,
	constraint [pkClassScreenings] primary key clustered ([ScreeningID])
) on [primary]
go

go
/******************************
 * db0023_InjuryIncidents.sql *
 ******************************/
-- actual injury information
create table [InjuryIncidents] (
	[IncidentID] [int] identity(17881, 1) not null,
	[CustomerID] [int] not null CONSTRAINT [fkInjuryIncidents_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	constraint [pkInjuryIncidents] primary key clustered ([IncidentID])
) on [primary]

create table [InjuryIncidentVersions] (
	[VersionID] [int] identity(1,1) not null,
	[IncidentID] [int] not null CONSTRAINT [fkIIVersion_Incident] FOREIGN KEY REFERENCES [InjuryIncidents] ([IncidentID]),
	[EnteredByUserID] [int] not null CONSTRAINT [fkIIVersion_EnterUser] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[EnteredOnDate] [datetime] not null,

	-- form 300 fields
	[InjuredUserID] [int] not null CONSTRAINT [fkIIVersion_InjuredUser] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[JobTitle] [nvarchar](50) null,
	[DateOfInjury] [datetime] not null,
	[WhereEventOccurred] [nvarchar](50) null,
	[CaseClassification] [int] not null,
	[DaysLost] [int] null,
	[TypeOfIllness] [int] not null,

	-- form 301 fields
	[Address1] [nvarchar](100) null,
	[Address2] [nvarchar](100) null,
	[City] [nvarchar](50) null,
	[State] [nvarchar](2) null,
	[ZipCode] [nvarchar](10) null,
	[DateOfBirth] [datetime] null,
	[HCName] [nvarchar](100) null,
	[HCAddress1] [nvarchar](100) null,
	[HCAddress2] [nvarchar](100) null,
	[HCCity] [nvarchar](50) null,
	[HCState] [nvarchar](2) null,
	[HCZipCode] [nvarchar](10) null,
	[HCEmergencyRoom] [bit] not null,
	[HCHospitalized] [bit] not null,
	[StartWorkTime] [datetime] null,
	[EventTime] [datetime] null,
	[TimeUnknown] [bit] not null,
	[DateOfDeath] [datetime] null,

	-- other fields
	[LocationID] [int] not null CONSTRAINT [fkIIVersion_Location] FOREIGN KEY REFERENCES [CustomerLocations] ([LocationID]),
	[IsPrivacy] [bit] not null,

	constraint [pkInjuryIncidentVersions] primary key clustered ([VersionID])
) on [primary]

go

alter table [InjuryIncidentVersions] add [HCPhysician] [nvarchar](100) null
go

alter table [InjuryIncidentVersions] drop column [TimeUnknown]
go

alter table [InjuryIncidentVersions] add 
	[SummaryDescription] [ntext] null,
	[DoingActivity] [ntext] null,
	[WhatHappened] [ntext] null,
	[InjuryOrIllness] [ntext] null,
	[ObjectHarmedEmployee] [ntext] null
go

alter table [InjuryIncidentVersions] add
	[MDAddress1] [nvarchar](100) null,
	[MDAddress2] [nvarchar](100) null,
	[MDCity] [nvarchar](50) null,
	[MDState] [nvarchar](2) null,
	[MDZipCode] [nvarchar](10) null
go


go
/***********************************
 * db0024_CustomerPurchaseType.sql *
 ***********************************/
alter table [CustomerPurchases] add [PurchaseType] [int] not null constraint [defPType] default(0)
alter table [CustomerPurchases] drop constraint [defPType]
go

update [CustomerPurchases] 
	set [PurchaseType] = 1 
where exists (select * from [CustomerPurchases] [prev] where [prev].[CustomerID] = [CustomerPurchases].[CustomerID] and [prev].[PurchaseID] < [CustomerPurchases].[PurchaseID])

--select * from [CustomerPurchases]
go

create table [DiscountCodes] (
	[DiscountCodeID] [int] not null identity(1,1),
	[Name] [nvarchar](50) not null,
	[Description] [ntext] null,
	[CodeType] [int] not null,
	[OffAmount] [float] not null,
	[FirstAmount] [float] not null,
	[CodeText] [nvarchar](20) not null,
	[StartDate] [datetime] not null,
	[EndDate] [datetime] not null,
	[IsMultiUse] [bit] not null,
	[IsNewPurchase] [bit] not null,
	[IsExistingCustomer] [bit] not null,
	[IsRenewal] [bit] not null,
	constraint [pkDiscountCodes] primary key clustered ([DiscountCodeID])	 
) on [primary]
go

alter table [CustomerPurchases] add [DiscountCodeID] [int] null CONSTRAINT [fkPurchase_Discount] FOREIGN KEY REFERENCES [DiscountCodes] ([DiscountCodeID])
go

alter table [DiscountCodes] add [IsDeleted] [bit] not null
go

alter table [CustomerPurchases] add [DiscountCodeAmount] [money] null, [DiscountCodeText] [nvarchar](20)
go

alter table [CustomerPurchases] add [TransactionId] [nvarchar](50)
go


go
/*******************************
 * db0025_CustomerPaidDate.sql *
 *******************************/
alter table [Customers] add [PaidDate] [datetime] null
go

go
/******************************
 * db0026_PuchaseSalesTax.sql *
 ******************************/
alter table CustomerPurchases add [SalesTax] [money] not null constraint [defSalesTax] default(0)
alter table CustomerPurchases drop constraint [defSalesTax]
go


go
/************************************
 * db0027_UserClassPrefLanguage.sql *
 ************************************/
alter table [UserClasses] add [PrefLanguageID] [int] null constraint [FK_UserClass_Language] foreign key references [Languages] ([LanguageID])
go
update [UserClasses] set [PrefLanguageID] = [LanguageID]
	from [UserClasses] inner join [Users] on [UserClasses].[UserID] = [Users].[UserID]
	where [Status] <> 1
update [UserClasses] set [PrefLanguageID] = 1 
	where not exists( select * from [UserClassVersions] [ucv] where [ucv].[LanguageID] = [PrefLanguageID] )
	and [Status] <> 1
go

--select * from UserClasses

go
/************************************
 * db0028_BillMeLaterCorrection.sql *
 ************************************/
select * from CustomerPurchases where TransactionId is null
/*
update CustomerPurchases set PaymentMethod = 0 where TransactionId is null
*/

go
/***********************************
 * db0029_ScreeningRoomUpdates.sql *
 ***********************************/
alter table [Classes] add [OriginalGuideName] [nvarchar](50) null,
	[GuideFileName] [nvarchar](50) null
go

go
/************************************
 * db0030_CustomersTrackCredits.sql *
 ************************************/
alter table [Customers] add [TracksCredits] [bit] not null constraint [defTC] default(1)
alter table [Customers] drop constraint [defTC] 
go

alter table [UserTests] add [Score] [float] null
go

create function TestScore( @TestID int )
returns [float]
as
begin
	declare @total int
	select @total = count(*) from UserTestQuestions where TestID = @TestID
	
	if( @total > 0 )
	begin
		declare @correct int
		
		select @correct = count(*) from UserTestQuestions utq
				inner join UserTestAnswers uta on utq.TQuestionID = uta.TQuestionID and uta.IsChosen = 1 and utq.TestID = @TestID
				inner join UserClassAnswers uca on uta.AnswerID = uca.AnswerID and uca.IsCorrect = 1

		return (100.0 * @correct) / @total;
	end

	return 0.0
end
go

create procedure GetTestScore @TestID int
as
begin
	select dbo.TestScore( @TestID ) as Score
end
go

update [UserTests] set [Score] = dbo.TestScore( TestID ) where CompleteDate is not null
go

alter table [UserClassActivity] drop constraint [FK_Activity_UserClass]
alter table [UserClassVersions] drop constraint [FK_UserClass_Version]
alter table [UserClassVersionDocuments] drop constraint [FK_UCVDocument_Version]
alter table [UserClassQuestions] drop constraint [FK_UCQuestion_Version]
alter table [UserClassAnswers] drop constraint [FK_UCAnswer_Question]
alter table [UserTests] drop constraint [FK_UserTest_UserClass]
alter table [UserTestQuestions] drop constraint [FK_TQuestion_Test]
alter table [UserTestAnswers] drop constraint [FK_TAnswer_TQuestion]
go

alter table [UserClassActivity] add constraint [FK_Activity_UserClass] foreign key ([UserClassID]) references [UserClasses]([UserClassID]) on delete cascade
alter table [UserClassVersions] add constraint [FK_UserClass_Version] foreign key ([UserClassID]) references [UserClasses]([UserClassID]) on delete cascade
alter table [UserClassVersionDocuments] add constraint [FK_UCVDocument_Version] foreign key ([VersionID]) references [UserClassVersions]([VersionID]) on delete cascade
alter table [UserClassQuestions] add constraint [FK_UCQuestion_Version] foreign key ([VersionID]) references [UserClassVersions]([VersionID]) on delete cascade
alter table [UserClassAnswers] add constraint [FK_UCAnswer_Question] foreign key ([QuestionID]) references [UserClassQuestions]([QuestionID]) on delete cascade
alter table [UserTests] add constraint [FK_UserTest_UserClass] foreign key ([UserClassID]) references [UserClasses]([UserClassID]) on delete cascade
alter table [UserTestQuestions] add constraint [FK_TQuestion_Test] foreign key ([TestID]) references [UserTests]([TestID]) on delete cascade
alter table [UserTestAnswers] add constraint [FK_TAnswer_TQuestion] foreign key ([TQuestionID]) references [UserTestQuestions]([TQuestionID]) on delete cascade
go

go
/*************************
 * db0031_PDFClasses.sql *
 *************************/
alter table [Classes] add
	[IsVideo] [bit] not null constraint [defVideo] default(1),
	[PDFFileName] [nvarchar](50) null,
	[OriginalPDFName] [nvarchar](50) null,
	[CustomerID] [int] null constraint [FK_Class_Customer] foreign key references [Customers]([CustomerID])
alter table [Classes] drop constraint [defVideo]
go

alter table [UserClasses] add
	[IsVideo] [bit] not null constraint [defVideo] default(1),
	[PDFFileName] [nvarchar](50) null
alter table [UserClasses] drop constraint [defVideo]
go


go
/*********************
 * db0032_Videos.sql *
 *********************/
create table [Videos] (
	[VideoID] [int] not null identity(1,1),
	[Name] [nvarchar](200) not null,
	[OriginalFileName] [nvarchar](100) not null,
	[BlobFileName] [nvarchar](100) not null,
	[JobID] [nvarchar](100) null,
	[StreamName] [nvarchar](500) null,
	[IsDeleted] [bit] not null,
	[DateCreated] [datetime] not null,
	CONSTRAINT [pkVideos] PRIMARY KEY CLUSTERED ([VideoID])
) on [primary]
go

insert into [Videos] ([Name], [OriginalFileName], [BlobFileName], [IsDeleted], [DateCreated])
	(select [Name], [OriginalVideoName], [VideoFileName], 0, getutcdate() from [Classes] where [IsVideo] = 1)
insert into [Videos] ([Name], [OriginalFileName], [BlobFileName], [IsDeleted], [DateCreated])
	(select [Name], 'unknown.mp4', [VideoFileName], 0, getutcdate() from [UserClasses] where [IsVideo] = 1)
delete from [Videos] where exists(select * from videos v2 where Videos.BlobFileName = v2.BlobFileName and v2.VideoID < videos.VideoID)
go

alter table [Classes] add [VideoID] [int] NULL constraint [FK_Class_Video] foreign key references [Videos] ([VideoID])
go

alter table [UserClasses] add [VideoID] [int] NULL constraint [FK_UserClass_Video] foreign key references [Videos] ([VideoID])
go

/*
update [Classes] set [Classes].[VideoID] = [Videos].[VideoID]
	from [Classes]
		inner join [Videos] on [Videos].[BlobFileName] = [Classes].[VideoFileName]
go

update [UserClasses] set [UserClasses].[VideoID] = [Videos].[VideoID]
	from [UserClasses]
		inner join [Videos] on [Videos].[BlobFileName] = [UserClasses].[VideoFileName]
go
*/
/*
alter table [Classes] drop column [OriginalVideoName], [VideoFileName]
alter table [UserClasses] drop column [VideoFileName]
go
*/

go
/*********************************
 * db0033_ClassVersionVideos.sql *
 *********************************/
alter table [ClassVersions] add 
	[VideoID] [int] NULL constraint [FK_ClassVersion_Video] foreign key references [Videos] ([VideoID]),
	[IsVideo] [bit] not null constraint [defIV] default(0),
	[PDFFileName] [nvarchar](50) null,
	[OriginalPDFName] [nvarchar](50) null
go

alter table [ClassVersions] drop constraint [defIV]
go

alter table [UserClassVersions] add [VideoID] [int] NULL constraint [FK_UserClassVersion_Video] foreign key references [Videos] ([VideoID]),
	[IsVideo] [bit] not null constraint [defIV] default(0),
	[PDFFileName] [nvarchar](50) null
go

alter table [UserClassVersions] drop constraint [defIV]
go

update [ClassVersions] 
set [VideoID] = c.[VideoID],
	[IsVideo] = c.[IsVideo],
	[PDFFileName] = c.[PDFFileName],
	[OriginalPDFName] = c.[OriginalPDFName]
from [ClassVersions] cv
	inner join [Classes] c on cv.[ClassID] = c.[ClassID]
go

update [UserClassVersions] 
set [VideoID] = uc.[VideoID],
	[IsVideo] = uc.[IsVideo],
	[PDFFileName] = uc.[PDFFileName]
from [UserClassVersions] ucv
	inner join [UserClasses] uc on ucv.[UserClassID] = uc.[UserClassID]
go

alter table [Classes] drop constraint [FK_Class_Video]
alter table [UserClasses] drop constraint [FK_UserClass_Video]
go

alter table [Classes] drop column [VideoID],
	[IsVideo],
	[PDFFileName],
	[OriginalPDFName]
go

alter table [UserClasses] drop column [VideoID],
	[IsVideo],
	[PDFFileName]
go


go
/***************************
 * db0034_ScoreImports.sql *
 ***************************/
create table [ScoreImports] (
	[ImportID] [int] not null identity(1,1),
	[CustomerID] [int] not null CONSTRAINT [FK_ScoreImport_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[ClassID] [int] not null CONSTRAINT [FK_ScoreImport_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID]),
	[OriginalSourceFileName] [nvarchar](200) not null,
	[SourceFileName] [nvarchar](100) not null,
	[OriginalErrorFileName] [nvarchar](200) null,
	[ErrorFileName] [nvarchar](100) null,
	[ImportCount] [int] not null,
	[ErrorCount] [int] not null,
	[DateImported] [datetime] not null,
	CONSTRAINT [pkScoreImports] PRIMARY KEY CLUSTERED ([ImportID])	
) on [primary]
go

alter table [UserTests] add [IsImport] [bit] not null constraint [defII] default(0)
alter table [UserTests] drop constraint [defII]
go

alter table [ScoreImports] add [UserID] [int] not null constraint [FK_ScoreImport_User] foreign key references [Users]([UserID])
go

go
/************************************
 * db0035_EmployeeEmailOptional.sql *
 ************************************/
alter table [Users] alter column [EmailAddress] [nvarchar](50) null
go


go
/********************************************
 * db0036_InstructorGuideToClassVersion.sql *
 ********************************************/
alter table [ClassVersions] add [OriginalGuideName] [nvarchar](50) null,
	[GuideFileName] [nvarchar](50) null
go

update [ClassVersions] set [OriginalGuideName] = cl.[OriginalGuideName],
    [GuideFileName] = cl.[GuideFileName]
from [ClassVersions] cv
    inner join Classes cl on cv.ClassID = cl.ClassID
go

alter table [Classes] drop column [OriginalGuideName], [GuideFileName]
go


go
/*********************************
 * db0037_CustomerSignatures.sql *
 *********************************/
create table [CustomerSignatures] (
	[SignatureID] [int] not null identity(1,1),
	[CustomerID] [int] not null CONSTRAINT [FK_Signature_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[Name] [nvarchar](100) not null,
	[Title] [nvarchar](100) not null,
	[ImageFileName] [nvarchar](50) null,
	[OriginalImageFileName] [nvarchar](100) null
	constraint [pkCustomerSignatures] primary key clustered ([SignatureID])	 
) on [primary]
go


go
/****************************
 * db0038_CustomerLogos.sql *
 ****************************/
alter table [Customers] add [LogoFileName] [nvarchar](50) null, [OriginalLogoFileName] [nvarchar](100) null
go


go
/***********************************
 * db0039_ThirdPartyClassLogos.sql *
 ***********************************/
alter table [Classes] add [LogoFileName] [nvarchar](50) null, [OriginalLogoFileName] [nvarchar](100) null
go


go
/*******************************
 * db0040_DeferSetupEmails.sql *
 *******************************/
alter table [Users] add [SetupEmailSent] [bit] not null constraint [defIsSent] default(1)
alter table [Users] drop constraint [defIsSent]
go


go
/***************************************
 * db0041_ScoreImportSignatureFile.sql *
 ***************************************/
alter table [ScoreImports] add [SignatureFileName] [nvarchar](100) null, [OriginalSignatureFileName] [nvarchar](200) null
go


go
/*************************************
 * db0042_ClassEmailFrequencysql.sql *
 *************************************/
alter table [Customers] add [ClassEmailFrequency] [int] not null default(0)
go


go
/********************************
 * db0043_ForeignKeyIndexes.sql *
 ********************************/
If IndexProperty(Object_Id('ClassVersions'), 'IX_ClassVersions_VideoID', 'IndexId') Is Null begin create index [IX_ClassVersions_VideoID] on [ClassVersions]([VideoID]) end
go
If IndexProperty(Object_Id('UserClassVersions'), 'IX_UserClassVersions_VideoID', 'IndexId') Is Null begin create index [IX_UserClassVersions_VideoID] on [UserClassVersions]([VideoID]) end
go
If IndexProperty(Object_Id('UserDashboardWidgets'), 'IX_UserDashboardWidgets_UserID', 'IndexId') Is Null begin create index [IX_UserDashboardWidgets_UserID] on [UserDashboardWidgets]([UserID]) end
go
If IndexProperty(Object_Id('ClassFAQs'), 'IX_ClassFAQs_AskUserID', 'IndexId') Is Null begin create index [IX_ClassFAQs_AskUserID] on [ClassFAQs]([AskUserID]) end
go
If IndexProperty(Object_Id('ClassFAQs'), 'IX_ClassFAQs_AnswerUserID', 'IndexId') Is Null begin create index [IX_ClassFAQs_AnswerUserID] on [ClassFAQs]([AnswerUserID]) end
go
If IndexProperty(Object_Id('CustomerAccountChanges'), 'IX_CustomerAccountChanges_UserID', 'IndexId') Is Null begin create index [IX_CustomerAccountChanges_UserID] on [CustomerAccountChanges]([UserID]) end
go
If IndexProperty(Object_Id('CustomerReclaimClasses'), 'IX_CustomerReclaimClasses_UserID', 'IndexId') Is Null begin create index [IX_CustomerReclaimClasses_UserID] on [CustomerReclaimClasses]([UserID]) end
go
If IndexProperty(Object_Id('CustomerReclaimClasses'), 'IX_CustomerReclaimClasses_EmployeeID', 'IndexId') Is Null begin create index [IX_CustomerReclaimClasses_EmployeeID] on [CustomerReclaimClasses]([EmployeeID]) end
go
If IndexProperty(Object_Id('ClassScreenings'), 'IX_ClassScreenings_UserID', 'IndexId') Is Null begin create index [IX_ClassScreenings_UserID] on [ClassScreenings]([UserID]) end
go
If IndexProperty(Object_Id('ResetEmails'), 'IX_ResetEmails_UserID', 'IndexId') Is Null begin create index [IX_ResetEmails_UserID] on [ResetEmails]([UserID]) end
go
If IndexProperty(Object_Id('InjuryIncidentVersions'), 'IX_InjuryIncidentVersions_EnteredByUserID', 'IndexId') Is Null begin create index [IX_InjuryIncidentVersions_EnteredByUserID] on [InjuryIncidentVersions]([EnteredByUserID]) end
go
If IndexProperty(Object_Id('InjuryIncidentVersions'), 'IX_InjuryIncidentVersions_InjuredUserID', 'IndexId') Is Null begin create index [IX_InjuryIncidentVersions_InjuredUserID] on [InjuryIncidentVersions]([InjuredUserID]) end
go
If IndexProperty(Object_Id('UserClasses'), 'IX_UserClasses_UserID', 'IndexId') Is Null begin create index [IX_UserClasses_UserID] on [UserClasses]([UserID]) end
go
If IndexProperty(Object_Id('ScoreImports'), 'IX_ScoreImports_UserID', 'IndexId') Is Null begin create index [IX_ScoreImports_UserID] on [ScoreImports]([UserID]) end
go
If IndexProperty(Object_Id('Notifications'), 'IX_Notifications_UserID', 'IndexId') Is Null begin create index [IX_Notifications_UserID] on [Notifications]([UserID]) end
go
If IndexProperty(Object_Id('UserLoginActivity'), 'IX_UserLoginActivity_UserID', 'IndexId') Is Null begin create index [IX_UserLoginActivity_UserID] on [UserLoginActivity]([UserID]) end
go
If IndexProperty(Object_Id('Users'), 'IX_Users_LanguageID', 'IndexId') Is Null begin create index [IX_Users_LanguageID] on [Users]([LanguageID]) end
go
If IndexProperty(Object_Id('ClassVersions'), 'IX_ClassVersions_LanguageID', 'IndexId') Is Null begin create index [IX_ClassVersions_LanguageID] on [ClassVersions]([LanguageID]) end
go
If IndexProperty(Object_Id('UserClassVersions'), 'IX_UserClassVersions_LanguageID', 'IndexId') Is Null begin create index [IX_UserClassVersions_LanguageID] on [UserClassVersions]([LanguageID]) end
go
If IndexProperty(Object_Id('UserClasses'), 'IX_UserClasses_PrefLanguageID', 'IndexId') Is Null begin create index [IX_UserClasses_PrefLanguageID] on [UserClasses]([PrefLanguageID]) end
go
If IndexProperty(Object_Id('ConfigurationOptions'), 'IX_ConfigurationOptions_DefaultPermissionGroupID', 'IndexId') Is Null begin create index [IX_ConfigurationOptions_DefaultPermissionGroupID] on [ConfigurationOptions]([DefaultPermissionGroupID]) end
go
If IndexProperty(Object_Id('InjuryIncidentVersions'), 'IX_InjuryIncidentVersions_IncidentID', 'IndexId') Is Null begin create index [IX_InjuryIncidentVersions_IncidentID] on [InjuryIncidentVersions]([IncidentID]) end
go
If IndexProperty(Object_Id('ClassFAQs'), 'IX_ClassFAQs_ClassID', 'IndexId') Is Null begin create index [IX_ClassFAQs_ClassID] on [ClassFAQs]([ClassID]) end
go
If IndexProperty(Object_Id('CustomerReclaimClasses'), 'IX_CustomerReclaimClasses_ClassID', 'IndexId') Is Null begin create index [IX_CustomerReclaimClasses_ClassID] on [CustomerReclaimClasses]([ClassID]) end
go
If IndexProperty(Object_Id('ClassScreenings'), 'IX_ClassScreenings_ClassID', 'IndexId') Is Null begin create index [IX_ClassScreenings_ClassID] on [ClassScreenings]([ClassID]) end
go
If IndexProperty(Object_Id('ClassVersions'), 'IX_ClassVersions_ClassID', 'IndexId') Is Null begin create index [IX_ClassVersions_ClassID] on [ClassVersions]([ClassID]) end
go
If IndexProperty(Object_Id('UserClasses'), 'IX_UserClasses_ClassID', 'IndexId') Is Null begin create index [IX_UserClasses_ClassID] on [UserClasses]([ClassID]) end
go
If IndexProperty(Object_Id('ScoreImports'), 'IX_ScoreImports_ClassID', 'IndexId') Is Null begin create index [IX_ScoreImports_ClassID] on [ScoreImports]([ClassID]) end
go
If IndexProperty(Object_Id('ClassVersionSafetyDocuments'), 'IX_ClassVersionSafetyDocuments_VersionID', 'IndexId') Is Null begin create index [IX_ClassVersionSafetyDocuments_VersionID] on [ClassVersionSafetyDocuments]([VersionID]) end
go
If IndexProperty(Object_Id('ClassVersionDocuments'), 'IX_ClassVersionDocuments_VersionID', 'IndexId') Is Null begin create index [IX_ClassVersionDocuments_VersionID] on [ClassVersionDocuments]([VersionID]) end
go
If IndexProperty(Object_Id('ClassQuestions'), 'IX_ClassQuestions_VersionID', 'IndexId') Is Null begin create index [IX_ClassQuestions_VersionID] on [ClassQuestions]([VersionID]) end
go
If IndexProperty(Object_Id('CustomerPurchases'), 'IX_CustomerPurchases_DiscountCodeID', 'IndexId') Is Null begin create index [IX_CustomerPurchases_DiscountCodeID] on [CustomerPurchases]([DiscountCodeID]) end
go
If IndexProperty(Object_Id('ClassAnswers'), 'IX_ClassAnswers_QuestionID', 'IndexId') Is Null begin create index [IX_ClassAnswers_QuestionID] on [ClassAnswers]([QuestionID]) end
go
If IndexProperty(Object_Id('UserClassActivity'), 'IX_UserClassActivity_UserClassID', 'IndexId') Is Null begin create index [IX_UserClassActivity_UserClassID] on [UserClassActivity]([UserClassID]) end
go
If IndexProperty(Object_Id('UserClassVersions'), 'IX_UserClassVersions_UserClassID', 'IndexId') Is Null begin create index [IX_UserClassVersions_UserClassID] on [UserClassVersions]([UserClassID]) end
go
If IndexProperty(Object_Id('UserTests'), 'IX_UserTests_UserClassID', 'IndexId') Is Null begin create index [IX_UserTests_UserClassID] on [UserTests]([UserClassID]) end
go
If IndexProperty(Object_Id('UserClassVersionDocuments'), 'IX_UserClassVersionDocuments_VersionID', 'IndexId') Is Null begin create index [IX_UserClassVersionDocuments_VersionID] on [UserClassVersionDocuments]([VersionID]) end
go
If IndexProperty(Object_Id('UserClassQuestions'), 'IX_UserClassQuestions_VersionID', 'IndexId') Is Null begin create index [IX_UserClassQuestions_VersionID] on [UserClassQuestions]([VersionID]) end
go
If IndexProperty(Object_Id('UserTestQuestions'), 'IX_UserTestQuestions_QuestionID', 'IndexId') Is Null begin create index [IX_UserTestQuestions_QuestionID] on [UserTestQuestions]([QuestionID]) end
go
If IndexProperty(Object_Id('UserClassAnswers'), 'IX_UserClassAnswers_QuestionID', 'IndexId') Is Null begin create index [IX_UserClassAnswers_QuestionID] on [UserClassAnswers]([QuestionID]) end
go
If IndexProperty(Object_Id('UserTestAnswers'), 'IX_UserTestAnswers_AnswerID', 'IndexId') Is Null begin create index [IX_UserTestAnswers_AnswerID] on [UserTestAnswers]([AnswerID]) end
go
If IndexProperty(Object_Id('UserTestQuestions'), 'IX_UserTestQuestions_TestID', 'IndexId') Is Null begin create index [IX_UserTestQuestions_TestID] on [UserTestQuestions]([TestID]) end
go
If IndexProperty(Object_Id('UserTestAnswers'), 'IX_UserTestAnswers_TQuestionID', 'IndexId') Is Null begin create index [IX_UserTestAnswers_TQuestionID] on [UserTestAnswers]([TQuestionID]) end
go
If IndexProperty(Object_Id('NotificationParameters'), 'IX_NotificationParameters_NotificationID', 'IndexId') Is Null begin create index [IX_NotificationParameters_NotificationID] on [NotificationParameters]([NotificationID]) end
go
If IndexProperty(Object_Id('CustomerAccountChanges'), 'IX_CustomerAccountChanges_CustomerID', 'IndexId') Is Null begin create index [IX_CustomerAccountChanges_CustomerID] on [CustomerAccountChanges]([CustomerID]) end
go
If IndexProperty(Object_Id('InjuryIncidents'), 'IX_InjuryIncidents_CustomerID', 'IndexId') Is Null begin create index [IX_InjuryIncidents_CustomerID] on [InjuryIncidents]([CustomerID]) end
go
If IndexProperty(Object_Id('ScoreImports'), 'IX_ScoreImports_CustomerID', 'IndexId') Is Null begin create index [IX_ScoreImports_CustomerID] on [ScoreImports]([CustomerID]) end
go
If IndexProperty(Object_Id('CustomerSignatures'), 'IX_CustomerSignatures_CustomerID', 'IndexId') Is Null begin create index [IX_CustomerSignatures_CustomerID] on [CustomerSignatures]([CustomerID]) end
go
If IndexProperty(Object_Id('CustomerLocations'), 'IX_CustomerLocations_CustomerID', 'IndexId') Is Null begin create index [IX_CustomerLocations_CustomerID] on [CustomerLocations]([CustomerID]) end
go
If IndexProperty(Object_Id('CustomerDepartments'), 'IX_CustomerDepartments_CustomerID', 'IndexId') Is Null begin create index [IX_CustomerDepartments_CustomerID] on [CustomerDepartments]([CustomerID]) end
go
If IndexProperty(Object_Id('CustomerPurchases'), 'IX_CustomerPurchases_CustomerID', 'IndexId') Is Null begin create index [IX_CustomerPurchases_CustomerID] on [CustomerPurchases]([CustomerID]) end
go
If IndexProperty(Object_Id('Classes'), 'IX_Classes_CustomerID', 'IndexId') Is Null begin create index [IX_Classes_CustomerID] on [Classes]([CustomerID]) end
go
If IndexProperty(Object_Id('CustomerCreditCards'), 'IX_CustomerCreditCards_CustomerID', 'IndexId') Is Null begin create index [IX_CustomerCreditCards_CustomerID] on [CustomerCreditCards]([CustomerID]) end
go
If IndexProperty(Object_Id('PermissionGroups'), 'IX_PermissionGroups_CustomerID', 'IndexId') Is Null begin create index [IX_PermissionGroups_CustomerID] on [PermissionGroups]([CustomerID]) end
go
If IndexProperty(Object_Id('InjuryIncidentVersions'), 'IX_InjuryIncidentVersions_LocationID', 'IndexId') Is Null begin create index [IX_InjuryIncidentVersions_LocationID] on [InjuryIncidentVersions]([LocationID]) end
go

go
/****************************************
 * db0044_ScheduledClassAssignments.sql *
 ****************************************/
CREATE TABLE [ScheduledClassAssignments](
	[ScheduledAssignmentID] [int] IDENTITY(1,1) NOT NULL,
	[CustomerID] [int] NOT NULL,
	[ClassName] [nvarchar](100) NOT NULL,
	[AssignmentDate] [date] NOT NULL,
	[DueDate] [date] NOT NULL,
	[Locations] [nvarchar](max) NOT NULL,
	[Departments] [nvarchar](max) NOT NULL,
	[IsComplete] [bit] NOT NULL,
	[CreatedScheduledUserClasses] [bit] NOT NULL,
	[FailureCount] [int] NOT NULL,
	[IsDeleted] [bit] NOT NULL,
	[CreatedByUserID] [int] NOT NULL,
	[WhenCreated] [datetime] NOT NULL,
	[WhenCompleted] [datetime] NULL,
	[LastError] [nvarchar](max) NULL,
	[LastErrorDateTime] [datetime] NULL
	CONSTRAINT [PK_ScheduledClassAssignments] PRIMARY KEY CLUSTERED ([ScheduledAssignmentID])
) ON [PRIMARY]
GO

ALTER TABLE [ScheduledClassAssignments]  WITH CHECK ADD  CONSTRAINT [FK_ScheduledClassAssignments_Customers] FOREIGN KEY([CustomerID])
REFERENCES [Customers] ([CustomerID])
GO

ALTER TABLE [ScheduledClassAssignments] CHECK CONSTRAINT [FK_ScheduledClassAssignments_Customers]
GO

ALTER TABLE [ScheduledClassAssignments]  WITH CHECK ADD  CONSTRAINT [FK_ScheduledClassAssignments_Users] FOREIGN KEY([CreatedByUserID])
REFERENCES [Users] ([UserID])
GO

ALTER TABLE [ScheduledClassAssignments] CHECK CONSTRAINT [FK_ScheduledClassAssignments_Users]
GO

CREATE TABLE [ScheduledUserClasses](
	[ScheduledUserClassID] [int] IDENTITY(1,1) NOT NULL,
	[ScheduledClassAssignmentID] [int] NOT NULL,
	[ClassID] [int] NOT NULL,
	[UserID] [int] NOT NULL,
	[DueDate] [date] NOT NULL,
	[WhenCreated] [datetime] NOT NULL,
	[WhenCompleted] [datetime] NULL,
	[UserClassID] [int] NULL,
	CONSTRAINT [PK_ScheduledUserClasses] PRIMARY KEY CLUSTERED ([ScheduledUserClassID])
) ON [PRIMARY]
GO

ALTER TABLE [ScheduledUserClasses]  WITH CHECK ADD  CONSTRAINT [FK_ScheduledUserClasses_Classes] FOREIGN KEY([ClassID])
REFERENCES [Classes] ([ClassID])
GO

ALTER TABLE [ScheduledUserClasses] CHECK CONSTRAINT [FK_ScheduledUserClasses_Classes]
GO

ALTER TABLE [ScheduledUserClasses]  WITH CHECK ADD  CONSTRAINT [FK_ScheduledUserClasses_ScheduledClassAssignments] FOREIGN KEY([ScheduledClassAssignmentID])
REFERENCES [ScheduledClassAssignments] ([ScheduledAssignmentID])
GO

ALTER TABLE [ScheduledUserClasses] CHECK CONSTRAINT [FK_ScheduledUserClasses_ScheduledClassAssignments]
GO

ALTER TABLE [ScheduledUserClasses]  WITH CHECK ADD  CONSTRAINT [FK_ScheduledUserClasses_UserClasses] FOREIGN KEY([UserClassID])
REFERENCES [UserClasses] ([UserClassID])
GO

ALTER TABLE [ScheduledUserClasses] CHECK CONSTRAINT [FK_ScheduledUserClasses_UserClasses]
GO

ALTER TABLE [ScheduledUserClasses]  WITH CHECK ADD  CONSTRAINT [FK_ScheduledUserClasses_Users] FOREIGN KEY([UserID])
REFERENCES [Users] ([UserID])
GO

ALTER TABLE [ScheduledUserClasses] CHECK CONSTRAINT [FK_ScheduledUserClasses_Users]
GO

CREATE NONCLUSTERED INDEX [IX_ScheduledClassAssignments] ON [ScheduledUserClasses] ([ScheduledClassAssignmentID])
GO


go
/*************************
 * db0045_AudioFiles.sql *
 *************************/
alter table [ClassQuestions] add [AudioFileName] [nvarchar](50) null,
	[OriginalAudioFileName] [nvarchar](50) null
alter table [UserClassQuestions] add [AudioFileName] [nvarchar](50) null
go
alter table [ClassAnswers] add [AudioFileName] [nvarchar](50) null,
	[OriginalAudioFileName] [nvarchar](50) null
alter table [UserClassAnswers] add [AudioFileName] [nvarchar](50) null
go
alter table [ClassQuestions] add [FullAudioFileName] [nvarchar](50) null,
	[OriginalFullAudioFileName] [nvarchar](50) null
go


go
/************************
 * db0046_Documents.sql *
 ************************/
create table [Documents] (
	[DocumentID] [int] not null identity(1,1),
	[CustomerID] [int] null CONSTRAINT [FK_Document_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[UserID] [int] null CONSTRAINT [FK_Document_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[Name] [nvarchar](100) not null,
	[Description] [ntext] null,
	[FileName] [nvarchar](50) null,
	[OriginalName] [nvarchar](100) null,
	[IsRestricted] [bit] not null,
	[LastUpateDateTime] [datetime] not null,
	[IsDeleted] [bit] not null
	constraint [pkDocuments] primary key clustered ([DocumentID])	 
) on [primary]
go


go
/********************
 * db0047_Notes.sql *
 ********************/
create table [Notes] (
	[NoteID] [int] not null identity(1,1),
	[CustomerID] [int] null CONSTRAINT [FK_Note_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[UserID] [int] null CONSTRAINT [FK_Note_User] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[Text] [ntext] null,
	[LastUpateDateTime] [datetime] not null,
	[LastUpdateByUserID] [int] not null CONSTRAINT [FK_Note_LastUpdateByUser] FOREIGN KEY REFERENCES [Users] ([UserID]),
	[IsDeleted] [bit] not null
	constraint [pkNotes] primary key clustered ([NoteID])	 
) on [primary]
go


go
/*******************************
 * db0048_EnterpriseLevels.sql *
 *******************************/
alter table [Customers] add [EnterpriseLevel] [int] not null default(0)
go

update [Customers] set [EnterpriseLevel] = 1
go

create table [AvailableClasses] (
	[CustomerID] [int] not null CONSTRAINT [FK_AvailableClass_Customer] FOREIGN KEY REFERENCES [Customers] ([CustomerID]),
	[ClassID] [int] not null CONSTRAINT [FK_AvailableClass_Class] FOREIGN KEY REFERENCES [Classes] ([ClassID])
	constraint [pkAvailableClasses] primary key clustered ([CustomerID], [ClassID])	 
) on [primary]
go


go
/*******************************
 * db0049_EULAandHelpFiles.sql *
 *******************************/
alter table [ConfigurationOptions] add [EULAFileName] [nvarchar](50) null
alter table [ConfigurationOptions] add [OriginalEULAFileName] [nvarchar](100) null
alter table [ConfigurationOptions] add [HelpFileName] [nvarchar](50) null
alter table [ConfigurationOptions] add [OriginalHelpFileName] [nvarchar](100) null
go


go
/**************************************
 * db0050_GDWCertificateSignature.sql *
 **************************************/
alter table [ConfigurationOptions] add [CertificateLogoFileName] [nvarchar](50) null
alter table [ConfigurationOptions] add [OriginalCertificateLogoFileName] [nvarchar](100) null
alter table [ConfigurationOptions] add [CertificateSignatureName] [nvarchar](100) null
alter table [ConfigurationOptions] add [CertificateSignatureTitle] [nvarchar](100) null
alter table [ConfigurationOptions] add [CertificateSignatureImageFileName] [nvarchar](50) null
alter table [ConfigurationOptions] add [OriginalCertificateSignatureImageFileName] [nvarchar](100) null
go


/***************************
 * db0051_ScormClasses.sql *
 ***************************/
create table [ScormClasses] (
    [ScormClassID] [int] not null identity(1,1),
    [ClassHandle] [nvarchar](200) null,
    [ScormProvider] [nvarchar](50) not null,
    [IsDeleted] bit not null,
    constraint [pkScormClasses] primary key clustered ([ScormClassID])
) on [primary]
go

-- ClassType enum definition:
-- 0: Video
-- 1: Scorm file
-- 2: PDF
alter table [ClassVersions] add
    [ClassType] [int] not null default(0),
    [ScormClassID] [int] null CONSTRAINT [FK_ClassVersion_ScormClass] FOREIGN KEY REFERENCES [ScormClasses] ([ScormClassID])
go

update [ClassVersions]
    set [ClassType] = 2
    where [IsVideo] = 0
go

alter table [ClassVersions]
    drop column [IsVideo]
go

alter table [UserClassVersions] add
    [ClassType] [int] not null default(0),
    [ScormClassID] [int] null CONSTRAINT [FK_UserClassVersion_ScormClass] FOREIGN KEY REFERENCES [ScormClasses] ([ScormClassID])
go

update [UserClassVersions]
    set [ClassType] = 2
    where [IsVideo] = 0
go

alter table [UserClassVersions]
    drop column [IsVideo]
go


go
