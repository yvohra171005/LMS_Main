alter table [ConfigurationOptions] add [CertificateLogoFileName] [nvarchar](50) null
alter table [ConfigurationOptions] add [OriginalCertificateLogoFileName] [nvarchar](100) null
alter table [ConfigurationOptions] add [CertificateSignatureName] [nvarchar](100) null
alter table [ConfigurationOptions] add [CertificateSignatureTitle] [nvarchar](100) null
alter table [ConfigurationOptions] add [CertificateSignatureImageFileName] [nvarchar](50) null
alter table [ConfigurationOptions] add [OriginalCertificateSignatureImageFileName] [nvarchar](100) null
go
