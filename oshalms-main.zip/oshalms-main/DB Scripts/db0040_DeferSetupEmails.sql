alter table [Users] add [SetupEmailSent] [bit] not null constraint [defIsSent] default(1)
alter table [Users] drop constraint [defIsSent]
go
