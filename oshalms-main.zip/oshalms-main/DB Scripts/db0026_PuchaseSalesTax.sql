alter table CustomerPurchases add [SalesTax] [money] not null constraint [defSalesTax] default(0)
alter table CustomerPurchases drop constraint [defSalesTax]
go
