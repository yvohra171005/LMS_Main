If IndexProperty(Object_Id('ClassVersions'), 'IX_ClassVersions_VideoID', 'IndexId') Is Null begin create index [IX_ClassVersions_VideoID] on [ClassVersions]([VideoID]) end
go
If IndexProperty(Object_Id('UserClassVersions'), 'IX_UserClassVersions_VideoID', 'IndexId') Is Null begin create index [IX_UserClassVersions_VideoID] on [UserClassVersions]([VideoID]) end
go
If IndexProperty(Object_Id('UserDashboardWidgets'), 'IX_UserDashboardWidgets_UserID', 'IndexId') Is Null begin create index [IX_UserDashboardWidgets_UserID] on [UserDashboardWidgets]([UserID]) end
go
If IndexProperty(Object_Id('ClassFAQs'), 'IX_ClassFAQs_AskUserID', 'IndexId') Is Null begin create index [IX_ClassFAQs_AskUserID] on [ClassFAQs]([AskUserID]) end
go
If IndexProperty(Object_Id('ClassFAQs'), 'IX_ClassFAQs_AnswerUserID', 'IndexId') Is Null begin create index [IX_ClassFAQs_AnswerUserID] on [ClassFAQs]([AnswerUserID]) end
go
If IndexProperty(Object_Id('CustomerAccountChanges'), 'IX_CustomerAccountChanges_UserID', 'IndexId') Is Null begin create index [IX_CustomerAccountChanges_UserID] on [CustomerAccountChanges]([UserID]) end
go
If IndexProperty(Object_Id('CustomerReclaimClasses'), 'IX_CustomerReclaimClasses_UserID', 'IndexId') Is Null begin create index [IX_CustomerReclaimClasses_UserID] on [CustomerReclaimClasses]([UserID]) end
go
If IndexProperty(Object_Id('CustomerReclaimClasses'), 'IX_CustomerReclaimClasses_EmployeeID', 'IndexId') Is Null begin create index [IX_CustomerReclaimClasses_EmployeeID] on [CustomerReclaimClasses]([EmployeeID]) end
go
If IndexProperty(Object_Id('ClassScreenings'), 'IX_ClassScreenings_UserID', 'IndexId') Is Null begin create index [IX_ClassScreenings_UserID] on [ClassScreenings]([UserID]) end
go
If IndexProperty(Object_Id('ResetEmails'), 'IX_ResetEmails_UserID', 'IndexId') Is Null begin create index [IX_ResetEmails_UserID] on [ResetEmails]([UserID]) end
go
If IndexProperty(Object_Id('InjuryIncidentVersions'), 'IX_InjuryIncidentVersions_EnteredByUserID', 'IndexId') Is Null begin create index [IX_InjuryIncidentVersions_EnteredByUserID] on [InjuryIncidentVersions]([EnteredByUserID]) end
go
If IndexProperty(Object_Id('InjuryIncidentVersions'), 'IX_InjuryIncidentVersions_InjuredUserID', 'IndexId') Is Null begin create index [IX_InjuryIncidentVersions_InjuredUserID] on [InjuryIncidentVersions]([InjuredUserID]) end
go
If IndexProperty(Object_Id('UserClasses'), 'IX_UserClasses_UserID', 'IndexId') Is Null begin create index [IX_UserClasses_UserID] on [UserClasses]([UserID]) end
go
If IndexProperty(Object_Id('ScoreImports'), 'IX_ScoreImports_UserID', 'IndexId') Is Null begin create index [IX_ScoreImports_UserID] on [ScoreImports]([UserID]) end
go
If IndexProperty(Object_Id('Notifications'), 'IX_Notifications_UserID', 'IndexId') Is Null begin create index [IX_Notifications_UserID] on [Notifications]([UserID]) end
go
If IndexProperty(Object_Id('UserLoginActivity'), 'IX_UserLoginActivity_UserID', 'IndexId') Is Null begin create index [IX_UserLoginActivity_UserID] on [UserLoginActivity]([UserID]) end
go
If IndexProperty(Object_Id('Users'), 'IX_Users_LanguageID', 'IndexId') Is Null begin create index [IX_Users_LanguageID] on [Users]([LanguageID]) end
go
If IndexProperty(Object_Id('ClassVersions'), 'IX_ClassVersions_LanguageID', 'IndexId') Is Null begin create index [IX_ClassVersions_LanguageID] on [ClassVersions]([LanguageID]) end
go
If IndexProperty(Object_Id('UserClassVersions'), 'IX_UserClassVersions_LanguageID', 'IndexId') Is Null begin create index [IX_UserClassVersions_LanguageID] on [UserClassVersions]([LanguageID]) end
go
If IndexProperty(Object_Id('UserClasses'), 'IX_UserClasses_PrefLanguageID', 'IndexId') Is Null begin create index [IX_UserClasses_PrefLanguageID] on [UserClasses]([PrefLanguageID]) end
go
If IndexProperty(Object_Id('ConfigurationOptions'), 'IX_ConfigurationOptions_DefaultPermissionGroupID', 'IndexId') Is Null begin create index [IX_ConfigurationOptions_DefaultPermissionGroupID] on [ConfigurationOptions]([DefaultPermissionGroupID]) end
go
If IndexProperty(Object_Id('InjuryIncidentVersions'), 'IX_InjuryIncidentVersions_IncidentID', 'IndexId') Is Null begin create index [IX_InjuryIncidentVersions_IncidentID] on [InjuryIncidentVersions]([IncidentID]) end
go
If IndexProperty(Object_Id('ClassFAQs'), 'IX_ClassFAQs_ClassID', 'IndexId') Is Null begin create index [IX_ClassFAQs_ClassID] on [ClassFAQs]([ClassID]) end
go
If IndexProperty(Object_Id('CustomerReclaimClasses'), 'IX_CustomerReclaimClasses_ClassID', 'IndexId') Is Null begin create index [IX_CustomerReclaimClasses_ClassID] on [CustomerReclaimClasses]([ClassID]) end
go
If IndexProperty(Object_Id('ClassScreenings'), 'IX_ClassScreenings_ClassID', 'IndexId') Is Null begin create index [IX_ClassScreenings_ClassID] on [ClassScreenings]([ClassID]) end
go
If IndexProperty(Object_Id('ClassVersions'), 'IX_ClassVersions_ClassID', 'IndexId') Is Null begin create index [IX_ClassVersions_ClassID] on [ClassVersions]([ClassID]) end
go
If IndexProperty(Object_Id('UserClasses'), 'IX_UserClasses_ClassID', 'IndexId') Is Null begin create index [IX_UserClasses_ClassID] on [UserClasses]([ClassID]) end
go
If IndexProperty(Object_Id('ScoreImports'), 'IX_ScoreImports_ClassID', 'IndexId') Is Null begin create index [IX_ScoreImports_ClassID] on [ScoreImports]([ClassID]) end
go
If IndexProperty(Object_Id('ClassVersionSafetyDocuments'), 'IX_ClassVersionSafetyDocuments_VersionID', 'IndexId') Is Null begin create index [IX_ClassVersionSafetyDocuments_VersionID] on [ClassVersionSafetyDocuments]([VersionID]) end
go
If IndexProperty(Object_Id('ClassVersionDocuments'), 'IX_ClassVersionDocuments_VersionID', 'IndexId') Is Null begin create index [IX_ClassVersionDocuments_VersionID] on [ClassVersionDocuments]([VersionID]) end
go
If IndexProperty(Object_Id('ClassQuestions'), 'IX_ClassQuestions_VersionID', 'IndexId') Is Null begin create index [IX_ClassQuestions_VersionID] on [ClassQuestions]([VersionID]) end
go
If IndexProperty(Object_Id('CustomerPurchases'), 'IX_CustomerPurchases_DiscountCodeID', 'IndexId') Is Null begin create index [IX_CustomerPurchases_DiscountCodeID] on [CustomerPurchases]([DiscountCodeID]) end
go
If IndexProperty(Object_Id('ClassAnswers'), 'IX_ClassAnswers_QuestionID', 'IndexId') Is Null begin create index [IX_ClassAnswers_QuestionID] on [ClassAnswers]([QuestionID]) end
go
If IndexProperty(Object_Id('UserClassActivity'), 'IX_UserClassActivity_UserClassID', 'IndexId') Is Null begin create index [IX_UserClassActivity_UserClassID] on [UserClassActivity]([UserClassID]) end
go
If IndexProperty(Object_Id('UserClassVersions'), 'IX_UserClassVersions_UserClassID', 'IndexId') Is Null begin create index [IX_UserClassVersions_UserClassID] on [UserClassVersions]([UserClassID]) end
go
If IndexProperty(Object_Id('UserTests'), 'IX_UserTests_UserClassID', 'IndexId') Is Null begin create index [IX_UserTests_UserClassID] on [UserTests]([UserClassID]) end
go
If IndexProperty(Object_Id('UserClassVersionDocuments'), 'IX_UserClassVersionDocuments_VersionID', 'IndexId') Is Null begin create index [IX_UserClassVersionDocuments_VersionID] on [UserClassVersionDocuments]([VersionID]) end
go
If IndexProperty(Object_Id('UserClassQuestions'), 'IX_UserClassQuestions_VersionID', 'IndexId') Is Null begin create index [IX_UserClassQuestions_VersionID] on [UserClassQuestions]([VersionID]) end
go
If IndexProperty(Object_Id('UserTestQuestions'), 'IX_UserTestQuestions_QuestionID', 'IndexId') Is Null begin create index [IX_UserTestQuestions_QuestionID] on [UserTestQuestions]([QuestionID]) end
go
If IndexProperty(Object_Id('UserClassAnswers'), 'IX_UserClassAnswers_QuestionID', 'IndexId') Is Null begin create index [IX_UserClassAnswers_QuestionID] on [UserClassAnswers]([QuestionID]) end
go
If IndexProperty(Object_Id('UserTestAnswers'), 'IX_UserTestAnswers_AnswerID', 'IndexId') Is Null begin create index [IX_UserTestAnswers_AnswerID] on [UserTestAnswers]([AnswerID]) end
go
If IndexProperty(Object_Id('UserTestQuestions'), 'IX_UserTestQuestions_TestID', 'IndexId') Is Null begin create index [IX_UserTestQuestions_TestID] on [UserTestQuestions]([TestID]) end
go
If IndexProperty(Object_Id('UserTestAnswers'), 'IX_UserTestAnswers_TQuestionID', 'IndexId') Is Null begin create index [IX_UserTestAnswers_TQuestionID] on [UserTestAnswers]([TQuestionID]) end
go
If IndexProperty(Object_Id('NotificationParameters'), 'IX_NotificationParameters_NotificationID', 'IndexId') Is Null begin create index [IX_NotificationParameters_NotificationID] on [NotificationParameters]([NotificationID]) end
go
If IndexProperty(Object_Id('CustomerAccountChanges'), 'IX_CustomerAccountChanges_CustomerID', 'IndexId') Is Null begin create index [IX_CustomerAccountChanges_CustomerID] on [CustomerAccountChanges]([CustomerID]) end
go
If IndexProperty(Object_Id('InjuryIncidents'), 'IX_InjuryIncidents_CustomerID', 'IndexId') Is Null begin create index [IX_InjuryIncidents_CustomerID] on [InjuryIncidents]([CustomerID]) end
go
If IndexProperty(Object_Id('ScoreImports'), 'IX_ScoreImports_CustomerID', 'IndexId') Is Null begin create index [IX_ScoreImports_CustomerID] on [ScoreImports]([CustomerID]) end
go
If IndexProperty(Object_Id('CustomerSignatures'), 'IX_CustomerSignatures_CustomerID', 'IndexId') Is Null begin create index [IX_CustomerSignatures_CustomerID] on [CustomerSignatures]([CustomerID]) end
go
If IndexProperty(Object_Id('CustomerLocations'), 'IX_CustomerLocations_CustomerID', 'IndexId') Is Null begin create index [IX_CustomerLocations_CustomerID] on [CustomerLocations]([CustomerID]) end
go
If IndexProperty(Object_Id('CustomerDepartments'), 'IX_CustomerDepartments_CustomerID', 'IndexId') Is Null begin create index [IX_CustomerDepartments_CustomerID] on [CustomerDepartments]([CustomerID]) end
go
If IndexProperty(Object_Id('CustomerPurchases'), 'IX_CustomerPurchases_CustomerID', 'IndexId') Is Null begin create index [IX_CustomerPurchases_CustomerID] on [CustomerPurchases]([CustomerID]) end
go
If IndexProperty(Object_Id('Classes'), 'IX_Classes_CustomerID', 'IndexId') Is Null begin create index [IX_Classes_CustomerID] on [Classes]([CustomerID]) end
go
If IndexProperty(Object_Id('CustomerCreditCards'), 'IX_CustomerCreditCards_CustomerID', 'IndexId') Is Null begin create index [IX_CustomerCreditCards_CustomerID] on [CustomerCreditCards]([CustomerID]) end
go
If IndexProperty(Object_Id('PermissionGroups'), 'IX_PermissionGroups_CustomerID', 'IndexId') Is Null begin create index [IX_PermissionGroups_CustomerID] on [PermissionGroups]([CustomerID]) end
go
If IndexProperty(Object_Id('InjuryIncidentVersions'), 'IX_InjuryIncidentVersions_LocationID', 'IndexId') Is Null begin create index [IX_InjuryIncidentVersions_LocationID] on [InjuryIncidentVersions]([LocationID]) end
go